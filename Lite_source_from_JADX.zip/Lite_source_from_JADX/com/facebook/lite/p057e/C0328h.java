package com.facebook.lite.p057e;

import java.util.List;

/* renamed from: com.facebook.lite.e.h */
public final class C0328h {
    final List f1287a;
    final List f1288b;
    final List f1289c;
    final List f1290d;
    final byte f1291e;
    final String f1292f;
    final long f1293g;
    final /* synthetic */ C0329i f1294h;

    public C0328h(C0329i c0329i, long j, String str, List list, List list2, List list3, List list4, byte b) {
        this.f1294h = c0329i;
        this.f1293g = j;
        this.f1292f = str;
        this.f1288b = list;
        this.f1289c = list2;
        this.f1287a = list3;
        this.f1290d = list4;
        this.f1291e = b;
    }

    public final List m2283a() {
        return this.f1287a;
    }

    public final List m2284b() {
        return this.f1288b;
    }

    public final List m2285c() {
        return this.f1289c;
    }

    public final List m2286d() {
        return this.f1290d;
    }

    public final byte m2287e() {
        return this.f1291e;
    }

    public final String m2288f() {
        return this.f1292f;
    }

    public final long m2289g() {
        return this.f1293g;
    }
}
