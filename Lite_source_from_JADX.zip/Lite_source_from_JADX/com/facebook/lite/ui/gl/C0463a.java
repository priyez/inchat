package com.facebook.lite.ui.gl;

/* renamed from: com.facebook.lite.ui.gl.a */
public final class C0463a extends RuntimeException {
    private final int f1835a;

    public C0463a(int i) {
        super("EGL Error: " + i);
        this.f1835a = i;
    }

    public final int m3127a() {
        return this.f1835a;
    }
}
