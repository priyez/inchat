package com.facebook.lite.p062j;

/* renamed from: com.facebook.lite.j.k */
final class C0363k implements C0358i {
    final /* synthetic */ C0366n f1421a;

    private C0363k(C0366n c0366n) {
        this.f1421a = c0366n;
    }

    public final String m2528a(StringBuilder stringBuilder) {
        stringBuilder.append("Render: ");
        stringBuilder.append(this.f1421a.f1426c.m2522b());
        return stringBuilder.toString();
    }
}
