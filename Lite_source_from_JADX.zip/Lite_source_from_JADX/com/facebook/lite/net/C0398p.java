package com.facebook.lite.net;

import com.p008a.p009a.p010a.p023m.C0115e;
import java.io.IOException;
import java.io.OutputStream;

/* renamed from: com.facebook.lite.net.p */
public class C0398p extends Thread {
    private final OutputStream f1596a;
    final /* synthetic */ C0400q f1597b;
    private Thread f1598c;

    public C0398p(C0400q c0400q, OutputStream outputStream) {
        this.f1597b = c0400q;
        this.f1596a = outputStream;
    }

    public void run() {
        this.f1598c = Thread.currentThread();
        while (this.f1597b.m2832a(this.f1598c)) {
            synchronized (this.f1597b.p) {
                if (this.f1597b.m2785l() || this.f1597b.m2787n()) {
                    try {
                        this.f1597b.p.wait();
                    } catch (InterruptedException e) {
                    }
                }
            }
            if (this.f1597b.m2832a(this.f1598c) && !this.f1597b.m2785l()) {
                m2790a();
                synchronized (this.f1597b.f1614u) {
                    this.f1597b.f1617x = System.currentTimeMillis() + ((long) this.f1597b.f1615v);
                }
            }
        }
        try {
            this.f1596a.close();
        } catch (IOException e2) {
            new StringBuilder("conn/send/run/").append(e2.toString());
        }
    }

    protected void m2791a(C0115e c0115e) {
        this.f1596a.write(c0115e.m1137a(), c0115e.m1128n(), c0115e.m1129o());
        this.f1596a.flush();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m2790a() {
        /*
        r8 = this;
    L_0x0000:
        r0 = r8.f1597b;
        r0 = r0.m2784k();
        if (r0 == 0) goto L_0x00c4;
    L_0x0008:
        r1 = r8.f1597b;	 Catch:{ Throwable -> 0x0077 }
        r1 = r1.p;	 Catch:{ Throwable -> 0x0077 }
        monitor-enter(r1);	 Catch:{ Throwable -> 0x0077 }
        r2 = new java.lang.StringBuilder;	 Catch:{ all -> 0x00be }
        r3 = "conn/sendmsg:";
        r2.<init>(r3);	 Catch:{ all -> 0x00be }
        r3 = com.facebook.lite.net.C0397b.m2757c(r0);	 Catch:{ all -> 0x00be }
        r2 = r2.append(r3);	 Catch:{ all -> 0x00be }
        r3 = "/ID:";
        r2 = r2.append(r3);	 Catch:{ all -> 0x00be }
        r3 = com.facebook.lite.net.C0397b.m2755b(r0);	 Catch:{ all -> 0x00be }
        r2.append(r3);	 Catch:{ all -> 0x00be }
        monitor-exit(r1);	 Catch:{ all -> 0x00be }
        r8.m2791a(r0);	 Catch:{ Throwable -> 0x0077 }
        r0 = r8.f1597b;	 Catch:{ Throwable -> 0x0077 }
        r0 = r0.f1606F;	 Catch:{ Throwable -> 0x0077 }
        if (r0 != 0) goto L_0x0000;
    L_0x0035:
        r0 = r8.f1597b;	 Catch:{ Throwable -> 0x0077 }
        r1 = r0.f1616w;	 Catch:{ Throwable -> 0x0077 }
        monitor-enter(r1);	 Catch:{ Throwable -> 0x0077 }
        r0 = r8.f1597b;	 Catch:{ all -> 0x0074 }
        r0 = r0.f1606F;	 Catch:{ all -> 0x0074 }
        if (r0 != 0) goto L_0x0072;
    L_0x0044:
        r0 = r8.f1597b;	 Catch:{ all -> 0x0074 }
        r0 = r0.n;	 Catch:{ all -> 0x0074 }
        r2 = 55;
        r0 = r0.m365c(r2);	 Catch:{ all -> 0x0074 }
        if (r0 != 0) goto L_0x0057;
    L_0x0050:
        r2 = 60000; // 0xea60 float:8.4078E-41 double:2.9644E-319;
        r0 = java.lang.Long.valueOf(r2);	 Catch:{ all -> 0x0074 }
    L_0x0057:
        r2 = r8.f1597b;	 Catch:{ all -> 0x0074 }
        r3 = r8.f1597b;	 Catch:{ all -> 0x0074 }
        r3 = r3.q;	 Catch:{ all -> 0x0074 }
        r4 = r8.f1597b;	 Catch:{ all -> 0x0074 }
        r4 = r4.f1612r;	 Catch:{ all -> 0x0074 }
        r6 = r0.longValue();	 Catch:{ all -> 0x0074 }
        r0 = r3.m110a(r4, r6);	 Catch:{ all -> 0x0074 }
        r2.f1609I = r0;	 Catch:{ all -> 0x0074 }
        r0 = r8.f1597b;	 Catch:{ all -> 0x0074 }
        r2 = 1;
        r0.f1606F = r2;	 Catch:{ all -> 0x0074 }
    L_0x0072:
        monitor-exit(r1);	 Catch:{ all -> 0x0074 }
        goto L_0x0000;
    L_0x0074:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0074 }
        throw r0;	 Catch:{ Throwable -> 0x0077 }
    L_0x0077:
        r0 = move-exception;
        r1 = r0;
        r0 = r8.f1597b;
        r2 = r8.f1598c;
        r0.m2802b(r2);
        r0 = r1 instanceof java.io.InterruptedIOException;
        if (r0 == 0) goto L_0x00c1;
    L_0x0084:
        r0 = "INTERRUPTED";
    L_0x0086:
        r2 = r8.f1597b;
        r2 = r2.g;
        r3 = 3;
        r4 = 65;
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r5 = r5.append(r1);
        r6 = ": ";
        r5 = r5.append(r6);
        r6 = r1.getMessage();
        r5 = r5.append(r6);
        r0 = r5.append(r0);
        r0 = r0.toString();
        r2.m126a(r3, r4, r0);
        r0 = new java.lang.StringBuilder;
        r2 = "conn/sendoutqueuecontent/";
        r0.<init>(r2);
        r1 = r1.toString();
        r0.append(r1);
    L_0x00bd:
        return;
    L_0x00be:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x00be }
        throw r0;	 Catch:{ Throwable -> 0x0077 }
    L_0x00c1:
        r0 = "";
        goto L_0x0086;
    L_0x00c4:
        r0 = r8.f1597b;
        r1 = r0.o;
        monitor-enter(r1);
        r0 = r8.f1597b;	 Catch:{ all -> 0x00d2 }
        r0 = r0.o;	 Catch:{ all -> 0x00d2 }
        r0.notifyAll();	 Catch:{ all -> 0x00d2 }
        monitor-exit(r1);	 Catch:{ all -> 0x00d2 }
        goto L_0x00bd;
    L_0x00d2:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x00d2 }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.net.p.a():void");
    }
}
