package com.facebook.lite.photo;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.p053b.C0300n;
import com.facebook.p038e.p040b.p041a.p042a.p043a.C0216b;
import com.p008a.p009a.p010a.p012b.C0011a;
import com.p008a.p009a.p010a.p023m.C0119g;

/* renamed from: com.facebook.lite.photo.k */
final class C0442k implements Comparable, Runnable {
    final /* synthetic */ C0443l f1768a;
    private final byte[] f1769b;
    private final C0119g f1770c;
    private final int f1771d;
    private final int f1772e;
    private final long f1773f;

    public C0442k(C0443l c0443l, byte[] bArr, int i, int i2, C0119g c0119g, long j) {
        this.f1768a = c0443l;
        this.f1769b = bArr;
        this.f1771d = i;
        this.f1772e = i2;
        this.f1770c = c0119g;
        this.f1773f = j;
    }

    public final int compareTo(Object obj) {
        return 0;
    }

    public final void run() {
        try {
            if (this.f1769b == null || this.f1771d <= 0) {
                this.f1768a.f1778e.m126a((short) 2, (short) 58, "decode image byte array is not valid");
                synchronized (this.f1768a.f1782i) {
                    this.f1768a.f1777d.remove(this.f1770c);
                }
            } else if (this.f1770c.m1189e() < 0) {
                this.f1768a.f1778e.m126a((short) 2, (short) 58, "decode image transparency size less than 0");
                synchronized (this.f1768a.f1782i) {
                    this.f1768a.f1777d.remove(this.f1770c);
                }
            } else {
                boolean b;
                if (this.f1770c.m1189e() > 0) {
                    b = m3020b();
                } else {
                    b = m3019a();
                }
                if (b) {
                    C0443l.f1775b;
                    new StringBuilder("photo/decode decode no transparency image successfully time cost:").append(System.currentTimeMillis() - this.f1773f);
                    ClientApplication.m1691c().m2387S().m2639N().m168a(C0011a.m71a(this.f1772e));
                } else {
                    this.f1768a.f1778e.m124a((short) 283, "decoded image in task failed " + this.f1770c.toString(), new Exception("decode Image Error"));
                    C0443l.f1775b;
                    new StringBuilder("photo/decode decode image failed: ").append(this.f1770c.toString());
                    C0216b.m1527a(this.f1770c.m1186b());
                }
                synchronized (this.f1768a.f1782i) {
                    this.f1768a.f1777d.remove(this.f1770c);
                }
            }
        } catch (Throwable e) {
            this.f1768a.f1778e.m124a((short) 283, "decoded transparency image in task failed " + this.f1770c.toString(), e);
            C0443l.f1775b;
            new StringBuilder("photo/decode decode transparency image failed: ").append(this.f1770c.toString());
            C0216b.m1527a(this.f1770c.m1186b());
            synchronized (this.f1768a.f1782i) {
            }
            this.f1768a.f1777d.remove(this.f1770c);
        } catch (Throwable e2) {
            this.f1768a.f1778e.m124a((short) 282, "decode transparency image find OOM!", e2);
            C0443l.f1775b;
            C0216b.m1527a(this.f1770c.m1186b());
            synchronized (this.f1768a.f1782i) {
            }
            this.f1768a.f1777d.remove(this.f1770c);
        } catch (Throwable th) {
            synchronized (this.f1768a.f1782i) {
            }
            this.f1768a.f1777d.remove(this.f1770c);
        }
    }

    private boolean m3019a() {
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(this.f1769b, 0, this.f1771d);
        if (decodeByteArray == null) {
            decodeByteArray = C0444m.m3040a(this.f1768a.f1776c, this.f1769b, this.f1769b.length, C0300n.m2120d(this.f1768a.f1776c), C0300n.m2102b(this.f1768a.f1776c));
        }
        if (decodeByteArray == null) {
            this.f1768a.f1778e.m126a((short) 2, (short) 58, "decode image from bytes error appController");
            return false;
        }
        Bitmap a = C0443l.m3022a(decodeByteArray, this.f1770c.m1188d(), this.f1770c.m1187c(), this.f1770c.m1191g(), this.f1770c.m1192h(), this.f1770c.m1190f(), this.f1770c.m1185a(), this.f1768a.f1778e);
        if (a != decodeByteArray) {
            decodeByteArray.recycle();
        }
        C0443l.m3026a(this.f1770c, a);
        return true;
    }

    private boolean m3020b() {
        Bitmap a = this.f1768a.m3032a(this.f1769b, this.f1771d);
        if (a == null) {
            this.f1768a.f1778e.m126a((short) 2, (short) 58, "decode image from jpg bytes error imageDecoderManager");
            return false;
        }
        int width = a.getWidth();
        int height = a.getHeight();
        int d = this.f1770c.m1188d();
        int c = this.f1770c.m1187c();
        int g = this.f1770c.m1191g();
        int h = this.f1770c.m1192h();
        int f = this.f1770c.m1190f();
        int a2 = this.f1770c.m1185a();
        int i = this.f1771d;
        int i2 = 255;
        int i3 = 0;
        int i4 = 0;
        while (i4 < height) {
            int i5 = i3;
            i3 = i2;
            i2 = i;
            for (int i6 = 0; i6 < width; i6++) {
                if (i5 <= 0) {
                    if (i2 + 1 < this.f1769b.length) {
                        i = i2 + 1;
                        i3 = (this.f1769b[i2] & 255) << 2;
                    } else {
                        i3 = 0;
                        i = i2;
                    }
                    if ((i3 & -256) != 0) {
                        i2 = i + 1;
                        int length = this.f1769b.length;
                        if (i2 < r0) {
                            i2 = i + 1;
                            i5 = (this.f1769b[i] & 255) - 1;
                            i3 &= 252;
                        } else {
                            i3 = 0;
                            i2 = i;
                        }
                    } else {
                        i2 = i;
                    }
                } else {
                    i5--;
                }
                if (i3 == 0) {
                    a.setPixel(i6, i4, 0);
                } else if (i3 != 252) {
                    a.setPixel(i6, i4, (a.getPixel(i6, i4) & 16777215) | (i3 << 24));
                }
            }
            i4++;
            i = i2;
            i2 = i3;
            i3 = i5;
        }
        Bitmap a3 = C0443l.m3022a(a, d, c, g, h, f, a2, this.f1768a.f1778e);
        if (a != a3) {
            a.recycle();
        }
        C0443l.m3026a(this.f1770c, a3);
        return true;
    }
}
