package com.facebook.lite.webview;

import android.webkit.WebChromeClient;
import android.webkit.WebView;
import com.facebook.lite.MainActivity;

/* renamed from: com.facebook.lite.webview.a */
final class C0466a extends WebChromeClient {
    final /* synthetic */ FbWebView f1853a;

    private C0466a(FbWebView fbWebView) {
        this.f1853a = fbWebView;
    }

    public final void onProgressChanged(WebView webView, int i) {
        MainActivity mainActivity = (MainActivity) this.f1853a.getContext();
        if (i < 100) {
            mainActivity.m1798p();
        } else {
            mainActivity.m1793k();
        }
    }
}
