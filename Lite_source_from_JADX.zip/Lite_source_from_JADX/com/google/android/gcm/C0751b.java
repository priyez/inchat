package com.google.android.gcm;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.os.Build.VERSION;
import android.util.Log;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/* renamed from: com.google.android.gcm.b */
public final class C0751b {
    private static GCMBroadcastReceiver f3203a;
    private static String f3204b;

    public static void m3994a(Context context) {
        int i = VERSION.SDK_INT;
        if (i < 8) {
            throw new UnsupportedOperationException("Device must be at least API Level 8 (instead of " + i + ")");
        }
        try {
            context.getPackageManager().getPackageInfo("com.google.android.gsf", 0);
        } catch (NameNotFoundException e) {
            throw new UnsupportedOperationException("Device does not have package com.google.android.gsf");
        }
    }

    public static void m4000b(Context context) {
        PackageManager packageManager = context.getPackageManager();
        String packageName = context.getPackageName();
        String str = packageName + ".permission.C2D_MESSAGE";
        try {
            packageManager.getPermissionInfo(str, 4096);
            try {
                ActivityInfo[] activityInfoArr = packageManager.getPackageInfo(packageName, 2).receivers;
                if (activityInfoArr == null || activityInfoArr.length == 0) {
                    throw new IllegalStateException("No receiver for package " + packageName);
                }
                if (Log.isLoggable("GCMRegistrar", 2)) {
                    new StringBuilder("number of receivers for ").append(packageName).append(": ").append(activityInfoArr.length);
                }
                Set hashSet = new HashSet();
                for (ActivityInfo activityInfo : activityInfoArr) {
                    if ("com.google.android.c2dm.permission.SEND".equals(activityInfo.permission)) {
                        hashSet.add(activityInfo.name);
                    }
                }
                if (hashSet.isEmpty()) {
                    throw new IllegalStateException("No receiver allowed to receive com.google.android.c2dm.permission.SEND");
                }
                C0751b.m3996a(context, hashSet, "com.google.android.c2dm.intent.REGISTRATION");
                C0751b.m3996a(context, hashSet, "com.google.android.c2dm.intent.RECEIVE");
            } catch (NameNotFoundException e) {
                throw new IllegalStateException("Could not get receivers for package " + packageName);
            }
        } catch (NameNotFoundException e2) {
            throw new IllegalStateException("Application does not define permission " + str);
        }
    }

    private static void m3996a(Context context, Set set, String str) {
        PackageManager packageManager = context.getPackageManager();
        String packageName = context.getPackageName();
        Intent intent = new Intent(str);
        intent.setPackage(packageName);
        List<ResolveInfo> queryBroadcastReceivers = packageManager.queryBroadcastReceivers(intent, 32);
        if (queryBroadcastReceivers.isEmpty()) {
            throw new IllegalStateException("No receivers for action " + str);
        }
        if (Log.isLoggable("GCMRegistrar", 2)) {
            new StringBuilder("Found ").append(queryBroadcastReceivers.size()).append(" receivers for action ").append(str);
        }
        for (ResolveInfo resolveInfo : queryBroadcastReceivers) {
            String str2 = resolveInfo.activityInfo.name;
            if (!set.contains(str2)) {
                throw new IllegalStateException("Receiver " + str2 + " is not set with permission com.google.android.c2dm.permission.SEND");
            }
        }
    }

    public static void m3998a(Context context, String... strArr) {
        C0751b.m4010k(context);
        C0751b.m4001b(context, strArr);
    }

    static void m4001b(Context context, String... strArr) {
        String a = C0751b.m3993a(strArr);
        new StringBuilder("Registering app ").append(context.getPackageName()).append(" of senders ").append(a);
        Intent intent = new Intent("com.google.android.c2dm.intent.REGISTER");
        intent.setPackage("com.google.android.gsf");
        intent.putExtra("app", PendingIntent.getBroadcast(context, 0, new Intent(), 0));
        intent.putExtra("sender", a);
        context.startService(intent);
    }

    static String m3993a(String... strArr) {
        if (strArr == null || strArr.length == 0) {
            throw new IllegalArgumentException("No senderIds");
        }
        StringBuilder stringBuilder = new StringBuilder(strArr[0]);
        for (int i = 1; i < strArr.length; i++) {
            stringBuilder.append(',').append(strArr[i]);
        }
        return stringBuilder.toString();
    }

    public static void m4002c(Context context) {
        C0751b.m4010k(context);
        C0751b.m4004e(context);
    }

    public static synchronized void m4003d(Context context) {
        synchronized (C0751b.class) {
            if (f3203a != null) {
                context.unregisterReceiver(f3203a);
                f3203a = null;
            }
        }
    }

    static void m4004e(Context context) {
        new StringBuilder("Unregistering app ").append(context.getPackageName());
        Intent intent = new Intent("com.google.android.c2dm.intent.UNREGISTER");
        intent.setPackage("com.google.android.gsf");
        intent.putExtra("app", PendingIntent.getBroadcast(context, 0, new Intent(), 0));
        context.startService(intent);
    }

    static synchronized void m4005f(Context context) {
        synchronized (C0751b.class) {
            if (f3203a == null) {
                if (f3204b == null) {
                    Log.e("GCMRegistrar", "internal error: retry receiver class not set yet");
                    f3203a = new GCMBroadcastReceiver();
                } else {
                    try {
                        f3203a = (GCMBroadcastReceiver) Class.forName(f3204b).newInstance();
                    } catch (Exception e) {
                        Log.e("GCMRegistrar", "Could not create instance of " + f3204b + ". Using " + GCMBroadcastReceiver.class.getName() + " directly.");
                        f3203a = new GCMBroadcastReceiver();
                    }
                }
                String packageName = context.getPackageName();
                IntentFilter intentFilter = new IntentFilter("com.google.android.gcm.intent.RETRY");
                intentFilter.addCategory(packageName);
                context.registerReceiver(f3203a, intentFilter, packageName + ".permission.C2D_MESSAGE", null);
            }
        }
    }

    static void m3999a(String str) {
        f3204b = str;
    }

    public static String m4006g(Context context) {
        SharedPreferences o = C0751b.m4014o(context);
        String string = o.getString("regId", "");
        int i = o.getInt("appVersion", Integer.MIN_VALUE);
        int n = C0751b.m4013n(context);
        if (i == Integer.MIN_VALUE || i == n) {
            return string;
        }
        new StringBuilder("App version changed from ").append(i).append(" to ").append(n).append("; resetting registration id");
        C0751b.m4008i(context);
        return "";
    }

    public static boolean m4007h(Context context) {
        return C0751b.m4006g(context).length() > 0;
    }

    static String m4008i(Context context) {
        return C0751b.m3992a(context, "");
    }

    static String m3992a(Context context, String str) {
        SharedPreferences o = C0751b.m4014o(context);
        String string = o.getString("regId", "");
        int n = C0751b.m4013n(context);
        Editor edit = o.edit();
        edit.putString("regId", str);
        edit.putInt("appVersion", n);
        edit.commit();
        return string;
    }

    public static void m3997a(Context context, boolean z) {
        Editor edit = C0751b.m4014o(context).edit();
        edit.putBoolean("onServer", z);
        long m = C0751b.m4012m(context) + System.currentTimeMillis();
        new StringBuilder("Setting registeredOnServer status as ").append(z).append(" until ").append(new Timestamp(m));
        edit.putLong("onServerExpirationTime", m);
        edit.commit();
    }

    public static boolean m4009j(Context context) {
        SharedPreferences o = C0751b.m4014o(context);
        boolean z = o.getBoolean("onServer", false);
        if (z) {
            long j = o.getLong("onServerExpirationTime", -1);
            if (System.currentTimeMillis() > j) {
                new StringBuilder("flag expired on: ").append(new Timestamp(j));
                return false;
            }
        }
        return z;
    }

    private static long m4012m(Context context) {
        return C0751b.m4014o(context).getLong("onServerLifeSpan", 604800000);
    }

    private static int m4013n(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (NameNotFoundException e) {
            throw new RuntimeException("Coult not get package name: " + e);
        }
    }

    static void m4010k(Context context) {
        new StringBuilder("resetting backoff for ").append(context.getPackageName());
        C0751b.m3995a(context, 3000);
    }

    static int m4011l(Context context) {
        return C0751b.m4014o(context).getInt("backoff_ms", 3000);
    }

    static void m3995a(Context context, int i) {
        Editor edit = C0751b.m4014o(context).edit();
        edit.putInt("backoff_ms", i);
        edit.commit();
    }

    private static SharedPreferences m4014o(Context context) {
        return context.getSharedPreferences("com.google.android.gcm", 0);
    }
}
