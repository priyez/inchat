package com.facebook.lite.net;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.HashSet;
import java.util.Set;

public class ConnectivityReceiver extends BroadcastReceiver {
    private static Set f1557a;

    static {
        f1557a = new HashSet();
    }

    public static void m2723a(C0388g c0388g) {
        f1557a.add(c0388g);
    }

    public void onReceive(Context context, Intent intent) {
        if (context != null && intent != null && "android.net.conn.CONNECTIVITY_CHANGE".equals(intent.getAction())) {
            m2722a(context);
        }
    }

    private static void m2722a(Context context) {
        for (C0388g a : f1557a) {
            a.m2716a(context);
        }
    }
}
