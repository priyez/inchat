package com.facebook.p037d;

/* renamed from: com.facebook.d.h */
public interface C0206h {
    void m1511a(C0202d c0202d, C0202d c0202d2, String str);
}
