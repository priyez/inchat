package com.facebook.p031b.p034c;

import com.facebook.p031b.C0148a;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;

/* renamed from: com.facebook.b.c.q */
public final class C0170q implements C0155b {
    private Proxy f645a;

    public C0170q(Proxy proxy) {
        this.f645a = proxy;
    }

    public final HttpURLConnection m1361a(URL url) {
        HttpURLConnection httpURLConnection = (HttpURLConnection) (this.f645a != null ? url.openConnection(this.f645a) : url.openConnection());
        if (httpURLConnection instanceof HttpsURLConnection) {
            try {
                SSLContext instance = SSLContext.getInstance("TLS");
                instance.init(null, new TrustManager[]{new C0168o()}, null);
                SSLSocketFactory socketFactory = instance.getSocketFactory();
                HttpsURLConnection httpsURLConnection = (HttpsURLConnection) httpURLConnection;
                httpsURLConnection.setSSLSocketFactory(socketFactory);
                httpsURLConnection.setHostnameVerifier(new C0169p(this));
            } catch (NoSuchAlgorithmException e) {
            } catch (KeyManagementException e2) {
            }
        }
        return C0170q.m1360a(httpURLConnection);
    }

    private static HttpURLConnection m1360a(HttpURLConnection httpURLConnection) {
        C0148a.m1327a();
        httpURLConnection.setConnectTimeout(3000);
        C0148a.m1327a();
        httpURLConnection.setReadTimeout(3000);
        return httpURLConnection;
    }
}
