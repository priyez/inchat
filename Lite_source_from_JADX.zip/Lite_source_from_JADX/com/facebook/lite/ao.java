package com.facebook.lite;

public final class ao {
    public static final int camera_button = 2130837504;
    public static final int contact_list_image_background = 2130837505;
    public static final int floating_text_box_background = 2130837506;
    public static final int icon_rotate = 2130837507;
    public static final int inline_text_box_dark_background = 2130837508;
    public static final int inline_text_box_light_background = 2130837509;
    public static final int launcher_icon = 2130837510;
    public static final int photo_placeholder_dark = 2130837511;
    public static final int rotate_bg = 2130837512;
    public static final int single_selection_mark = 2130837513;
    public static final int sysnotif_facebook = 2130837514;
    public static final int sysnotif_friend_request = 2130837515;
    public static final int sysnotif_invite = 2130837516;
    public static final int sysnotif_message = 2130837517;
}
