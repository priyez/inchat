package com.facebook.p031b;

import android.app.Application;
import android.net.Uri;
import com.facebook.p031b.p032a.C0147a;

/* renamed from: com.facebook.b.x */
public final class C0193x extends C0147a {
    public C0193x(Application application) {
        super(application);
    }

    public static Uri m1467a(String str) {
        return Uri.parse("https://www.facebook.com/mobile/generic_android_crash_logs/").buildUpon().appendPath(str).build();
    }

    public final boolean m1468d() {
        return true;
    }
}
