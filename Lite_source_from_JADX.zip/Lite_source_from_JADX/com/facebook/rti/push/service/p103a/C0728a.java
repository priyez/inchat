package com.facebook.rti.push.service.p103a;

import android.content.SharedPreferences;
import com.facebook.rti.p046a.p074f.C0527a;
import com.facebook.rti.p078b.p093d.C0619c;

/* renamed from: com.facebook.rti.push.service.a.a */
public class C0728a {
    private static final String f3119a;
    private final C0730c f3120b;
    private final SharedPreferences f3121c;

    static {
        f3119a = C0728a.class.getSimpleName();
    }

    public C0728a(C0730c c0730c, SharedPreferences sharedPreferences) {
        this.f3120b = c0730c;
        this.f3121c = sharedPreferences;
    }

    public final C0619c m3950a() {
        this.f3120b.m3954a();
        C0527a.m3338b(f3119a, "returning shared id %s", m3951b());
        return m3951b();
    }

    public final C0619c m3951b() {
        return new C0619c(this.f3121c.getString("fbns_shared_id", ""), this.f3121c.getString("fbns_shared_secret", ""), this.f3121c.getLong("fbns_shared_timestamp", Long.MAX_VALUE));
    }
}
