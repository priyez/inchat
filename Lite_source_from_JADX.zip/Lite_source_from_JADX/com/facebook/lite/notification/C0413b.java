package com.facebook.lite.notification;

import android.content.Context;
import android.util.Log;

/* renamed from: com.facebook.lite.notification.b */
final class C0413b implements Runnable {
    final /* synthetic */ Context f1689a;
    final /* synthetic */ PushRegistrationBroadcastReceiver f1690b;

    C0413b(PushRegistrationBroadcastReceiver pushRegistrationBroadcastReceiver, Context context) {
        this.f1690b = pushRegistrationBroadcastReceiver;
        this.f1689a = context;
    }

    public final void run() {
        try {
            C0415d.m2919a(this.f1689a);
        } catch (UnsupportedOperationException e) {
            Log.e(PushRegistrationBroadcastReceiver.f1657a, "Fail to register push token. Google play services not found.");
        }
    }
}
