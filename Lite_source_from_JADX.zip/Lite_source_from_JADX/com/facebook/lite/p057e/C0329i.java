package com.facebook.lite.p057e;

import android.content.Context;
import android.os.Build.VERSION;
import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p023m.C0114f;
import java.text.BreakIterator;
import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

/* renamed from: com.facebook.lite.e.i */
public final class C0329i {
    private final C0330j f1295a;
    private final Context f1296b;
    private final C0022b f1297c;

    public C0329i(Context context, C0022b c0022b, String str) {
        this.f1295a = new C0330j(context, c0022b, str);
        this.f1296b = context;
        this.f1297c = c0022b;
    }

    private void m2290a(C0328h c0328h) {
        if (c0328h == null || c0328h.m2284b() == null || c0328h.m2283a() == null || c0328h.m2286d() == null || c0328h.m2285c() == null || c0328h.m2288f() == null) {
            this.f1297c.m126a((short) 2, (short) 287, "table info is not valid in addTable");
            return;
        }
        String str = c0328h.m2288f() + Long.toString(c0328h.m2289g());
        if ((c0328h.m2287e() & 2) == 2) {
            this.f1295a.m2308a(str);
        }
        this.f1295a.m2310a(str, c0328h.m2284b(), c0328h.m2285c());
        List arrayList = new ArrayList();
        for (int i = 0; i < c0328h.m2286d().size(); i++) {
            if ((((Byte) c0328h.m2286d().get(i)).byteValue() & 1) == 1) {
                arrayList.add(Boolean.valueOf(true));
            } else {
                arrayList.add(Boolean.valueOf(false));
            }
        }
        this.f1295a.m2309a(str, c0328h.m2285c(), c0328h.m2283a(), arrayList);
    }

    private void m2291b(C0328h c0328h) {
        if ((c0328h.m2287e() & 1) == 1) {
            m2292c(c0328h);
        }
    }

    private void m2292c(C0328h c0328h) {
        if (c0328h == null || c0328h.m2284b() == null || c0328h.m2283a() == null || c0328h.m2286d() == null || c0328h.m2285c() == null || c0328h.m2288f() == null) {
            this.f1297c.m126a((short) 2, (short) 287, "table info is not valid in addTable");
        } else if (c0328h.m2284b().size() < 2 || c0328h.m2283a().size() < 2) {
            this.f1297c.m126a((short) 2, (short) 287, "entry is not valid in addTable");
        } else {
            List d = c0328h.m2286d();
            List arrayList = new ArrayList();
            String str = c0328h.m2288f() + Long.toString(c0328h.m2289g()) + "_name";
            List asList = Arrays.asList(new String[]{(String) c0328h.m2284b().get(0), (String) c0328h.m2284b().get(1)});
            List asList2 = Arrays.asList(new Byte[]{(Byte) c0328h.m2285c().get(0), (Byte) c0328h.m2285c().get(1)});
            this.f1295a.m2312b(str, asList, asList2, Arrays.asList(new Integer[]{Integer.valueOf(0), Integer.valueOf(1)}));
            BreakIterator wordInstance = BreakIterator.getWordInstance(this.f1296b.getResources().getConfiguration().locale);
            for (int i = 0; i < d.size(); i++) {
                if ((((Byte) d.get(i)).byteValue() & 1) == 1) {
                    String normalize;
                    List list = (List) c0328h.m2283a().get(i);
                    if (VERSION.SDK_INT >= 9) {
                        normalize = Normalizer.normalize((String) list.get(1), Form.NFD);
                    } else {
                        normalize = (String) list.get(1);
                    }
                    wordInstance.setText(normalize);
                    int first = wordInstance.first();
                    for (int next = wordInstance.next(); next != -1; next = wordInstance.next()) {
                        if (!"".equals(normalize.substring(first, next).replaceAll("\\s+", ""))) {
                            arrayList.add(Arrays.asList(new Object[]{list.get(0), normalize.substring(first, next).replaceAll("\\s+", "")}));
                        }
                        first = next;
                    }
                }
            }
            Boolean[] boolArr = new Boolean[arrayList.size()];
            Arrays.fill(boolArr, Boolean.valueOf(true));
            this.f1295a.m2309a(str, asList2, arrayList, new ArrayList(Arrays.asList(boolArr)));
        }
    }

    public final C0328h m2293a(C0114f c0114f) {
        long i = c0114f.m1123i();
        String k = c0114f.m1125k();
        int h = c0114f.m1122h();
        List arrayList = new ArrayList();
        List<Byte> arrayList2 = new ArrayList();
        List arrayList3 = new ArrayList();
        List arrayList4 = new ArrayList();
        for (int i2 = 0; i2 < h; i2++) {
            arrayList.add(c0114f.m1125k());
            arrayList2.add(Byte.valueOf(c0114f.m1121g()));
        }
        int h2 = c0114f.m1122h();
        for (h = 0; h < h2; h++) {
            List arrayList5 = new ArrayList();
            for (Byte b : arrayList2) {
                switch (b.byteValue()) {
                    case (byte) 2:
                        arrayList5.add(Integer.valueOf(c0114f.m1122h()));
                        break;
                    case (byte) 3:
                        arrayList5.add(Long.valueOf(c0114f.m1123i()));
                        break;
                    case (byte) 6:
                        arrayList5.add(c0114f.m1125k());
                        break;
                    default:
                        this.f1297c.m124a((short) 285, null, new IllegalArgumentException("Wrong message type, can't decode message. Should be INTEGER, LONG or STRING, but have" + b));
                        break;
                }
            }
            arrayList3.add(arrayList5);
            arrayList4.add(Byte.valueOf(c0114f.m1121g()));
        }
        return new C0328h(this, i, k, arrayList, arrayList2, arrayList3, arrayList4, Byte.valueOf(c0114f.m1121g()).byteValue());
    }

    public final List m2294a(String str, List list) {
        return this.f1295a.m2306a(str, list);
    }

    public final List m2295a(String str, List list, String str2) {
        if (str == null || list == null || str2 == null || list.size() < 2) {
            this.f1297c.m126a((short) 2, (short) 287, "input parameters invalid in getPrefixSearchFromNameTable");
            return Collections.emptyList();
        }
        List<List> b = this.f1295a.m2311b(str + "_name", Arrays.asList(new Byte[]{(Byte) list.get(0), (Byte) list.get(1)}), str2);
        if (b == null) {
            this.f1297c.m126a((short) 2, (short) 287, "prefix search error in getPrefixSearchFromNameTable");
            return Collections.emptyList();
        }
        List a;
        HashSet hashSet = new HashSet();
        List arrayList = new ArrayList();
        for (List a2 : b) {
            if (a2 == null || a2.get(0) == null) {
                this.f1297c.m126a((short) 2, (short) 287, "friend id be null in getPrefixSearchFromNameTable");
            } else {
                hashSet.add(Long.valueOf(((Long) a2.get(0)).longValue()));
            }
        }
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            a2 = this.f1295a.m2307a(str, list, Long.toString(((Long) it.next()).longValue()));
            if (!a2.isEmpty()) {
                arrayList.add(a2.get(0));
            }
        }
        return arrayList;
    }

    public final void m2296a(C0320a c0320a) {
        C0328h c = c0320a.m2273c();
        m2290a(c);
        m2291b(c);
    }
}
