package com.facebook.rti.push.service;

import android.content.Context;
import android.content.Intent;
import com.facebook.rti.p078b.p080b.p082b.C0551a;
import com.facebook.rti.p078b.p080b.p082b.C0554d;
import org.json.JSONObject;

/* renamed from: com.facebook.rti.push.service.e */
public final class C0735e extends C0551a {
    private final Context f3159a;
    private volatile C0554d f3160b;

    public C0735e(Context context) {
        this.f3159a = context;
        this.f3160b = new C0554d(new JSONObject(), context);
    }

    public final void m3960a() {
        JSONObject jSONObject = new JSONObject();
        m3420a(jSONObject);
        this.f3160b = new C0554d(jSONObject, this.f3159a);
    }

    public final C0554d m3961b() {
        return this.f3160b;
    }

    public final void m3962c() {
        this.f3159a.sendBroadcast(new Intent("com.facebook.rti.mqtt.ACTION_MQTT_CONFIG_CHANGED"));
    }
}
