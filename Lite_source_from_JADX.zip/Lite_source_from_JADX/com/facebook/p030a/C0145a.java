package com.facebook.p030a;

import android.os.Build.VERSION;

/* renamed from: com.facebook.a.a */
public class C0145a {
    public static void m1312a(Throwable th, Throwable th2) {
        if (VERSION.SDK_INT < 19) {
            C0145a.class.getName();
        } else {
            th.addSuppressed(th2);
        }
    }
}
