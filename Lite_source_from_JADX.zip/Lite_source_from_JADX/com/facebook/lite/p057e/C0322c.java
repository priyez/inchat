package com.facebook.lite.p057e;

/* renamed from: com.facebook.lite.e.c */
public final class C0322c {
    public static final int f1273a;
    public static final int f1274b;
    public static final int f1275c;
    private static final /* synthetic */ int[] f1276d;

    static {
        f1273a = 1;
        f1274b = 2;
        f1275c = 3;
        f1276d = new int[]{f1273a, f1274b, f1275c};
    }

    public static int[] m2275a() {
        return (int[]) f1276d.clone();
    }
}
