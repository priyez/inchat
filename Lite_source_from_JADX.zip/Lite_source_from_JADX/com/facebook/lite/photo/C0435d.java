package com.facebook.lite.photo;

import android.database.Cursor;
import android.os.AsyncTask;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/* renamed from: com.facebook.lite.photo.d */
final class C0435d extends AsyncTask {
    final /* synthetic */ AlbumGalleryActivity f1759a;

    private C0435d(AlbumGalleryActivity albumGalleryActivity) {
        this.f1759a = albumGalleryActivity;
    }

    protected final /* synthetic */ Object doInBackground(Object[] objArr) {
        return m3011a();
    }

    protected final /* synthetic */ void onPostExecute(Object obj) {
        m3012a((List) obj);
    }

    private List m3011a() {
        List arrayList = new ArrayList();
        if (this.f1759a.f1727b) {
            this.f1759a.f1730e = new GalleryItem(-1);
            arrayList.add(this.f1759a.f1730e);
        }
        Cursor j = this.f1759a.m2974c();
        ArrayList a = this.f1759a.f1739n.m3067a();
        HashMap hashMap = new HashMap();
        Iterator it = a.iterator();
        while (it.hasNext()) {
            GalleryItem galleryItem = (GalleryItem) it.next();
            hashMap.put(Integer.valueOf(galleryItem.m2991b()), galleryItem);
        }
        if (j != null && j.getCount() > 0) {
            while (j.moveToNext()) {
                Object obj;
                int i = j.getInt(j.getColumnIndex("_id"));
                if (hashMap.containsKey(Integer.valueOf(i))) {
                    obj = (GalleryItem) hashMap.get(Integer.valueOf(i));
                } else {
                    obj = new GalleryItem(i);
                }
                arrayList.add(obj);
            }
        }
        if (j != null) {
            j.close();
        }
        return arrayList;
    }

    private void m3012a(List list) {
        this.f1759a.f1728c = new C0437f(this.f1759a, this.f1759a.getApplicationContext(), list);
        this.f1759a.f1733h.setAdapter(this.f1759a.f1728c);
    }
}
