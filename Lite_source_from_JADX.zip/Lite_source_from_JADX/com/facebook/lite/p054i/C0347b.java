package com.facebook.lite.p054i;

import android.location.Location;

/* renamed from: com.facebook.lite.i.b */
final class C0347b implements Runnable {
    final /* synthetic */ Location f1381a;
    final /* synthetic */ C0351g f1382b;

    C0347b(C0351g c0351g, Location location) {
        this.f1382b = c0351g;
        this.f1381a = location;
    }

    public final void run() {
        if (this.f1382b.f1390e.get()) {
            this.f1382b.f1388c.m2181a(this.f1381a);
        }
    }
}
