package com.facebook.rti.push.service;

import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.IBinder;
import android.os.IDeviceIdleController;
import android.os.IDeviceIdleController.Stub;
import android.os.Looper;
import android.os.PowerManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.facebook.p035c.p036a.C0196c;
import com.facebook.p035c.p036a.C0197d;
import com.facebook.rti.p046a.p047b.C0516d;
import com.facebook.rti.p046a.p069a.C0501e;
import com.facebook.rti.p046a.p069a.C0512p;
import com.facebook.rti.p046a.p071d.C0523a;
import com.facebook.rti.p046a.p074f.C0527a;
import com.facebook.rti.p046a.p075g.C0528c;
import com.facebook.rti.p046a.p076h.C0533c;
import com.facebook.rti.p046a.p076h.C0534d;
import com.facebook.rti.p046a.p077i.C0537c;
import com.facebook.rti.p078b.p080b.p081a.C0539a;
import com.facebook.rti.p078b.p080b.p081a.C0540b;
import com.facebook.rti.p078b.p080b.p081a.C0544f;
import com.facebook.rti.p078b.p080b.p081a.C0545g;
import com.facebook.rti.p078b.p080b.p081a.C0546h;
import com.facebook.rti.p078b.p080b.p082b.C0551a;
import com.facebook.rti.p078b.p080b.p082b.C0553c;
import com.facebook.rti.p078b.p080b.p082b.C0555e;
import com.facebook.rti.p078b.p080b.p082b.C0557g;
import com.facebook.rti.p078b.p080b.p082b.C0558h;
import com.facebook.rti.p078b.p080b.p083c.C0570g;
import com.facebook.rti.p078b.p080b.p083c.C0573o;
import com.facebook.rti.p078b.p080b.p083c.C0578t;
import com.facebook.rti.p078b.p080b.p084d.C0580b;
import com.facebook.rti.p078b.p080b.p084d.C0583e;
import com.facebook.rti.p078b.p080b.p084d.C0584f;
import com.facebook.rti.p078b.p080b.p084d.C0589k;
import com.facebook.rti.p078b.p080b.p086f.C0611e;
import com.facebook.rti.p078b.p080b.p086f.C0612f;
import com.facebook.rti.p078b.p080b.p086f.p090b.C0608a;
import com.facebook.rti.p078b.p080b.p091g.C0614b;
import com.facebook.rti.p078b.p092c.C0616b;
import com.facebook.rti.p078b.p093d.C0618b;
import com.facebook.rti.p078b.p094e.C0620a;
import com.facebook.rti.p078b.p094e.C0623d;
import com.facebook.rti.p078b.p095f.C0624a;
import com.facebook.rti.p078b.p095f.C0628d;
import com.facebook.rti.p078b.p095f.C0629e;
import com.facebook.rti.p078b.p095f.C0645u;
import com.facebook.rti.p078b.p095f.C0646v;
import com.facebook.rti.p078b.p095f.C0650z;
import com.facebook.rti.p078b.p095f.ad;
import com.facebook.rti.p078b.p095f.al;
import com.facebook.rti.p078b.p095f.am;
import com.facebook.rti.p078b.p095f.an;
import com.facebook.rti.p078b.p095f.ao;
import com.facebook.rti.p078b.p095f.ap;
import com.facebook.rti.p078b.p095f.aq;
import com.facebook.rti.p078b.p095f.ar;
import com.facebook.rti.p078b.p095f.at;
import com.facebook.rti.p078b.p096g.C0681b;
import com.facebook.rti.p078b.p096g.C0694c;
import com.facebook.rti.p078b.p096g.C0697e;
import com.facebook.rti.p078b.p096g.p098b.C0669o;
import com.facebook.rti.p078b.p096g.p099c.C0692k;
import com.facebook.rti.p078b.p096g.p099c.C0693l;
import com.facebook.rti.p078b.p101h.C0721c;
import com.facebook.rti.p078b.p102i.C0725c;
import com.facebook.rti.push.service.p103a.C0728a;
import com.facebook.rti.push.service.p103a.C0730c;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import org.json.JSONObject;
import p006c.p007a.C0003a;

public class FbnsService extends al {
    C0746p f3111r;
    protected C0750t f3112s;
    private C0618b f3113t;
    private C0734d f3114u;
    private C0739i f3115v;
    private C0614b f3116w;
    private C0646v f3117x;
    private IDeviceIdleController f3118y;

    public final String m3944d() {
        return "FBNS";
    }

    protected final void m3945e() {
        C0740j c0740j = new C0740j(this);
        C0003a c0741k = new C0741k(this);
        c0741k = new C0742l(this);
        C0614b c0614b = new C0614b(this);
        SharedPreferences a = C0528c.f2215a.m3346a(this, "rti.mqtt.shared_ids");
        C0646v c0646v = new C0646v(this, new C0728a(new C0730c(this, c0614b, a), a));
        C0618b c0618b = new C0618b(this);
        C0551a c0735e = new C0735e(this);
        C0692k c0692k = new C0692k();
        C0693l c0693l = new C0693l();
        Handler handler = new Handler(Looper.getMainLooper());
        C0523a c0523a = new C0523a();
        C0747q.f3190d = c0618b;
        C0747q.f3192f = c0646v;
        C0553c c0553c = new C0553c(this);
        if (!c0553c.m3427c()) {
            C0527a.m3334a();
        }
        C0527a.m3335a(getPackageName());
        aq.f2664x = new C0540b(this);
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService("connectivity");
        aq.f2661u = (AlarmManager) getSystemService("alarm");
        aq.f2665y = (PowerManager) getSystemService("power");
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService("phone");
        aq.f2651k = C0534d.m3354b();
        aq.f2659s = C0533c.m3352b();
        aq.f2660t = new C0558h(this, c0553c, C0646v.m3686b());
        aq.f2649i = new C0589k(this, aq.f2665y);
        aq.f2647g = this;
        aq.f2648h = C0516d.m3313a((Context) this);
        aq.f2642b = new C0583e(connectivityManager, aq.f2647g, aq.f2659s);
        aq.f2666z = new C0584f(aq.f2665y);
        aq.f2639G = new C0580b(this);
        SharedPreferences a2 = C0528c.f2215a.m3347a(this, "rti.mqtt.analytics", true);
        a = C0528c.f2215a.m3347a(this, "rti.mqtt.gk", true);
        SharedPreferences a3 = C0528c.f2215a.m3347a(this, "rti.mqtt.stats", true);
        aq.f2641a = c0646v;
        aq.f2662v = c0735e;
        aq.f2634B = new at(this, aq.f2662v);
        aq.f2635C = new C0624a(this);
        aq.f2636D = new C0629e(a);
        aq.f2638F = new C0628d(a3, aq.f2642b, aq.f2665y, aq.f2639G, ((Boolean) c0741k.m41b()).booleanValue());
        aq.f2662v.m3419a(aq.f2634B);
        aq.f2662v.m3419a(aq.f2635C);
        aq.f2662v.m3419a(aq.f2636D);
        aq.f2662v.m3418a();
        C0501e c0501e = new C0501e(a2, c0553c.m3427c());
        aq.f2644d = new C0512p(this, new am(), c0501e, a2, new an(c0646v), aq.f2660t.m3433a(), c0553c.m3425a(), c0553c.m3426b(), "725056107548211", "0e20c3123a90c76c02c901b7415ff67f");
        aq.f2645e = new C0539a(this, m3606d(), c0501e, aq.f2642b, aq.f2639G, aq.f2644d, aq.f2659s);
        aq.f2646f = new C0546h(this, m3606d(), telephonyManager, aq.f2642b, aq.f2649i, aq.f2659s, aq.f2651k);
        ExecutorService newSingleThreadExecutor = Executors.newSingleThreadExecutor();
        ExecutorService newSingleThreadExecutor2 = Executors.newSingleThreadExecutor();
        ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(2);
        ScheduledExecutorService newScheduledThreadPool = Executors.newScheduledThreadPool(2);
        aq.f2650j = new C0573o();
        aq.f2633A = handler;
        aq.f2658r = new C0570g(aq.f2633A);
        aq.f2663w = new C0578t(m3606d(), this, aq.f2659s, aq.f2661u, aq.f2633A);
        aq.f2657q = new C0620a(aq.f2662v.m3421b().f2394q);
        C0608a c0608a = new C0608a(new C0196c());
        C0611e c0611e = new C0611e(newFixedThreadPool, new C0612f(c0608a, new C0197d()), c0608a);
        C0681b c0681b = new C0681b(this, newSingleThreadExecutor2, new C0697e(), aq.f2666z);
        ar aoVar = new ao();
        aq.f2652l = new ap(c0646v, this, c0618b, c0741k, c0740j, c0741k, c0741k, c0741k, c0611e, newSingleThreadExecutor, newScheduledThreadPool, c0681b, c0693l, c0692k, c0523a, c0741k, aoVar);
        aq.f2653m = new C0721c(aq.f2659s, new C0725c(aq.f2648h, aq.f2649i, aq.f2659s), aq.f2658r, aq.f2663w, aq.f2662v);
        aq.f2654n = new C0650z((C0578t) aq.f2663w, aq.f2645e, aq.f2646f, aq.f2659s);
        aq.f2655o = new C0623d(this, aq.f2657q, aq.f2659s, aq.f2661u, aq.f2633A);
        aq.f2643c = new C0616b(aq.f2645e, aq.f2642b);
        aq.f2640H = new ad(aq.f2658r, aoVar);
        aq.f2656p = new C0645u(this, aq.f2652l, aq.f2653m, c0618b, c0646v, aq.f2654n, aq.f2655o, aq.f2657q, aq.f2645e, aq.f2646f, aq.f2658r, aq.f2659s, aq.f2662v, aq.f2666z, c0692k, c0741k, aq.f2640H, c0741k);
        aq.f2637E = c0614b;
        C0747q.f3187a = new C0750t(C0528c.f2215a.m3346a(this, "rti.mqtt.registrations"), C0528c.f2215a.m3346a(this, "rti.mqtt.fbns_state"), aq.f2651k, new C0553c(this));
        C0747q.f3188b = new C0739i(this, aq.f2661u, aq.f2659s, c0614b);
        C0747q.f3189c = new C0734d(this, aq.f2642b, aq.f2659s, aq.f2644d);
        C0747q.f3191e = aq.f2637E;
    }

    protected final void m3946f() {
        super.m3608f();
        C0750t c0750t = C0747q.f3187a;
        C0618b c0618b = C0747q.f3190d;
        C0734d c0734d = C0747q.f3189c;
        C0739i c0739i = C0747q.f3188b;
        C0614b c0614b = C0747q.f3191e;
        C0646v c0646v = C0747q.f3192f;
        this.f3112s = c0750t;
        this.f3113t = c0618b;
        this.f3114u = c0734d;
        this.f3115v = c0739i;
        this.f3111r = new C0746p();
        this.f3116w = c0614b;
        this.f3117x = c0646v;
        if (VERSION.SDK_INT >= 23 && C0557g.m3431b(this)) {
            try {
                this.f3118y = Stub.asInterface((IBinder) Class.forName("android.os.ServiceManager").getMethod("getService", new Class[]{String.class}).invoke(null, new Object[]{"deviceidle"}));
            } catch (Throwable e) {
                C0527a.m3337a("FbnsService", e, "Failed to get IDeviceIdleController", new Object[0]);
            }
        }
    }

    protected final void m3947g() {
        super.m3609g();
        this.c.m3670a(new C0743m(this));
        this.f3117x.m3691f();
    }

    public final void m3940a(Intent intent) {
        if ("com.facebook.rti.fbns.service.intent.KEEPALIVE".equals(intent.getAction())) {
            m3941a(C0544f.SVC_KEEPALIVE);
        } else if ("com.facebook.rti.mqtt.ACTION_MQTT_CONFIG_CHANGED".equals(intent.getAction())) {
            this.l.m3418a();
            m3941a(C0544f.PERSISTENT_KICK);
        } else if (!this.f3116w.m3523a(intent)) {
            this.f3114u.m3959a(intent.toString());
        } else if ("com.facebook.rti.fbns.intent.REGISTER".equals(intent.getAction())) {
            m3941a(C0544f.FBNS_REGISTER);
            m3937c(intent);
        } else if ("com.facebook.rti.fbns.intent.REGISTER_RETRY".equals(intent.getAction())) {
            m3941a(C0544f.FBNS_REGISTER_RETRY);
            m3938d(intent);
        } else if ("com.facebook.rti.fbns.intent.UNREGISTER".equals(intent.getAction())) {
            String c;
            m3941a(C0544f.FBNS_UNREGISTER);
            String stringExtra = intent.getStringExtra("pkg_name");
            String c2 = this.f3112s.m3987c(stringExtra);
            this.f3112s.m3982a(stringExtra);
            Intent a = m3933a(stringExtra, "unregistered", null);
            String str = a.getPackage();
            if (!TextUtils.isEmpty(str)) {
                if (str.equals(getBaseContext().getPackageName())) {
                    this.f3116w.m3524a(a, str);
                } else if (!this.f3116w.m3525a(str)) {
                    c = this.f3112s.m3987c(str);
                    if (c != null) {
                        try {
                            c = new C0748r(c, str).m3976a();
                            if (this.c.m3664a("/fbns_unreg_req", C0537c.m3361a(c), C0669o.ACKNOWLEDGED_DELIVERY, new C0745o(this)) == -1) {
                                this.f3114u.m3957a(C0732b.UNREGISTER_FAILURE_MQTT_NOT_CONNECTED, null);
                            }
                        } catch (Throwable e) {
                            C0527a.m3339b("FbnsService", e, "Failed to serialize register message", new Object[0]);
                            this.f3114u.m3957a(C0732b.FAILURE_UNKNOWN_CLIENT_ERROR, null);
                        }
                    }
                } else if (C0555e.m3429a(getBaseContext(), str)) {
                    if (this.f3118y != null) {
                        try {
                            this.f3118y.addPowerSaveTempWhitelistApp(str, 60000, 0, "fbns");
                        } catch (Throwable e2) {
                            C0527a.m3337a("FbnsService", e2, "Failed to add %s to temp whitelist", str);
                        }
                    }
                    this.f3116w.m3524a(a, str);
                }
            }
            this.f3114u.m3957a(C0732b.UNREGISTER_CALLED, null);
            if (c2 != null) {
                try {
                    c = new C0748r(c2, stringExtra).m3976a();
                    if (this.c.m3664a("/fbns_unreg_req", C0537c.m3361a(c), C0669o.ACKNOWLEDGED_DELIVERY, new C0745o(this)) == -1) {
                        this.f3114u.m3957a(C0732b.UNREGISTER_FAILURE_MQTT_NOT_CONNECTED, null);
                    }
                } catch (Throwable e22) {
                    C0527a.m3339b("FbnsService", e22, "Failed to serialize register message", new Object[0]);
                    this.f3114u.m3957a(C0732b.FAILURE_UNKNOWN_CLIENT_ERROR, null);
                }
            }
        }
    }

    protected final void m3941a(C0544f c0544f) {
        boolean z = this.b.get();
        super.m3598a(c0544f);
        if (!z && C0557g.m3430a(this)) {
            C0527a.m3338b("FbnsService", "FBNS_STARTED", new Object[0]);
            this.f3116w.m3527c(new Intent("com.facebook.rti.intent.ACTION_FBNS_STARTED"));
        }
    }

    protected final Future m3939a(C0545g c0545g) {
        if (C0557g.m3430a(this)) {
            C0527a.m3338b("FbnsService", "FBNS_STOPPED", new Object[0]);
            this.f3116w.m3527c(new Intent("com.facebook.rti.intent.ACTION_FBNS_STOPPED"));
        }
        return super.m3594a(c0545g);
    }

    protected final void m3943a(String str, byte[] bArr) {
        if (bArr == null) {
            C0527a.m3344f("FbnsService", "Wrong publish payload: %s", str);
            return;
        }
        C0527a.m3338b("FbnsService", "topic: %s payload: %s", str, C0537c.m3360a(bArr));
        try {
            String a = C0537c.m3360a(bArr);
            String str2;
            if ("/fbns_msg".equals(str)) {
                C0736f c0736f = new C0736f();
                JSONObject jSONObject = new JSONObject(a);
                c0736f.f3161a = jSONObject.optString("token");
                c0736f.f3162b = jSONObject.optString("ck");
                c0736f.f3163c = jSONObject.optString("pn");
                c0736f.f3164d = jSONObject.optString("cp");
                c0736f.f3165e = jSONObject.optString("fbpushnotif");
                c0736f.f3166f = jSONObject.optString("nid");
                c0736f.f3167g = jSONObject.optString("bu");
                if (this.f3111r.f3186a.contains(c0736f.f3166f)) {
                    C0527a.m3344f("FbnsService", "Duplicated notif: %s", c0736f);
                    this.f3114u.m3956a(C0731a.DUPLICATED_NOTIFICATION, c0736f.f3166f, c0736f.f3167g, this.n, this.o, this.p);
                    return;
                }
                C0746p c0746p = this.f3111r;
                if (!TextUtils.isEmpty(c0736f.f3166f)) {
                    if (c0746p.f3186a.size() >= 100) {
                        c0746p.f3186a.removeFirst();
                    }
                    c0746p.f3186a.add(c0736f.f3166f);
                }
                Intent a2 = m3933a(c0736f.f3163c, "message", c0736f.f3165e);
                if (!TextUtils.isEmpty(c0736f.f3161a)) {
                    a2.putExtra("token", c0736f.f3161a);
                }
                if (!TextUtils.isEmpty(c0736f.f3164d)) {
                    a2.putExtra("collapse_key", c0736f.f3164d);
                }
                str2 = a2.getPackage();
                if (!TextUtils.isEmpty(str2)) {
                    if (str2.equals(getBaseContext().getPackageName())) {
                        this.f3116w.m3524a(a2, str2);
                    } else if (!this.f3116w.m3525a(str2)) {
                        a = this.f3112s.m3987c(str2);
                        if (a != null) {
                            try {
                                a = new C0748r(a, str2).m3976a();
                                if (this.c.m3664a("/fbns_unreg_req", C0537c.m3361a(a), C0669o.ACKNOWLEDGED_DELIVERY, new C0745o(this)) == -1) {
                                    this.f3114u.m3957a(C0732b.UNREGISTER_FAILURE_MQTT_NOT_CONNECTED, null);
                                }
                            } catch (Throwable e) {
                                C0527a.m3339b("FbnsService", e, "Failed to serialize register message", new Object[0]);
                                this.f3114u.m3957a(C0732b.FAILURE_UNKNOWN_CLIENT_ERROR, null);
                            }
                        }
                    } else if (C0555e.m3429a(getBaseContext(), str2)) {
                        if (this.f3118y != null) {
                            try {
                                this.f3118y.addPowerSaveTempWhitelistApp(str2, 60000, 0, "fbns");
                            } catch (Throwable e2) {
                                C0527a.m3337a("FbnsService", e2, "Failed to add %s to temp whitelist", str2);
                            }
                        }
                        this.f3116w.m3524a(a2, str2);
                    }
                }
                this.f3114u.m3956a(C0731a.NOTIFICATION_RECEIVED, c0736f.f3166f, c0736f.f3167g, this.n, this.o, this.p);
            } else if ("/fbns_reg_resp".equals(str)) {
                C0738h c0738h = new C0738h();
                JSONObject jSONObject2 = new JSONObject(a);
                c0738h.f3170a = jSONObject2.optString("pkg_name");
                c0738h.f3171b = jSONObject2.optString("token");
                c0738h.f3172c = jSONObject2.optString("error");
                if (!TextUtils.isEmpty(c0738h.f3172c)) {
                    if (TextUtils.isEmpty(c0738h.f3170a)) {
                        C0527a.m3344f("FbnsService", "packageName is empty", new Object[0]);
                    } else {
                        this.f3112s.m3985b(c0738h.f3170a);
                    }
                    this.f3114u.m3957a(C0732b.FAILURE_SERVER_RESPOND_WITH_ERROR, c0738h.f3172c);
                } else if (TextUtils.isEmpty(c0738h.f3170a)) {
                    C0527a.m3344f("FbnsService", "packageName is empty", new Object[0]);
                    this.f3114u.m3957a(C0732b.FAILURE_SERVER_RESPOND_WITH_INVALID_PACKAGE_NAME, null);
                } else if (TextUtils.isEmpty(c0738h.f3171b)) {
                    C0527a.m3344f("FbnsService", "token is empty", new Object[0]);
                    this.f3114u.m3957a(C0732b.FAILURE_SERVER_RESPOND_WITH_INVALID_TOKEN, null);
                } else if (this.f3112s.m3986b(c0738h.f3170a, c0738h.f3171b)) {
                    a = c0738h.f3170a;
                    C0527a.m3338b("FbnsService", "broadcastRegistrationSuccess %s %s", a, c0738h.f3171b);
                    this.f3115v.m3965a(a);
                    m3936b(m3933a(a, "registered", str2));
                    this.f3114u.m3957a(C0732b.RESPONSE_RECEIVED, null);
                } else {
                    C0527a.m3344f("FbnsService", "Failed to update cache and send registration response", new Object[0]);
                    this.f3114u.m3957a(C0732b.FAILURE_CACHE_UPDATE, c0738h.f3170a);
                }
            } else {
                C0527a.m3344f("FbnsService", "Wrong topic: %s", str);
                this.f3114u.m3958a(C0733c.UNEXPECTED_TOPIC, str);
            }
        } catch (Throwable e22) {
            C0527a.m3339b("FbnsService", e22, "Wrong json payload: %s", str);
            this.f3114u.m3958a(C0733c.JSON_PARSE_ERROR, str);
        }
    }

    private void m3936b(Intent intent) {
        String str = intent.getPackage();
        if (!TextUtils.isEmpty(str)) {
            if (str.equals(getBaseContext().getPackageName())) {
                this.f3116w.m3524a(intent, str);
            } else if (!this.f3116w.m3525a(str)) {
                String c = this.f3112s.m3987c(str);
                if (c != null) {
                    try {
                        c = new C0748r(c, str).m3976a();
                        if (this.c.m3664a("/fbns_unreg_req", C0537c.m3361a(c), C0669o.ACKNOWLEDGED_DELIVERY, new C0745o(this)) == -1) {
                            this.f3114u.m3957a(C0732b.UNREGISTER_FAILURE_MQTT_NOT_CONNECTED, null);
                        }
                    } catch (Throwable e) {
                        C0527a.m3339b("FbnsService", e, "Failed to serialize register message", new Object[0]);
                        this.f3114u.m3957a(C0732b.FAILURE_UNKNOWN_CLIENT_ERROR, null);
                    }
                }
            } else if (C0555e.m3429a(getBaseContext(), str)) {
                if (this.f3118y != null) {
                    try {
                        this.f3118y.addPowerSaveTempWhitelistApp(str, 60000, 0, "fbns");
                    } catch (Throwable e2) {
                        C0527a.m3337a("FbnsService", e2, "Failed to add %s to temp whitelist", str);
                    }
                }
                this.f3116w.m3524a(intent, str);
            }
        }
    }

    private void m3937c(Intent intent) {
        String stringExtra = intent.getStringExtra("pkg_name");
        String stringExtra2 = intent.getStringExtra("appid");
        this.f3115v.m3965a(stringExtra);
        if (!this.b.get()) {
            C0527a.m3344f("FbnsService", "Service has to start before register", new Object[0]);
            this.f3114u.m3957a(C0732b.FAILURE_SERVICE_NOT_STARTED, null);
        }
        C0527a.m3338b("FbnsService", "Register from %s for %s", stringExtra2, stringExtra);
        this.f3114u.m3957a(C0732b.REGISTER, stringExtra);
        Object c = this.f3112s.m3987c(stringExtra);
        if (TextUtils.isEmpty(c)) {
            m3935a(stringExtra, stringExtra2);
            return;
        }
        C0527a.m3338b("FbnsService", "broadcastRegistrationSuccess %s %s", stringExtra, c);
        this.f3115v.m3965a(stringExtra);
        m3936b(m3933a(stringExtra, "registered", c));
        this.f3114u.m3957a(C0732b.CACHE_HIT, null);
    }

    private void m3938d(Intent intent) {
        m3935a(intent.getStringExtra("pkg_name"), intent.getStringExtra("appid"));
    }

    private void m3935a(String str, String str2) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2)) {
            C0527a.m3338b("FbnsService", "Cancel requestNewToken because packageName or appId is empty", new Object[0]);
            return;
        }
        this.f3115v.m3966a(str, str2);
        this.f3112s.m3983a(str, str2);
        try {
            String a = new C0737g(str, str2).m3963a();
            C0527a.m3338b("FbnsService", a, new Object[0]);
            if (this.c.m3664a("/fbns_reg_req", C0537c.m3361a(a), C0669o.ACKNOWLEDGED_DELIVERY, new C0744n(this)) == -1) {
                this.f3114u.m3957a(C0732b.FAILURE_MQTT_NOT_CONNECTED, null);
            }
        } catch (Throwable e) {
            C0527a.m3339b("FbnsService", e, "Failed to serialize register message", new Object[0]);
            this.f3114u.m3957a(C0732b.FAILURE_UNKNOWN_CLIENT_ERROR, null);
        }
    }

    public final void m3949k() {
        List<C0749s> b = this.f3112s.m3984b();
        this.f3112s.m3981a();
        this.f3114u.m3957a(C0732b.CREDENTIALS_UPDATED, String.valueOf(b.size()));
        m3941a(C0544f.CREDENTIALS_UPDATED);
        for (C0749s c0749s : b) {
            Intent intent = new Intent("com.facebook.rti.fbns.intent.REGISTER");
            intent.putExtra("pkg_name", c0749s.f3196b);
            intent.putExtra("appid", c0749s.f3195a);
            m3937c(intent);
        }
    }

    protected final void m3942a(C0694c c0694c) {
        if (C0694c.FAILED_CONNECTION_REFUSED_BAD_USER_NAME_OR_PASSWORD.equals(c0694c) && this.f3112s.m3988c()) {
            this.f3112s.m3989d();
            List<C0749s> b = this.f3112s.m3984b();
            this.f3112s.m3981a();
            this.f3114u.m3957a(C0732b.AUTHFAIL_AUTO_REGISTER, String.valueOf(b.size()));
            for (C0749s c0749s : b) {
                Intent intent = new Intent("com.facebook.rti.fbns.intent.REGISTER");
                intent.putExtra("pkg_name", c0749s.f3196b);
                intent.putExtra("appid", c0749s.f3195a);
                m3937c(intent);
            }
        }
    }

    private static Intent m3933a(String str, String str2, String str3) {
        Intent intent = new Intent("com.facebook.rti.fbns.intent.RECEIVE");
        intent.setPackage(str);
        intent.addCategory(str);
        intent.putExtra("receive_type", str2);
        if (str3 != null) {
            intent.putExtra("data", str3);
        }
        return intent;
    }

    protected final boolean m3948h() {
        return !this.f3112s.m3984b().isEmpty();
    }
}
