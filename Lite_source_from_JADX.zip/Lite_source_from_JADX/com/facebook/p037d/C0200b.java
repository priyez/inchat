package com.facebook.p037d;

import android.annotation.TargetApi;
import android.app.PendingIntent;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.Base64;
import java.security.MessageDigest;

/* renamed from: com.facebook.d.b */
public final class C0200b {
    public static boolean m1499a(Context context, Bundle bundle) {
        PendingIntent pendingIntent = (PendingIntent) bundle.getParcelable("auth");
        if (pendingIntent == null) {
            return false;
        }
        String creatorPackage;
        if (VERSION.SDK_INT >= 17) {
            creatorPackage = pendingIntent.getCreatorPackage();
        } else {
            creatorPackage = pendingIntent.getTargetPackage();
        }
        try {
            return C0200b.m1500a(context.getPackageManager().getPackageInfo(creatorPackage, 64));
        } catch (NameNotFoundException e) {
            return false;
        }
    }

    public static boolean m1500a(PackageInfo packageInfo) {
        return C0201c.m1502a(C0200b.m1501b(packageInfo));
    }

    private static String m1501b(PackageInfo packageInfo) {
        if (packageInfo.signatures == null || packageInfo.signatures.length != 1 || VERSION.SDK_INT < 8) {
            return null;
        }
        return C0200b.m1498a(packageInfo.signatures[0].toByteArray());
    }

    @TargetApi(8)
    private static String m1498a(byte[] bArr) {
        try {
            MessageDigest instance = MessageDigest.getInstance("SHA-1");
            instance.update(bArr, 0, bArr.length);
            return Base64.encodeToString(instance.digest(), 11);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }
}
