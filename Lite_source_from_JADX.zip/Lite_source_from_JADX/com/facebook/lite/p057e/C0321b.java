package com.facebook.lite.p057e;

/* renamed from: com.facebook.lite.e.b */
final /* synthetic */ class C0321b {
    static final /* synthetic */ int[] f1272a;

    static {
        f1272a = new int[C0322c.m2275a().length];
        try {
            f1272a[C0322c.f1275c - 1] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            f1272a[C0322c.f1273a - 1] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            f1272a[C0322c.f1274b - 1] = 3;
        } catch (NoSuchFieldError e3) {
        }
    }
}
