package com.facebook.lite.p049a;

import android.util.Log;
import com.facebook.lite.p049a.p050a.C0262b;
import com.p008a.p009a.p010a.p018f.C0047a;
import com.p026b.p027a.C0135g;
import com.p026b.p027a.C0136h;
import java.io.File;

/* renamed from: com.facebook.lite.a.b */
final class C0266b extends C0263a {
    final /* synthetic */ C0280i f1019a;
    private final C0047a f1020b;
    private final String f1021c;
    private final int f1022d;
    private final int f1023e;

    public C0266b(C0280i c0280i, C0047a c0047a, String str, long j) {
        this.f1019a = c0280i;
        super(j);
        this.f1020b = c0047a;
        this.f1022d = 1;
        this.f1023e = 1;
        this.f1021c = str;
    }

    public final void run() {
        String str;
        if (this.f1019a.f1075f.get(Byte.valueOf(this.f1020b.m325b())) == null) {
            C0280i.f1070a;
            new StringBuilder().append(C0280i.m1873a(this.f1020b.m325b())).append("cache created");
            if (this.f1020b.m325b() == null) {
                str = this.f1021c + "/images";
            } else {
                str = this.f1021c + "/generic/" + this.f1020b.m325b();
            }
            try {
                if (this.f1019a.f1075f.get(Byte.valueOf(this.f1020b.m325b())) != null || !this.f1020b.m327d()) {
                    return;
                }
                if (this.f1020b.m325b() == null || this.f1019a.f1074e) {
                    this.f1019a.f1075f.put(Byte.valueOf(this.f1019a.f1074e ? this.f1020b.m325b() : (byte) 0), new C0262b(C0135g.m1266a(new File(str), this.f1022d, this.f1023e, (long) this.f1020b.m326c()), this.f1020b));
                    if (this.f1020b.m325b() == null) {
                        this.f1019a.m1899w();
                    }
                }
            } catch (C0136h e) {
                this.f1019a.m1878a(str, e);
            } catch (Throwable e2) {
                this.f1019a.f1076g.m124a((short) 161, null, e2);
                Log.e(C0280i.f1070a, C0280i.m1873a(this.f1020b.m325b()) + "can't open journal file ");
            }
        }
    }
}
