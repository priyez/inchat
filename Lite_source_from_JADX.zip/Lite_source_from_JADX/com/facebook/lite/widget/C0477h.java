package com.facebook.lite.widget;

/* renamed from: com.facebook.lite.widget.h */
final class C0477h implements Runnable {
    final /* synthetic */ int f2091a;
    final /* synthetic */ DummySurfaceView f2092b;

    C0477h(DummySurfaceView dummySurfaceView, int i) {
        this.f2092b = dummySurfaceView;
        this.f2091a = i;
    }

    public final void run() {
        this.f2092b.setVisibility(this.f2091a);
    }
}
