package com.facebook.lite.webview;

import com.facebook.lite.p053b.C0302p;
import java.util.Locale;

/* renamed from: com.facebook.lite.webview.c */
enum C0468c {
    FACEBOOK(".facebook.com"),
    FBME(".fb.me");
    
    private final String f1858c;

    private C0468c(String str) {
        this.f1858c = str;
    }

    public final boolean m3137a(String str) {
        if (C0302p.m2177b((CharSequence) str)) {
            return false;
        }
        String toLowerCase = str.toLowerCase(Locale.ENGLISH);
        if (toLowerCase.endsWith(this.f1858c) || toLowerCase.equals(this.f1858c.substring(1))) {
            return true;
        }
        return false;
    }
}
