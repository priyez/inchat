package com.facebook.rti.push.service;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.TextUtils;
import com.facebook.rti.p046a.p074f.C0527a;
import com.facebook.rti.p046a.p075g.C0528c;
import com.facebook.rti.p046a.p076h.C0531a;
import com.facebook.rti.p078b.p080b.p082b.C0553c;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.json.JSONObject;

/* renamed from: com.facebook.rti.push.service.t */
public final class C0750t {
    private final SharedPreferences f3199a;
    private final SharedPreferences f3200b;
    private final C0531a f3201c;

    public C0750t(SharedPreferences sharedPreferences, SharedPreferences sharedPreferences2, C0531a c0531a, C0553c c0553c) {
        this.f3199a = sharedPreferences;
        this.f3200b = sharedPreferences2;
        this.f3201c = c0531a;
        String string = this.f3200b.getString("mqtt_version", "");
        String b = c0553c.m3426b();
        if (!string.equals(b)) {
            m3981a();
            C0528c.m3345a(this.f3200b.edit().putString("mqtt_version", b));
        }
    }

    public final boolean m3983a(String str, String str2) {
        int i;
        int i2 = 1;
        C0527a.m3338b("RegistrationState", "add app %s %s", str, str2);
        if (TextUtils.isEmpty(str)) {
            i = 0;
        } else {
            i = 1;
        }
        if (i == 0) {
            throw new IllegalArgumentException();
        }
        if (TextUtils.isEmpty(str2)) {
            i2 = 0;
        }
        if (i2 == 0) {
            throw new IllegalArgumentException();
        }
        C0749s c0749s = new C0749s();
        c0749s.f3196b = str;
        c0749s.f3195a = str2;
        c0749s.f3198d = Long.valueOf(this.f3201c.m3350a());
        return m3978a(str, c0749s);
    }

    public final boolean m3986b(String str, String str2) {
        int i = 1;
        C0527a.m3338b("RegistrationState", "updateTokenCache %s %s", str, str2);
        if (TextUtils.isEmpty(str)) {
            boolean z = false;
        } else {
            int i2 = 1;
        }
        if (i2 == 0) {
            throw new IllegalArgumentException();
        }
        if (TextUtils.isEmpty(str2)) {
            i = 0;
        }
        if (i == 0) {
            throw new IllegalArgumentException();
        }
        m3980e();
        C0749s d = m3979d(str);
        if (d == null) {
            C0527a.m3344f("RegistrationState", "Missing entry", new Object[0]);
            return false;
        }
        d.f3197c = str2;
        d.f3198d = Long.valueOf(this.f3201c.m3350a());
        return m3978a(str, d);
    }

    public final void m3982a(String str) {
        int i = 1;
        C0527a.m3338b("RegistrationState", "remove app %s", str);
        if (TextUtils.isEmpty(str)) {
            i = 0;
        }
        if (i == 0) {
            throw new IllegalArgumentException();
        } else if (this.f3199a.contains(str)) {
            C0528c.m3345a(this.f3199a.edit().remove(str));
        }
    }

    public final void m3985b(String str) {
        int i = 1;
        C0527a.m3338b("RegistrationState", "invalidateTokenCache %s", str);
        if (TextUtils.isEmpty(str)) {
            i = 0;
        }
        if (i == 0) {
            throw new IllegalArgumentException();
        }
        C0749s d = m3979d(str);
        if (d == null) {
            C0527a.m3344f("RegistrationState", "Missing entry", new Object[0]);
            return;
        }
        d.f3197c = "";
        d.f3198d = Long.valueOf(this.f3201c.m3350a());
        m3978a(str, d);
    }

    public final void m3981a() {
        C0527a.m3338b("RegistrationState", "invalidateAllTokenCache", new Object[0]);
        Editor edit = this.f3199a.edit();
        for (String str : this.f3199a.getAll().keySet()) {
            C0749s d = m3979d(str);
            if (d == null) {
                C0527a.m3344f("RegistrationState", "invalid value for %s", str);
            } else {
                d.f3197c = "";
                d.f3198d = Long.valueOf(this.f3201c.m3350a());
                try {
                    edit.putString(str, d.m3977a());
                } catch (Throwable e) {
                    C0527a.m3339b("RegistrationState", e, "RegistrationCacheEntry serialization failed", new Object[0]);
                }
            }
        }
        C0528c.m3345a(edit);
    }

    public final String m3987c(String str) {
        int i = 1;
        C0527a.m3338b("RegistrationState", "getValidToken %s", str);
        if (TextUtils.isEmpty(str)) {
            i = 0;
        }
        if (i == 0) {
            throw new IllegalArgumentException();
        } else if (TextUtils.isEmpty(this.f3199a.getString(str, ""))) {
            return null;
        } else {
            C0749s d = m3979d(str);
            if (d == null) {
                return null;
            }
            long a = this.f3201c.m3350a();
            if (d.f3198d.longValue() + 86400000 < a || d.f3198d.longValue() > a) {
                return null;
            }
            return d.f3197c;
        }
    }

    public final List m3984b() {
        Map all = this.f3199a.getAll();
        List linkedList = new LinkedList();
        for (Entry key : all.entrySet()) {
            try {
                C0527a.m3338b("RegistrationState", "getRegisteredApps retrieving %s:%s", key.getKey(), ((Entry) r2.next()).getValue());
                String obj = key.getValue().toString();
                C0749s c0749s = new C0749s();
                if (obj != null) {
                    JSONObject jSONObject = new JSONObject(obj);
                    c0749s.f3195a = jSONObject.optString("app_id");
                    c0749s.f3196b = jSONObject.optString("pkg_name");
                    c0749s.f3197c = jSONObject.optString("token");
                    c0749s.f3198d = Long.valueOf(jSONObject.optLong("time"));
                }
                linkedList.add(c0749s);
            } catch (Throwable e) {
                C0527a.m3339b("RegistrationState", e, "Parse failed", new Object[0]);
            }
        }
        return linkedList;
    }

    private C0749s m3979d(String str) {
        Object string = this.f3199a.getString(str, "");
        if (TextUtils.isEmpty(string)) {
            return null;
        }
        try {
            C0749s c0749s = new C0749s();
            if (string == null) {
                return c0749s;
            }
            JSONObject jSONObject = new JSONObject(string);
            c0749s.f3195a = jSONObject.optString("app_id");
            c0749s.f3196b = jSONObject.optString("pkg_name");
            c0749s.f3197c = jSONObject.optString("token");
            c0749s.f3198d = Long.valueOf(jSONObject.optLong("time"));
            return c0749s;
        } catch (Throwable e) {
            C0527a.m3339b("RegistrationState", e, "Parse failed", new Object[0]);
            return null;
        }
    }

    private boolean m3978a(String str, C0749s c0749s) {
        boolean z = false;
        try {
            C0528c.m3345a(this.f3199a.edit().putString(str, c0749s.m3977a()));
            return true;
        } catch (Throwable e) {
            C0527a.m3339b("RegistrationState", e, "RegistrationCacheEntry serialization failed", new Object[z]);
            return z;
        }
    }

    public final boolean m3988c() {
        return this.f3201c.m3350a() - this.f3200b.getLong("auto_reg_retry", 0) > 86400000;
    }

    private void m3980e() {
        C0528c.m3345a(this.f3200b.edit().remove("auto_reg_retry"));
    }

    public final void m3989d() {
        C0528c.m3345a(this.f3200b.edit().putLong("auto_reg_retry", this.f3201c.m3350a()));
    }
}
