package com.facebook.lite.widget;

import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Build.VERSION;

/* renamed from: com.facebook.lite.widget.l */
final class C0481l implements OnPreparedListener {
    final /* synthetic */ FbVideoView f2097a;

    C0481l(FbVideoView fbVideoView) {
        this.f2097a = fbVideoView;
    }

    public final void onPrepared(MediaPlayer mediaPlayer) {
        if (this.f2097a.f1902f) {
            if (VERSION.SDK_INT < 17) {
                this.f2097a.f1899c.setVisibility(8);
            }
            mediaPlayer.start();
        }
        if (VERSION.SDK_INT >= 17) {
            mediaPlayer.setOnInfoListener(new C0480k(this));
        }
    }
}
