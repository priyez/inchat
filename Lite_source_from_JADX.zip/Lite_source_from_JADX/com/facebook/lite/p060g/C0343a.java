package com.facebook.lite.p060g;

import android.graphics.Bitmap;
import android.os.SystemClock;
import com.facebook.lite.p059m.C0387i;
import com.facebook.p038e.p040b.p041a.p042a.p043a.C0216b;
import com.p008a.p009a.p010a.p012b.C0011a;
import com.p008a.p009a.p010a.p012b.C0020n;
import com.p008a.p009a.p010a.p012b.C0025b;
import com.p008a.p009a.p010a.p012b.C0026e;

/* renamed from: com.facebook.lite.g.a */
public final class C0343a extends C0025b {
    private final C0387i f1377d;
    private final C0026e f1378e;

    public C0343a(C0387i c0387i, C0026e c0026e, C0020n c0020n) {
        super(c0387i, c0387i, c0387i, c0387i, c0387i, c0387i, c0387i, c0020n, c0387i);
        this.f1377d = c0387i;
        this.f1378e = c0026e;
    }

    protected final void m2469c(C0011a c0011a) {
        long uptimeMillis = SystemClock.uptimeMillis();
        super.m195c(c0011a);
        this.f1377d.m2646U().m2535a().m2521a((int) (SystemClock.uptimeMillis() - uptimeMillis));
    }

    protected final void m2470d(C0011a c0011a) {
        switch (c0011a.f45b) {
            case 83:
                this.f1378e.m222a();
                if (this.a != null) {
                    this.a.m338a(c0011a.f46c);
                }
            case 90:
                if (c0011a.f48e != null && (c0011a.f48e instanceof Bitmap)) {
                    ((Bitmap) c0011a.f48e).recycle();
                }
            case 91:
                C0216b.m1534e();
                C0216b.m1532d();
            default:
                super.m200d(c0011a);
        }
    }
}
