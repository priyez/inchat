package com.facebook.lite.p053b;

import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: com.facebook.lite.b.j */
public final class C0296j {
    public static boolean m1991a(JSONObject jSONObject, String str, boolean z) {
        if (jSONObject != null) {
            try {
                z = jSONObject.getBoolean(str);
            } catch (JSONException e) {
            }
        }
        return z;
    }

    public static int m1989a(JSONObject jSONObject, String str, int i) {
        if (jSONObject != null) {
            try {
                i = jSONObject.getInt(str);
            } catch (JSONException e) {
            }
        }
        return i;
    }

    public static long m1990a(JSONObject jSONObject, String str) {
        long j = 86400000;
        if (jSONObject != null) {
            try {
                j = jSONObject.getLong(str);
            } catch (JSONException e) {
            }
        }
        return j;
    }
}
