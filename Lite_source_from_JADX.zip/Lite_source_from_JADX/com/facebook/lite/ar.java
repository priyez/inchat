package com.facebook.lite;

public final class ar {
    public static final int black = 2131034114;
    public static final int blue = 2131034112;
    public static final int button_bg_color = 2131034121;
    public static final int camera_icon_bg_color = 2131034122;
    public static final int contact_list_divider_color = 2131034123;
    public static final int contact_list_head_bg_color = 2131034124;
    public static final int contact_list_head_text_color = 2131034125;
    public static final int contact_list_item_text_color = 2131034126;
    public static final int dark_blue = 2131034116;
    public static final int darker_blue = 2131034119;
    public static final int empty_image_border = 2131034127;
    public static final int empty_image_fill = 2131034128;
    public static final int grayish_blue = 2131034117;
    public static final int light_gray = 2131034115;
    public static final int light_grayish_blue = 2131034118;
    public static final int mention_highlight = 2131034129;
    public static final int title_text_color = 2131034120;
    public static final int white = 2131034113;
}
