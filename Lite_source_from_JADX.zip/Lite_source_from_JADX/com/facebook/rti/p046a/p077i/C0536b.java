package com.facebook.rti.p046a.p077i;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.DeadObjectException;
import android.util.Base64;
import java.security.MessageDigest;
import java.util.List;

/* renamed from: com.facebook.rti.a.i.b */
public final class C0536b {
    public static PackageInfo m3357a(Context context, String str, int i) {
        PackageInfo packageInfo = null;
        try {
            packageInfo = context.getPackageManager().getPackageInfo(str, i);
        } catch (NameNotFoundException e) {
        } catch (RuntimeException e2) {
            if (!(e2.getCause() instanceof DeadObjectException)) {
                throw e2;
            }
        }
        return packageInfo;
    }

    public static List m3359a(Context context, Intent intent) {
        try {
            return context.getPackageManager().queryBroadcastReceivers(intent, 0);
        } catch (RuntimeException e) {
            if (e.getCause() instanceof DeadObjectException) {
                return null;
            }
            throw e;
        }
    }

    public static String m3358a(byte[] bArr) {
        try {
            MessageDigest instance = MessageDigest.getInstance("SHA-1");
            instance.update(bArr, 0, bArr.length);
            return Base64.encodeToString(instance.digest(), 11);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }
}
