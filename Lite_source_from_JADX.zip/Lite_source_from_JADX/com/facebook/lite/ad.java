package com.facebook.lite;

final class ad implements Runnable {
    final /* synthetic */ boolean f1118a;
    final /* synthetic */ MainActivity f1119b;

    ad(MainActivity mainActivity) {
        this.f1119b = mainActivity;
        this.f1118a = false;
    }

    public final void run() {
        this.f1119b.f985q.setVisibility(this.f1118a ? 0 : 8);
    }
}
