package com.facebook.lite.p054i;

import android.location.Location;

/* renamed from: com.facebook.lite.i.e */
public interface C0303e {
    void m2180a();

    void m2181a(Location location);
}
