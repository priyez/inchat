package com.facebook.rti.push.service;

import java.util.LinkedList;

/* renamed from: com.facebook.rti.push.service.p */
final class C0746p {
    LinkedList f3186a;

    C0746p() {
        this.f3186a = new LinkedList();
    }
}
