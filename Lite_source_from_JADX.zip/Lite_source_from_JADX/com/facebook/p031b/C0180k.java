package com.facebook.p031b;

import java.io.File;
import java.util.Comparator;

/* renamed from: com.facebook.b.k */
final class C0180k implements Comparator {
    final /* synthetic */ C0184o f663a;

    C0180k(C0184o c0184o) {
        this.f663a = c0184o;
    }

    public final /* synthetic */ int compare(Object obj, Object obj2) {
        return C0180k.m1388a((File) obj, (File) obj2);
    }

    private static int m1388a(File file, File file2) {
        long lastModified = file.lastModified();
        long lastModified2 = file2.lastModified();
        if (lastModified == lastModified2) {
            return 0;
        }
        return lastModified < lastModified2 ? 1 : -1;
    }
}
