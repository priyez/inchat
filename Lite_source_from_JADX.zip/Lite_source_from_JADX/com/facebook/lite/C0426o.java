package com.facebook.lite;

import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;

/* renamed from: com.facebook.lite.o */
final class C0426o implements OnClickListener {
    final /* synthetic */ C0455r f1710a;

    C0426o(C0455r c0455r) {
        this.f1710a = c0455r;
    }

    public final void onClick(View view) {
        if (this.f1710a.f1816f.f984p != null && this.f1710a.f1816f.f984p.isShowing()) {
            this.f1710a.f1816f.f984p.dismiss();
        }
        this.f1710a.f1816f.startActivity(new Intent("android.settings.SETTINGS"));
    }
}
