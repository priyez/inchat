package com.facebook.lite;

import android.view.ViewGroup.LayoutParams;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;

/* renamed from: com.facebook.lite.m */
final class C0390m implements Runnable {
    final /* synthetic */ int f1545a;
    final /* synthetic */ int f1546b;
    final /* synthetic */ int f1547c;
    final /* synthetic */ int f1548d;
    final /* synthetic */ boolean f1549e;
    final /* synthetic */ int f1550f;
    final /* synthetic */ int f1551g;
    final /* synthetic */ int f1552h;
    final /* synthetic */ MainActivity f1553i;

    C0390m(MainActivity mainActivity, int i, int i2, int i3, int i4, boolean z, int i5, int i6, int i7) {
        this.f1553i = mainActivity;
        this.f1545a = i;
        this.f1546b = i2;
        this.f1547c = i3;
        this.f1548d = i4;
        this.f1549e = z;
        this.f1550f = i5;
        this.f1551g = i6;
        this.f1552h = i7;
    }

    public final void run() {
        LayoutParams layoutParams = new FrameLayout.LayoutParams(this.f1545a, this.f1546b);
        layoutParams.setMargins(this.f1547c, this.f1548d, 0, 0);
        layoutParams.gravity = 48;
        this.f1553i.f973e.setLayoutParams(layoutParams);
        this.f1553i.f973e.setVisibility(0);
        if (this.f1549e) {
            Animation translateAnimation = new TranslateAnimation(0, (float) this.f1550f, 0, (float) this.f1547c, 0, (float) this.f1551g, 0, (float) this.f1548d);
            translateAnimation.setDuration((long) this.f1552h);
            translateAnimation.setFillAfter(true);
            this.f1553i.f973e.startAnimation(translateAnimation);
        }
    }
}
