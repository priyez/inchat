package com.facebook.lite.photo;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;

/* renamed from: com.facebook.lite.photo.r */
public final class C0449r extends AsyncTask {
    final /* synthetic */ PreviewActivity f1792a;

    public C0449r(PreviewActivity previewActivity) {
        this.f1792a = previewActivity;
    }

    protected final /* synthetic */ Object doInBackground(Object[] objArr) {
        return m3074a();
    }

    protected final /* synthetic */ void onPostExecute(Object obj) {
        m3075a((Bitmap) obj);
    }

    private Bitmap m3074a() {
        try {
            return C0444m.m3042a(this.f1792a.f1752c, this.f1792a.f1754e);
        } catch (Throwable e) {
            Throwable th = e;
            Bitmap c = this.f1792a.f1752c;
            Log.e(PreviewActivity.f1750a, "preview/out of memory while rotating the photo.", th);
            PreviewActivity.m3004b(th);
            return c;
        }
    }

    private void m3075a(Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            this.f1792a.f1753d.setImageBitmap(bitmap);
        }
    }
}
