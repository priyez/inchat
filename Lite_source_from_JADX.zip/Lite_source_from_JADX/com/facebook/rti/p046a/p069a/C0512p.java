package com.facebook.rti.p046a.p069a;

import android.app.AlarmManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build.VERSION;
import android.os.Handler;
import android.text.TextUtils;
import com.facebook.rti.p046a.p070c.C0518b;
import com.facebook.rti.p046a.p070c.C0520d;
import com.facebook.rti.p046a.p070c.C0522f;
import com.facebook.rti.p046a.p074f.C0527a;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import p006c.p007a.C0003a;

/* renamed from: com.facebook.rti.a.a.p */
public final class C0512p implements C0500d {
    final Context f2159a;
    final AlarmManager f2160b;
    C0503g f2161c;
    final Handler f2162d;
    final Queue f2163e;
    final C0522f f2164f;
    final AtomicBoolean f2165g;
    final Runnable f2166h;
    final C0504h f2167i;
    final C0506j f2168j;
    final SharedPreferences f2169k;
    final int f2170l;
    private final C0003a f2171m;
    private final String f2172n;
    private final String f2173o;
    private final String f2174p;
    private final C0501e f2175q;

    public C0512p(Context context, C0003a c0003a, C0501e c0501e, SharedPreferences sharedPreferences, C0003a c0003a2, String str, String str2, String str3, String str4, String str5) {
        this.f2162d = new C0507k(this);
        this.f2163e = new ConcurrentLinkedQueue();
        this.f2164f = new C0520d(C0518b.m3316a()).m3318a();
        this.f2165g = new AtomicBoolean(false);
        this.f2159a = context.getApplicationContext();
        this.f2169k = sharedPreferences;
        this.f2160b = (AlarmManager) this.f2159a.getSystemService("alarm");
        this.f2171m = c0003a2;
        this.f2173o = str3;
        this.f2172n = str2;
        this.f2174p = str4;
        this.f2166h = new C0508l();
        this.f2167i = new C0504h(context.getApplicationContext());
        this.f2168j = new C0506j(context, c0003a, str, str4, str5);
        this.f2175q = c0501e;
        this.f2170l = VERSION.SDK_INT;
        C0497a.f2123a = this;
        if (!(this.f2161c == null || this.f2161c.m3301b().isEmpty())) {
            C0527a.m3336a("DefaultAnalyticsLogger", "Storing batch %s", this.f2161c);
            this.f2167i.m3307a(this.f2161c);
            this.f2161c.m3296a();
        }
        C0527a.m3336a("DefaultAnalyticsLogger", "Starting new session", new Object[0]);
        C0503g c0503g = new C0503g();
        c0503g.m3300a(this.f2172n);
        c0503g.m3302b(this.f2173o);
        String string = this.f2169k.getString("fb_uid", "");
        if (TextUtils.isEmpty(string)) {
            string = "0";
        }
        c0503g.m3306d(string);
        c0503g.m3304c(this.f2174p);
        c0503g.m3298a(this.f2171m);
        this.f2161c = c0503g;
    }

    public final void m3312a(C0498b c0498b) {
        if (this.f2175q.m3293a()) {
            this.f2163e.add(new C0509m(c0498b, (byte) 0));
            if (this.f2165g.compareAndSet(false, true)) {
                this.f2164f.execute(this.f2166h);
            }
        }
    }

    public final void m3311a() {
        this.f2163e.add(new C0511o());
        if (this.f2165g.compareAndSet(false, true)) {
            this.f2164f.execute(this.f2166h);
        }
    }
}
