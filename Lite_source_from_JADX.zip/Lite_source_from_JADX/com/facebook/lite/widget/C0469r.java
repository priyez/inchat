package com.facebook.lite.widget;

import android.graphics.Bitmap;
import android.view.View;
import com.facebook.lite.ui.C0461c;

/* renamed from: com.facebook.lite.widget.r */
public interface C0469r extends C0461c {
    View m3138a();

    void m3139a(View view, boolean z);

    void m3140a(int[] iArr);

    Bitmap getScreenshot();

    void onPause();

    void onResume();
}
