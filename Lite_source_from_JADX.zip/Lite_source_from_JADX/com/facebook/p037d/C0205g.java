package com.facebook.p037d;

/* renamed from: com.facebook.d.g */
public interface C0205g {
    C0202d m1509a();

    void m1510a(C0202d c0202d);
}
