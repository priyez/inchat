package com.facebook.p031b.p032a;

import android.content.Context;

/* renamed from: com.facebook.b.a.a */
public class C0147a implements C0146b {
    protected Context f619a;
    protected boolean f620b;

    public C0147a(Context context) {
        this.f620b = true;
        if (context == null) {
            throw new IllegalArgumentException("Application context cannot be null");
        }
        this.f619a = context;
    }

    public final String[] m1321a() {
        return new String[0];
    }

    public final String[] m1322b() {
        return new String[]{"-t", "200", "-v", "time"};
    }

    public final String m1323c() {
        return "application/x-www-form-urlencoded";
    }

    public boolean m1324d() {
        return this.f620b;
    }

    public final void m1320a(boolean z) {
        this.f620b = z;
    }

    public final Context m1325e() {
        return this.f619a;
    }

    public final String m1326f() {
        return "Android";
    }
}
