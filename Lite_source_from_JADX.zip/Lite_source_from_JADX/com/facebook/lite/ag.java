package com.facebook.lite;

import com.facebook.lite.widget.aj;

final class ag implements aj {
    final /* synthetic */ ah f1146a;

    ag(ah ahVar) {
        this.f1146a = ahVar;
    }

    public final void m1929a() {
        this.f1146a.f1153g.m1766s();
    }

    public final void m1930a(float f) {
        if (f < this.f1146a.f1153g.f985q.getMinScale()) {
            this.f1146a.f1153g.m1766s();
        }
    }

    public final void m1931b() {
        this.f1146a.f1153g.m1766s();
    }
}
