package com.facebook.lite;

import android.location.Location;
import com.facebook.lite.p054i.C0303e;
import com.p008a.p009a.p010a.p012b.C0011a;

/* renamed from: com.facebook.lite.b */
final class C0304b implements C0303e {
    final /* synthetic */ boolean f1211a;
    final /* synthetic */ C0342f f1212b;

    C0304b(C0342f c0342f, boolean z) {
        this.f1212b = c0342f;
        this.f1211a = z;
    }

    public final void m2184a(Location location) {
        this.f1212b.f1354I = location;
        this.f1212b.f1369s.m2639N().m168a(new C0011a(207));
        m2182a(this.f1211a);
    }

    public final void m2183a() {
        m2182a(this.f1211a);
        C0342f.f1331b;
    }

    private void m2182a(boolean z) {
        if (z && this.f1212b.m2381M() != null) {
            this.f1212b.m2381M().m1793k();
        }
    }
}
