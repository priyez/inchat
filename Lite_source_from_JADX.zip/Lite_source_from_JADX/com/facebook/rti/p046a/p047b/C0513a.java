package com.facebook.rti.p046a.p047b;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

/* renamed from: com.facebook.rti.a.b.a */
final class C0513a extends Handler {
    final /* synthetic */ C0516d f2176a;

    C0513a(C0516d c0516d, Looper looper) {
        this.f2176a = c0516d;
        super(looper);
    }

    public final void handleMessage(Message message) {
        switch (message.what) {
            case 1:
                C0516d.m3314a(this.f2176a);
            default:
                super.handleMessage(message);
        }
    }
}
