package com.p028c.p029a;

/* renamed from: com.c.a.a */
public interface C0140a {
    void m1302a();
}
