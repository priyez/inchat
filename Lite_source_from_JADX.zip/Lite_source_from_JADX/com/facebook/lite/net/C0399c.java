package com.facebook.lite.net;

import com.p008a.p009a.p010a.p023m.C0115e;
import com.p008a.p009a.p010a.p023m.C0116b;
import java.io.OutputStream;

/* renamed from: com.facebook.lite.net.c */
final class C0399c extends C0398p {
    final /* synthetic */ C0401d f1599a;

    public C0399c(C0401d c0401d, OutputStream outputStream) {
        this.f1599a = c0401d;
        super(c0401d, outputStream);
    }

    protected final void m2792a(C0115e c0115e) {
        C0115e c0116b;
        synchronized (this.f1599a.p) {
            c0116b = new C0116b(c0115e.m1130p());
        }
        boolean a = this.f1599a.m2841d(c0116b);
        super.m2791a(c0116b);
        if (a) {
            this.f1599a.f1624x = false;
        }
    }
}
