package com.facebook.lite.p056d;

/* renamed from: com.facebook.lite.d.b */
final class C0310b {
    private static final C0311c f1225a;

    static {
        f1225a = new C0311c();
    }
}
