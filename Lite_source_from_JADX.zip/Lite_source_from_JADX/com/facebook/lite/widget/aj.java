package com.facebook.lite.widget;

public interface aj {
    void m1926a();

    void m1927a(float f);

    void m1928b();
}
