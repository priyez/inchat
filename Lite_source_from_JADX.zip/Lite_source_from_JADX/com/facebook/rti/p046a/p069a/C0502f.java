package com.facebook.rti.p046a.p069a;

import com.facebook.rti.p046a.p074f.C0527a;
import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;
import java.util.Map.Entry;
import p006c.p007a.C0003a;

/* renamed from: com.facebook.rti.a.a.f */
public class C0502f {
    private static final String f2137a;
    private final C0003a f2138b;

    static {
        f2137a = C0502f.class.getSimpleName();
    }

    public C0502f(C0003a c0003a) {
        this.f2138b = c0003a;
    }

    public final int m3295a(Map map, String str) {
        int i = -1;
        try {
            try {
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL((String) this.f2138b.m41b()).openConnection();
                httpURLConnection.setConnectTimeout(10000);
                try {
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                    httpURLConnection.setRequestProperty("User-Agent", str);
                    if (!C0502f.m3294a(map, httpURLConnection)) {
                        return i;
                    }
                    i = httpURLConnection.getResponseCode();
                    httpURLConnection.disconnect();
                    return i;
                } catch (Throwable e) {
                    C0527a.m3339b(f2137a, e, "", new Object[0]);
                    return i;
                } finally {
                    httpURLConnection.disconnect();
                }
            } catch (Throwable e2) {
                C0527a.m3339b(f2137a, e2, "Failed to open http connection", new Object[0]);
                return i;
            }
        } catch (Throwable e22) {
            C0527a.m3339b(f2137a, e22, "Logging end point malformed", new Object[0]);
            return i;
        }
    }

    private static boolean m3294a(Map map, HttpURLConnection httpURLConnection) {
        try {
            DataOutputStream dataOutputStream = new DataOutputStream(httpURLConnection.getOutputStream());
            StringBuilder stringBuilder = new StringBuilder();
            for (Entry entry : map.entrySet()) {
                if (stringBuilder.length() != 0) {
                    stringBuilder.append("&");
                }
                try {
                    stringBuilder.append(URLEncoder.encode((String) entry.getKey(), "UTF-8")).append("=").append(URLEncoder.encode((String) entry.getValue(), "UTF-8"));
                } catch (Throwable e) {
                    C0527a.m3339b(f2137a, e, "", new Object[0]);
                    dataOutputStream.close();
                    return false;
                }
            }
            try {
                dataOutputStream.writeBytes(stringBuilder.toString());
                dataOutputStream.flush();
                return true;
            } catch (Throwable e2) {
                C0527a.m3339b(f2137a, e2, "Failed to write to output stream", new Object[0]);
                return false;
            } finally {
                dataOutputStream.close();
            }
        } catch (Throwable e22) {
            C0527a.m3339b(f2137a, e22, "Unable to create output stream", new Object[0]);
            return false;
        } catch (Throwable e222) {
            C0527a.m3339b(f2137a, e222, "Unable to create output stream", new Object[0]);
            return false;
        }
    }
}
