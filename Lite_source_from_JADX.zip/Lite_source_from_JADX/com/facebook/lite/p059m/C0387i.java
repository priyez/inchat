package com.facebook.lite.p059m;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.os.Build;
import android.util.Log;
import android.view.SurfaceHolder;
import com.facebook.lite.C0260h;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.aw;
import com.facebook.lite.net.C0396j;
import com.facebook.lite.net.C0401d;
import com.facebook.lite.net.C0403i;
import com.facebook.lite.net.C0407l;
import com.facebook.lite.net.C0411r;
import com.facebook.lite.net.ConnectivityReceiver;
import com.facebook.lite.net.p066a.C0393a;
import com.facebook.lite.net.p066a.C0394b;
import com.facebook.lite.p049a.p052c.C0270d;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p053b.C0299m;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p053b.C0302p;
import com.facebook.lite.p055c.C0305a;
import com.facebook.lite.p056d.C0311c;
import com.facebook.lite.p056d.C0313f;
import com.facebook.lite.p057e.C0320a;
import com.facebook.lite.p057e.C0322c;
import com.facebook.lite.p057e.C0323d;
import com.facebook.lite.p057e.C0328h;
import com.facebook.lite.p058f.C0336d;
import com.facebook.lite.p060g.C0343a;
import com.facebook.lite.p061h.C0345a;
import com.facebook.lite.p062j.C0356d;
import com.facebook.lite.p062j.C0357e;
import com.facebook.lite.p062j.C0366n;
import com.facebook.lite.ui.C0460b;
import com.facebook.lite.ui.gl.EGLWrapper;
import com.facebook.lite.widget.DummySurfaceView;
import com.facebook.lite.widget.ad;
import com.facebook.p031b.C0184o;
import com.facebook.p038e.C0248h;
import com.facebook.p038e.C0249i;
import com.facebook.p038e.C0250j;
import com.facebook.p038e.C0252m;
import com.facebook.p038e.C0254o;
import com.facebook.p038e.p040b.p041a.p042a.p043a.C0216b;
import com.facebook.p038e.p045d.C0242l;
import com.p008a.p009a.p010a.C0031b;
import com.p008a.p009a.p010a.p011a.C0004a;
import com.p008a.p009a.p010a.p011a.C0007d;
import com.p008a.p009a.p010a.p012b.C0014c;
import com.p008a.p009a.p010a.p012b.C0015d;
import com.p008a.p009a.p010a.p012b.C0016g;
import com.p008a.p009a.p010a.p012b.C0017i;
import com.p008a.p009a.p010a.p012b.C0018j;
import com.p008a.p009a.p010a.p012b.C0019m;
import com.p008a.p009a.p010a.p012b.C0020n;
import com.p008a.p009a.p010a.p012b.C0025b;
import com.p008a.p009a.p010a.p012b.C0026e;
import com.p008a.p009a.p010a.p012b.C0027f;
import com.p008a.p009a.p010a.p012b.C0028h;
import com.p008a.p009a.p010a.p012b.C0029k;
import com.p008a.p009a.p010a.p012b.C0030l;
import com.p008a.p009a.p010a.p013c.C0013a;
import com.p008a.p009a.p010a.p013c.C0021b;
import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p014e.C0045a;
import com.p008a.p009a.p010a.p015g.C0023a;
import com.p008a.p009a.p010a.p016h.C0051c;
import com.p008a.p009a.p010a.p016h.C0054f;
import com.p008a.p009a.p010a.p016h.C0055g;
import com.p008a.p009a.p010a.p017d.C0039f;
import com.p008a.p009a.p010a.p019i.C0057a;
import com.p008a.p009a.p010a.p019i.C0058b;
import com.p008a.p009a.p010a.p019i.C0059c;
import com.p008a.p009a.p010a.p019i.C0060d;
import com.p008a.p009a.p010a.p019i.C0061e;
import com.p008a.p009a.p010a.p019i.C0062f;
import com.p008a.p009a.p010a.p019i.C0063g;
import com.p008a.p009a.p010a.p019i.C0064h;
import com.p008a.p009a.p010a.p020j.C0067c;
import com.p008a.p009a.p010a.p022l.C0074c;
import com.p008a.p009a.p010a.p022l.C0077f;
import com.p008a.p009a.p010a.p022l.C0078g;
import com.p008a.p009a.p010a.p022l.C0079h;
import com.p008a.p009a.p010a.p022l.C0080i;
import com.p008a.p009a.p010a.p022l.C0082k;
import com.p008a.p009a.p010a.p022l.C0089s;
import com.p008a.p009a.p010a.p022l.C0093w;
import com.p008a.p009a.p010a.p022l.C0094y;
import com.p008a.p009a.p010a.p023m.C0099a;
import com.p008a.p009a.p010a.p023m.C0114f;
import com.p008a.p009a.p010a.p023m.C0115e;
import com.p008a.p009a.p010a.p023m.C0116b;
import com.p008a.p009a.p010a.p023m.C0118d;
import com.p008a.p009a.p010a.p023m.C0121i;
import com.p008a.p009a.p010a.p023m.C0123k;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;
import javax.microedition.khronos.opengles.GL11;
import p000a.p001a.C0001b;

/* renamed from: com.facebook.lite.m.i */
public final class C0387i extends C0013a implements C0031b, C0014c, C0015d, C0027f, C0016g, C0028h, C0017i, C0029k, C0030l, C0021b, C0022b, C0023a, C0061e, C0077f, C0079h, C0252m, Runnable {
    private static final Random f1493f;
    private static final List f1494g;
    private C0007d f1495A;
    private boolean f1496B;
    private boolean f1497C;
    private boolean f1498D;
    private final C0025b f1499E;
    private final C0059c f1500F;
    private C0396j f1501G;
    private int f1502H;
    private boolean f1503I;
    private int f1504J;
    private C0386h f1505K;
    private long f1506L;
    private final C0062f f1507M;
    private final C0393a f1508N;
    private C0394b f1509O;
    private final C0039f f1510P;
    private String[] f1511Q;
    private int f1512R;
    private short f1513S;
    private short f1514T;
    private short f1515U;
    private String f1516V;
    private String f1517W;
    private long f1518X;
    private boolean f1519Y;
    private final C0022b f1520Z;
    public boolean f1521a;
    private final C0018j aA;
    private final C0082k aB;
    private final C0094y aC;
    private final int aa;
    private final C0123k ab;
    private byte ac;
    private int ad;
    private final short[] ae;
    private final short[] af;
    private final String[] ag;
    private final C0357e ah;
    private final C0366n ai;
    private boolean aj;
    private boolean ak;
    private final C0078g al;
    private final C0055g am;
    private final C0060d an;
    private short ao;
    private final int ap;
    private final C0064h aq;
    private String ar;
    private int as;
    private final C0299m at;
    private final C0340j au;
    private byte av;
    private long aw;
    private final Object ax;
    private C0055g ay;
    private Integer az;
    public C0067c f1522d;
    protected final C0336d f1523e;
    private boolean f1524h;
    private String[] f1525i;
    private final C0074c f1526j;
    private final C0004a f1527k;
    private String f1528l;
    private final C0057a f1529m;
    private C0305a f1530n;
    private final C0045a f1531o;
    private final C0403i f1532p;
    private int f1533q;
    private int f1534r;
    private final C0058b f1535s;
    private final Context f1536t;
    private final long f1537u;
    private int f1538v;
    private final C0323d f1539w;
    private int f1540x;
    private Integer f1541y;
    private final C0001b f1542z;

    static {
        f1493f = new Random(System.currentTimeMillis() + ((long) Runtime.getRuntime().hashCode()));
        f1494g = Arrays.asList(new Byte[]{Byte.valueOf((byte) 3), Byte.valueOf((byte) 6), Byte.valueOf((byte) 2)});
    }

    public C0387i(Context context, C0063g c0063g, C0051c c0051c, C0060d c0060d, C0057a c0057a, C0058b c0058b, C0059c c0059c, C0064h c0064h, C0078g c0078g, C0045a c0045a, C0062f c0062f, C0340j c0340j, C0026e c0026e, C0020n c0020n, C0004a c0004a, C0305a c0305a) {
        int nextInt;
        this.f1521a = false;
        this.f1538v = -1;
        this.f1539w = aK();
        this.f1540x = -1;
        this.f1541y = null;
        this.f1542z = new C0001b();
        this.f1497C = false;
        this.f1502H = 0;
        this.f1505K = null;
        this.f1506L = -1;
        this.f1513S = (short) 0;
        this.f1515U = (short) 7;
        this.f1516V = "";
        this.ab = new C0123k();
        this.ac = (byte) 1;
        this.ad = 0;
        this.ae = new short[10];
        this.af = new short[10];
        this.ag = new String[10];
        this.ah = new C0357e();
        this.ai = new C0366n(this);
        this.ao = (short) 2000;
        this.as = 4;
        this.aw = 0;
        this.ax = new Object();
        this.f1537u = System.currentTimeMillis();
        this.f1536t = context;
        this.an = c0060d;
        this.f1529m = c0057a;
        this.f1535s = c0058b;
        this.f1500F = c0059c;
        this.aq = c0064h;
        this.al = c0078g;
        this.f1531o = c0045a;
        this.f1507M = c0062f;
        this.f1527k = c0004a;
        this.f1499E = new C0343a(this, c0026e, c0020n);
        this.f1520Z = this.f1499E;
        this.aA = this.f1499E;
        this.ay = new C0055g(this.f1520Z);
        c0063g.m405a(this.f1520Z, this.f1499E);
        this.am = new C0055g(c0051c, c0060d.m392j(), this.f1520Z, c0060d.m387e());
        aX();
        this.f1510P = new C0039f(this.f1520Z);
        this.aB = c0063g.m406u();
        this.at = aM();
        this.f1499E.m169a(this.at);
        C0055g c0055g = new C0055g(this.f1520Z);
        this.a_ = new C0345a(this, c0055g);
        m97a(this.a_);
        if (m96A()) {
            ((C0345a) this.a_).m2472c(2);
        }
        this.f1499E.m97a(this.a_);
        C0380b.m2558a().m2560a(this.f1499E);
        ClientApplication.m1690b();
        this.f1532p = ClientApplication.m1693e().m2394a(this.a_);
        this.f1508N = new C0393a(context, this.f1507M);
        if (C0336d.f1316a) {
            this.f1523e = new C0336d();
        } else {
            this.f1523e = null;
        }
        this.aC = new C0460b(this.f1520Z, this.at, this.aB, this, this.aA, this, this.am, this, (C0345a) this.a_, this.f1499E);
        this.aB.m647a(this.aC);
        this.f1499E.m170a(this.aC);
        this.at.m2051a(this.aC);
        this.at.m2052a(this.aC);
        this.f1530n = c0305a;
        c0055g.m358a(4, (int) (System.currentTimeMillis() - System.currentTimeMillis()));
        this.f1522d = new C0067c(this, this.at);
        int i = 0;
        do {
            nextInt = f1493f.nextInt();
            if (nextInt != 0) {
                break;
            }
            i++;
        } while (i < 5);
        this.ap = nextInt;
        this.aa = aE();
        m2619j(this.aa + 1);
        ConnectivityReceiver.m2723a(new C0389k(this));
        if (m96A()) {
            this.a_.m244a(3, (int) (System.currentTimeMillis() - this.f1537u));
        }
        C0184o.m1401a().m1450a("client_id", Long.toString(m2632G()));
        this.au = c0340j;
        if (aw.f1162a) {
            this.ah.m2514a(this.f1534r > 0);
        }
        this.f1526j = new C0074c();
        C0248h.m1653a().m1659a(this, this.ah, aF(), aD());
    }

    private static String m2570a(int i, String str) {
        return "(" + i + " times)" + str;
    }

    private static long m2611f(int i) {
        return Math.abs((long) f1493f.nextInt()) % ((long) i);
    }

    private void m2574a(C0027f c0027f) {
        C0121i j = c0027f.m224j();
        int b = j.m1201b();
        for (int i = 0; i < b; i++) {
            this.ab.m1217a(j.m1202b(i), c0027f);
        }
    }

    public final void m2678a(String[] strArr) {
        m2601c(strArr);
        if (am()) {
            this.aC.m989c();
            aU();
        }
    }

    public final void m2654a(byte b) {
        throw new UnsupportedOperationException("backgroundChange  shouldn't be called for android");
    }

    public final void m2664a(long j) {
        this.f1526j.m585a(j);
    }

    public final void m2687b(boolean z) {
        if (this.f1501G != null) {
            this.f1501G.m2749f();
            this.f1501G.m2744b();
        }
        if (z && this.f1521a && this.ao != (short) 0) {
            this.aC.m1004f(this.aC.m1020l());
            this.f1538v = this.aA.m110a(this, (long) this.ao);
        } else if (z) {
            aA();
        }
    }

    public final void m2689c() {
        this.aC.m1033r(2);
        if (this.aC.m992c(this.aC.m1026o())) {
            this.aC.m1004f(this.aC.m1007g());
        }
    }

    public final void m2692d() {
        this.aC.m1004f(this.aC.m1026o());
    }

    public final void m2694e() {
        if (am()) {
            this.f1540x = -1;
            this.aC.m938C();
        } else {
            m2606d(true);
        }
        this.f1533q = 0;
        this.f1504J = this.aA.m110a(this, 700);
    }

    public final void m2697f() {
    }

    public final void m2677a(boolean z, boolean z2, byte b) {
        this.ac = b;
        new StringBuilder("conn/connectorFailure/retry:").append(this.f1533q).append("/").append(System.currentTimeMillis());
        this.aA.m111a(this.f1504J);
        if (aI() == 0) {
            aQ();
        }
        C0294h.m1957a(this.f1499E);
        if (!C0294h.m1974f()) {
            az();
        } else if (this.f1533q < C0403i.f1627b) {
            this.f1533q++;
            this.f1540x = this.aA.m110a(this, C0403i.f1626a[this.f1533q - 1]);
        } else if (aO()) {
            C0407l.m2881a().m2889c();
            aP();
            this.f1499E.m171a(m2653a(true, false));
        } else {
            az();
        }
    }

    public final boolean m2681a(byte[] bArr, int i, int i2, int i3, int i4, int i5, int i6, boolean z, int i7, C0089s c0089s, int i8) {
        try {
            return this.f1510P.m280a(bArr, i, i2, i3, i4, i5, i6, z, i7, c0089s, i8);
        } catch (Throwable e) {
            this.f1520Z.m124a((short) 58, null, e);
            return false;
        }
    }

    public final void m2627B() {
        this.f1499E.m188b(new C0382d(this));
    }

    private void ar() {
        this.aC.m946K();
    }

    public final void m2665a(C0115e c0115e) {
        if (this.f1501G != null) {
            this.f1501G.m2741a(c0115e);
        }
    }

    public final void m2698g() {
        m2606d(false);
    }

    public final long m2706o() {
        Runtime runtime = Runtime.getRuntime();
        return runtime.maxMemory() - runtime.totalMemory();
    }

    public final C0345a m2628C() {
        return (C0345a) this.a_;
    }

    public final C0007d m2629D() {
        return this.f1495A;
    }

    public final long m2630E() {
        Long c = m2652a().m365c(47);
        return (c == null || c.longValue() < 0 || c.longValue() > Long.MAX_VALUE) ? 86400000 : c.longValue();
    }

    public final C0057a m2709r() {
        return this.f1529m;
    }

    public final C0305a m2631F() {
        if (this.f1530n == null) {
            this.f1530n = new C0305a();
        }
        return this.f1530n;
    }

    public final long m2632G() {
        Long c = this.am.m365c(3);
        return c == null ? -1 : c.longValue();
    }

    public final Runnable m2653a(boolean z, boolean z2) {
        return new C0383e(this, z, z2);
    }

    public final C0403i m2633H() {
        return this.f1532p;
    }

    public final int m2699h() {
        return this.f1534r;
    }

    public final Context m2634I() {
        return this.f1536t;
    }

    public final long m2635J() {
        return this.f1537u;
    }

    public final C0336d m2636K() {
        return this.f1523e;
    }

    public final C0323d m2637L() {
        return this.f1539w;
    }

    public final long m2638M() {
        Long c = m2652a().m365c(45);
        return (c == null || c.longValue() < 0) ? 5000 : c.longValue();
    }

    public final Integer m2708q() {
        return this.f1541y;
    }

    public final C0025b m2639N() {
        return this.f1499E;
    }

    public final String m2640O() {
        return m2652a().m366d(20);
    }

    public final long m2641P() {
        Long c = m2652a().m365c(21);
        return c == null ? 0 : c.longValue();
    }

    public final C0059c m2710s() {
        return this.f1500F;
    }

    private C0396j as() {
        return this.f1501G;
    }

    public final int m2700i() {
        return 3;
    }

    public final C0022b m2642Q() {
        return this.f1520Z;
    }

    public final boolean m2643R() {
        Integer a = m2647V().m356a(63);
        if (a != null && a.intValue() == 1) {
            return true;
        }
        return false;
    }

    public final Integer m2644S() {
        return m2647V().m356a(71);
    }

    public final C0121i m2701j() {
        C0121i c0121i = new C0121i();
        c0121i.m1200a(12);
        c0121i.m1200a(13);
        c0121i.m1200a(17);
        c0121i.m1200a(64);
        c0121i.m1200a(65);
        c0121i.m1200a(25);
        c0121i.m1200a(53);
        c0121i.m1200a(41);
        c0121i.m1200a(34);
        c0121i.m1200a(20);
        c0121i.m1200a(43);
        c0121i.m1200a(45);
        c0121i.m1200a(54);
        c0121i.m1200a(55);
        c0121i.m1200a(57);
        c0121i.m1200a(63);
        c0121i.m1200a(69);
        c0121i.m1200a(78);
        c0121i.m1200a(24);
        c0121i.m1200a(91);
        c0121i.m1200a(89);
        return c0121i;
    }

    public final C0357e m2645T() {
        return this.ah;
    }

    public final C0366n m2646U() {
        return this.ai;
    }

    public final C0055g m2647V() {
        return this.am;
    }

    public final int m2648W() {
        Integer a = m2652a().m356a(28);
        return (a == null || a.intValue() < 0 || a.intValue() > 100) ? 70 : a.intValue();
    }

    public final C0060d m2712u() {
        return this.an;
    }

    public final int m2704m() {
        return this.as;
    }

    public final C0080i m2714w() {
        return this.at;
    }

    public final C0055g m2652a() {
        return this.ay;
    }

    public final int m2649X() {
        if (this.az != null) {
            return this.az.intValue();
        }
        Integer a = this.am.m356a(35);
        Long c = this.am.m365c(36);
        if (a == null || c == null || System.currentTimeMillis() - c.longValue() >= 3600000) {
            return Math.abs(a == null ? 0 : (a.intValue() / 100000) * 100000) + Math.abs(this.ap % 100000);
        }
        m2592b(a);
        return a.intValue();
    }

    public final long m2650Y() {
        return C0313f.m2224b(m2634I()).m2231f();
    }

    public final C0067c a_() {
        return this.f1522d;
    }

    public final C0019m m2651Z() {
        return this.f1499E;
    }

    public final C0094y aa() {
        return this.aC;
    }

    public final void m2705n() {
        throw new UnsupportedOperationException("hideNotify not supported on Android");
    }

    public final boolean ab() {
        return m2618i(33);
    }

    public final boolean ac() {
        Integer a = m2652a().m356a(46);
        return a != null && a.intValue() > 0;
    }

    public final boolean ad() {
        return m2618i(30);
    }

    public final boolean ae() {
        Integer a = m2652a().m356a(48);
        return a != null && (a.intValue() & 32) == 32;
    }

    public final boolean af() {
        return this.f1496B;
    }

    public final boolean ag() {
        return this.f1501G != null && this.f1501G.m2746c();
    }

    public final boolean ah() {
        return this.f1497C;
    }

    private boolean at() {
        return C0313f.m2224b(m2634I()).m2232g();
    }

    public final boolean m2696e(int i) {
        return this.ab.m1220b(i) != null;
    }

    public final boolean ai() {
        Integer a = m2652a().m356a(48);
        if (a == null || (a.intValue() & 1) != 1) {
            return false;
        }
        return true;
    }

    public final boolean aj() {
        return m2618i(31);
    }

    public final boolean ak() {
        return m2618i(35);
    }

    public final boolean al() {
        return m2618i(34);
    }

    public final boolean am() {
        return this.aw != 0;
    }

    public final boolean an() {
        return this.f1498D;
    }

    public final void m2703l() {
        m2600c(false);
    }

    private void m2573a(int i, String str, boolean z, String[] strArr, String[] strArr2, byte[] bArr) {
        if (this.f1505K != null) {
            this.f1505K.m2564a();
            this.f1505K = null;
        }
        this.f1505K = new C0386h(this, i, str, z, strArr, strArr2, bArr);
        this.f1505K.start();
    }

    public final void m2662a(int i, C0114f c0114f) {
        C0027f c0027f = (C0027f) this.ab.m1220b(i);
        if (c0027f == null) {
            m2675a((short) 2, (short) 47, Integer.toString(i) + ",", (long) (c0114f.m1129o() + 1));
        } else {
            c0027f.m223b(i, c0114f);
        }
        if (i == 11 || i == 42) {
            C0380b.m2558a().m2561a(C0381c.SCREEN_DATA_RECEIVED);
        }
    }

    public final void m2707p() {
        this.aC.m1033r(3);
    }

    public final byte[] m2688b(int i) {
        String str = null;
        try {
            return new byte[i];
        } catch (Throwable e) {
            this.f1520Z.m124a((short) 279, str, e);
            return str;
        }
    }

    public final void m2658a(int i, int i2, int i3, int i4, long j, int i5, int i6, boolean z, int i7, int i8) {
        Integer a = m2652a().m356a(9);
        if (a != null && a.intValue() != 0 && C0387i.m2611f(a.intValue()) == 0) {
            m2571a((byte) 1, i, i2, i3, i4, j, i5, i6, z, i7, i8);
        }
    }

    public final void m2684b(int i, int i2, int i3, int i4, long j, int i5, int i6, boolean z, int i7, int i8) {
        Integer a = m2652a().m356a(9);
        if (a != null && a.intValue() != 0 && C0387i.m2611f(a.intValue()) == 0) {
            m2571a((byte) 3, i, i2, i3, i4, j, i5, i6, z, i7, i8);
        }
    }

    public final void m2685b(int i, C0114f c0114f) {
        if (!m2602c(i, c0114f)) {
            m2674a((short) 2, (short) 2, null);
        }
    }

    public final void m2661a(int i, int i2, boolean z, int i3) {
        if (aw.f1162a) {
            this.ai.m2535a().m2527d(i2);
        }
        Integer a = m2652a().m356a(10);
        int a2 = C0242l.m1631a(ClientApplication.m1691c().m2377I());
        int b = C0242l.m1634b(ClientApplication.m1691c().m2377I());
        boolean g = C0294h.m1976g();
        if (a != null && a.intValue() != 0 && C0387i.m2611f(a.intValue()) == 0) {
            m2572a(i, i2, z, ClientApplication.m1691c().m2378J().m44a(), i3, b, a2, g);
        }
    }

    private void m2578a(String str, boolean z) {
        this.an.m379a(str, z, this);
    }

    public final void m2676a(boolean z) {
        m2600c(true);
        if (z) {
            this.f1521a = true;
            m2627B();
        }
    }

    public final boolean ao() {
        return this.aj;
    }

    public final boolean ap() {
        return this.ak;
    }

    public final boolean m2679a(byte b, C0114f c0114f) {
        return m2582a(b, c0114f, false);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean m2582a(byte r11, com.p008a.p009a.p010a.p023m.C0114f r12, boolean r13) {
        /*
        r10 = this;
        r7 = 2;
        r0 = 0;
        r9 = 1;
        switch(r11) {
            case 1: goto L_0x0007;
            case 3: goto L_0x0105;
            case 6: goto L_0x0192;
            case 7: goto L_0x0157;
            case 14: goto L_0x0167;
            case 16: goto L_0x00f6;
            case 17: goto L_0x01e7;
            case 19: goto L_0x003b;
            case 25: goto L_0x0148;
            case 27: goto L_0x002e;
            case 35: goto L_0x01f0;
            case 36: goto L_0x02a1;
            case 37: goto L_0x02ac;
            case 38: goto L_0x0174;
            case 39: goto L_0x02bb;
            case 46: goto L_0x019f;
            case 48: goto L_0x02e8;
            case 49: goto L_0x000a;
            case 51: goto L_0x000a;
            case 52: goto L_0x02ef;
            case 55: goto L_0x000c;
            case 58: goto L_0x0315;
            case 59: goto L_0x0320;
            case 60: goto L_0x004f;
            case 63: goto L_0x005f;
            case 65: goto L_0x009d;
            case 66: goto L_0x011f;
            case 72: goto L_0x027d;
            case 77: goto L_0x00bf;
            case 81: goto L_0x0240;
            default: goto L_0x0006;
        };
    L_0x0006:
        return r0;
    L_0x0007:
        r10.m2627B();	 Catch:{ Exception -> 0x0016 }
    L_0x000a:
        r0 = r9;
        goto L_0x0006;
    L_0x000c:
        r0 = r12.m1121g();	 Catch:{ Exception -> 0x0016 }
        r1 = r10.an;	 Catch:{ Exception -> 0x0016 }
        r1.m375a(r0);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x0016:
        r0 = move-exception;
        r1 = r10.f1520Z;
        r2 = 18;
        r3 = new java.lang.StringBuilder;
        r4 = "c=";
        r3.<init>(r4);
        r3 = r3.append(r11);
        r3 = r3.toString();
        r1.m124a(r2, r3, r0);
        goto L_0x000a;
    L_0x002e:
        r0 = new com.a.a.a.m.b;	 Catch:{ Exception -> 0x0016 }
        r0.<init>();	 Catch:{ Exception -> 0x0016 }
        r1 = 1;
        r0.m1155a(r1);	 Catch:{ Exception -> 0x0016 }
        r10.m2587b(r11, r0);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x003b:
        r0 = r10.aC;	 Catch:{ Exception -> 0x0016 }
        r1 = 1;
        r0.m986b(r1);	 Catch:{ Exception -> 0x0016 }
        r0 = r12.m1124j();	 Catch:{ Exception -> 0x0016 }
        r1 = r10.aC;	 Catch:{ Exception -> 0x0016 }
        r1 = r1.m1034s();	 Catch:{ Exception -> 0x0016 }
        r1.m729c(r0);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x004f:
        r0 = r12.m1125k();	 Catch:{ Exception -> 0x0016 }
        r1 = r12.m1120f();	 Catch:{ Exception -> 0x0016 }
        r2 = r12.m1120f();	 Catch:{ Exception -> 0x0016 }
        r10.m2579a(r0, r1, r2);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x005f:
        r1 = r12.m1120f();	 Catch:{ Exception -> 0x0016 }
        if (r1 == 0) goto L_0x0094;
    L_0x0065:
        r1 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r2 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r3 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r4 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r5 = r12.m1120f();	 Catch:{ Exception -> 0x0016 }
        if (r5 == 0) goto L_0x0090;
    L_0x007b:
        r6 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r7 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r8 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
    L_0x0087:
        r0 = com.facebook.lite.ClientApplication.m1692d();	 Catch:{ Exception -> 0x0016 }
        r0.m1772a(r1, r2, r3, r4, r5, r6, r7, r8);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x0090:
        r8 = r2;
        r7 = r1;
        r6 = r0;
        goto L_0x0087;
    L_0x0094:
        r0 = com.facebook.lite.ClientApplication.m1692d();	 Catch:{ Exception -> 0x0016 }
        r0.m1791i();	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x009d:
        r0 = new android.content.Intent;	 Catch:{ Exception -> 0x00b5 }
        r1 = "android.intent.action.VIEW";
        r2 = r12.m1125k();	 Catch:{ Exception -> 0x00b5 }
        r2 = android.net.Uri.parse(r2);	 Catch:{ Exception -> 0x00b5 }
        r0.<init>(r1, r2);	 Catch:{ Exception -> 0x00b5 }
        r1 = com.facebook.lite.ClientApplication.m1692d();	 Catch:{ Exception -> 0x00b5 }
        r1.startActivity(r0);	 Catch:{ Exception -> 0x00b5 }
        goto L_0x000a;
    L_0x00b5:
        r0 = move-exception;
        r1 = "ClientSession";
        r2 = "intent command failed";
        android.util.Log.e(r1, r2, r0);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x00bf:
        r1 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r2 = new java.util.ArrayList;	 Catch:{ Exception -> 0x0016 }
        r2.<init>();	 Catch:{ Exception -> 0x0016 }
        r0 = 0;
        r0 = java.lang.Integer.valueOf(r0);	 Catch:{ Exception -> 0x0016 }
    L_0x00cd:
        r3 = r0.intValue();	 Catch:{ Exception -> 0x0016 }
        if (r3 >= r1) goto L_0x00e9;
    L_0x00d3:
        r3 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r3 = java.lang.Integer.valueOf(r3);	 Catch:{ Exception -> 0x0016 }
        r2.add(r3);	 Catch:{ Exception -> 0x0016 }
        r0 = r0.intValue();	 Catch:{ Exception -> 0x0016 }
        r0 = r0 + 1;
        r0 = java.lang.Integer.valueOf(r0);	 Catch:{ Exception -> 0x0016 }
        goto L_0x00cd;
    L_0x00e9:
        r0 = com.facebook.lite.ClientApplication.m1691c();	 Catch:{ Exception -> 0x0016 }
        r0 = r0.m2377I();	 Catch:{ Exception -> 0x0016 }
        com.facebook.lite.notification.C0422k.m2935a(r0, r2);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x00f6:
        r0 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r1 = r10.aC;	 Catch:{ Exception -> 0x0016 }
        r1 = r1.m1018k();	 Catch:{ Exception -> 0x0016 }
        r10.m2588b(r1, r0);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x0105:
        r1 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r2 = r12.m1121g();	 Catch:{ Exception -> 0x0016 }
        r3 = r10.aC;	 Catch:{ Exception -> 0x0016 }
        r4 = r10.f1524h;	 Catch:{ Exception -> 0x0016 }
        if (r13 != 0) goto L_0x0114;
    L_0x0113:
        r0 = r9;
    L_0x0114:
        r0 = r3.m978a(r1, r2, r4, r0);	 Catch:{ Exception -> 0x0016 }
        if (r0 == 0) goto L_0x000a;
    L_0x011a:
        r10.m2656a(r1);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x011f:
        r0 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r1 = r12.m1124j();	 Catch:{ Exception -> 0x0016 }
        r2 = r12.m1120f();	 Catch:{ Exception -> 0x0016 }
        r3 = r10.at;	 Catch:{ Exception -> 0x0016 }
        r4 = 1;
        r3 = r3.m2067d(r0, r4);	 Catch:{ Exception -> 0x0016 }
        if (r3 == 0) goto L_0x0141;
    L_0x0134:
        r3 = r10.at;	 Catch:{ Exception -> 0x0016 }
        r4 = 1;
        r3.m2041a(r4, r0);	 Catch:{ Exception -> 0x0016 }
        if (r2 == 0) goto L_0x0141;
    L_0x013c:
        r2 = r10.f1522d;	 Catch:{ Exception -> 0x0016 }
        r2.m429d(r1);	 Catch:{ Exception -> 0x0016 }
    L_0x0141:
        r1 = r10.f1530n;	 Catch:{ Exception -> 0x0016 }
        r1.m2194b(r0);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x0148:
        r0 = r10.aC;	 Catch:{ Exception -> 0x0016 }
        r1 = 1;
        r2 = 0;
        r0.m976a(r1, r2);	 Catch:{ Exception -> 0x0016 }
        r0 = r10.aC;	 Catch:{ Exception -> 0x0016 }
        r1 = 1;
        r0.m975a(r1);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x0157:
        r0 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r1 = r10.aC;	 Catch:{ Exception -> 0x0016 }
        r1.m1014i(r0);	 Catch:{ Exception -> 0x0016 }
        r0 = r10.aC;	 Catch:{ Exception -> 0x0016 }
        r0.m939D();	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x0167:
        r0 = r10.f1499E;	 Catch:{ Exception -> 0x0016 }
        r1 = 1;
        r2 = 0;
        r1 = r10.m2653a(r1, r2);	 Catch:{ Exception -> 0x0016 }
        r0.m171a(r1);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x0174:
        r0 = r12.m1121g();	 Catch:{ Exception -> 0x0016 }
        r0 = com.facebook.lite.net.p066a.C0394b.m2727a(r0);	 Catch:{ Exception -> 0x0016 }
        r1 = r10.f1508N;	 Catch:{ Exception -> 0x0016 }
        r1.m2726a(r0);	 Catch:{ Exception -> 0x0016 }
        r1 = r10.f1509O;	 Catch:{ Exception -> 0x0016 }
        if (r1 == r0) goto L_0x000a;
    L_0x0185:
        r1 = r10.m2569a(r0);	 Catch:{ Exception -> 0x0016 }
        r2 = r10.f1501G;	 Catch:{ Exception -> 0x0016 }
        r2.m2742a(r1);	 Catch:{ Exception -> 0x0016 }
        r10.f1509O = r0;	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x0192:
        r0 = r12.m1125k();	 Catch:{ Exception -> 0x0016 }
        r1 = r12.m1120f();	 Catch:{ Exception -> 0x0016 }
        r10.m2578a(r0, r1);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x019f:
        r12.m1125k();	 Catch:{ Exception -> 0x0016 }
        r12.m1125k();	 Catch:{ Exception -> 0x0016 }
        r0 = r12.m1121g();	 Catch:{ Exception -> 0x0016 }
        r1 = com.facebook.lite.p059m.C0387i.m2583a(r12);	 Catch:{ Exception -> 0x0016 }
        r2 = r12.m1121g();	 Catch:{ Exception -> 0x0016 }
        r3 = com.facebook.lite.p059m.C0387i.m2583a(r12);	 Catch:{ Exception -> 0x0016 }
        r4 = r12.m1121g();	 Catch:{ Exception -> 0x0016 }
        r5 = com.facebook.lite.p059m.C0387i.m2583a(r12);	 Catch:{ Exception -> 0x0016 }
        r6 = r10.an;	 Catch:{ Exception -> 0x0016 }
        r6 = r6.m395m();	 Catch:{ Exception -> 0x0016 }
        if (r6 != 0) goto L_0x01cf;
    L_0x01c5:
        r2 = new com.a.a.a.m.b;	 Catch:{ Exception -> 0x0016 }
        r2.<init>(r1);	 Catch:{ Exception -> 0x0016 }
        r10.m2679a(r0, r2);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x01cf:
        if (r6 != r9) goto L_0x01db;
    L_0x01d1:
        r0 = new com.a.a.a.m.b;	 Catch:{ Exception -> 0x0016 }
        r0.<init>(r3);	 Catch:{ Exception -> 0x0016 }
        r10.m2679a(r2, r0);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x01db:
        if (r6 != r7) goto L_0x000a;
    L_0x01dd:
        r0 = new com.a.a.a.m.b;	 Catch:{ Exception -> 0x0016 }
        r0.<init>(r5);	 Catch:{ Exception -> 0x0016 }
        r10.m2679a(r4, r0);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x01e7:
        r0 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r10.m2614g(r0);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x01f0:
        r0 = r12.m1121g();	 Catch:{ Exception -> 0x0016 }
        r2 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r1 = r12.m1124j();	 Catch:{ Exception -> 0x0016 }
        r4 = r12.m1121g();	 Catch:{ Exception -> 0x0016 }
        r5 = r12.m1124j();	 Catch:{ Exception -> 0x0016 }
        r3 = r12.m1120f();	 Catch:{ Exception -> 0x0016 }
        r6 = r10.at;	 Catch:{ Exception -> 0x0016 }
        r6 = r6.m2067d(r2, r0);	 Catch:{ Exception -> 0x0016 }
        if (r6 == 0) goto L_0x000a;
    L_0x0210:
        r6 = r10.f1530n;	 Catch:{ Exception -> 0x0016 }
        r6 = r6.m2200e(r2);	 Catch:{ Exception -> 0x0016 }
        if (r6 == 0) goto L_0x000a;
    L_0x0218:
        r6 = r10.at;	 Catch:{ Exception -> 0x0016 }
        r6 = r6.m2064c(r2, r0);	 Catch:{ Exception -> 0x0016 }
        if (r6 != 0) goto L_0x022a;
    L_0x0220:
        r0 = r10.f1520Z;	 Catch:{ Exception -> 0x0016 }
        r1 = 2;
        r2 = 298; // 0x12a float:4.18E-43 double:1.47E-321;
        r0.m125a(r1, r2);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x022a:
        r0 = r10.f1522d;	 Catch:{ Exception -> 0x0016 }
        r0.m424a(r3);	 Catch:{ Exception -> 0x0016 }
        r0 = r10.f1522d;	 Catch:{ Exception -> 0x0016 }
        r3 = new com.a.a.a.m.b;	 Catch:{ Exception -> 0x0016 }
        r3.<init>(r6);	 Catch:{ Exception -> 0x0016 }
        r0.m422a(r1, r2, r3, r4, r5);	 Catch:{ Exception -> 0x0016 }
        r0 = r10.f1530n;	 Catch:{ Exception -> 0x0016 }
        r0.m2196c(r2);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x0240:
        r0 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r1 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r2 = r10.at;	 Catch:{ Exception -> 0x0016 }
        r3 = 1;
        r2 = r2.m2067d(r0, r3);	 Catch:{ Exception -> 0x0016 }
        if (r2 == 0) goto L_0x000a;
    L_0x0251:
        r2 = r10.at;	 Catch:{ Exception -> 0x0016 }
        r3 = 1;
        r2 = r2.m2064c(r0, r3);	 Catch:{ Exception -> 0x0016 }
        r3 = r10.at;	 Catch:{ Exception -> 0x0016 }
        r4 = 1;
        r3.m2041a(r4, r0);	 Catch:{ Exception -> 0x0016 }
        r3 = r10.m2682a(r2);	 Catch:{ Exception -> 0x0016 }
        r4 = r10.at;	 Catch:{ Exception -> 0x0016 }
        r5 = 0;
        r5 = r3[r5];	 Catch:{ Exception -> 0x0016 }
        r6 = 1;
        r3 = r3[r6];	 Catch:{ Exception -> 0x0016 }
        r4.m2043a(r1, r2, r5, r3);	 Catch:{ Exception -> 0x0016 }
        r2 = com.facebook.lite.ClientApplication.m1691c();	 Catch:{ Exception -> 0x0016 }
        r2.m2444e(r1);	 Catch:{ Exception -> 0x0016 }
        r2 = r10.m2631F();	 Catch:{ Exception -> 0x0016 }
        r2.m2188a(r0, r1);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x027d:
        r0 = r12.m1124j();	 Catch:{ Exception -> 0x0016 }
    L_0x0281:
        r1 = r10.f1530n;	 Catch:{ Exception -> 0x0016 }
        r1 = r1.m2203h();	 Catch:{ Exception -> 0x0016 }
        if (r1 == 0) goto L_0x0295;
    L_0x0289:
        r1 = r10.f1522d;	 Catch:{ Exception -> 0x0016 }
        r2 = r10.f1530n;	 Catch:{ Exception -> 0x0016 }
        r2 = r2.m2193b();	 Catch:{ Exception -> 0x0016 }
        r1.m420a(r2);	 Catch:{ Exception -> 0x0016 }
        goto L_0x0281;
    L_0x0295:
        r1 = r10.f1530n;	 Catch:{ Exception -> 0x0016 }
        r1.m2186a();	 Catch:{ Exception -> 0x0016 }
        r1 = r10.f1522d;	 Catch:{ Exception -> 0x0016 }
        r1.m421a(r0);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x02a1:
        r0 = r12.m1124j();	 Catch:{ Exception -> 0x0016 }
        r1 = r10.f1522d;	 Catch:{ Exception -> 0x0016 }
        r1.m429d(r0);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x02ac:
        r0 = r12.m1121g();	 Catch:{ Exception -> 0x0016 }
        r1 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r2 = r10.at;	 Catch:{ Exception -> 0x0016 }
        r2.m2041a(r0, r1);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x02bb:
        r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r1 = r12.m1124j();	 Catch:{ Exception -> 0x0016 }
        r12.m1124j();	 Catch:{ Exception -> 0x0016 }
        r2 = r12.m1121g();	 Catch:{ Exception -> 0x0016 }
        r3 = r12.m1124j();	 Catch:{ Exception -> 0x0016 }
        r12.m1124j();	 Catch:{ Exception -> 0x0016 }
        r4 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r5 = new int[r4];	 Catch:{ Exception -> 0x0016 }
    L_0x02d6:
        if (r0 >= r4) goto L_0x02e1;
    L_0x02d8:
        r6 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r5[r0] = r6;	 Catch:{ Exception -> 0x0016 }
        r0 = r0 + 1;
        goto L_0x02d6;
    L_0x02e1:
        r0 = r10.f1535s;	 Catch:{ Exception -> 0x0016 }
        r0.m370a(r1, r2, r3);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x02e8:
        r0 = r10.aq;	 Catch:{ Exception -> 0x0016 }
        r0.m408v();	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x02ef:
        r0 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r1 = r12.m1120f();	 Catch:{ Exception -> 0x0016 }
        r2 = r10.an;	 Catch:{ Exception -> 0x0016 }
        r0 = r2.m384c(r0);	 Catch:{ Exception -> 0x0016 }
        if (r1 == 0) goto L_0x000a;
    L_0x02ff:
        r1 = new com.a.a.a.m.b;	 Catch:{ Exception -> 0x0016 }
        r1.<init>();	 Catch:{ Exception -> 0x0016 }
        r2 = 76;
        r10.m2655a(r2, r1);	 Catch:{ Exception -> 0x0016 }
        r1.m1136a(r0);	 Catch:{ Exception -> 0x0016 }
        r0 = r10.as();	 Catch:{ Exception -> 0x0016 }
        r0.m2741a(r1);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x0315:
        r0 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r1 = r10.aq;	 Catch:{ Exception -> 0x0016 }
        r1.m407d(r0);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x0320:
        r0 = r12.m1122h();	 Catch:{ Exception -> 0x0016 }
        r1 = r12.m1121g();	 Catch:{ Exception -> 0x0016 }
        r2 = com.facebook.lite.p059m.C0387i.m2583a(r12);	 Catch:{ Exception -> 0x0016 }
        r3 = r12.m1121g();	 Catch:{ Exception -> 0x0016 }
        r4 = com.facebook.lite.p059m.C0387i.m2583a(r12);	 Catch:{ Exception -> 0x0016 }
        r5 = r10.f1500F;	 Catch:{ Exception -> 0x0016 }
        r0 = r5.m373a(r0);	 Catch:{ Exception -> 0x0016 }
        if (r0 == 0) goto L_0x0346;
    L_0x033c:
        r0 = new com.a.a.a.m.b;	 Catch:{ Exception -> 0x0016 }
        r0.<init>(r2);	 Catch:{ Exception -> 0x0016 }
        r10.m2679a(r1, r0);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
    L_0x0346:
        r0 = new com.a.a.a.m.b;	 Catch:{ Exception -> 0x0016 }
        r0.<init>(r4);	 Catch:{ Exception -> 0x0016 }
        r10.m2679a(r3, r0);	 Catch:{ Exception -> 0x0016 }
        goto L_0x000a;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.m.i.a(byte, com.a.a.a.m.f, boolean):boolean");
    }

    public final void m2660a(int i, int i2, String str) {
        if (am()) {
            C0115e c0116b = new C0116b();
            m2655a((byte) 72, c0116b);
            c0116b.m1141d(i);
            c0116b.m1141d(i2);
            c0116b.m1138b(str);
            as().m2741a(c0116b);
        }
    }

    public final void m2669a(String str, long j) {
        m2593b(str, j);
        if (am()) {
            aV();
        }
        this.aC.m989c();
    }

    public final void m2668a(String str) {
        if (am()) {
            C0115e c0116b = new C0116b();
            m2655a((byte) 75, c0116b);
            c0116b.m1136a(str != null);
            if (str != null) {
                c0116b.m1138b(str);
            }
            as().m2741a(c0116b);
        }
    }

    public final void m2686b(String str) {
        if (am()) {
            C0115e c0116b = new C0116b();
            m2655a((byte) 71, c0116b);
            c0116b.m1138b(str);
            as().m2741a(c0116b);
        }
    }

    public final void m2670a(String str, String str2, String str3) {
        if (am()) {
            C0115e c0116b = new C0116b();
            m2655a((byte) 86, c0116b);
            c0116b.m1138b(str);
            c0116b.m1138b(str2);
            c0116b.m1138b(str3);
            as().m2741a(c0116b);
        }
    }

    public final void m2655a(byte b, C0115e c0115e) {
        c0115e.m1135a((short) 0);
        c0115e.m1131a(b);
        c0115e.m1132a(aI());
        c0115e.m1141d(0);
    }

    public final int[] m2682a(byte[] bArr) {
        Options options = new Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bArr, 0, bArr.length, options);
        if (options.outWidth == -1 || options.outHeight == -1) {
            throw new RuntimeException("Error decoding image for width/height");
        }
        return new int[]{options.outWidth, options.outHeight};
    }

    public final void m2690c(int i) {
        this.a_.m243a(i);
    }

    public final void m2695e(int i, int i2) {
        this.a_.m244a(i, i2);
    }

    public final void m2711t() {
        throw new UnsupportedOperationException("reportConnectionAttempt should not be called on Android.");
    }

    public final void m2672a(short s, String str, Throwable th) {
        if (m2699h() > 0) {
            th.printStackTrace();
        }
        m2674a((short) 1, s, str + th.getClass().getName() + ": " + th.getMessage());
        Map hashMap = new HashMap();
        hashMap.put("logger_id", Short.toString(s));
        hashMap.put("logger_text", str);
        C0184o.m1401a().m1449a(th, hashMap);
        if (th instanceof OutOfMemoryError) {
            C0254o.m1684a();
        }
    }

    public final void m2663a(int i, boolean z, String str, int i2, byte[] bArr) {
        C0115e c0116b = new C0116b();
        m2655a((byte) 79, c0116b);
        c0116b.m1135a((short) i);
        c0116b.m1136a(z);
        if (z) {
            c0116b.m1138b(str);
        }
        c0116b.m1135a((short) i2);
        if (bArr == null) {
            c0116b.m1135a((short) 0);
        } else {
            c0116b.m1135a((short) bArr.length);
            c0116b.m1142d(bArr);
        }
        as().m2741a(c0116b);
    }

    public final void m2673a(short s, short s2) {
        m2674a(s, s2, null);
    }

    public final void m2674a(short s, short s2, String str) {
        if (str != null && str.equals(this.f1516V) && s == this.f1515U && s2 == this.f1513S && this.f1512R < 100) {
            this.f1512R++;
            return;
        }
        if (this.f1512R != 0) {
            m2599c(this.f1515U, this.f1513S, C0387i.m2570a(this.f1512R, this.f1516V));
        }
        m2599c(s, s2, str);
        this.f1515U = s;
        this.f1513S = s2;
        this.f1516V = str;
        this.f1512R = 0;
    }

    public final void m2675a(short s, short s2, String str, long j) {
        if (str == null) {
            m2674a(s, s2, Long.toString(j));
        } else {
            m2674a(s, s2, str + "," + Long.toString(j));
        }
    }

    public final boolean m2680a(C0249i c0249i) {
        try {
            String c0209b = C0250j.m1671a(c0249i).toString();
            if (at() && m2704m() > 0 && C0380b.m2558a().m2562b()) {
                m2612f(c0209b);
                aT();
                return true;
            }
        } catch (Throwable e) {
            Log.w("ClientSession", "honeyclient/logging fails for event " + c0249i.m1669c(), e);
        }
        return false;
    }

    public final void run() {
        ay();
        aW();
    }

    private void au() {
        if (this.f1501G.m2746c()) {
            C0115e c0116b = new C0116b(40);
            m2655a((byte) 56, c0116b);
            long currentTimeMillis = System.currentTimeMillis();
            c0116b.m1132a(currentTimeMillis - this.f1499E.m207j());
            c0116b.m1132a(currentTimeMillis - this.f1499E.m208k());
            c0116b.m1132a(currentTimeMillis - this.f1499E.m209l());
            as().m2741a(c0116b);
        }
    }

    private void m2587b(byte b, C0114f c0114f) {
        C0115e c0116b = new C0116b();
        m2655a((byte) 46, c0116b);
        c0116b.m1131a(b);
        c0114f.m1118e();
        c0116b.m1133a(c0114f);
        as().m2741a(c0116b);
    }

    public final void m2666a(C0320a c0320a) {
        List<List> a = ClientApplication.m1691c().m2379K().m2294a(c0320a.m2274d(), c0320a.m2272b());
        List arrayList = new ArrayList();
        for (List list : a) {
            arrayList.add(Long.valueOf(((Long) list.get(0)).longValue()));
        }
        try {
            long a2 = C0118d.m1182a(arrayList);
            C0115e c0116b = new C0116b();
            m2655a((byte) 94, c0116b);
            c0116b.m1132a(a2);
            as().m2741a(c0116b);
        } catch (Throwable e) {
            this.f1520Z.m124a((short) 293, null, e);
        }
    }

    private void m2614g(int i) {
        C0115e c0116b = new C0116b(40);
        m2655a((byte) 33, c0116b);
        c0116b.m1141d(i);
        as().m2741a(c0116b);
    }

    public final void m2713v() {
        this.a_.m242a();
    }

    public final void m2657a(int i, int i2) {
        C0115e c0116b = new C0116b();
        m2655a((byte) 93, c0116b);
        C0114f c0116b2 = new C0116b();
        c0116b2.m1141d(i);
        c0116b2.m1141d(i2);
        c0116b2.m1118e();
        c0116b.m1133a(c0116b2);
        as().m2741a(c0116b);
    }

    private void m2594b(short s, short s2, String str) {
        new StringBuilder("conn/sendlog/ID: ").append(s2).append("/").append(str == null ? "null" : str);
        C0115e c0116b = new C0116b(40);
        m2655a((byte) 4, c0116b);
        c0116b.m1135a(s);
        c0116b.m1135a(s2);
        if (str == null) {
            c0116b.m1135a((short) 0);
        } else {
            c0116b.m1138b(str);
        }
        this.f1501G.m2741a(c0116b);
    }

    public final void m2691c(String str) {
        if (this.aw == 0) {
            this.f1531o.m317a("ClientSession", "nonce/cache nonceLoginMessage");
            this.f1528l = str;
            return;
        }
        this.f1531o.m317a("ClientSession", "nonce/send nonceLoginMessage");
        as().m2741a(m2609e(str));
    }

    public final void m2656a(int i) {
        C0115e c0116b = new C0116b(40);
        m2655a((byte) 7, c0116b);
        c0116b.m1141d(i);
        as().m2741a(c0116b);
    }

    public final void m2659a(int i, int i2, int i3, int i4, C0099a c0099a, C0121i c0121i, boolean z, boolean z2, C0099a c0099a2, boolean z3, long j) {
        if (c0099a.m1064c() != c0121i.m1201b()) {
            throw new IllegalArgumentException("list size mismatch");
        }
        C0115e c0116b = new C0116b();
        if (z) {
            m2655a((byte) 67, c0116b);
        } else if (z2) {
            m2655a((byte) 83, c0116b);
        } else {
            m2655a((byte) 2, c0116b);
        }
        c0116b.m1141d(i);
        c0116b.m1141d(i2);
        c0116b.m1141d(i3);
        c0116b.m1135a((short) i4);
        int c = c0099a.m1064c();
        c0116b.m1135a((short) c);
        C0114f c0116b2 = new C0116b();
        for (int i5 = 0; i5 < c; i5++) {
            c0116b2.m1131a((byte) c0121i.m1202b(i5));
            c0116b2.m1138b(C0116b.m1144a((String) c0099a.m1056a(i5)));
        }
        c0116b2.m1118e();
        int c2 = c0099a2.m1064c();
        C0114f c0116b3 = new C0116b();
        byte b = (byte) 0;
        if (z3) {
            b = (byte) 2;
        }
        if (!c0099a2.m1062b()) {
            byte b2 = (byte) (b | 1);
            for (c = 0; c < c2; c++) {
                ad adVar = (ad) c0099a2.m1056a(c);
                c0116b3.m1132a(adVar.m3266c());
                c0116b3.m1135a(adVar.m3264b());
                c0116b3.m1135a(adVar.m3262a());
            }
            c0116b3.m1118e();
            b = b2;
        }
        if (z) {
            byte[] bArr = new byte[c0116b2.m1129o()];
            c0116b2.m1116c(bArr);
            c0116b.m1141d(bArr.length);
            c0116b.m1142d(this.f1542z.m39a(bArr));
        } else {
            c0116b.m1133a(c0116b2);
            c0116b.m1131a(b);
            if ((b & 1) == 1) {
                c0116b.m1135a((short) c2);
                c0116b.m1133a(c0116b3);
            }
            c0116b.m1132a(j);
        }
        as().m2741a(c0116b);
    }

    public final void m2667a(Integer num) {
        this.f1541y = num;
    }

    public final void aq() {
        String d = this.an.m386d("installId");
        if (d != null) {
            this.f1506L = Long.parseLong(d);
        }
        this.aC.m966a(0, ax(), 0);
        this.aC.m946K();
        this.aC.m942G();
        new Thread(this.f1499E).start();
        new Thread(this.f1539w).start();
        this.f1499E.m171a((Runnable) this);
    }

    public final void m2693d(int i) {
        if (this.f1538v == i) {
            this.f1538v = -1;
            if (m96A()) {
                this.a_.m243a(47);
            }
            aA();
        } else if (this.f1540x == i) {
            if (m96A()) {
                this.a_.m243a(48);
            }
            this.f1540x = -1;
            new StringBuilder("conn/reconnect triggered/").append(System.currentTimeMillis());
            this.f1499E.m171a(m2653a(false, false));
        } else if (this.f1504J == i) {
            this.aC.m1033r(1);
        }
    }

    public final void m2683b() {
        long P = m2641P();
        if (P != 0) {
            this.f1539w.m2280b(new C0320a(C0322c.f1275c, "contact_table" + P, f1494g));
        }
    }

    public final void m2671a(short s) {
        if (this.f1501G != null) {
            this.f1501G.m2743a(s);
        }
    }

    private void m2600c(boolean z) {
        int i;
        byte aG = aG();
        if (z) {
            i = (byte) ((aG & -13) | 8);
        } else {
            i = (byte) ((aG & -4) | 2);
        }
        this.am.m359a(5, (long) i);
    }

    public final void m2702k() {
        this.f1499E.m171a(m2653a(true, false));
        au();
    }

    protected final int[] m2715x() {
        return new int[]{1, 8, 3, 2, 4, 9, 22, 43, 47, 48, 53, 54, 55, 56, 65, 66, 81, 83};
    }

    private static byte[] m2583a(C0114f c0114f) {
        byte[] bArr = new byte[c0114f.m1122h()];
        c0114f.m1116c(bArr);
        return bArr;
    }

    private void m2616h(int i) {
        C0115e c0116b = new C0116b(40);
        m2655a((byte) 58, c0116b);
        as().m2741a(c0116b);
        this.f1499E.m164a(((long) i) * 1000);
        this.f1501G.m2739a();
        this.f1495A.m58d();
    }

    private static boolean m2607d(String str) {
        try {
            Class.forName(str);
            return true;
        } catch (Throwable th) {
            return false;
        }
    }

    private void av() {
        if (this.f1525i != null && Arrays.deepEquals(this.f1525i, this.f1511Q)) {
            m2601c(null);
        }
        this.f1525i = null;
    }

    private void aw() {
        if (this.ar != null && this.ar.equals(this.f1517W)) {
            m2593b(null, 0);
        }
        this.ar = null;
    }

    private C0093w ax() {
        C0093w c0093w = new C0093w(this.aB.m643D(), this.aB.m654y(), this.aC);
        c0093w.m522e(1);
        c0093w.m525f(1);
        return c0093w;
    }

    private void ay() {
        int i = 0;
        C0027f[] c0027fArr = new C0027f[]{this, this.at, this.aC, this.f1522d, this.a_};
        this.ab.m1218a();
        while (i < 5) {
            m2574a(c0027fArr[i]);
            i++;
        }
    }

    private C0115e m2609e(String str) {
        C0115e c0116b = new C0116b();
        m2655a((byte) 85, c0116b);
        c0116b.m1138b(str);
        return c0116b;
    }

    private void m2591b(C0114f c0114f) {
        int h = c0114f.m1122h();
        for (int i = 0; i < h; i++) {
            C0311c.m2220a().m2221a(m2634I(), c0114f.m1125k(), c0114f.m1125k());
        }
    }

    private void m2580a(short s, Integer num) {
        this.aC.m947L();
        this.aC.m942G();
        C0115e c0116b = new C0116b(40);
        m2655a((byte) 26, c0116b);
        c0116b.m1135a(s);
        if ((s & 4) == 4) {
            c0116b.m1136a(true);
            c0116b.m1141d(0);
            c0116b.m1141d(0);
        }
        if ((s & 8) == 8 && num != null) {
            m2576a(c0116b, num.intValue());
        }
        if ((s & 16) == 16) {
            m2590b(c0116b);
        }
        this.f1501G.m2741a(c0116b);
    }

    private void m2590b(C0115e c0115e) {
        long j;
        Throwable th;
        Throwable e;
        long j2;
        int[] iArr = new int[]{12324, 8, 12323, 8, 12322, 8, 12321, 8, 12352, 1, 12344};
        int[] iArr2 = new int[]{12324, 8, 12323, 8, 12322, 8, 12321, 8, 12352, 4, 12344};
        long j3 = 0;
        long j4 = 0;
        try {
            EGL10 eGLWrapper = new EGLWrapper((EGL10) EGLContext.getEGL());
            EGLDisplay eglGetDisplay = eGLWrapper.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
            eGLWrapper.eglInitialize(eglGetDisplay, new int[2]);
            int[] iArr3 = new int[1];
            eGLWrapper.eglChooseConfig(eglGetDisplay, iArr2, null, 0, iArr3);
            j4 = 0 | (iArr3[0] > 0 ? 1 : 0);
            EGLConfig[] eGLConfigArr = new EGLConfig[1];
            iArr3 = new int[1];
            eGLWrapper.eglChooseConfig(eglGetDisplay, iArr, eGLConfigArr, 1, iArr3);
            if (iArr3[0] == 0) {
                throw new RuntimeException("Display does not support GL11 config.");
            }
            DummySurfaceView f = ClientApplication.m1692d().m1788f();
            f.m3167a(0);
            EGLContext eglCreateContext = eGLWrapper.eglCreateContext(eglGetDisplay, eGLConfigArr[0], EGL10.EGL_NO_CONTEXT, null);
            SurfaceHolder a = f.m3166a();
            if (a.getSurface().isValid()) {
                EGLSurface eglCreateWindowSurface = eGLWrapper.eglCreateWindowSurface(eglGetDisplay, eGLConfigArr[0], a, null);
                eGLWrapper.eglMakeCurrent(eglGetDisplay, eglCreateWindowSurface, eglCreateWindowSurface, eglCreateContext);
                String glGetString = ((GL11) eglCreateContext.getGL()).glGetString(7939);
                j = 1;
                try {
                    j = (((glGetString.contains("GL_OES_draw_texture") ? 8 : 0) | 1) | (glGetString.contains("GL_EXT_texture_format_BGRA8888") ? 4 : 0)) | (ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN ? 2 : 0);
                    eGLWrapper.eglMakeCurrent(eglGetDisplay, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
                    f.m3167a(8);
                    eGLWrapper.eglDestroySurface(eglGetDisplay, eglCreateWindowSurface);
                    eGLWrapper.eglDestroyContext(eglGetDisplay, eglCreateContext);
                    eGLWrapper.eglTerminate(eglGetDisplay);
                    c0115e.m1132a(j);
                    c0115e.m1132a(j4);
                    return;
                } catch (Throwable e2) {
                    th = e2;
                    j2 = j4;
                    try {
                        if (th.m3127a() != 12297) {
                            j |= 16;
                            j2 |= 2;
                        } else {
                            this.f1520Z.m124a((short) 268, null, th);
                        }
                        c0115e.m1132a(j);
                        c0115e.m1132a(j2);
                    } catch (Throwable th2) {
                        j4 = j2;
                        j3 = j;
                        e2 = th2;
                        c0115e.m1132a(j3);
                        c0115e.m1132a(j4);
                        throw e2;
                    }
                } catch (Exception e3) {
                    e2 = e3;
                    j3 = 1;
                    try {
                        this.f1520Z.m124a((short) 268, null, e2);
                        c0115e.m1132a(j3);
                        c0115e.m1132a(j4);
                    } catch (Throwable th3) {
                        e2 = th3;
                        c0115e.m1132a(j3);
                        c0115e.m1132a(j4);
                        throw e2;
                    }
                } catch (Throwable th4) {
                    e2 = th4;
                    j3 = 1;
                    c0115e.m1132a(j3);
                    c0115e.m1132a(j4);
                    throw e2;
                }
            }
            throw new RuntimeException("Surface invalid, app in background: " + C0260h.m1725a());
        } catch (Throwable e22) {
            th2 = e22;
            j = 0;
            j2 = j4;
            if (th2.m3127a() != 12297) {
                this.f1520Z.m124a((short) 268, null, th2);
            } else {
                j |= 16;
                j2 |= 2;
            }
            c0115e.m1132a(j);
            c0115e.m1132a(j2);
        } catch (Exception e4) {
            e22 = e4;
            this.f1520Z.m124a((short) 268, null, e22);
            c0115e.m1132a(j3);
            c0115e.m1132a(j4);
        }
    }

    private void m2576a(C0115e c0115e, int i) {
        long currentTimeMillis;
        try {
            currentTimeMillis = System.currentTimeMillis();
            while (i > 0) {
                this.aB.m644E();
                i--;
            }
            currentTimeMillis = System.currentTimeMillis() - currentTimeMillis;
        } catch (Throwable e) {
            Throwable th = e;
            currentTimeMillis = -1;
            this.f1520Z.m124a((short) 87, null, th);
        }
        c0115e.m1132a(0);
        c0115e.m1132a(currentTimeMillis);
    }

    private void az() {
        if (!this.aC.m1002e(this.f1524h)) {
            if (this.ac == 1) {
                this.aC.m977a(this.f1524h, false);
            } else {
                this.aC.m969a(this.f1533q, this.f1524h);
            }
        }
    }

    private void m2599c(short s, short s2, String str) {
        if (this.as >= s) {
            int d = m2603d(s, s2, str);
            if (aw.f1162a && s2 != (short) 255 && this.ah.m2515a() && m2699h() >= s) {
                switch (d) {
                    case 0:
                        this.ah.m2513a(s, s2, str, C0356d.NORMAL);
                        break;
                    case 1:
                        this.ah.m2513a(s, s2, str, C0356d.OFFLINE);
                        break;
                    case 2:
                        this.ah.m2513a(s, s2, str, C0356d.DISCARDED);
                        break;
                }
                this.aC.m939D();
            }
        }
    }

    private void m2597c(C0115e c0115e) {
        int i = 0;
        short s = (short) (this.f1511Q == null ? 0 : 1);
        c0115e.m1135a(s);
        if (s > (short) 0) {
            c0115e.m1135a((short) this.f1511Q.length);
            String[] strArr = this.f1511Q;
            int length = strArr.length;
            while (i < length) {
                c0115e.m1138b(strArr[i]);
                i++;
            }
        }
    }

    private void m2605d(C0115e c0115e) {
        boolean z = this.f1517W != null;
        c0115e.m1136a(z);
        if (z) {
            c0115e.m1138b(C0116b.m1144a(this.ar));
        }
    }

    private void aA() {
        this.f1499E.m220w();
        C0380b.m2558a().m2563c();
        this.an.m396n();
    }

    private long aB() {
        String d = this.an.m386d("channelId");
        if (d != null) {
            try {
                return Long.parseLong(d);
            } catch (NumberFormatException e) {
            }
        }
        Long c = this.am.m365c(34);
        if (c == null) {
            return (long) this.am.m356a(10).intValue();
        }
        return c.longValue();
    }

    private byte aC() {
        byte b = (byte) 0;
        if (this.f1507M.m401p()) {
            b = (byte) 1;
        }
        if (this.f1507M.m402q()) {
            return (byte) (b | 2);
        }
        return b;
    }

    private C0411r m2569a(C0394b c0394b) {
        String[] e = this.ay.m367e(5);
        int[] b = this.ay.m364b(6);
        int a = c0394b.m2728a();
        if (e == null) {
            return m2585b(c0394b);
        }
        return new C0411r(e[a], b[a]);
    }

    private C0411r m2585b(C0394b c0394b) {
        String[] e;
        int[] b;
        switch (C0385g.f1481a[c0394b.ordinal()]) {
            case 1:
                e = this.am.m367e(67);
                b = this.am.m364b(68);
                break;
            case 2:
                e = this.am.m367e(29);
                b = this.am.m364b(30);
                break;
            default:
                throw new UnsupportedOperationException("Invalid ip pool type: " + c0394b);
        }
        return new C0411r(e[this.f1502H], b[this.f1502H]);
    }

    private int aD() {
        return C0313f.m2224b(this.f1536t).m2228c();
    }

    private int aE() {
        Integer a = this.am.m356a(38);
        return a == null ? 0 : a.intValue();
    }

    private int aF() {
        return C0313f.m2224b(this.f1536t).m2229d();
    }

    private byte aG() {
        Long c = this.am.m365c(5);
        if (c != null) {
            return (byte) ((int) (c.longValue() & 255));
        }
        return (byte) 0;
    }

    private byte aH() {
        return this.av;
    }

    private long aI() {
        long j;
        synchronized (this.ax) {
            j = this.aw;
        }
        return j;
    }

    private byte aJ() {
        byte b = (byte) -1;
        String d = this.an.m386d("sigid");
        if (d != null && d.length() > 0) {
            try {
                b = Byte.parseByte(d);
            } catch (NumberFormatException e) {
            }
        }
        return b;
    }

    private void m2598c(C0114f c0114f) {
        long i = c0114f.m1123i();
        byte g = c0114f.m1121g();
        long i2 = (g & 4) == 0 ? -1 : c0114f.m1123i();
        short j = c0114f.m1124j();
        byte g2 = c0114f.m1121g();
        int h = c0114f.m1122h();
        if (this.f1514T == c0114f.m1124j()) {
            if (m96A()) {
                m2628C().m2472c(9);
                this.a_.m243a(56);
                this.a_.m247b(83);
            }
            if (!am()) {
                ar();
                this.aC.m1000e(2);
            }
            this.aC.m938C();
            this.av = g;
            this.ao = j;
            this.f1524h = true;
            this.f1503I = false;
            m2589b(i);
            this.aC.m1027o(g2);
            this.am.m361a(true);
            m2619j(0);
            m2592b(Integer.valueOf(h));
            this.am.m361a(false);
            if ((g & 4) != 0) {
                this.am.m359a(3, i2);
            }
            if ((aH() & 8) != 0) {
                this.f1496B = true;
            }
            if (this.f1528l != null) {
                this.f1531o.m317a("ClientSession", "nonce/send out cached nonce login message");
                as().m2741a(m2609e(this.f1528l));
                this.f1528l = null;
            }
            C0184o.m1401a().m1450a("session_id", Long.toString(i));
            C0184o.m1401a().m1450a("client_id", Long.toString(m2632G()));
            new StringBuilder("conn/clientid: ").append(m2632G());
        }
    }

    private void m2575a(C0055g c0055g) {
        boolean z;
        Integer a = this.ay.m356a(17);
        if (a != null) {
            this.aC.m1029p(a.intValue());
        }
        a = this.ay.m356a(18);
        if (a != null) {
            this.aC.m1023m(a.intValue());
        }
        a = this.ay.m356a(19);
        if (a != null) {
            this.aC.m1025n(a.intValue());
        }
        a = this.ay.m356a(53);
        if (a != null) {
            this.aj = a.intValue() == 1;
        }
        a = this.ay.m356a(57);
        if (a != null) {
            if (a.intValue() == 1) {
                z = true;
            } else {
                z = false;
            }
            this.ak = z;
        }
        a = this.ay.m356a(58);
        if (a != null) {
            C0216b.m1530b(a.intValue());
        }
        if (this.au != null) {
            if (m2652a().m365c(21) != null) {
                this.au.m2346R();
            }
            this.au.m2347f(m2652a().m366d(25));
        }
        Integer a2 = m2652a().m356a(23);
        Integer a3 = m2652a().m356a(54);
        String d = m2652a().m366d(55);
        Integer a4 = m2652a().m356a(27);
        Integer a5 = m2652a().m356a(26);
        String d2 = m2652a().m366d(50);
        Integer a6 = m2652a().m356a(56);
        a = m2652a().m356a(59);
        z = a != null && a.intValue() == 1;
        this.f1497C = z;
        a = m2652a().m356a(48);
        if (a != null) {
            if ((a.intValue() & 16) == 16) {
                z = true;
            } else {
                z = false;
            }
            C0270d.m1846a(z);
        }
        if (a2 != null) {
            C0299m c0299m = this.at;
            if (a2.intValue() > 0) {
                z = true;
            } else {
                z = false;
            }
            c0299m.m2053a(z);
        }
        if (a3 != null) {
            if (a3.intValue() > 0) {
                z = true;
            } else {
                z = false;
            }
            C0300n.m2100a(ClientApplication.m1691c().m2377I(), z);
            if (z && !C0302p.m2175a((CharSequence) d)) {
                C0300n.m2142h(ClientApplication.m1691c().m2377I(), d);
            }
            this.at.m2069e();
        }
        if (a5 != null) {
            this.aC.m1036u().m648a(a5);
        }
        if (a4 != null) {
            this.aC.m1036u().m651b(a4);
        }
        if (d2 != null) {
            C0300n.m2155n(ClientApplication.m1691c().m2377I(), d2);
        }
        if (!(a6 == null || a6.intValue() == 0 || this.f1519Y)) {
            C0060d u = this.aC.m1024n().m616u();
            if (u != null) {
                this.f1519Y = true;
                u.m380a(false, false);
            }
        }
        a = c0055g.m356a(36);
        if (a != null && a.intValue() == 1) {
            this.f1495A = new C0007d(this.ay, this.f1531o);
            this.f1495A.m54a(this.f1527k);
        }
    }

    private boolean m2618i(int i) {
        Integer a = m2652a().m356a(i);
        return a == null || a.intValue() > 0;
    }

    private void m2579a(String str, boolean z, boolean z2) {
        if (ClientApplication.m1692d() != null) {
            if (ClientApplication.m1692d().m1799q() || z2) {
                ClientApplication.m1692d().runOnUiThread(new C0384f(this, str, z));
            }
        }
    }

    private C0323d aK() {
        return new C0323d(this, this);
    }

    private C0396j aL() {
        C0394b a = this.f1508N.m2725a();
        C0411r a2 = m2569a(a);
        String.format("conn/create connector index=%d, pool=%s", new Object[]{Integer.valueOf(this.f1502H), a.name()});
        C0396j c0401d = new C0401d(this, a2.m2898a(), a2.m2899b());
        this.f1509O = a;
        return c0401d;
    }

    private C0299m aM() {
        return new C0299m(this.f1520Z, this, this, this.an, this.f1499E, this.am, this.ay, this.al, this.f1507M);
    }

    private boolean m2602c(int i, C0114f c0114f) {
        Integer num = null;
        int i2 = 0;
        short j;
        short s;
        String k;
        byte g;
        switch (i) {
            case 12:
                j = c0114f.m1124j();
                String[] strArr = new String[j];
                boolean[] zArr = new boolean[j];
                while (s < j) {
                    strArr[s] = c0114f.m1125k();
                    zArr[s] = C0387i.m2607d(strArr[s]);
                    s++;
                }
                m2581a(strArr, zArr);
                break;
            case 13:
                String[] strArr2 = new String[c0114f.m1124j()];
                while (i2 < strArr2.length) {
                    strArr2[i2] = c0114f.m1125k();
                    i2++;
                }
                m2595b(strArr2);
                break;
            case 17:
                this.as = c0114f.m1121g();
                m2675a((short) 5, (short) 1, null, (long) this.as);
                break;
            case 20:
                k = c0114f.m1125k();
                m2687b(false);
                m2578a(k, true);
                break;
            case 24:
                this.at.m2062c();
                m2712u().m382c();
                break;
            case 25:
                s = c0114f.m1124j();
                if ((s & 8) == 8) {
                    if ((s & 4) == 4) {
                        c0114f.m1115c(c0114f.m1124j() + c0114f.m1128n());
                    }
                    c0114f.m1122h();
                    num = Integer.valueOf(c0114f.m1122h());
                }
                m2580a(s, num);
                break;
            case 34:
                g = c0114f.m1121g();
                k = c0114f.m1125k();
                boolean f = c0114f.m1120f();
                if ((g & 1) != 1) {
                    this.an.m378a(k, (C0061e) this);
                    break;
                }
                m2578a(k, f);
                break;
            case 41:
                g = c0114f.m1121g();
                if (c0114f.m1123i() == this.aw && (g & 1) != 0) {
                    m2698g();
                    break;
                }
            case 43:
                j = c0114f.m1124j();
                while (s < j) {
                    short j2 = c0114f.m1124j();
                    if (j2 != (short) 1) {
                        if (j2 == (short) 2) {
                            C0115e c0116b = new C0116b(300);
                            m2655a((byte) 54, c0116b);
                            C0055g.m343a(c0116b, this.am);
                            as().m2741a(c0116b);
                        } else {
                            this.f1520Z.m127a((short) 3, (short) 116, "", (long) j2);
                        }
                    }
                    s++;
                }
                break;
            case 45:
                m2582a(c0114f.m1121g(), c0114f, true);
                break;
            case 53:
                m2598c(c0114f);
                break;
            case 54:
                this.am.m360a(c0114f);
                aN();
                break;
            case 55:
                au();
                break;
            case 57:
                m2616h(c0114f.m1122h());
                break;
            case 63:
                this.ay.m360a(c0114f.m1117d());
                C0055g c0055g = new C0055g(this.f1520Z);
                c0055g.m360a(c0114f);
                m2575a(c0055g);
                break;
            case 64:
                break;
            case 65:
                aS();
                break;
            case 69:
                m2592b(Integer.valueOf(c0114f.m1122h()));
                this.f1503I = true;
                aP();
                if (m96A()) {
                    this.a_.m243a(53);
                    m2628C().m2472c(54);
                }
                aW();
                break;
            case 78:
                byte[] bArr;
                int m = c0114f.m1127m();
                String k2 = c0114f.m1125k();
                boolean f2 = c0114f.m1120f();
                int m2 = c0114f.m1127m();
                String[] strArr3 = new String[m2];
                String[] strArr4 = new String[m2];
                while (i2 < m2) {
                    strArr3[i2] = c0114f.m1125k();
                    strArr4[i2] = c0114f.m1125k();
                    i2++;
                }
                i2 = c0114f.m1127m();
                if (i2 == 0) {
                    bArr = null;
                } else {
                    bArr = new byte[i2];
                    c0114f.m1116c(bArr);
                }
                m2573a(m, k2, f2, strArr3, strArr4, bArr);
                break;
            case 89:
                m2591b(c0114f);
                break;
            case 91:
                C0328h a = ClientApplication.m1691c().m2379K().m2293a(c0114f);
                this.f1539w.m2280b(new C0320a(C0322c.f1273a, a.m2288f(), a.m2285c(), a));
                break;
            default:
                return false;
        }
        return true;
    }

    private void aN() {
        boolean z;
        boolean z2 = true;
        aX();
        Integer a = m2647V().m356a(61);
        C0300n.m2126e(this.f1536t, a == null ? 0 : a.intValue());
        a = m2647V().m356a(65);
        C0300n.m2131f(this.f1536t, a == null ? 0 : a.intValue());
        a = m2647V().m356a(64);
        Context context = this.f1536t;
        if (a == null || a.intValue() == 0) {
            z = false;
        } else {
            z = true;
        }
        C0300n.m2119c(context, z);
        a = m2647V().m356a(72);
        context = this.f1536t;
        if (a == null || a.intValue() == 0) {
            z = false;
        } else {
            z = true;
        }
        C0300n.m2134f(context, z);
        a = m2647V().m356a(66);
        if (a == null || a.intValue() != 1) {
            z2 = false;
        }
        this.f1498D = z2;
    }

    private boolean aO() {
        if (this.f1502H >= this.am.m367e(29).length - 1) {
            return false;
        }
        this.f1502H++;
        new StringBuilder("conn/gatewayFallbackIndex:").append(this.f1502H);
        return true;
    }

    private void aP() {
        this.f1501G.m2747d();
        aR();
        this.f1501G = null;
    }

    private void m2612f(String str) {
        m2594b((short) 1, (short) 255, str);
    }

    private void aQ() {
        m2589b(0);
        if (this.f1501G != null) {
            this.f1501G.m2748e();
        }
    }

    private void aR() {
        boolean am = am();
        this.aC.m943H();
        this.ay = new C0055g(this.f1520Z);
        this.f1495A = null;
        this.f1522d.m419a();
        if (am) {
            this.at.m2065d();
            this.aC.m1000e(1);
            aQ();
            C0407l.m2881a().m2888b();
            C0380b.m2558a();
            C0380b.m2559d();
        }
    }

    private void aS() {
        C0115e c0116b = new C0116b(40);
        m2655a((byte) 64, c0116b);
        this.f1501G.m2741a(c0116b);
    }

    private void m2581a(String[] strArr, boolean[] zArr) {
        C0115e c0116b = new C0116b(40);
        m2655a((byte) 5, c0116b);
        c0116b.m1135a((short) strArr.length);
        for (int i = 0; i < strArr.length; i++) {
            c0116b.m1138b(C0116b.m1144a(strArr[i]));
            c0116b.m1136a(zArr[i]);
        }
        this.f1501G.m2741a(c0116b);
    }

    private void m2571a(byte b, int i, int i2, int i3, int i4, long j, int i5, int i6, boolean z, int i7, int i8) {
        C0115e c0116b = new C0116b(70);
        m2655a((byte) 68, c0116b);
        c0116b.m1131a(b);
        c0116b.m1141d(i);
        c0116b.m1141d(i2);
        c0116b.m1131a((byte) 2);
        c0116b.m1141d(9);
        c0116b.m1141d(0);
        c0116b.m1141d(i3);
        c0116b.m1141d(1);
        c0116b.m1141d(i4);
        c0116b.m1141d(2);
        c0116b.m1141d((int) ((j - 1420099200000L) / 1000));
        c0116b.m1141d(3);
        c0116b.m1141d((int) (j % 1000));
        int i9 = 1;
        if (z) {
            i9 = 3;
        }
        c0116b.m1141d(4);
        c0116b.m1141d(i9);
        c0116b.m1141d(5);
        c0116b.m1141d(i5);
        c0116b.m1141d(6);
        c0116b.m1141d(i6);
        c0116b.m1141d(7);
        c0116b.m1141d(i7);
        c0116b.m1141d(8);
        c0116b.m1141d(i8);
        as().m2741a(c0116b);
    }

    private void m2606d(boolean z) {
        int i;
        String str = null;
        aR();
        C0115e c0116b = new C0116b(256);
        c0116b.m1135a((short) 0);
        c0116b.m1131a((byte) 1);
        c0116b.m1141d(241);
        c0116b.m1132a(m2632G());
        c0116b.m1132a(this.f1506L);
        c0116b.m1132a(aB());
        c0116b.m1135a(this.am.m356a(11).shortValue());
        c0116b.m1132a(aI());
        c0116b.m1141d(0);
        c0116b.m1135a((short) this.aB.m643D());
        c0116b.m1135a((short) this.aB.m654y());
        c0116b.m1132a(m2706o());
        c0116b.m1132a(C0294h.m1980j(ClientApplication.m1690b().getApplicationContext()));
        c0116b.m1136a(false);
        c0116b.m1131a(aG());
        c0116b.m1131a(aJ());
        c0116b.m1141d(this.ap);
        c0116b.m1135a((short) 0);
        c0116b.m1141d(-1);
        c0116b.m1141d(-1);
        c0116b.m1132a(System.currentTimeMillis());
        boolean z2 = this.f1502H != 0;
        if (this.f1503I) {
            i = 2;
        } else {
            i = 0;
        }
        int i2 = i | 0;
        if (z2) {
            i = 1;
        } else {
            i = 0;
        }
        c0116b.m1131a((byte) (i | i2));
        String str2 = this.am.m367e(31)[0];
        if (z2) {
            int i3 = this.am.m364b(32)[0];
            c0116b.m1138b(str2);
            c0116b.m1135a((short) i3);
        }
        c0116b.m1138b("");
        c0116b.m1131a(this.am.m356a(33).byteValue());
        c0116b.m1138b(C0116b.m1144a(this.an.m387e()));
        if (this.f1517W != null) {
            this.ar = this.f1517W;
        }
        m2605d(c0116b);
        if (this.f1511Q != null) {
            this.f1525i = this.f1511Q;
        }
        m2597c(c0116b);
        c0116b.m1132a(-1);
        c0116b.m1132a(-1);
        c0116b.m1132a(2);
        c0116b.m1135a((short) this.aa);
        c0116b.m1138b(str2);
        c0116b.m1141d(C0054f.m341a(this.am, this.ay));
        c0116b.m1141d(C0345a.m2471b());
        c0116b.m1138b(C0116b.m1144a(this.an.m390h()));
        c0116b.m1138b(C0116b.m1144a(C0294h.m1970d()));
        c0116b.m1138b(C0116b.m1144a(Build.MODEL));
        if (m96A()) {
            this.a_.m247b(81);
        }
        c0116b.m1135a((short) this.aB.m653x());
        String a = this.at.m2045a(1, true) == null ? null : this.at.m2045a(1, true).m752a().m586a();
        if (this.at.m2045a(2, true) != null) {
            str = this.at.m2045a(2, true).m752a().m586a();
        }
        c0116b.m1138b(C0116b.m1144a(a));
        c0116b.m1138b(C0116b.m1144a(str));
        c0116b.m1131a(aC());
        c0116b.m1138b(C0116b.m1144a(this.f1507M.m400o()));
        this.f1514T = (short) ((int) (Math.random() * 32767.0d));
        c0116b.m1135a(this.f1514T);
        new StringBuilder("conn/login/id: ").append(this.f1514T);
        this.f1501G.m2741a(c0116b);
        if (m96A()) {
            this.a_.m243a(55);
            if (z) {
                m2628C().m2472c(8);
                if (str != null && a != null) {
                    this.a_.m244a(65, a.length() + str.length());
                }
            }
        }
    }

    private void aT() {
        if (C0380b.m2558a().m2562b()) {
            for (int i = 0; i < this.ad; i++) {
                m2594b(this.af[i], this.ae[i], this.ag[i] + " (OFFLINE)");
            }
            this.ad = 0;
        }
    }

    private void m2588b(int i, int i2) {
        C0099a c0099a = new C0099a();
        C0121i c0121i = new C0121i();
        C0099a c0099a2 = new C0099a();
        c0099a.m1059a(String.valueOf(i));
        c0121i.m1200a(0);
        m2659a(this.aC.m1035t(), i2, 0, 0, c0099a, c0121i, false, false, c0099a2, false, -1);
        this.aC.m989c();
    }

    private void aU() {
        if (this.f1511Q != null) {
            C0115e c0116b = new C0116b();
            m2655a((byte) 74, c0116b);
            m2597c(c0116b);
            as().m2741a(c0116b);
            m2601c(null);
        }
    }

    private void aV() {
        if (this.f1517W != null) {
            C0115e c0116b = new C0116b();
            m2655a((byte) 73, c0116b);
            c0116b.m1135a((short) 1);
            c0116b.m1138b(this.f1517W);
            c0116b.m1132a(this.f1518X);
            as().m2741a(c0116b);
            aw();
        }
    }

    private int m2603d(short s, short s2, String str) {
        if (C0380b.m2558a().m2562b()) {
            aT();
            m2594b(s, s2, str);
            return 0;
        } else if (this.ad >= 10) {
            return 2;
        } else {
            this.ag[this.ad] = str;
            this.af[this.ad] = s;
            this.ae[this.ad] = s2;
            this.ad++;
            return 1;
        }
    }

    private void m2572a(int i, int i2, boolean z, int i3, int i4, int i5, int i6, boolean z2) {
        int i7;
        int i8 = 1;
        C0115e c0116b = new C0116b(30);
        m2655a((byte) 68, c0116b);
        c0116b.m1131a((byte) 0);
        c0116b.m1141d(i);
        c0116b.m1141d(i2);
        if (z) {
            i7 = 1;
        } else {
            i7 = 0;
        }
        c0116b.m1131a((byte) (i7 | 2));
        c0116b.m1141d(5);
        c0116b.m1141d(0);
        c0116b.m1141d(i3);
        c0116b.m1141d(1);
        c0116b.m1141d(i4);
        if (z2) {
            i8 = 3;
        }
        c0116b.m1141d(2);
        c0116b.m1141d(i8);
        c0116b.m1141d(3);
        c0116b.m1141d(i5);
        c0116b.m1141d(4);
        c0116b.m1141d(i6);
        as().m2741a(c0116b);
    }

    private void m2595b(String[] strArr) {
        C0115e c0116b = new C0116b(40);
        m2655a((byte) 6, c0116b);
        c0116b.m1135a((short) strArr.length);
        for (String str : strArr) {
            boolean z;
            String d = this.an.m386d(str);
            c0116b.m1138b(C0116b.m1144a(str));
            if (d != null) {
                z = true;
            } else {
                z = false;
            }
            c0116b.m1136a(z);
            if (z) {
                c0116b.m1138b(C0116b.m1144a(d));
            }
        }
        this.f1501G.m2741a(c0116b);
    }

    private void m2619j(int i) {
        this.am.m358a(38, i);
    }

    private void m2592b(Integer num) {
        this.az = num;
        boolean b = this.am.m363b();
        this.am.m361a(true);
        this.am.m358a(35, this.az.intValue());
        this.am.m359a(36, System.currentTimeMillis());
        if (!b) {
            this.am.m361a(false);
        }
    }

    private void aW() {
        this.aC.m1000e(0);
        this.f1499E.m171a(m2653a(true, true));
    }

    private void aX() {
        Integer a = m2647V().m356a(59);
        if (a != null) {
            this.f1534r = a.intValue();
        }
    }

    private void m2601c(String[] strArr) {
        this.f1511Q = strArr;
    }

    private void m2593b(String str, long j) {
        this.f1517W = str;
        this.f1518X = j;
    }

    private void m2589b(long j) {
        synchronized (this.ax) {
            this.aw = j;
        }
        if (am()) {
            this.f1501G.m2740a(j);
            aw();
            aV();
            av();
            aU();
        }
    }
}
