package com.facebook.lite.photo;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore.Images.Media;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.ap;
import com.facebook.lite.as;
import com.p008a.p009a.p010a.p014e.C0022b;

public class PreviewActivity extends Activity {
    private static final String f1750a;
    private Context f1751b;
    private Bitmap f1752c;
    private ImageView f1753d;
    private int f1754e;
    private LinearLayout f1755f;

    static {
        f1750a = PreviewActivity.class.getSimpleName();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(ap.multi_picker_preview);
        this.f1753d = (ImageView) findViewById(as.preview_image);
        this.f1755f = (LinearLayout) findViewById(as.rotate_button);
        TextView textView = (TextView) findViewById(as.rotate_text);
        this.f1751b = getApplicationContext();
        CharSequence stringExtra = getIntent().getStringExtra("preview_select");
        CharSequence stringExtra2 = getIntent().getStringExtra("preview_rotate");
        String stringExtra3 = getIntent().getStringExtra("button_color");
        this.f1754e = getIntent().getIntExtra("user_rotate_degree", 0);
        TextView textView2 = (TextView) findViewById(as.select_button);
        if (!(stringExtra == null || stringExtra.length() == 0)) {
            textView2.setText(stringExtra);
        }
        if (stringExtra3 != null && stringExtra3.length() > 0) {
            textView2.setBackgroundColor(Color.parseColor(stringExtra3));
        }
        if (stringExtra2 != null && stringExtra2.length() > 0) {
            textView.setText(stringExtra2);
        }
        textView2.setOnClickListener(new C0446o(this));
        String a = C0444m.m3048a(getApplicationContext(), Uri.withAppendedPath(Media.EXTERNAL_CONTENT_URI, Integer.toString(getIntent().getIntExtra("preview_id", -1))));
        new C0448q(this).execute(new String[]{a});
        this.f1755f.setOnClickListener(new C0447p(this));
    }

    protected void onDestroy() {
        if (!(this.f1752c == null || this.f1752c.isRecycled())) {
            this.f1752c.recycle();
        }
        super.onDestroy();
    }

    private static void m3004b(Throwable th) {
        C0022b T = ClientApplication.m1691c().m2388T();
        if (T != null) {
            T.m124a((short) 278, null, th);
        }
    }
}
