package com.facebook.lite.p049a.p050a;

import com.facebook.lite.p049a.p052c.C0269c;
import com.facebook.lite.p049a.p052c.C0270d;
import com.p008a.p009a.p010a.p018f.C0047a;
import com.p026b.p027a.C0129a;
import com.p026b.p027a.C0135g;

/* renamed from: com.facebook.lite.a.a.b */
public final class C0262b extends C0261a implements C0129a {
    public C0262b(C0135g c0135g, C0047a c0047a) {
        super(c0135g, c0047a);
        m1802a((C0129a) this);
    }

    public final void m1815a(String str) {
        C0270d.m1848b(C0269c.DISK, Integer.valueOf(str).intValue());
    }

    public final void m1816b(String str) {
        C0270d.m1845a(C0269c.DISK, Integer.valueOf(str).intValue());
    }

    public final void m1817c(String str) {
        C0270d.m1851c(C0269c.DISK, Integer.valueOf(str).intValue());
    }
}
