package com.facebook.p031b.p033b;

/* renamed from: com.facebook.b.b.d */
public final class C0152d extends Exception {
    public C0152d(String str, Throwable th) {
        super(str, th);
    }
}
