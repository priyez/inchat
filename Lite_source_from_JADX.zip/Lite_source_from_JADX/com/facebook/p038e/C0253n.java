package com.facebook.p038e;

/* renamed from: com.facebook.e.n */
public enum C0253n {
    BEST_EFFORT(false),
    LEAST_IMPORTANT(false),
    MUST_HAVE(true);
    
    private final boolean f939d;

    private C0253n(boolean z) {
        this.f939d = z;
    }

    public final boolean m1683a() {
        return this.f939d;
    }
}
