package com.facebook.lite.photo;

import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.p055c.C0305a;
import com.facebook.lite.p055c.C0306b;
import com.facebook.lite.p059m.C0387i;
import java.util.ArrayList;

/* renamed from: com.facebook.lite.photo.a */
final class C0431a implements OnClickListener {
    final /* synthetic */ AlbumGalleryActivity f1756a;

    C0431a(AlbumGalleryActivity albumGalleryActivity) {
        this.f1756a = albumGalleryActivity;
    }

    public final void onClick(View view) {
        C0387i S = ClientApplication.m1691c().m2387S();
        if (S == null) {
            this.f1756a.finish();
        }
        ArrayList a = this.f1756a.f1739n.m3067a();
        C0305a F = S.m2631F();
        int g = F.m2202g();
        ArrayList a2 = C0306b.m2207a(a, F, S);
        Intent putParcelableArrayListExtra = new Intent().putParcelableArrayListExtra("selected_items", a2);
        putParcelableArrayListExtra.putExtra("selected_num", a.size());
        if (!ClientApplication.m1691c().m2387S().ap() || ((a2.isEmpty() && !S.m2631F().m2203h()) || this.f1756a.f1731f <= 0)) {
            this.f1756a.setResult(-1, putParcelableArrayListExtra);
            this.f1756a.finish();
            return;
        }
        this.f1756a.f1736k.setVisibility(0);
        this.f1756a.f1732g = true;
        ClientApplication.m1691c().m2431b(putParcelableArrayListExtra);
        if (g == a.size()) {
            S.aa().m1021l(this.f1756a.f1731f);
        } else {
            S.aa().m1019k(this.f1756a.f1731f);
        }
    }
}
