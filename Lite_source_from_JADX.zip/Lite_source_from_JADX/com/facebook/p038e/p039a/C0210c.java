package com.facebook.p038e.p039a;

/* renamed from: com.facebook.e.a.c */
public final class C0210c implements C0207d {
    public String f795a;

    public C0210c(String str) {
        this.f795a = C0211e.m1515a(str).toString();
    }

    public C0210c(long j) {
        this.f795a = String.valueOf(j);
    }

    public C0210c(double d) {
        this.f795a = String.valueOf(d);
    }

    public C0210c(boolean z) {
        this.f795a = String.valueOf(z);
    }

    public final String toString() {
        return this.f795a;
    }
}
