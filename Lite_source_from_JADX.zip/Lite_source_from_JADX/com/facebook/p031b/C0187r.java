package com.facebook.p031b;

/* renamed from: com.facebook.b.r */
public enum C0187r {
    DUMP_TOO_BIG(64257),
    DUMP_TOO_OLD(64258);
    
    private final int f711c;

    private C0187r(int i) {
        this.f711c = i;
    }
}
