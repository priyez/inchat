package com.facebook.rti.push.service;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build.VERSION;
import com.facebook.rti.p046a.p074f.C0527a;
import com.facebook.rti.p046a.p075g.C0528c;
import com.facebook.rti.p046a.p076h.C0532b;
import com.facebook.rti.p078b.p080b.p091g.C0614b;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.facebook.rti.push.service.i */
public final class C0739i {
    private Context f3173a;
    private AlarmManager f3174b;
    private SharedPreferences f3175c;
    private C0532b f3176d;
    private Map f3177e;
    private final int f3178f;
    private C0614b f3179g;

    public C0739i(Context context, AlarmManager alarmManager, C0532b c0532b, C0614b c0614b) {
        this.f3173a = context;
        this.f3174b = alarmManager;
        this.f3175c = C0528c.f2215a.m3346a(this.f3173a, "rti.mqtt.retry");
        this.f3176d = c0532b;
        this.f3179g = c0614b;
        this.f3177e = new HashMap();
        this.f3178f = VERSION.SDK_INT;
    }

    public final void m3966a(String str, String str2) {
        m3964a(str, str2, FbnsService.class);
    }

    private void m3964a(String str, String str2, Class cls) {
        long j = 86400000;
        Intent intent = new Intent("com.facebook.rti.fbns.intent.REGISTER_RETRY");
        intent.setClass(this.f3173a, cls);
        intent.setPackage(str);
        intent.putExtra("pkg_name", str);
        intent.putExtra("appid", str2);
        PendingIntent service = PendingIntent.getService(this.f3173a, 0, this.f3179g.m3528d(intent), 134217728);
        this.f3177e.put(str, service);
        long j2 = this.f3175c.getLong(str, 120000);
        C0527a.m3338b("FbnsRegistrarRetry", "scheduleRetry %s", Long.valueOf(j2));
        if (this.f3178f == 23) {
            this.f3174b.setAndAllowWhileIdle(2, this.f3176d.m3351a() + j2, service);
        } else {
            this.f3174b.set(2, this.f3176d.m3351a() + j2, service);
        }
        long j3 = 2 * j2;
        if (j3 <= 86400000) {
            j = j3;
        }
        C0528c.m3345a(this.f3175c.edit().putLong(str, j));
    }

    public final void m3965a(String str) {
        C0527a.m3338b("FbnsRegistrarRetry", "Registration alarmManager retry cancelled.", new Object[0]);
        PendingIntent pendingIntent = (PendingIntent) this.f3177e.remove(str);
        if (pendingIntent != null) {
            this.f3174b.cancel(pendingIntent);
        }
        C0527a.m3338b("FbnsRegistrarRetry", "Registration reset retry.", new Object[0]);
        C0528c.m3345a(this.f3175c.edit().putLong(str, 120000));
    }
}
