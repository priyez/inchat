package com.facebook.lite;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.view.KeyEvent;
import android.view.MotionEvent;
import com.facebook.p038e.p044c.C0229d;

/* renamed from: com.facebook.lite.h */
public class C0260h extends Activity {
    private static boolean f962a;
    private static final C0229d f963b;
    private static final IntentFilter f964c;
    private static final BroadcastReceiver f965d;

    static {
        f963b = new C0229d();
        IntentFilter intentFilter = new IntentFilter();
        f964c = intentFilter;
        intentFilter.addAction("android.intent.action.TIME_SET");
        f965d = new C0344g();
    }

    public static boolean m1725a() {
        return f962a;
    }

    public boolean dispatchGenericMotionEvent(MotionEvent motionEvent) {
        f963b.m1578d(System.currentTimeMillis());
        return super.dispatchGenericMotionEvent(motionEvent);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        f963b.m1578d(System.currentTimeMillis());
        return super.dispatchKeyEvent(keyEvent);
    }

    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        f963b.m1578d(System.currentTimeMillis());
        return super.dispatchTouchEvent(motionEvent);
    }

    public boolean dispatchTrackballEvent(MotionEvent motionEvent) {
        f963b.m1578d(System.currentTimeMillis());
        return super.dispatchTrackballEvent(motionEvent);
    }

    protected void onDestroy() {
        super.onDestroy();
    }

    protected void onPause() {
        super.onPause();
        unregisterReceiver(f965d);
        f963b.m1575a(System.currentTimeMillis());
        f962a = false;
    }

    protected void onResume() {
        super.onResume();
        registerReceiver(f965d, f964c);
        f963b.m1576b(System.currentTimeMillis());
        f962a = true;
    }
}
