package com.facebook.p031b;

import android.content.res.Configuration;
import android.util.Log;
import android.util.SparseArray;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;

/* renamed from: com.facebook.b.c */
public final class C0172c {
    private static SparseArray f648a;
    private static SparseArray f649b;
    private static SparseArray f650c;
    private static SparseArray f651d;
    private static SparseArray f652e;
    private static SparseArray f653f;
    private static SparseArray f654g;
    private static SparseArray f655h;
    private static SparseArray f656i;
    private static final HashMap f657j;

    static {
        f648a = new SparseArray();
        f649b = new SparseArray();
        f650c = new SparseArray();
        f651d = new SparseArray();
        f652e = new SparseArray();
        f653f = new SparseArray();
        f654g = new SparseArray();
        f655h = new SparseArray();
        f656i = new SparseArray();
        HashMap hashMap = new HashMap();
        f657j = hashMap;
        hashMap.put("HARDKEYBOARDHIDDEN_", f648a);
        f657j.put("KEYBOARD_", f649b);
        f657j.put("KEYBOARDHIDDEN_", f650c);
        f657j.put("NAVIGATION_", f651d);
        f657j.put("NAVIGATIONHIDDEN_", f652e);
        f657j.put("ORIENTATION_", f653f);
        f657j.put("SCREENLAYOUT_", f654g);
        f657j.put("TOUCHSCREEN_", f655h);
        f657j.put("UI_MODE_", f656i);
        for (Field field : Configuration.class.getFields()) {
            if (Modifier.isStatic(field.getModifiers()) && Modifier.isFinal(field.getModifiers())) {
                String name = field.getName();
                try {
                    if (name.startsWith("HARDKEYBOARDHIDDEN_")) {
                        f648a.put(field.getInt(null), name);
                    } else if (name.startsWith("KEYBOARD_")) {
                        f649b.put(field.getInt(null), name);
                    } else if (name.startsWith("KEYBOARDHIDDEN_")) {
                        f650c.put(field.getInt(null), name);
                    } else if (name.startsWith("NAVIGATION_")) {
                        f651d.put(field.getInt(null), name);
                    } else if (name.startsWith("NAVIGATIONHIDDEN_")) {
                        f652e.put(field.getInt(null), name);
                    } else if (name.startsWith("ORIENTATION_")) {
                        f653f.put(field.getInt(null), name);
                    } else if (name.startsWith("SCREENLAYOUT_")) {
                        f654g.put(field.getInt(null), name);
                    } else if (name.startsWith("TOUCHSCREEN_")) {
                        f655h.put(field.getInt(null), name);
                    } else if (name.startsWith("UI_MODE_")) {
                        f656i.put(field.getInt(null), name);
                    }
                } catch (Throwable e) {
                    Log.w(C0148a.f621a, "Error while inspecting device configuration: ", e);
                } catch (Throwable e2) {
                    Log.w(C0148a.f621a, "Error while inspecting device configuration: ", e2);
                }
            }
        }
    }

    public static String m1370a(Configuration configuration) {
        StringBuilder stringBuilder = new StringBuilder();
        for (Field field : configuration.getClass().getFields()) {
            try {
                if (!Modifier.isStatic(field.getModifiers())) {
                    stringBuilder.append(field.getName()).append('=');
                    if (field.getType().equals(Integer.TYPE)) {
                        stringBuilder.append(C0172c.m1371a(configuration, field));
                    } else if (field.get(configuration) == null) {
                        stringBuilder.append("null");
                    } else {
                        stringBuilder.append(field.get(configuration).toString());
                    }
                    stringBuilder.append('\n');
                }
            } catch (Throwable e) {
                Log.e(C0148a.f621a, "Error while inspecting device configuration: ", e);
            } catch (Throwable e2) {
                Log.e(C0148a.f621a, "Error while inspecting device configuration: ", e2);
            }
        }
        return stringBuilder.toString();
    }

    private static String m1371a(Configuration configuration, Field field) {
        String name = field.getName();
        if (name.equals("mcc") || name.equals("mnc")) {
            return Integer.toString(field.getInt(configuration));
        }
        if (name.equals("uiMode")) {
            return C0172c.m1372a((SparseArray) f657j.get("UI_MODE_"), field.getInt(configuration));
        }
        if (name.equals("screenLayout")) {
            return C0172c.m1372a((SparseArray) f657j.get("SCREENLAYOUT_"), field.getInt(configuration));
        }
        SparseArray sparseArray = (SparseArray) f657j.get(name.toUpperCase() + '_');
        if (sparseArray == null) {
            return Integer.toString(field.getInt(configuration));
        }
        name = (String) sparseArray.get(field.getInt(configuration));
        if (name == null) {
            return Integer.toString(field.getInt(configuration));
        }
        return name;
    }

    private static String m1372a(SparseArray sparseArray, int i) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i2 = 0; i2 < sparseArray.size(); i2++) {
            int keyAt = sparseArray.keyAt(i2);
            if (((String) sparseArray.get(keyAt)).endsWith("_MASK")) {
                int i3 = i & keyAt;
                if (i3 > 0) {
                    if (stringBuilder.length() > 0) {
                        stringBuilder.append('+');
                    }
                    stringBuilder.append((String) sparseArray.get(i3));
                }
            }
        }
        return stringBuilder.toString();
    }
}
