package com.facebook.lite;

import android.view.View;
import android.view.View.OnClickListener;
import com.facebook.lite.widget.ae;

/* renamed from: com.facebook.lite.y */
final class C0495y implements OnClickListener {
    final /* synthetic */ ae f2119a;
    final /* synthetic */ MainActivity f2120b;

    C0495y(MainActivity mainActivity, ae aeVar) {
        this.f2120b = mainActivity;
        this.f2119a = aeVar;
    }

    public final void onClick(View view) {
        this.f2120b.m1737a(this.f2119a);
    }
}
