package com.facebook.lite;

import android.app.Application;
import android.content.Context;
import android.util.Log;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.photo.AlbumGalleryActivity;
import com.facebook.p031b.C0148a;
import com.facebook.p031b.C0184o;
import com.facebook.p031b.C0193x;

public class ClientApplication extends Application {
    private static final String f944a;
    private static final C0370k f945b;
    private static final C0342f f946c;
    private static ClientApplication f947d;

    static {
        f944a = ClientApplication.class.getSimpleName();
        f945b = new C0370k("275254692598279", "EMA for Android");
        f946c = new C0342f();
    }

    public static AlbumGalleryActivity m1688a() {
        return f946c.m2375G();
    }

    public static ClientApplication m1690b() {
        return f947d;
    }

    public static C0342f m1691c() {
        return f946c;
    }

    public static MainActivity m1692d() {
        return f946c.m2381M();
    }

    public static C0342f m1693e() {
        return f946c;
    }

    public void onCreate() {
        super.onCreate();
        f947d = this;
        f946c.m2393a(getApplicationContext());
    }

    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        m1694f();
        m1689a(context);
    }

    private static void m1694f() {
        try {
            Class.forName("android.os.AsyncTask");
        } catch (Throwable th) {
            Log.i(f944a, "class:cannot load asynctask");
        }
    }

    private static C0370k m1695g() {
        return f945b;
    }

    private void m1689a(Context context) {
        C0370k g = m1695g();
        String a = m1695g().m2543a();
        C0184o a2 = C0148a.m1328a(new C0193x(this), C0193x.m1467a(a).toString());
        a2.m1450a("app", g.m2544b());
        a2.m1450a("fb_app_id", a);
        long i = C0300n.m2143i(context);
        a2.m1455a(i == 0 ? null : Long.toString(i));
        Thread.setDefaultUncaughtExceptionHandler(new C0352i(a2));
    }
}
