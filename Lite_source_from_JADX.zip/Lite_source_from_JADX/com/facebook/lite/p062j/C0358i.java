package com.facebook.lite.p062j;

/* renamed from: com.facebook.lite.j.i */
interface C0358i {
    String m2516a(StringBuilder stringBuilder);
}
