package com.facebook.p031b;

import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;

/* renamed from: com.facebook.b.f */
public final class C0175f {
    public static String m1383a(Context context) {
        if (C0153b.m1337a() < 5) {
            return "Data available only with API Level > 5";
        }
        StringBuffer stringBuffer = new StringBuffer();
        try {
            Object[] objArr = (Object[]) PackageManager.class.getMethod("getSystemAvailableFeatures", null).invoke(context.getPackageManager(), new Object[0]);
            if (objArr != null) {
                for (Object obj : objArr) {
                    String str = (String) obj.getClass().getField("name").get(obj);
                    if (str != null) {
                        stringBuffer.append(str);
                    } else {
                        str = (String) obj.getClass().getMethod("getGlEsVersion", null).invoke(obj, new Object[0]);
                        stringBuffer.append("glEsVersion = ");
                        stringBuffer.append(str);
                    }
                    stringBuffer.append("\n");
                }
            }
        } catch (Throwable th) {
            Log.w(C0148a.f621a, "Couldn't retrieve device features for " + context.getPackageName(), th);
            stringBuffer.append("Could not retrieve data: ");
            stringBuffer.append(th.getMessage());
        }
        return stringBuffer.toString();
    }
}
