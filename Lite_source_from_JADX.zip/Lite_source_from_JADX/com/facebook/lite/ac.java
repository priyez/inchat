package com.facebook.lite;

import android.view.View;
import android.view.View.OnClickListener;
import com.facebook.lite.widget.ae;

final class ac implements OnClickListener {
    final /* synthetic */ ae f1115a;
    final /* synthetic */ boolean f1116b;
    final /* synthetic */ MainActivity f1117c;

    ac(MainActivity mainActivity, ae aeVar, boolean z) {
        this.f1117c = mainActivity;
        this.f1115a = aeVar;
        this.f1116b = z;
    }

    public final void onClick(View view) {
        this.f1117c.m1747b(this.f1115a);
    }
}
