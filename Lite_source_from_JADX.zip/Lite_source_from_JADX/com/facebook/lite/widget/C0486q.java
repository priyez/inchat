package com.facebook.lite.widget;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;

/* renamed from: com.facebook.lite.widget.q */
final class C0486q implements OnClickListener {
    final /* synthetic */ Context f2104a;
    final /* synthetic */ FloatingTextBox f2105b;

    C0486q(FloatingTextBox floatingTextBox, Context context) {
        this.f2105b = floatingTextBox;
        this.f2104a = context;
    }

    public final void onClick(View view) {
        this.f2105b.m3183e();
    }
}
