package com.facebook.rti.p046a.p069a;

import com.facebook.rti.p046a.p074f.C0527a;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONObject;
import p006c.p007a.C0003a;

/* renamed from: com.facebook.rti.a.a.g */
class C0503g {
    private static final String f2139a;
    private UUID f2140b;
    private int f2141c;
    private C0003a f2142d;
    private String f2143e;
    private String f2144f;
    private String f2145g;
    private String f2146h;
    private long f2147i;
    private List f2148j;

    static {
        f2139a = C0503g.class.getSimpleName();
    }

    public C0503g() {
        this.f2148j = new ArrayList(50);
        this.f2141c = 0;
    }

    public final void m3296a() {
        this.f2148j.clear();
        this.f2141c++;
    }

    public final List m3301b() {
        return this.f2148j;
    }

    public final void m3299a(C0498b c0498b) {
        this.f2148j.add(c0498b);
    }

    public final UUID m3303c() {
        if (this.f2140b == null) {
            this.f2140b = UUID.randomUUID();
        }
        return this.f2140b;
    }

    public final int m3305d() {
        return this.f2141c;
    }

    public final void m3297a(long j) {
        this.f2147i = j;
    }

    public final void m3298a(C0003a c0003a) {
        this.f2142d = c0003a;
    }

    public final void m3300a(String str) {
        this.f2143e = str;
    }

    public final void m3302b(String str) {
        this.f2144f = str;
    }

    public final void m3304c(String str) {
        this.f2145g = str;
    }

    public final void m3306d(String str) {
        this.f2146h = str;
    }

    public String toString() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("seq", this.f2141c);
            jSONObject.put("time", String.format(null, "%.3f", new Object[]{Double.valueOf(((double) this.f2147i) / 1000.0d)}));
            jSONObject.putOpt("app_id", this.f2145g);
            jSONObject.putOpt("app_ver", this.f2143e);
            jSONObject.putOpt("build_num", this.f2144f);
            jSONObject.putOpt("device_id", this.f2142d.m41b());
            jSONObject.putOpt("session_id", this.f2140b);
            jSONObject.putOpt("uid", this.f2146h);
            if (this.f2148j != null) {
                JSONArray jSONArray = new JSONArray();
                for (C0498b a : this.f2148j) {
                    jSONArray.put(a.m3287a());
                }
                jSONObject.put("data", jSONArray);
            }
            jSONObject.put("log_type", "client_event");
            return jSONObject.toString();
        } catch (Throwable e) {
            C0527a.m3337a(f2139a, e, "Failed to serialize", new Object[0]);
            return "";
        }
    }
}
