package com.facebook.p031b.p032a;

import android.content.Context;

/* renamed from: com.facebook.b.a.b */
public interface C0146b {
    void m1313a(boolean z);

    String[] m1314a();

    String[] m1315b();

    String m1316c();

    boolean m1317d();

    Context m1318e();

    String m1319f();
}
