package com.facebook.lite.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.SystemClock;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.MainActivity;
import com.facebook.lite.av;
import com.facebook.lite.net.C0407l;
import com.facebook.lite.p049a.p051b.C0264a;
import com.facebook.lite.p049a.p051b.C0265b;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p061h.C0345a;
import com.facebook.lite.photo.AlbumGalleryActivity;
import com.facebook.lite.widget.ConnectivityBar;
import com.p008a.p009a.p010a.C0031b;
import com.p008a.p009a.p010a.p012b.C0011a;
import com.p008a.p009a.p010a.p012b.C0018j;
import com.p008a.p009a.p010a.p012b.C0025b;
import com.p008a.p009a.p010a.p012b.C0029k;
import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p016h.C0052d;
import com.p008a.p009a.p010a.p021k.C0068a;
import com.p008a.p009a.p010a.p021k.C0069b;
import com.p008a.p009a.p010a.p022l.C0070p;
import com.p008a.p009a.p010a.p022l.C0071x;
import com.p008a.p009a.p010a.p022l.C0079h;
import com.p008a.p009a.p010a.p022l.C0080i;
import com.p008a.p009a.p010a.p022l.C0082k;
import com.p008a.p009a.p010a.p022l.C0087q;
import com.p008a.p009a.p010a.p022l.C0089s;
import com.p008a.p009a.p010a.p022l.C0093w;
import com.p008a.p009a.p010a.p022l.C0094y;
import com.p008a.p009a.p010a.p023m.C0099a;

/* renamed from: com.facebook.lite.ui.b */
public final class C0460b extends C0094y {
    protected boolean f1823o;
    private int f1824p;
    private long f1825q;
    private int f1826r;

    public C0460b(C0022b c0022b, C0080i c0080i, C0082k c0082k, C0079h c0079h, C0018j c0018j, C0029k c0029k, C0052d c0052d, C0031b c0031b, C0345a c0345a, C0025b c0025b) {
        super(c0022b, c0080i, c0082k, c0079h, c0018j, c0029k, c0052d, c0031b, c0345a, c0025b);
        this.f1824p = -1;
        m987b(true, m1036u().m643D() * m1036u().m654y());
    }

    public final void m3109b(boolean z) {
        if (m1034s() != null && m1034s().m872R()) {
            m3110c(z);
            MainActivity d = ClientApplication.m1692d();
            if (d != null) {
                d.m1793k();
            }
        }
    }

    public final C0069b m3102a(C0093w c0093w, C0080i c0080i, int i, int[] iArr, short s, byte b) {
        return new C0265b(c0093w, c0080i, i, iArr, s, b);
    }

    public final void m3112e(int i) {
        MainActivity d = ClientApplication.m1692d();
        if (d != null) {
            d.m1793k();
            if (d.m1787e() != null) {
                d.m1787e().setBarEnabled(false);
            }
        }
        super.m1000e(i);
    }

    public final void m3115f(int i) {
        super.m1004f(i);
        if (i == this.j) {
            MainActivity d = ClientApplication.m1692d();
            if (d != null) {
                d.m1798p();
            }
        }
    }

    public final void m3107a(boolean z, boolean z2) {
        MainActivity d = ClientApplication.m1692d();
        if (d != null) {
            d.m1793k();
            m992c(this.j);
            d.m1782a(z, z2);
        }
    }

    public final void m3105a(int i, boolean z) {
        MainActivity d = ClientApplication.m1692d();
        if (d != null) {
            d.m1793k();
            m992c(this.j);
            d.m1775a(i, z);
        }
    }

    public final void m3116g(int i) {
        if (this.f1824p == i && this.f1823o) {
            AlbumGalleryActivity a = ClientApplication.m1688a();
            if (a != null) {
                a.setResult(-1, new Intent().putExtra("result_handled", true));
                a.finish();
            }
            this.f1824p = -1;
            this.f1823o = false;
        }
    }

    public final C0068a m3111d() {
        return C0264a.m1822a(this.f);
    }

    public final long m3101V() {
        return this.f1825q;
    }

    public final void m3096C() {
        MainActivity d = ClientApplication.m1692d();
        if (d != null) {
            d.m1793k();
            d.m1792j();
        }
    }

    public final void m3106a(C0011a c0011a) {
        super.m971a(c0011a);
        this.f1825q = SystemClock.uptimeMillis();
    }

    public final void m3110c(boolean z) {
        if (m1035t() == this.j) {
            MainActivity d = ClientApplication.m1692d();
            if (d != null) {
                d.m1794l();
                d.m1793k();
            }
        }
        super.m991c(z);
    }

    public final C0070p m3097I() {
        if (ClientApplication.m1692d() == null) {
            return null;
        }
        C0070p I = super.m944I();
        if (I == null) {
            return null;
        }
        Context I2 = ClientApplication.m1691c().m2377I();
        I.m519d(I2.getResources().getDimensionPixelSize(av.toolbar_button_height) + C0300n.m2078F(I2));
        return I;
    }

    public final void m3120k(int i) {
        this.f1824p = i;
    }

    public final void m3121l(int i) {
        this.f1824p = i;
        this.f1823o = true;
    }

    public final void m3122q(int i) {
        if (this.f1824p == i) {
            this.f1823o = true;
        }
    }

    public final boolean m3114e(boolean z) {
        if (m3098P()) {
            return false;
        }
        m3107a(z, true);
        return true;
    }

    public final void m3123r(int i) {
        ClientApplication.m1690b();
        if (ClientApplication.m1693e().m2387S().ao()) {
            MainActivity d = ClientApplication.m1692d();
            if (d == null || d.m1787e() == null) {
                ConnectivityBar.setType(i);
                return;
            }
            d.m1787e().m3165a(m1028p().m629b(103, false), m950O(), m949N());
            d.m1787e().m3163a(i, m999e());
            m939D();
        }
    }

    protected final void m3108b(int i, C0093w c0093w, int i2) {
        Activity d = ClientApplication.m1692d();
        if (!(d == null || d.m1787e() == null)) {
            d.m1787e().setBarEnabled(true);
            d.m1787e().m3164a(c0093w);
        }
        c0093w.m869K();
        if (!c0093w.f397m) {
            super.m984b(i, c0093w, i2);
        } else if (d != null) {
            d.m1786d().m3157a(d, c0093w, m950O(), m949N());
        }
    }

    protected final void m3113e(int i, int i2) {
        Object obj = 1;
        this.g.m764a();
        int C = this.h.m642C();
        if (C == 0 || i2 >= this.g.m789i()) {
            i2 = this.g.m789i();
            C = 0;
            i = 0;
        }
        System.currentTimeMillis();
        Object obj2 = (i == 1 || i == 2) ? 1 : null;
        long j = 0;
        if (this.i != 0) {
            j = (long) (C / (this.i / i2));
            if (obj2 != null) {
                i2 /= 2;
                this.i = (this.i / 2) + i2;
            }
        }
        while (true) {
            long currentTimeMillis = System.currentTimeMillis();
            if (this.i != 0) {
                switch (i) {
                    case 1:
                        C0089s c0089s = this.g;
                        if (obj != null) {
                            C = this.g.m789i() / 2;
                        } else {
                            C = i2;
                        }
                        c0089s.m766a(C, this.i);
                        break;
                    case 2:
                        this.g.m776b(obj != null ? this.g.m789i() / 2 : i2, this.i);
                        break;
                    case 3:
                        C = 256 / (this.i + 1);
                        this.g.m775b(C);
                        if (this.i != 3) {
                            C = (256 - ((this.i - 1) * 85)) - C;
                        }
                        this.g.m765a(C);
                        break;
                    default:
                        break;
                }
            }
            this.g.m764a();
            m948M();
            long currentTimeMillis2 = System.currentTimeMillis();
            if (this.i != 0) {
                C0460b.m3095b(currentTimeMillis2 - currentTimeMillis, j);
            }
            if (m1005f(i, i2)) {
                obj = null;
            } else {
                return;
            }
        }
    }

    protected final boolean m3098P() {
        if (ClientApplication.m1692d() != null) {
            return C0294h.m1974f();
        }
        return true;
    }

    protected final boolean m3099Q() {
        ClientApplication.m1690b();
        return ClientApplication.m1693e().m2387S().ag();
    }

    protected final C0089s m3103a(int i, int i2, int[][] iArr, C0022b c0022b) {
        return new C0459a(i, i2, iArr, c0022b);
    }

    protected final C0089s m3104a(int i, int i2, int[][] iArr, C0022b c0022b, C0089s c0089s) {
        return new C0459a(i, i2, iArr, c0022b, c0089s);
    }

    protected final void m3100R() {
        C0407l.m2881a().m2887a(false);
        ((C0345a) this.a_).m2472c(7);
        super.m953R();
    }

    protected final void m3117g(C0093w c0093w) {
        super.m1009g(c0093w);
        MainActivity d = ClientApplication.m1692d();
        if (d != null) {
            m3094a(c0093w, d);
        }
    }

    protected final void m3118h(C0093w c0093w) {
        super.m1010h(c0093w);
        MainActivity d = ClientApplication.m1692d();
        if (d != null) {
            m3094a(c0093w, d);
            m3093a((C0087q) c0093w, d);
        }
    }

    protected final void m3119i(C0093w c0093w) {
        super.m1015i(c0093w);
        MainActivity d = ClientApplication.m1692d();
        if (d != null) {
            m3094a(c0093w, d);
            d.m1796n();
        }
    }

    private static void m3095b(long j, long j2) {
        if (j < j2) {
            try {
                Thread.sleep(j2 - j);
            } catch (InterruptedException e) {
            }
        }
    }

    private void m3093a(C0087q c0087q, MainActivity mainActivity) {
        if (c0087q != null && c0087q.m736f() != null) {
            C0099a f = c0087q.m736f();
            for (int i = 0; i < f.m1064c(); i++) {
                Object a = f.m1056a(i);
                if (a instanceof C0071x) {
                    C0071x c0071x = (C0071x) a;
                    if (c0071x.m573Q()) {
                        mainActivity.m1776a(Uri.parse(c0071x.m571O()), c0071x.m504b(), c0071x.m512c(), c0071x.m538m(), c0071x.m526g(), c0071x.m567K(), c0071x.m566J(), c0071x.m570N());
                    }
                } else if (a instanceof C0087q) {
                    m3093a((C0087q) a, mainActivity);
                }
            }
        }
    }

    private void m3094a(C0093w c0093w, MainActivity mainActivity) {
        int e = m998e(c0093w);
        if (this.f1826r != e && e != -1) {
            mainActivity.m1794l();
            this.f1826r = e;
        }
    }
}
