package com.facebook.lite.photo;

import com.facebook.lite.ClientApplication;
import java.util.ArrayList;
import java.util.Iterator;

/* renamed from: com.facebook.lite.photo.n */
public final class C0445n {
    private long f1785a;
    private final int f1786b;
    private int f1787c;
    private final ArrayList f1788d;

    public C0445n(int i, ArrayList arrayList) {
        this.f1785a = 0;
        this.f1788d = new ArrayList();
        this.f1786b = i;
        if (arrayList != null) {
            this.f1787c = arrayList.size();
            for (int i2 = 0; i2 < arrayList.size(); i2++) {
                this.f1788d.add((GalleryItem) arrayList.get(i2));
            }
        }
    }

    public final void m3068a(GalleryItem galleryItem) {
        int c = galleryItem.m2993c();
        galleryItem.m2989a();
        this.f1788d.remove(galleryItem);
        this.f1787c--;
        Iterator it = this.f1788d.iterator();
        while (it.hasNext()) {
            GalleryItem galleryItem2 = (GalleryItem) it.next();
            int c2 = galleryItem2.m2993c();
            if (c2 > c) {
                galleryItem2.m2992b(c2 - 1);
            }
        }
    }

    public final ArrayList m3067a() {
        return this.f1788d;
    }

    public final boolean m3069b() {
        return this.f1787c >= this.f1786b;
    }

    public final boolean m3070b(GalleryItem galleryItem) {
        if (this.f1788d.contains(galleryItem)) {
            return false;
        }
        if (this.f1787c >= this.f1786b) {
            m3071c();
            return false;
        }
        this.f1788d.add(galleryItem);
        int i = this.f1787c + 1;
        this.f1787c = i;
        galleryItem.m2990a(i);
        return true;
    }

    public final void m3071c() {
        long currentTimeMillis = System.currentTimeMillis();
        if (Math.abs(currentTimeMillis - this.f1785a) > 2500) {
            ClientApplication.m1691c().m2374F();
            this.f1785a = currentTimeMillis;
        }
    }
}
