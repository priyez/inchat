package com.facebook.lite.deviceid;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.facebook.lite.p053b.C0300n;
import com.facebook.p037d.C0203e;
import java.util.Random;

public class FbLitePhoneIdUpdater {
    private static final String f1255a;
    private static volatile FbLitePhoneIdUpdater f1256b;
    private final Context f1257c;
    private final C0203e f1258d;

    public class LocalBroadcastReceiver extends BroadcastReceiver {
        public void onReceive(Context context, Intent intent) {
            FbLitePhoneIdUpdater.m2254a(context).m2258d();
        }
    }

    static {
        f1255a = FbLitePhoneIdUpdater.class.getName();
    }

    private FbLitePhoneIdUpdater(Context context) {
        this.f1257c = context;
        this.f1258d = new C0203e(this.f1257c, C0317a.m2260a(this.f1257c), new C0318b(this.f1257c));
    }

    public static FbLitePhoneIdUpdater m2254a(Context context) {
        if (f1256b == null) {
            synchronized (FbLitePhoneIdUpdater.class) {
                if (f1256b == null) {
                    f1256b = new FbLitePhoneIdUpdater(context.getApplicationContext());
                }
            }
        }
        return f1256b;
    }

    public final void m2259a() {
        Object obj = null;
        synchronized (this) {
            if (System.currentTimeMillis() - C0300n.m2150l(this.f1257c) > 86400000) {
                obj = 1;
                C0300n.m2132f(this.f1257c, System.currentTimeMillis());
            }
        }
        if (obj != null) {
            m2258d();
            m2257c();
        }
    }

    private static long m2256b() {
        Random random = new Random(System.currentTimeMillis());
        return (((long) (random.nextInt(60) - 30)) * 60000) + (((long) (random.nextInt(12) - 6)) * 3600000);
    }

    private void m2257c() {
        long currentTimeMillis = (System.currentTimeMillis() + 86400000) + m2256b();
        ((AlarmManager) this.f1257c.getSystemService("alarm")).set(1, currentTimeMillis, PendingIntent.getBroadcast(this.f1257c, -1, new Intent(this.f1257c, LocalBroadcastReceiver.class), 0));
        new StringBuilder("Schedule the next synchronization after ").append(currentTimeMillis - System.currentTimeMillis());
    }

    private void m2258d() {
        this.f1258d.m1507a();
    }
}
