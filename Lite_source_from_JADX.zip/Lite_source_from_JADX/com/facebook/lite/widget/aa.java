package com.facebook.lite.widget;

import android.text.method.PasswordTransformationMethod;
import android.view.View;

final class aa extends PasswordTransformationMethod {
    private aa() {
    }

    public final CharSequence getTransformation(CharSequence charSequence, View view) {
        return new C0493z(this, charSequence);
    }
}
