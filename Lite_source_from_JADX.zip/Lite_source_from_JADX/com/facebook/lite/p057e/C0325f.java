package com.facebook.lite.p057e;

import com.facebook.lite.widget.InlineTextBox;
import java.util.List;

/* renamed from: com.facebook.lite.e.f */
final class C0325f implements Runnable {
    final /* synthetic */ InlineTextBox f1284a;
    final /* synthetic */ List f1285b;
    final /* synthetic */ C0327g f1286c;

    C0325f(C0327g c0327g, InlineTextBox inlineTextBox, List list) {
        this.f1286c = c0327g;
        this.f1284a = inlineTextBox;
        this.f1285b = list;
    }

    public final void run() {
        this.f1284a.m3223a(true, this.f1285b);
    }
}
