package com.facebook.lite.widget;

import android.content.Context;
import android.view.KeyEvent;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import com.facebook.lite.p053b.C0294h;

/* renamed from: com.facebook.lite.widget.v */
final class C0489v implements OnEditorActionListener {
    final /* synthetic */ Context f2108a;
    final /* synthetic */ InlineTextBox f2109b;

    C0489v(InlineTextBox inlineTextBox, Context context) {
        this.f2109b = inlineTextBox;
        this.f2108a = context;
    }

    public final boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
        if (i != 2 && i != 3 && i != 4 && i != 5 && i != 6) {
            return false;
        }
        C0294h.m1954a(this.f2108a, this.f2109b.f1946s);
        this.f2109b.m3214d();
        return true;
    }
}
