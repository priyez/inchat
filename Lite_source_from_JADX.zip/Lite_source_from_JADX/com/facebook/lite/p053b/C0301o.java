package com.facebook.lite.p053b;

import android.content.Context;
import android.os.Build.VERSION;
import android.os.Environment;
import com.facebook.lite.ClientApplication;
import java.io.File;

/* renamed from: com.facebook.lite.b.o */
public final class C0301o {
    private static boolean f1210a;

    static {
        f1210a = "mounted".equals(Environment.getExternalStorageState());
    }

    public static String m2171a(Context context) {
        if (!C0301o.m2173a()) {
            return null;
        }
        File externalStorageDirectory = VERSION.SDK_INT < 8 ? Environment.getExternalStorageDirectory() : context.getExternalCacheDir();
        if (externalStorageDirectory == null) {
            return null;
        }
        CharSequence absolutePath = externalStorageDirectory.getAbsolutePath();
        if (C0302p.m2177b(absolutePath)) {
            return null;
        }
        if (VERSION.SDK_INT < 8) {
            return absolutePath + "/facebook";
        }
        return absolutePath;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static long m2170a(java.lang.String r6) {
        /*
        r0 = new android.os.StatFs;	 Catch:{ NoSuchMethodError -> 0x0040, IllegalArgumentException -> 0x003b }
        r0.<init>(r6);	 Catch:{ NoSuchMethodError -> 0x0040, IllegalArgumentException -> 0x003b }
        r1 = android.os.Build.VERSION.SDK_INT;	 Catch:{ NoSuchMethodError -> 0x0040, IllegalArgumentException -> 0x003b }
        r2 = 18;
        if (r1 < r2) goto L_0x002b;
    L_0x000b:
        r2 = r0.getAvailableBlocksLong();	 Catch:{ NoSuchMethodError -> 0x001a, IllegalArgumentException -> 0x003b }
        r4 = r0.getBlockSizeLong();	 Catch:{ NoSuchMethodError -> 0x001a, IllegalArgumentException -> 0x003b }
        r2 = r2 * r4;
        r4 = 1048576; // 0x100000 float:1.469368E-39 double:5.180654E-318;
        r0 = r2 / r4;
    L_0x0019:
        return r0;
    L_0x001a:
        r1 = move-exception;
        r1 = r0.getAvailableBlocks();	 Catch:{ NoSuchMethodError -> 0x0040, IllegalArgumentException -> 0x003b }
        r2 = (long) r1;	 Catch:{ NoSuchMethodError -> 0x0040, IllegalArgumentException -> 0x003b }
        r0 = r0.getBlockSize();	 Catch:{ NoSuchMethodError -> 0x0040, IllegalArgumentException -> 0x003b }
        r0 = (long) r0;	 Catch:{ NoSuchMethodError -> 0x0040, IllegalArgumentException -> 0x003b }
        r0 = r0 * r2;
        r2 = 1048576; // 0x100000 float:1.469368E-39 double:5.180654E-318;
        r0 = r0 / r2;
        goto L_0x0019;
    L_0x002b:
        r1 = r0.getAvailableBlocks();	 Catch:{ NoSuchMethodError -> 0x0040, IllegalArgumentException -> 0x003b }
        r2 = (long) r1;	 Catch:{ NoSuchMethodError -> 0x0040, IllegalArgumentException -> 0x003b }
        r0 = r0.getBlockSize();	 Catch:{ NoSuchMethodError -> 0x0040, IllegalArgumentException -> 0x003b }
        r0 = (long) r0;	 Catch:{ NoSuchMethodError -> 0x0040, IllegalArgumentException -> 0x003b }
        r0 = r0 * r2;
        r2 = 1048576; // 0x100000 float:1.469368E-39 double:5.180654E-318;
        r0 = r0 / r2;
        goto L_0x0019;
    L_0x003b:
        r0 = move-exception;
    L_0x003c:
        r0 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
        goto L_0x0019;
    L_0x0040:
        r0 = move-exception;
        goto L_0x003c;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.b.o.a(java.lang.String):long");
    }

    public static long m2169a(File file) {
        return C0301o.m2170a(file.getAbsolutePath());
    }

    public static boolean m2173a() {
        return f1210a;
    }

    public static void m2172a(boolean z) {
        f1210a = z;
        if (z) {
            ClientApplication.m1691c().m2382N();
        } else {
            ClientApplication.m1691c().m2383O();
        }
    }
}
