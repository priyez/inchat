package com.facebook.lite.p059m;

import com.facebook.lite.net.p066a.C0394b;

/* renamed from: com.facebook.lite.m.g */
final /* synthetic */ class C0385g {
    static final /* synthetic */ int[] f1481a;

    static {
        f1481a = new int[C0394b.values().length];
        try {
            f1481a[C0394b.PAID.ordinal()] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            f1481a[C0394b.FREE.ordinal()] = 2;
        } catch (NoSuchFieldError e2) {
        }
    }
}
