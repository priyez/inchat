package com.facebook.lite;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

final class am extends BroadcastReceiver {
    final /* synthetic */ MainActivity f1158a;

    am(MainActivity mainActivity) {
        this.f1158a = mainActivity;
    }

    public final void onReceive(Context context, Intent intent) {
        MainActivity.f966a;
        this.f1158a.f990v = (Uri) intent.getParcelableExtra("extra_uri");
        this.f1158a.m1740a(context);
    }
}
