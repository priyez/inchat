package com.facebook.p031b;

import android.content.Context;
import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: com.facebook.b.t */
public abstract class C0189t {
    private static final String[] f712a;

    static {
        f712a = new String[]{"android.permission.READ_CALENDAR", "android.permission.CAMERA", "android.permission.READ_CONTACTS", "android.permission.ACCESS_FINE_LOCATION", "android.permission.RECORD_AUDIO", "android.permission.READ_PHONE_STATE", "android.permission.BODY_SENSORS", "android.permission.SEND_SMS", "android.permission.READ_EXTERNAL_STORAGE"};
    }

    private static String m1460a(String str) {
        Object obj = -1;
        switch (str.hashCode()) {
            case -2062386608:
                if (str.equals("android.permission.READ_SMS")) {
                    obj = 19;
                    break;
                }
                break;
            case -1928411001:
                if (str.equals("android.permission.READ_CALENDAR")) {
                    obj = null;
                    break;
                }
                break;
            case -1921431796:
                if (str.equals("android.permission.READ_CALL_LOG")) {
                    obj = 11;
                    break;
                }
                break;
            case -1888586689:
                if (str.equals("android.permission.ACCESS_FINE_LOCATION")) {
                    obj = 6;
                    break;
                }
                break;
            case -1479758289:
                if (str.equals("android.permission.RECEIVE_WAP_PUSH")) {
                    obj = 20;
                    break;
                }
                break;
            case -1238066820:
                if (str.equals("android.permission.BODY_SENSORS")) {
                    obj = 16;
                    break;
                }
                break;
            case -895673731:
                if (str.equals("android.permission.RECEIVE_SMS")) {
                    obj = 18;
                    break;
                }
                break;
            case -406040016:
                if (str.equals("android.permission.READ_EXTERNAL_STORAGE")) {
                    obj = 21;
                    break;
                }
                break;
            case -63024214:
                if (str.equals("android.permission.ACCESS_COARSE_LOCATION")) {
                    obj = 7;
                    break;
                }
                break;
            case -5573545:
                if (str.equals("android.permission.READ_PHONE_STATE")) {
                    obj = 9;
                    break;
                }
                break;
            case 52602690:
                if (str.equals("android.permission.SEND_SMS")) {
                    obj = 17;
                    break;
                }
                break;
            case 112197485:
                if (str.equals("android.permission.CALL_PHONE")) {
                    obj = 10;
                    break;
                }
                break;
            case 214526995:
                if (str.equals("android.permission.WRITE_CONTACTS")) {
                    obj = 4;
                    break;
                }
                break;
            case 463403621:
                if (str.equals("android.permission.CAMERA")) {
                    obj = 2;
                    break;
                }
                break;
            case 603653886:
                if (str.equals("android.permission.WRITE_CALENDAR")) {
                    obj = 1;
                    break;
                }
                break;
            case 610633091:
                if (str.equals("android.permission.WRITE_CALL_LOG")) {
                    obj = 12;
                    break;
                }
                break;
            case 784519842:
                if (str.equals("android.permission.USE_SIP")) {
                    obj = 14;
                    break;
                }
                break;
            case 952819282:
                if (str.equals("android.permission.PROCESS_OUTGOING_CALLS")) {
                    obj = 15;
                    break;
                }
                break;
            case 1271781903:
                if (str.equals("android.permission.GET_ACCOUNTS")) {
                    obj = 5;
                    break;
                }
                break;
            case 1365911975:
                if (str.equals("android.permission.WRITE_EXTERNAL_STORAGE")) {
                    obj = 22;
                    break;
                }
                break;
            case 1831139720:
                if (str.equals("android.permission.RECORD_AUDIO")) {
                    obj = 8;
                    break;
                }
                break;
            case 1977429404:
                if (str.equals("android.permission.READ_CONTACTS")) {
                    obj = 3;
                    break;
                }
                break;
            case 2133799037:
                if (str.equals("com.android.voicemail.permission.ADD_VOICEMAIL")) {
                    obj = 13;
                    break;
                }
                break;
        }
        switch (obj) {
            case null:
            case 1:
                return "android.permission-group.CALENDAR";
            case 2:
                return "android.permission-group.CAMERA";
            case 3:
            case 4:
            case 5:
                return "android.permission-group.CONTACTS";
            case 6:
            case 7:
                return "android.permission-group.LOCATION";
            case 8:
                return "android.permission-group.MICROPHONE";
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
                return "android.permission-group.PHONE";
            case 16:
                return "android.permission-group.SENSORS";
            case 17:
            case 18:
            case 19:
            case 20:
                return "android.permission-group.SMS";
            case 21:
            case 22:
                return "android.permission-group.STORAGE";
            default:
                return null;
        }
    }

    private static boolean m1461a(Context context, String str) {
        try {
            return context.checkCallingOrSelfPermission(str) == 0;
        } catch (RuntimeException e) {
            return false;
        }
    }

    public static String m1459a(Context context) {
        JSONObject jSONObject = new JSONObject();
        for (int i = 0; i < f712a.length; i++) {
            String a = C0189t.m1460a(f712a[i]);
            int lastIndexOf = a.lastIndexOf(46);
            if (lastIndexOf >= 0) {
                a = a.substring(lastIndexOf + 1);
            }
            try {
                jSONObject.put(a, C0189t.m1461a(context, f712a[i]));
            } catch (JSONException e) {
                Log.e("PermissionsReporter", "Caught JSONException " + e);
            }
        }
        return jSONObject.toString();
    }
}
