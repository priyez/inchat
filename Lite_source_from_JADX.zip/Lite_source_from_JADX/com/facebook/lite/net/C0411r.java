package com.facebook.lite.net;

/* renamed from: com.facebook.lite.net.r */
public final class C0411r {
    private final String f1655a;
    private final int f1656b;

    public C0411r(String str, int i) {
        this.f1655a = str;
        this.f1656b = i;
    }

    public final String m2898a() {
        return this.f1655a;
    }

    public final int m2899b() {
        return this.f1656b;
    }
}
