package com.facebook.lite.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;
import com.facebook.lite.ap;
import com.facebook.lite.as;
import com.facebook.lite.p053b.C0302p;
import com.facebook.lite.p068p.C0429c;
import com.p008a.p009a.p010a.p014e.C0022b;

public class FbVideoView extends RelativeLayout {
    private GestureDetector f1897a;
    private MediaController f1898b;
    private LinearLayout f1899c;
    private TextView f1900d;
    private int f1901e;
    private boolean f1902f;
    private C0429c f1903g;
    private VideoView f1904h;

    public FbVideoView(Context context) {
        super(context);
        m3171d();
    }

    public FbVideoView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        m3171d();
    }

    public FbVideoView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        m3171d();
    }

    public final void m3176a() {
        m3174e();
        post(new C0478i(this));
    }

    public final void m3178b() {
        this.f1902f = false;
        this.f1901e = this.f1904h.getCurrentPosition();
        this.f1904h.pause();
    }

    public final void m3179c() {
        if (this.f1903g != null && this.f1903g.m2960b()) {
            this.f1904h.seekTo(this.f1901e);
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        return true;
    }

    public final void m3177a(int i, int i2, int i3, int i4, String str, long j, C0022b c0022b, int i5, int i6, int i7, boolean z, String str2) {
        m3174e();
        try {
            this.f1903g = new C0429c(str, i5, i6, i7, c0022b, j);
            this.f1903g.m2961c();
            this.f1902f = z;
            if (!C0302p.m2177b((CharSequence) str2)) {
                this.f1900d.setText(str2);
            }
            LayoutParams layoutParams = new LayoutParams(-1, -1);
            layoutParams.width = i3;
            layoutParams.height = i4;
            layoutParams.setMargins(i, i2, 0, 0);
            post(new C0479j(this, layoutParams));
        } catch (Throwable e) {
            c0022b.m124a((short) 296, null, e);
        }
    }

    private void m3171d() {
        Context context = getContext();
        ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(ap.full_screen_video, this, true);
        this.f1904h = (VideoView) findViewById(as.video_view);
        this.f1899c = (LinearLayout) findViewById(as.loading_bar);
        this.f1900d = (TextView) findViewById(as.loading_text);
        this.f1904h.setZOrderMediaOverlay(true);
        this.f1904h.setOnPreparedListener(new C0481l(this));
        this.f1898b = new MediaController(context);
        this.f1898b.setAnchorView(this.f1904h);
        this.f1898b.setMediaPlayer(this.f1904h);
        this.f1898b.setEnabled(true);
        this.f1904h.setMediaController(this.f1898b);
        this.f1904h.setOnTouchListener(new C0482m(this));
        this.f1897a = new GestureDetector(context, new C0483n(this), null);
    }

    private void m3174e() {
        if (this.f1903g != null) {
            this.f1903g.m2962d();
            this.f1903g = null;
        }
    }
}
