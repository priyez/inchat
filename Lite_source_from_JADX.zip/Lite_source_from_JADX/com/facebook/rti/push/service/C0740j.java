package com.facebook.rti.push.service;

import android.text.TextUtils;
import com.facebook.rti.p078b.p079a.C0538a;
import com.facebook.rti.p078b.p093d.C0619c;
import com.facebook.rti.p078b.p096g.aa;

/* renamed from: com.facebook.rti.push.service.j */
final class C0740j implements aa {
    final /* synthetic */ FbnsService f3180a;

    C0740j(FbnsService fbnsService) {
        this.f3180a = fbnsService;
    }

    private static Long m3967a(C0619c c0619c) {
        long j = 0;
        if (TextUtils.isEmpty(c0619c.m3543a()) || !TextUtils.isEmpty(c0619c.m3544b())) {
            j = 0 | ((long) (1 << (C0538a.f2226h - 1)));
        }
        return Long.valueOf(j);
    }
}
