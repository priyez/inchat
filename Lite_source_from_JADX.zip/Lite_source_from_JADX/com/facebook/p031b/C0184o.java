package com.facebook.p031b;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Environment;
import android.os.Process;
import android.os.StatFs;
import android.os.SystemClock;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.text.format.Time;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import com.facebook.p031b.p033b.C0149c;
import com.facebook.p031b.p033b.C0152d;
import com.facebook.p031b.p034c.C0161h;
import com.facebook.p031b.p034c.C0162i;
import com.facebook.p031b.p034c.C0163j;
import com.facebook.p031b.p034c.C0164k;
import com.facebook.p031b.p034c.C0167n;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.Thread.UncaughtExceptionHandler;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPOutputStream;

/* renamed from: com.facebook.b.o */
public final class C0184o implements UncaughtExceptionHandler {
    private static AtomicBoolean f677E;
    private static final Pattern f678c;
    private static final C0182m[] f679j;
    private static C0184o f680n;
    private static int f681q;
    private static int f682r;
    private boolean f683A;
    private boolean f684B;
    private C0176g f685C;
    private C0185p f686D;
    Map f687a;
    Map f688b;
    private long f689d;
    private boolean f690e;
    private ArrayList f691f;
    private final Map f692g;
    private final Map f693h;
    private C0162i f694i;
    private boolean f695k;
    private final Object f696l;
    private UncaughtExceptionHandler f697m;
    private Context f698o;
    private File f699p;
    private final C0167n f700s;
    private String f701t;
    private String f702u;
    private volatile String f703v;
    private volatile boolean f704w;
    private boolean f705x;
    private String f706y;
    private final Time f707z;

    public C0184o() {
        this.f689d = 1048576;
        this.f690e = false;
        this.f691f = new ArrayList();
        this.f692g = new HashMap();
        this.f693h = new HashMap();
        this.f687a = new ConcurrentHashMap();
        this.f688b = new ConcurrentHashMap();
        this.f695k = false;
        this.f696l = new Object();
        this.f699p = null;
        this.f700s = new C0167n(f682r);
        this.f704w = false;
        this.f707z = new Time();
        this.f683A = false;
    }

    static {
        f678c = Pattern.compile("^\\d+-[a-zA-Z0-9_\\-]+-(\\d+)\\.(temp_stacktrace|stacktrace)$");
        f679j = new C0182m[]{C0182m.ACRA_CRASH_REPORT, C0182m.NATIVE_CRASH_REPORT, C0182m.ANR_REPORT};
        f681q = 5;
        f682r = 20;
        f677E = new AtomicBoolean(false);
    }

    private C0185p m1428c() {
        return this.f686D;
    }

    private C0176g m1431d() {
        return this.f685C;
    }

    private String m1433e() {
        return this.f703v;
    }

    public final void m1455a(String str) {
        this.f703v = str;
    }

    public final String m1450a(String str, String str2) {
        if (str2 != null) {
            return (String) this.f687a.put(str, str2);
        }
        return m1421b(str);
    }

    private String m1421b(String str) {
        if (str == null) {
            return null;
        }
        return (String) this.f687a.remove(str);
    }

    private String m1408a(Map map) {
        StringBuilder stringBuilder = new StringBuilder();
        C0184o.m1427b(stringBuilder, this.f687a);
        if (map != null) {
            C0184o.m1427b(stringBuilder, map);
        }
        C0184o.m1416a(stringBuilder, this.f688b);
        return stringBuilder.toString();
    }

    private static void m1416a(StringBuilder stringBuilder, Map map) {
        for (Entry entry : map.entrySet()) {
            String str = (String) entry.getKey();
            try {
                String a = ((C0174e) entry.getValue()).m1382a();
                if (a != null) {
                    C0184o.m1415a(stringBuilder, str, a);
                }
            } catch (Throwable th) {
                Log.e(C0148a.f621a, "Caught throwable while getting custom report data", th);
            }
        }
    }

    private static void m1427b(StringBuilder stringBuilder, Map map) {
        for (Entry entry : map.entrySet()) {
            C0184o.m1415a(stringBuilder, (String) entry.getKey(), (String) entry.getValue());
        }
    }

    private static void m1415a(StringBuilder stringBuilder, String str, String str2) {
        String replace;
        String str3 = null;
        if (str != null) {
            replace = str.replace("\n", "\\n");
        } else {
            replace = null;
        }
        if (str2 != null) {
            str3 = str2.replace("\n", "\\n");
        }
        stringBuilder.append(replace).append(" = ").append(str3).append("\n");
    }

    private String m1435f() {
        if (this.f705x) {
            return this.f706y;
        }
        this.f706y = null;
        int myPid = Process.myPid();
        ActivityManager activityManager = (ActivityManager) this.f698o.getSystemService("activity");
        if (activityManager == null) {
            return this.f706y;
        }
        List<RunningAppProcessInfo> runningAppProcesses = activityManager.getRunningAppProcesses();
        if (runningAppProcesses == null) {
            return this.f706y;
        }
        for (RunningAppProcessInfo runningAppProcessInfo : runningAppProcesses) {
            if (runningAppProcessInfo.pid == myPid) {
                this.f706y = runningAppProcessInfo.processName;
                break;
            }
        }
        this.f705x = true;
        return this.f706y;
    }

    private void m1436g() {
        this.f706y = null;
        this.f705x = false;
    }

    private String m1437h() {
        String f = m1435f();
        if (f == null) {
            return "n/a";
        }
        return f;
    }

    private String m1438i() {
        String readLine;
        String str;
        Throwable th;
        String f = m1435f();
        if (f == null) {
            BufferedReader bufferedReader;
            BufferedReader bufferedReader2 = null;
            try {
                bufferedReader = new BufferedReader(new FileReader("/proc/self/cmdline"), 128);
                try {
                    readLine = bufferedReader.readLine();
                    if (readLine != null) {
                        try {
                            readLine = readLine.trim();
                        } catch (Throwable e) {
                            Throwable th2 = e;
                            bufferedReader2 = bufferedReader;
                            str = readLine;
                            th = th2;
                            Log.e(C0148a.f621a, "Failed to get process name.", th);
                            readLine = str;
                            bufferedReader = bufferedReader2;
                            if (bufferedReader != null) {
                                try {
                                    bufferedReader.close();
                                } catch (Throwable e2) {
                                    Log.e(C0148a.f621a, "Failed to close file.", e2);
                                }
                            }
                            if (readLine != null) {
                                return "";
                            }
                            return readLine;
                        }
                    }
                } catch (IOException e3) {
                    th = e3;
                    bufferedReader2 = bufferedReader;
                    str = f;
                    Log.e(C0148a.f621a, "Failed to get process name.", th);
                    readLine = str;
                    bufferedReader = bufferedReader2;
                    if (bufferedReader != null) {
                        bufferedReader.close();
                    }
                    if (readLine != null) {
                        return readLine;
                    }
                    return "";
                }
            } catch (IOException e4) {
                th = e4;
                str = f;
                Log.e(C0148a.f621a, "Failed to get process name.", th);
                readLine = str;
                bufferedReader = bufferedReader2;
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (readLine != null) {
                    return readLine;
                }
                return "";
            }
            if (bufferedReader != null) {
                bufferedReader.close();
            }
        } else {
            readLine = f;
        }
        if (readLine != null) {
            return "";
        }
        return readLine;
    }

    private static String m1439j() {
        String str = Build.TAGS;
        if (str != null && str.contains("test-keys")) {
            return "yes";
        }
        try {
            if (new File("/system/app/Superuser.apk").exists()) {
                return "yes";
            }
        } catch (Throwable e) {
            Log.e(C0148a.f621a, "Failed to find Superuser.pak", e);
        }
        Map map = System.getenv();
        if (map != null) {
            String[] split = ((String) map.get("PATH")).split(":");
            int length = split.length;
            int i = 0;
            while (i < length) {
                try {
                    if (new File(split[i] + "/su").exists()) {
                        return "yes";
                    }
                    i++;
                } catch (Throwable e2) {
                    Log.e(C0148a.f621a, "Failed to find su binary in the PATH", e2);
                }
            }
        }
        return "no";
    }

    private static long m1440k() {
        return Process.getElapsedCpuTime();
    }

    private static long m1441l() {
        return SystemClock.elapsedRealtime();
    }

    public static C0184o m1401a() {
        if (f680n == null) {
            f680n = new C0184o();
        }
        return f680n;
    }

    public final void m1451a(Context context) {
        if (this.f697m == null) {
            this.f697m = Thread.getDefaultUncaughtExceptionHandler();
            this.f684B = false;
            this.f698o = context;
            PackageInfo a = new C0162i(context).m1351a();
            if (a != null) {
                this.f701t = Integer.toString(a.versionCode);
                this.f702u = a.versionName != null ? a.versionName : "not set";
            }
            this.f694i = new C0162i(context);
            this.f707z.setToNow();
            try {
                this.f692g.put(C0191v.ANDROID_ID, Secure.getString(context.getContentResolver(), "android_id"));
                this.f692g.put(C0191v.APP_VERSION_CODE, this.f701t);
                this.f692g.put(C0191v.APP_VERSION_NAME, this.f702u);
                this.f692g.put(C0191v.PACKAGE_NAME, context.getPackageName());
                this.f692g.put(C0191v.PHONE_MODEL, Build.MODEL);
                this.f692g.put(C0191v.DEVICE, Build.DEVICE);
                this.f692g.put(C0191v.ANDROID_VERSION, VERSION.RELEASE);
                this.f692g.put(C0191v.OS_VERSION, System.getProperty("os.version"));
                this.f692g.put(C0191v.BUILD_HOST, Build.HOST);
                this.f692g.put(C0191v.BRAND, Build.BRAND);
                this.f692g.put(C0191v.PRODUCT, Build.PRODUCT);
                Object obj = "n/a";
                File filesDir = context.getFilesDir();
                if (filesDir != null) {
                    obj = filesDir.getAbsolutePath();
                }
                this.f692g.put(C0191v.FILE_PATH, obj);
                if (VERSION.SDK_INT >= 9) {
                    this.f692g.put(C0191v.SERIAL, Build.SERIAL);
                    if (a != null) {
                        this.f692g.put(C0191v.APP_INSTALL_TIME, C0184o.m1403a(a.firstInstallTime));
                        this.f692g.put(C0191v.APP_UPGRADE_TIME, C0184o.m1403a(a.lastUpdateTime));
                    }
                }
            } catch (Throwable e) {
                Log.e(C0148a.f621a, "failed to install constants", e);
            }
            this.f699p = C0184o.m1402a(context, "acra-reports", "reportfile.prealloc");
            m1442m();
        }
    }

    private static String m1403a(long j) {
        Time time = new Time();
        time.set(j);
        return time.format3339(false);
    }

    private void m1442m() {
        Throwable e;
        FileOutputStream fileOutputStream = null;
        long j = 0;
        try {
            if (this.f699p.exists()) {
                j = this.f699p.length();
            }
            if (j <= 1048576) {
                byte[] bArr = new byte[10240];
                FileOutputStream fileOutputStream2 = new FileOutputStream(this.f699p, true);
                long j2 = j;
                while (j2 < 1048576) {
                    try {
                        fileOutputStream2.write(bArr);
                        j2 += 10240;
                    } catch (IOException e2) {
                        e = e2;
                        fileOutputStream = fileOutputStream2;
                    } catch (Throwable th) {
                        e = th;
                        fileOutputStream = fileOutputStream2;
                    }
                }
                try {
                    fileOutputStream2.close();
                } catch (IOException e3) {
                }
            }
        } catch (IOException e4) {
            e = e4;
            try {
                Log.e(C0148a.f621a, "Failed to pre-allocate crash report file", e);
                if (fileOutputStream != null) {
                    try {
                        fileOutputStream.close();
                    } catch (IOException e5) {
                    }
                }
            } catch (Throwable th2) {
                e = th2;
                if (fileOutputStream != null) {
                    try {
                        fileOutputStream.close();
                    } catch (IOException e6) {
                    }
                }
                throw e;
            }
        }
    }

    private static long m1443n() {
        try {
            StatFs statFs = new StatFs(Environment.getDataDirectory().getPath());
            return ((long) statFs.getAvailableBlocks()) * ((long) statFs.getBlockSize());
        } catch (Exception e) {
            return -1;
        }
    }

    private static long m1444o() {
        try {
            StatFs statFs = new StatFs(Environment.getDataDirectory().getPath());
            return ((long) statFs.getBlockCount()) * ((long) statFs.getBlockSize());
        } catch (Exception e) {
            return -1;
        }
    }

    private void m1411a(C0173d c0173d, Writer writer) {
        for (Entry entry : m1445p().entrySet()) {
            m1412a((C0191v) entry.getKey(), (String) entry.getValue(), c0173d, writer);
        }
    }

    private Map m1445p() {
        Map map;
        synchronized (this.f693h) {
            if (this.f693h.isEmpty()) {
                this.f693h.put(C0191v.BUILD, C0190u.m1462a(Build.class));
                this.f693h.put(C0191v.JAIL_BROKEN, C0184o.m1439j());
                this.f693h.put(C0191v.INSTALLATION_ID, C0161h.m1348a(this.f698o));
                this.f693h.put(C0191v.TOTAL_MEM_SIZE, Long.toString(C0184o.m1444o()));
                if (this.f694i.m1352a("android.permission.READ_PHONE_STATE")) {
                    String deviceId = ((TelephonyManager) this.f698o.getSystemService("phone")).getDeviceId();
                    if (deviceId != null) {
                        this.f693h.put(C0191v.DEVICE_ID, deviceId);
                    }
                }
                this.f693h.put(C0191v.DISPLAY, C0184o.m1404a(((WindowManager) this.f698o.getSystemService("window")).getDefaultDisplay()));
                this.f693h.put(C0191v.ENVIRONMENT, C0190u.m1463b(Environment.class));
                this.f693h.put(C0191v.DEVICE_FEATURES, C0175f.m1383a(this.f698o));
                this.f693h.put(C0191v.SETTINGS_SYSTEM, C0192w.m1464a(this.f698o));
                this.f693h.put(C0191v.SETTINGS_SECURE, C0192w.m1466b(this.f698o));
                if (VERSION.SDK_INT >= 19) {
                    this.f693h.put(C0191v.IS_LOW_RAM_DEVICE, Boolean.toString(((ActivityManager) this.f698o.getSystemService("activity")).isLowRamDevice()));
                }
                this.f693h.put(C0191v.ANDROID_RUNTIME, C0184o.m1446q());
                if (VERSION.SDK_INT >= 21) {
                    PackageInfo b = this.f694i.m1353b("com.google.android.webview");
                    if (b != null) {
                        this.f693h.put(C0191v.WEBVIEW_VERSION, b.versionName);
                    }
                }
            }
            map = this.f693h;
        }
        return map;
    }

    private static String m1446q() {
        if (VERSION.SDK_INT < 19) {
            return "DALVIK";
        }
        String property = System.getProperty("java.boot.class.path");
        if (property != null) {
            if (property.contains("/system/framework/core-libart.jar")) {
                return "ART";
            }
            if (property.contains("/system/framework/core.jar")) {
                return "DALVIK";
            }
        }
        return "UNKNOWN";
    }

    private void m1409a(Context context, Throwable th, C0191v[] c0191vArr, C0173d c0173d, Writer writer) {
        List asList = Arrays.asList(c0191vArr);
        if (asList.contains(C0191v.REPORT_ID)) {
            m1412a(C0191v.REPORT_ID, UUID.randomUUID().toString(), c0173d, writer);
        }
        if (asList.contains(C0191v.PROCESS_NAME)) {
            m1412a(C0191v.PROCESS_NAME, m1438i(), c0173d, writer);
        }
        if (asList.contains(C0191v.USER_APP_START_DATE)) {
            m1412a(C0191v.USER_APP_START_DATE, this.f707z.format3339(false), c0173d, writer);
        }
        if (asList.contains(C0191v.PROCESS_UPTIME)) {
            m1412a(C0191v.PROCESS_UPTIME, Long.toString(C0184o.m1440k()), c0173d, writer);
        }
        if (asList.contains(C0191v.DEVICE_UPTIME)) {
            m1412a(C0191v.DEVICE_UPTIME, Long.toString(C0184o.m1441l()), c0173d, writer);
        }
        if (asList.contains(C0191v.CRASH_CONFIGURATION)) {
            m1412a(C0191v.CRASH_CONFIGURATION, C0172c.m1370a(context.getResources().getConfiguration()), c0173d, writer);
        }
        if (asList.contains(C0191v.AVAILABLE_MEM_SIZE)) {
            m1412a(C0191v.AVAILABLE_MEM_SIZE, Long.toString(C0184o.m1443n()), c0173d, writer);
        }
        if (asList.contains(C0191v.DUMPSYS_MEMINFO)) {
            m1412a(C0191v.DUMPSYS_MEMINFO, C0178i.m1386a(context), c0173d, writer);
        }
        if (asList.contains(C0191v.USER_CRASH_DATE)) {
            Time time = new Time();
            time.setToNow();
            m1412a(C0191v.USER_CRASH_DATE, time.format3339(false), c0173d, writer);
        }
        if (asList.contains(C0191v.ACTIVITY_LOG)) {
            String c0167n;
            if (th instanceof OutOfMemoryError) {
                c0167n = this.f700s.toString();
            } else {
                c0167n = this.f700s.m1359a(f681q);
            }
            m1412a(C0191v.ACTIVITY_LOG, c0167n, c0173d, writer);
        }
        if (asList.contains(C0191v.PROCESS_NAME_BY_AMS)) {
            m1412a(C0191v.PROCESS_NAME_BY_AMS, m1437h(), c0173d, writer);
        }
        m1436g();
        if (asList.contains(C0191v.OPEN_FD_COUNT)) {
            m1412a(C0191v.OPEN_FD_COUNT, String.valueOf(C0164k.m1354a()), c0173d, writer);
        }
        if (asList.contains(C0191v.OPEN_FD_SOFT_LIMIT) || asList.contains(C0191v.OPEN_FD_HARD_LIMIT)) {
            C0163j b = C0164k.m1355b();
            if (b != null) {
                if (asList.contains(C0191v.OPEN_FD_SOFT_LIMIT)) {
                    m1412a(C0191v.OPEN_FD_SOFT_LIMIT, b.f634a, c0173d, writer);
                }
                if (asList.contains(C0191v.OPEN_FD_HARD_LIMIT)) {
                    m1412a(C0191v.OPEN_FD_HARD_LIMIT, b.f635b, c0173d, writer);
                }
            }
        }
        if (VERSION.SDK_INT >= 23 && asList.contains(C0191v.RUNTIME_PERMISSIONS)) {
            m1412a(C0191v.RUNTIME_PERMISSIONS, C0189t.m1459a(this.f698o), c0173d, writer);
        }
        if (VERSION.SDK_INT >= 16 && this.f684B) {
            if (asList.contains(C0191v.LOGCAT)) {
                m1412a(C0191v.LOGCAT, C0186q.m1457a(null), c0173d, writer);
            }
            if (asList.contains(C0191v.EVENTSLOG)) {
                m1412a(C0191v.EVENTSLOG, C0186q.m1457a("events"), c0173d, writer);
            }
            if (asList.contains(C0191v.RADIOLOG)) {
                m1412a(C0191v.RADIOLOG, C0186q.m1457a("radio"), c0173d, writer);
            }
            if (asList.contains(C0191v.DROPBOX)) {
                m1412a(C0191v.DROPBOX, C0177h.m1385a(this.f698o, C0148a.m1327a().m1314a()), c0173d, writer);
            }
        }
        if (asList.contains(C0191v.LARGE_MEM_HEAP) && VERSION.SDK_INT >= 11) {
            m1412a(C0191v.LARGE_MEM_HEAP, C0178i.m1387b(context), c0173d, writer);
        }
    }

    private static String m1404a(Display display) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        display.getMetrics(displayMetrics);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("width=").append(display.getWidth()).append('\n').append("height=").append(display.getHeight()).append('\n').append("pixelFormat=").append(display.getPixelFormat()).append('\n').append("refreshRate=").append(display.getRefreshRate()).append("fps\nmetrics.density=x").append(displayMetrics.density).append('\n').append("metrics.scaledDensity=x").append(displayMetrics.scaledDensity).append('\n').append("metrics.widthPixels=").append(displayMetrics.widthPixels).append('\n').append("metrics.heightPixels=").append(displayMetrics.heightPixels).append('\n').append("metrics.xdpi=").append(displayMetrics.xdpi).append('\n').append("metrics.ydpi=").append(displayMetrics.ydpi);
        return stringBuilder.toString();
    }

    public final void uncaughtException(Thread thread, Throwable th) {
        Map hashMap;
        Throwable a;
        Log.e(C0148a.f621a, "ACRA caught a " + th.getClass().getSimpleName() + " exception for " + this.f698o.getPackageName() + ". Building report.");
        this.f683A = true;
        boolean andSet = f677E.getAndSet(true);
        try {
            hashMap = new HashMap();
            try {
                hashMap.put("IS_PROCESSING_ANOTHER_EXCEPTION", String.valueOf(andSet));
            } catch (OutOfMemoryError e) {
            }
        } catch (OutOfMemoryError e2) {
            hashMap = null;
        }
        C0176g d = m1431d();
        if (d != null) {
            a = d.m1384a();
            if (a != null) {
                th = a;
            }
        }
        C0183n a2 = m1449a(th, hashMap);
        if (a2 != null) {
            while (a2.isAlive()) {
                try {
                    Thread.sleep(100);
                } catch (Throwable e3) {
                    Log.e(C0148a.f621a, "Error : ", e3);
                }
            }
            a = a2.m1394a();
            if (a != null) {
                Log.e(C0148a.f621a, "ReportsWorkerSender failed with exception", a);
                m1400a(a, hashMap, C0184o.m1430c(th), false);
            }
        }
        if (this.f697m != null) {
            this.f697m.uncaughtException(thread, th);
        }
    }

    private void m1413a(String str, String str2, Throwable th) {
        if (m1428c() == null) {
            Log.e(str, str2, th);
        }
    }

    private static String m1422b(Throwable th) {
        if (th == null) {
            th = new Exception("Report requested by developer");
        }
        Writer stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        th.printStackTrace(printWriter);
        printWriter.close();
        return stringWriter.toString();
    }

    private void m1414a(String str, Throwable th, C0191v[] c0191vArr, C0173d c0173d, Writer writer, Map map) {
        C0191v[] c0191vArr2;
        if (c0191vArr == null) {
            c0191vArr2 = C0148a.f623c;
        } else {
            c0191vArr2 = c0191vArr;
        }
        m1412a(C0191v.UID, m1433e(), c0173d, writer);
        m1412a(C0191v.STACK_TRACE, str, c0173d, writer);
        for (Entry entry : this.f692g.entrySet()) {
            m1412a((C0191v) entry.getKey(), (String) entry.getValue(), c0173d, writer);
        }
        m1409a(this.f698o, th, c0191vArr2, c0173d, writer);
        m1411a(c0173d, writer);
        m1412a(C0191v.CUSTOM_DATA, m1408a(map), c0173d, writer);
    }

    private void m1412a(C0191v c0191v, String str, C0173d c0173d, Writer writer) {
        try {
            if (this.f704w) {
                writer = null;
            }
            c0173d.m1379a(c0191v, str, writer);
        } catch (IOException e) {
            this.f704w = true;
        }
    }

    public final C0183n m1448a(Throwable th) {
        return m1449a(th, null);
    }

    public final C0183n m1449a(Throwable th, Map map) {
        return m1400a(th, map, C0184o.m1430c(th), !(th instanceof OutOfMemoryError));
    }

    private C0183n m1400a(Throwable th, Map map, C0191v[] c0191vArr, boolean z) {
        RandomAccessFile randomAccessFile;
        Throwable d = C0184o.m1432d(th);
        Class cls = d.getClass();
        if (!m1434e(d)) {
            return null;
        }
        FileChannel channel;
        C0183n c0183n;
        String str;
        C0173d c0173d = new C0173d();
        m1413a(C0148a.f621a, "Handling exception for " + (th instanceof C0188s ? ((C0188s) th).m1458a() : "crash"), th);
        String str2 = C0148a.f621a;
        File a = C0184o.m1402a(this.f698o, "acra-reports", m1407a(cls, ".temp_stacktrace"));
        String a2 = m1407a(cls, ".stacktrace");
        File a3 = C0184o.m1402a(this.f698o, "acra-reports", a2);
        RandomAccessFile randomAccessFile2 = null;
        Writer writer = null;
        try {
            if (this.f683A) {
                this.f699p.renameTo(a);
            }
            RandomAccessFile randomAccessFile3 = new RandomAccessFile(a, "rw");
            try {
                writer = C0173d.m1373a(new FileOutputStream(randomAccessFile3.getFD()));
                randomAccessFile = randomAccessFile3;
            } catch (Exception e) {
                d = e;
                randomAccessFile2 = randomAccessFile3;
                Log.e(C0148a.f621a, "An error occurred while creating the report file ...", d);
                this.f704w = true;
                randomAccessFile = randomAccessFile2;
                m1412a(C0191v.ACRA_REPORT_FILENAME, a2, c0173d, writer);
                m1412a(C0191v.EXCEPTION_CAUSE, cls.getName(), c0173d, writer);
                m1414a(C0184o.m1422b(th), th, c0191vArr, c0173d, writer, map);
                if (randomAccessFile != null) {
                    try {
                        channel = randomAccessFile.getChannel();
                        channel.truncate(channel.position());
                        randomAccessFile.close();
                        a.renameTo(a3);
                    } catch (Throwable d2) {
                        Log.e(C0148a.f621a, "An error occurred while deleting closing the report file ...", d2);
                    }
                }
                if (z) {
                    if (this.f704w) {
                        c0183n = new C0183n(this, c0173d);
                    } else {
                        c0183n = new C0183n(this, C0182m.ACRA_CRASH_REPORT);
                    }
                    str = C0148a.f621a;
                    c0183n.start();
                    return c0183n;
                }
                str2 = C0148a.f621a;
                return null;
            }
        } catch (Exception e2) {
            d2 = e2;
            Log.e(C0148a.f621a, "An error occurred while creating the report file ...", d2);
            this.f704w = true;
            randomAccessFile = randomAccessFile2;
            m1412a(C0191v.ACRA_REPORT_FILENAME, a2, c0173d, writer);
            m1412a(C0191v.EXCEPTION_CAUSE, cls.getName(), c0173d, writer);
            m1414a(C0184o.m1422b(th), th, c0191vArr, c0173d, writer, map);
            if (randomAccessFile != null) {
                channel = randomAccessFile.getChannel();
                channel.truncate(channel.position());
                randomAccessFile.close();
                a.renameTo(a3);
            }
            if (z) {
                str2 = C0148a.f621a;
                return null;
            }
            if (this.f704w) {
                c0183n = new C0183n(this, C0182m.ACRA_CRASH_REPORT);
            } else {
                c0183n = new C0183n(this, c0173d);
            }
            str = C0148a.f621a;
            c0183n.start();
            return c0183n;
        }
        try {
            m1412a(C0191v.ACRA_REPORT_FILENAME, a2, c0173d, writer);
            m1412a(C0191v.EXCEPTION_CAUSE, cls.getName(), c0173d, writer);
            m1414a(C0184o.m1422b(th), th, c0191vArr, c0173d, writer, map);
            if (randomAccessFile != null) {
                channel = randomAccessFile.getChannel();
                channel.truncate(channel.position());
                randomAccessFile.close();
                a.renameTo(a3);
            }
        } catch (Throwable d22) {
            try {
                Log.e(C0148a.f621a, "An error occurred while gathering crash data ...", d22);
                m1412a(C0191v.ACRA_INTERNAL, C0184o.m1422b(d22), c0173d, writer);
            } catch (Throwable e3) {
                Log.e(C0148a.f621a, "An error occurred while gathering internal crash data ...", e3);
                m1412a(C0191v.ACRA_INTERNAL, "ACRA_INTERNAL=java.lang.Exception: An exception occurred while trying to collect data about an ACRA internal error\n\tat com.facebook.acra.ErrorReporter.handleException(ErrorReporter.java:810)\n\tat com.facebook.acra.ErrorReporter.handleException(ErrorReporter.java:866)\n\tat com.facebook.acra.ErrorReporter.uncaughtException(ErrorReporter.java:666)\n\tat java.lang.ThreadGroup.uncaughtException(ThreadGroup.java:693)\n\tat java.lang.ThreadGroup.uncaughtException(ThreadGroup.java:690)\n", c0173d, writer);
                if (randomAccessFile != null) {
                    try {
                        channel = randomAccessFile.getChannel();
                        channel.truncate(channel.position());
                        randomAccessFile.close();
                        a.renameTo(a3);
                    } catch (Throwable d222) {
                        Log.e(C0148a.f621a, "An error occurred while deleting closing the report file ...", d222);
                    }
                }
                if (z) {
                    if (this.f704w) {
                        c0183n = new C0183n(this, c0173d);
                    } else {
                        c0183n = new C0183n(this, C0182m.ACRA_CRASH_REPORT);
                    }
                    str = C0148a.f621a;
                    c0183n.start();
                    return c0183n;
                }
                str2 = C0148a.f621a;
                return null;
            } finally {
                Log.e(C0148a.f621a, "An error occurred while gathering crash data ...", d222);
            }
            if (randomAccessFile != null) {
                channel = randomAccessFile.getChannel();
                channel.truncate(channel.position());
                randomAccessFile.close();
                a.renameTo(a3);
            }
        } catch (Throwable th2) {
            if (randomAccessFile != null) {
                try {
                    FileChannel channel2 = randomAccessFile.getChannel();
                    channel2.truncate(channel2.position());
                    randomAccessFile.close();
                    a.renameTo(a3);
                } catch (Throwable e32) {
                    Log.e(C0148a.f621a, "An error occurred while deleting closing the report file ...", e32);
                }
            }
        }
        if (z) {
            if (this.f704w) {
                c0183n = new C0183n(this, c0173d);
            } else {
                c0183n = new C0183n(this, C0182m.ACRA_CRASH_REPORT);
            }
            str = C0148a.f621a;
            c0183n.start();
            return c0183n;
        }
        str2 = C0148a.f621a;
        return null;
    }

    private void m1410a(C0173d c0173d) {
        Iterator it = this.f691f.iterator();
        Object obj = null;
        while (it.hasNext()) {
            C0149c c0149c = (C0149c) it.next();
            try {
                c0149c.m1332a(c0173d);
                obj = 1;
            } catch (C0152d e) {
                if (obj == null) {
                    throw e;
                }
                Log.w(C0148a.f621a, "ReportSender of class " + c0149c.getClass().getName() + " failed but other senders completed their task. ACRA will not send this report again.");
            }
        }
    }

    private String m1407a(Class cls, String str) {
        return Long.toString(System.currentTimeMillis()) + "-" + cls.getSimpleName() + (this.f701t != null ? "-" + this.f701t : "") + str;
    }

    private File[] m1419a(String str, String... strArr) {
        if (this.f698o == null) {
            Log.e(C0148a.f621a, "Trying to get ACRA reports but ACRA is not initialized.");
            return new File[0];
        }
        File dir = this.f698o.getDir(str, 0);
        if (dir == null) {
            Log.w(C0148a.f621a, "Application files directory does not exist! The application may not be installed correctly. Please try reinstalling.");
            return new File[0];
        }
        String str2 = C0148a.f621a;
        new StringBuilder("Looking for error files in ").append(dir.getAbsolutePath());
        File[] listFiles = dir.listFiles(new C0179j(this, strArr));
        if (listFiles == null) {
            return new File[0];
        }
        Arrays.sort(listFiles, new C0180k(this));
        return listFiles;
    }

    final synchronized void m1453a(Context context, C0182m... c0182mArr) {
        String str = C0148a.f621a;
        for (C0182m c0182m : c0182mArr) {
            if (C0182m.ACRA_CRASH_REPORT == c0182m) {
                m1423b(context);
            } else {
                m1395a(context, c0182m);
            }
        }
        str = C0148a.f621a;
    }

    private void m1423b(Context context) {
        int i = 0;
        File[] a = m1419a("acra-reports", ".stacktrace", ".temp_stacktrace");
        String h = m1437h();
        for (File file : a) {
            if (i >= 5) {
                C0184o.m1426b(file);
            } else {
                String name = file.getName();
                String str = C0148a.f621a;
                try {
                    C0173d a2 = m1397a(context, file);
                    if (a2 != null) {
                        a2.put(C0191v.ACRA_REPORT_TYPE, C0182m.ACRA_CRASH_REPORT.name());
                        a2.put(C0191v.ACRA_REPORT_FILENAME, name);
                        a2.put(C0191v.UPLOADED_BY_PROCESS, h);
                        Log.i(C0148a.f621a, "Sending file " + name);
                        m1410a(a2);
                        C0184o.m1426b(file);
                    }
                    i++;
                } catch (Throwable e) {
                    Log.e(C0148a.f621a, "Failed to send crash reports", e);
                    C0184o.m1426b(file);
                    return;
                } catch (Throwable e2) {
                    Log.e(C0148a.f621a, "Failed to load crash report for " + name, e2);
                    C0184o.m1426b(file);
                    return;
                } catch (Throwable e22) {
                    Log.e(C0148a.f621a, "Failed to send crash report for " + name, e22);
                    return;
                }
            }
        }
    }

    private int m1395a(Context context, C0182m c0182m) {
        int i = 0;
        String str = C0148a.f621a;
        if (new File(c0182m.f669d + "/.noupload").exists()) {
            return 0;
        }
        int i2;
        File[] a = m1419a(c0182m.f669d, c0182m.f672g);
        if (a == null || a.length <= 0) {
            i2 = 0;
        } else {
            C0173d c0173d = new C0173d();
            c0173d.put(C0191v.ACRA_REPORT_TYPE, c0182m.name());
            try {
                m1414a("crash attachment", new C0181l(), C0148a.f622b, c0173d, null, null);
            } catch (Exception e) {
                m1412a(C0191v.REPORT_LOAD_THROW, "retrieve exception: " + e.getMessage(), c0173d, null);
            }
            int length = a.length;
            i2 = 0;
            while (i < length) {
                int i3;
                File file = a[i];
                if (i2 >= 5) {
                    C0184o.m1426b(file);
                    i3 = i2;
                } else {
                    String name = file.getName();
                    try {
                        C0173d a2 = m1398a(context, file, c0182m);
                        if (a2 == null) {
                            i3 = i2;
                        } else {
                            str = (String) a2.get(c0182m.f671f);
                            c0173d.m1379a(C0191v.REPORT_ID, name.substring(0, name.lastIndexOf(46)), null);
                            c0173d.m1379a(c0182m.f671f, str, null);
                            c0173d.m1380a(a2);
                            c0173d.m1379a(C0191v.EXCEPTION_CAUSE, "crash attachment", null);
                            m1410a(c0173d);
                            C0184o.m1426b(file);
                            i3 = i2 + 1;
                        }
                    } catch (Throwable e2) {
                        Log.e(C0148a.f621a, "Failed to send crash attachment report " + name, e2);
                    } catch (Throwable e22) {
                        Log.e(C0148a.f621a, "Failed on crash attachment file " + name, e22);
                        C0184o.m1426b(file);
                    }
                }
                i++;
                i2 = i3;
            }
        }
        str = C0148a.f621a;
        new StringBuilder("#checkAndSendCrashAttachments - finish, sent: ").append(Integer.toString(i2));
        return i2;
    }

    final synchronized void m1452a(Context context, C0173d c0173d) {
        Log.i(C0148a.f621a, "Sending in-memory report");
        try {
            c0173d.put(C0191v.UPLOADED_BY_PROCESS, m1437h());
            m1410a(c0173d);
            String str = (String) c0173d.get(C0191v.ACRA_REPORT_FILENAME);
            if (str != null) {
                C0184o.m1426b(C0184o.m1402a(context, "acra-reports", str));
            }
        } catch (Throwable e) {
            Log.e(C0148a.f621a, "Failed to send in-memory crash report: ", e);
        }
    }

    private C0173d m1397a(Context context, File file) {
        return m1399a(context, file, C0182m.ACRA_CRASH_REPORT, this.f689d);
    }

    private C0173d m1398a(Context context, File file, C0182m c0182m) {
        return m1399a(context, file, c0182m, c0182m.f670e);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private com.facebook.p031b.C0173d m1399a(android.content.Context r21, java.io.File r22, com.facebook.p031b.C0182m r23, long r24) {
        /*
        r20 = this;
        r7 = r22.getName();
        r4 = java.lang.System.currentTimeMillis();
        r8 = r22.lastModified();
        r2 = ".temp_stacktrace";
        r2 = r7.endsWith(r2);
        if (r2 == 0) goto L_0x0061;
    L_0x0014:
        r2 = 0;
        r2 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1));
        if (r2 <= 0) goto L_0x003f;
    L_0x001a:
        r2 = r4 - r8;
        r10 = 600000; // 0x927c0 float:8.40779E-40 double:2.964394E-318;
        r2 = (r2 > r10 ? 1 : (r2 == r10 ? 0 : -1));
        if (r2 >= 0) goto L_0x003f;
    L_0x0023:
        r2 = com.facebook.p031b.C0148a.f621a;
        r3 = new java.lang.StringBuilder;
        r4 = "temp file ";
        r3.<init>(r4);
        r3 = r3.append(r7);
        r4 = " is too recent; skipping";
        r3 = r3.append(r4);
        r3 = r3.toString();
        android.util.Log.w(r2, r3);
        r2 = 0;
    L_0x003e:
        return r2;
    L_0x003f:
        r2 = r22.exists();
        if (r2 != 0) goto L_0x0061;
    L_0x0045:
        r2 = com.facebook.p031b.C0148a.f621a;
        r3 = new java.lang.StringBuilder;
        r4 = "temp file ";
        r3.<init>(r4);
        r3 = r3.append(r7);
        r4 = " deleted. skipping";
        r3 = r3.append(r4);
        r3 = r3.toString();
        android.util.Log.w(r2, r3);
        r2 = 0;
        goto L_0x003e;
    L_0x0061:
        r2 = new com.facebook.b.d;
        r2.<init>();
        r3 = com.facebook.p031b.C0191v.TIME_OF_CRASH;
        r6 = java.lang.Long.toString(r8);
        r2.put(r3, r6);
        r4 = r4 - r8;
        r8 = 604800000; // 0x240c8400 float:3.046947E-17 double:2.988109026E-315;
        r3 = (r4 > r8 ? 1 : (r4 == r8 ? 0 : -1));
        if (r3 <= 0) goto L_0x00af;
    L_0x0077:
        r3 = com.facebook.p031b.C0148a.f621a;
        r4 = new java.lang.StringBuilder;
        r5 = "crash report ";
        r4.<init>(r5);
        r4 = r4.append(r7);
        r5 = " was too old; deleted";
        r4 = r4.append(r5);
        r4 = r4.toString();
        android.util.Log.w(r3, r4);
        com.facebook.p031b.C0184o.m1426b(r22);
        r3 = r23.f671f;
        if (r3 == 0) goto L_0x00a3;
    L_0x009a:
        r3 = r23.f671f;
        r4 = "attachment too old";
        r2.put(r3, r4);
    L_0x00a3:
        r3 = com.facebook.p031b.C0191v.MINIDUMP_EXCLUDE_REASON;
        r4 = com.facebook.p031b.C0187r.DUMP_TOO_OLD;
        r4 = r4.name();
        r2.put(r3, r4);
        goto L_0x003e;
    L_0x00af:
        r8 = r22.length();
        r3 = (r8 > r24 ? 1 : (r8 == r24 ? 0 : -1));
        if (r3 <= 0) goto L_0x010d;
    L_0x00b7:
        r3 = com.facebook.p031b.C0148a.f621a;
        r4 = new java.lang.StringBuilder;
        r4.<init>();
        r4 = r4.append(r8);
        r5 = "-byte crash report ";
        r4 = r4.append(r5);
        r4 = r4.append(r7);
        r5 = " exceeded max size of ";
        r4 = r4.append(r5);
        r0 = r24;
        r4 = r4.append(r0);
        r5 = " bytes; deleted";
        r4 = r4.append(r5);
        r4 = r4.toString();
        android.util.Log.w(r3, r4);
        com.facebook.p031b.C0184o.m1426b(r22);
        r3 = r23.f671f;
        if (r3 == 0) goto L_0x00f7;
    L_0x00ee:
        r3 = r23.f671f;
        r4 = "attachment too big";
        r2.put(r3, r4);
    L_0x00f7:
        r3 = com.facebook.p031b.C0191v.MINIDUMP_EXCLUDE_REASON;
        r4 = com.facebook.p031b.C0187r.DUMP_TOO_BIG;
        r4 = r4.name();
        r2.put(r3, r4);
        r3 = com.facebook.p031b.C0191v.ATTACHMENT_ORIGINAL_SIZE;
        r4 = java.lang.String.valueOf(r8);
        r2.put(r3, r4);
        goto L_0x003e;
    L_0x010d:
        r10 = new java.io.FileInputStream;
        r0 = r22;
        r10.<init>(r0);
        r6 = 0;
        r3 = com.facebook.p031b.C0182m.ACRA_CRASH_REPORT;	 Catch:{ Throwable -> 0x019c }
        r0 = r23;
        if (r0 != r3) goto L_0x012d;
    L_0x011b:
        r2.m1381a(r10);	 Catch:{ Throwable -> 0x019c }
    L_0x011e:
        r10.close();
    L_0x0121:
        r3 = com.facebook.p031b.C0191v.ACRA_REPORT_FILENAME;
        r2.put(r3, r7);
        r0 = r20;
        r0.m1425b(r2);
        goto L_0x003e;
    L_0x012d:
        r3 = (int) r8;
        r3 = com.facebook.p031b.C0184o.m1406a(r10, r3);	 Catch:{ Throwable -> 0x019c }
        r4 = com.facebook.p031b.C0182m.NATIVE_CRASH_REPORT;	 Catch:{ Throwable -> 0x019c }
        r0 = r23;
        if (r0 != r4) goto L_0x018b;
    L_0x0138:
        r0 = r20;
        r4 = r0.f698o;	 Catch:{ Throwable -> 0x019c }
        r11 = r4.getFilesDir();	 Catch:{ Throwable -> 0x019c }
        r12 = new java.io.File;	 Catch:{ Throwable -> 0x019c }
        r4 = "last_url_opened";
        r12.<init>(r11, r4);	 Catch:{ Throwable -> 0x019c }
        r4 = r12.exists();	 Catch:{ Throwable -> 0x019c }
        if (r4 != 0) goto L_0x01ff;
    L_0x014d:
        r4 = com.facebook.p031b.C0191v.LAST_URL_VISITED;	 Catch:{ Throwable -> 0x019c }
        r5 = "NO_FILE";
        r2.put(r4, r5);	 Catch:{ Throwable -> 0x019c }
    L_0x0154:
        r12 = new java.io.File;	 Catch:{ Throwable -> 0x019c }
        r4 = "last_activity_opened";
        r12.<init>(r11, r4);	 Catch:{ Throwable -> 0x019c }
        r4 = r12.exists();	 Catch:{ Throwable -> 0x019c }
        if (r4 != 0) goto L_0x0276;
    L_0x0161:
        r4 = com.facebook.p031b.C0191v.LAST_ACTIVITY_LOGGED;	 Catch:{ Throwable -> 0x019c }
        r5 = "NO_FILE";
        r2.put(r4, r5);	 Catch:{ Throwable -> 0x019c }
    L_0x0168:
        r4 = new java.io.File;	 Catch:{ Throwable -> 0x019c }
        r5 = "iab_open_times";
        r4.<init>(r11, r5);	 Catch:{ Throwable -> 0x019c }
        r5 = com.facebook.p031b.C0184o.m1405a(r4);	 Catch:{ Throwable -> 0x019c }
        r11 = "NO_FILE";
        r11 = r11.equals(r5);	 Catch:{ Throwable -> 0x019c }
        if (r11 == 0) goto L_0x02dc;
    L_0x017b:
        r5 = com.facebook.p031b.C0191v.IAB_OPEN_TIMES;	 Catch:{ Throwable -> 0x019c }
        r11 = "0";
        r2.put(r5, r11);	 Catch:{ Throwable -> 0x019c }
    L_0x0182:
        r5 = r4.exists();	 Catch:{ Throwable -> 0x019c }
        if (r5 == 0) goto L_0x018b;
    L_0x0188:
        r4.delete();	 Catch:{ Throwable -> 0x019c }
    L_0x018b:
        r4 = r23.f671f;	 Catch:{ Throwable -> 0x019c }
        r2.put(r4, r3);	 Catch:{ Throwable -> 0x019c }
        r3 = com.facebook.p031b.C0191v.ATTACHMENT_ORIGINAL_SIZE;	 Catch:{ Throwable -> 0x019c }
        r4 = java.lang.String.valueOf(r8);	 Catch:{ Throwable -> 0x019c }
        r2.put(r3, r4);	 Catch:{ Throwable -> 0x019c }
        goto L_0x011e;
    L_0x019c:
        r3 = move-exception;
        r4 = com.facebook.p031b.C0191v.REPORT_LOAD_THROW;	 Catch:{ all -> 0x0227 }
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0227 }
        r8 = "throwable: ";
        r5.<init>(r8);	 Catch:{ all -> 0x0227 }
        r8 = r3.getMessage();	 Catch:{ all -> 0x0227 }
        r5 = r5.append(r8);	 Catch:{ all -> 0x0227 }
        r5 = r5.toString();	 Catch:{ all -> 0x0227 }
        r2.put(r4, r5);	 Catch:{ all -> 0x0227 }
        r4 = com.facebook.p031b.C0148a.f621a;	 Catch:{ all -> 0x0227 }
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0227 }
        r8 = "Could not load crash report:";
        r5.<init>(r8);	 Catch:{ all -> 0x0227 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x0227 }
        r8 = " ";
        r5 = r5.append(r8);	 Catch:{ all -> 0x0227 }
        r3 = r5.append(r3);	 Catch:{ all -> 0x0227 }
        r3 = r3.toString();	 Catch:{ all -> 0x0227 }
        android.util.Log.e(r4, r3);	 Catch:{ all -> 0x0227 }
        r10.close();	 Catch:{ all -> 0x0227 }
        r3 = 1;
        r0 = r21;
        r0.deleteFile(r7);	 Catch:{ all -> 0x01f8 }
        r4 = com.facebook.p031b.C0148a.f621a;	 Catch:{ all -> 0x01f8 }
        r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x01f8 }
        r6 = "Crash report:";
        r5.<init>(r6);	 Catch:{ all -> 0x01f8 }
        r5 = r5.append(r7);	 Catch:{ all -> 0x01f8 }
        r6 = " deleted";
        r5 = r5.append(r6);	 Catch:{ all -> 0x01f8 }
        r5 = r5.toString();	 Catch:{ all -> 0x01f8 }
        android.util.Log.e(r4, r5);	 Catch:{ all -> 0x01f8 }
        goto L_0x0121;
    L_0x01f8:
        r2 = move-exception;
    L_0x01f9:
        if (r3 != 0) goto L_0x01fe;
    L_0x01fb:
        r10.close();
    L_0x01fe:
        throw r2;
    L_0x01ff:
        r13 = new java.io.FileReader;	 Catch:{ Throwable -> 0x019c }
        r13.<init>(r12);	 Catch:{ Throwable -> 0x019c }
        r5 = 0;
        r14 = new java.io.BufferedReader;	 Catch:{ Throwable -> 0x0253, all -> 0x0266 }
        r4 = 1024; // 0x400 float:1.435E-42 double:5.06E-321;
        r14.<init>(r13, r4);	 Catch:{ Throwable -> 0x0253, all -> 0x0266 }
        r4 = 0;
        r15 = r14.readLine();	 Catch:{ Throwable -> 0x0245, all -> 0x02e7 }
        if (r15 != 0) goto L_0x022a;
    L_0x0213:
        r15 = com.facebook.p031b.C0191v.LAST_URL_VISITED;	 Catch:{ Throwable -> 0x0245, all -> 0x02e7 }
        r16 = "EMPTY_URL";
        r0 = r16;
        r2.put(r15, r0);	 Catch:{ Throwable -> 0x0245, all -> 0x02e7 }
    L_0x021c:
        r12.delete();	 Catch:{ Throwable -> 0x0245, all -> 0x02e7 }
        r14.close();	 Catch:{ Throwable -> 0x0253, all -> 0x0266 }
        r13.close();	 Catch:{ Throwable -> 0x019c }
        goto L_0x0154;
    L_0x0227:
        r2 = move-exception;
        r3 = r6;
        goto L_0x01f9;
    L_0x022a:
        r15 = r15.trim();	 Catch:{ Throwable -> 0x0245, all -> 0x02e7 }
        r16 = com.facebook.p031b.C0191v.LAST_URL_VISITED;	 Catch:{ Throwable -> 0x0245, all -> 0x02e7 }
        r0 = r16;
        r2.put(r0, r15);	 Catch:{ Throwable -> 0x0245, all -> 0x02e7 }
        r15 = com.facebook.p031b.C0191v.LAST_URL_VISITED_TIME;	 Catch:{ Throwable -> 0x0245, all -> 0x02e7 }
        r16 = r12.lastModified();	 Catch:{ Throwable -> 0x0245, all -> 0x02e7 }
        r16 = java.lang.Long.toString(r16);	 Catch:{ Throwable -> 0x0245, all -> 0x02e7 }
        r0 = r16;
        r2.put(r15, r0);	 Catch:{ Throwable -> 0x0245, all -> 0x02e7 }
        goto L_0x021c;
    L_0x0245:
        r3 = move-exception;
        throw r3;	 Catch:{ all -> 0x0247 }
    L_0x0247:
        r4 = move-exception;
        r18 = r4;
        r4 = r3;
        r3 = r18;
    L_0x024d:
        if (r4 == 0) goto L_0x0269;
    L_0x024f:
        r14.close();	 Catch:{ Throwable -> 0x0261, all -> 0x0266 }
    L_0x0252:
        throw r3;	 Catch:{ Throwable -> 0x0253, all -> 0x0266 }
    L_0x0253:
        r3 = move-exception;
        throw r3;	 Catch:{ all -> 0x0255 }
    L_0x0255:
        r4 = move-exception;
        r18 = r4;
        r4 = r3;
        r3 = r18;
    L_0x025b:
        if (r4 == 0) goto L_0x0272;
    L_0x025d:
        r13.close();	 Catch:{ Throwable -> 0x026d }
    L_0x0260:
        throw r3;	 Catch:{ Throwable -> 0x019c }
    L_0x0261:
        r8 = move-exception;
        com.facebook.p030a.C0145a.m1312a(r4, r8);	 Catch:{ Throwable -> 0x0253, all -> 0x0266 }
        goto L_0x0252;
    L_0x0266:
        r3 = move-exception;
        r4 = r5;
        goto L_0x025b;
    L_0x0269:
        r14.close();	 Catch:{ Throwable -> 0x0253, all -> 0x0266 }
        goto L_0x0252;
    L_0x026d:
        r5 = move-exception;
        com.facebook.p030a.C0145a.m1312a(r4, r5);	 Catch:{ Throwable -> 0x019c }
        goto L_0x0260;
    L_0x0272:
        r13.close();	 Catch:{ Throwable -> 0x019c }
        goto L_0x0260;
    L_0x0276:
        r13 = new java.io.FileReader;	 Catch:{ Throwable -> 0x019c }
        r13.<init>(r12);	 Catch:{ Throwable -> 0x019c }
        r5 = 0;
        r14 = new java.io.BufferedReader;	 Catch:{ Throwable -> 0x02b9, all -> 0x02cc }
        r4 = 1024; // 0x400 float:1.435E-42 double:5.06E-321;
        r14.<init>(r13, r4);	 Catch:{ Throwable -> 0x02b9, all -> 0x02cc }
        r4 = 0;
        r15 = r14.readLine();	 Catch:{ Throwable -> 0x02ab, all -> 0x02e5 }
        if (r15 == 0) goto L_0x02a0;
    L_0x028a:
        r16 = com.facebook.p031b.C0191v.LAST_ACTIVITY_LOGGED;	 Catch:{ Throwable -> 0x02ab, all -> 0x02e5 }
        r0 = r16;
        r2.put(r0, r15);	 Catch:{ Throwable -> 0x02ab, all -> 0x02e5 }
        r15 = com.facebook.p031b.C0191v.LAST_ACTIVITY_LOGGED_TIME;	 Catch:{ Throwable -> 0x02ab, all -> 0x02e5 }
        r16 = r12.lastModified();	 Catch:{ Throwable -> 0x02ab, all -> 0x02e5 }
        r16 = java.lang.Long.toString(r16);	 Catch:{ Throwable -> 0x02ab, all -> 0x02e5 }
        r0 = r16;
        r2.put(r15, r0);	 Catch:{ Throwable -> 0x02ab, all -> 0x02e5 }
    L_0x02a0:
        r12.delete();	 Catch:{ Throwable -> 0x02ab, all -> 0x02e5 }
        r14.close();	 Catch:{ Throwable -> 0x02b9, all -> 0x02cc }
        r13.close();	 Catch:{ Throwable -> 0x019c }
        goto L_0x0168;
    L_0x02ab:
        r3 = move-exception;
        throw r3;	 Catch:{ all -> 0x02ad }
    L_0x02ad:
        r4 = move-exception;
        r18 = r4;
        r4 = r3;
        r3 = r18;
    L_0x02b3:
        if (r4 == 0) goto L_0x02cf;
    L_0x02b5:
        r14.close();	 Catch:{ Throwable -> 0x02c7, all -> 0x02cc }
    L_0x02b8:
        throw r3;	 Catch:{ Throwable -> 0x02b9, all -> 0x02cc }
    L_0x02b9:
        r3 = move-exception;
        throw r3;	 Catch:{ all -> 0x02bb }
    L_0x02bb:
        r4 = move-exception;
        r18 = r4;
        r4 = r3;
        r3 = r18;
    L_0x02c1:
        if (r4 == 0) goto L_0x02d8;
    L_0x02c3:
        r13.close();	 Catch:{ Throwable -> 0x02d3 }
    L_0x02c6:
        throw r3;	 Catch:{ Throwable -> 0x019c }
    L_0x02c7:
        r8 = move-exception;
        com.facebook.p030a.C0145a.m1312a(r4, r8);	 Catch:{ Throwable -> 0x02b9, all -> 0x02cc }
        goto L_0x02b8;
    L_0x02cc:
        r3 = move-exception;
        r4 = r5;
        goto L_0x02c1;
    L_0x02cf:
        r14.close();	 Catch:{ Throwable -> 0x02b9, all -> 0x02cc }
        goto L_0x02b8;
    L_0x02d3:
        r5 = move-exception;
        com.facebook.p030a.C0145a.m1312a(r4, r5);	 Catch:{ Throwable -> 0x019c }
        goto L_0x02c6;
    L_0x02d8:
        r13.close();	 Catch:{ Throwable -> 0x019c }
        goto L_0x02c6;
    L_0x02dc:
        if (r5 == 0) goto L_0x0182;
    L_0x02de:
        r11 = com.facebook.p031b.C0191v.IAB_OPEN_TIMES;	 Catch:{ Throwable -> 0x019c }
        r2.put(r11, r5);	 Catch:{ Throwable -> 0x019c }
        goto L_0x0182;
    L_0x02e5:
        r3 = move-exception;
        goto L_0x02b3;
    L_0x02e7:
        r3 = move-exception;
        goto L_0x024d;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.b.o.a(android.content.Context, java.io.File, com.facebook.b.m, long):com.facebook.b.d");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static java.lang.String m1405a(java.io.File r6) {
        /*
        r1 = 0;
        r0 = r6.exists();
        if (r0 != 0) goto L_0x000a;
    L_0x0007:
        r0 = "NO_FILE";
    L_0x0009:
        return r0;
    L_0x000a:
        r3 = new java.io.FileReader;	 Catch:{ Exception -> 0x0023 }
        r3.<init>(r6);	 Catch:{ Exception -> 0x0023 }
        r4 = new java.io.BufferedReader;	 Catch:{ Throwable -> 0x0036, all -> 0x0047 }
        r0 = 1024; // 0x400 float:1.435E-42 double:5.06E-321;
        r4.<init>(r3, r0);	 Catch:{ Throwable -> 0x0036, all -> 0x0047 }
        r0 = r4.readLine();	 Catch:{ Throwable -> 0x002d, all -> 0x0057 }
        if (r0 == 0) goto L_0x0026;
    L_0x001c:
        r4.close();	 Catch:{ Throwable -> 0x0036, all -> 0x0047 }
        r3.close();	 Catch:{ Exception -> 0x0023 }
        goto L_0x0009;
    L_0x0023:
        r0 = move-exception;
    L_0x0024:
        r0 = r1;
        goto L_0x0009;
    L_0x0026:
        r4.close();	 Catch:{ Throwable -> 0x0036, all -> 0x0047 }
        r3.close();	 Catch:{ Exception -> 0x0023 }
        goto L_0x0024;
    L_0x002d:
        r2 = move-exception;
        throw r2;	 Catch:{ all -> 0x002f }
    L_0x002f:
        r0 = move-exception;
    L_0x0030:
        if (r2 == 0) goto L_0x004a;
    L_0x0032:
        r4.close();	 Catch:{ Throwable -> 0x0042, all -> 0x0047 }
    L_0x0035:
        throw r0;	 Catch:{ Throwable -> 0x0036, all -> 0x0047 }
    L_0x0036:
        r0 = move-exception;
        throw r0;	 Catch:{ all -> 0x0038 }
    L_0x0038:
        r2 = move-exception;
        r5 = r2;
        r2 = r0;
        r0 = r5;
    L_0x003c:
        if (r2 == 0) goto L_0x0053;
    L_0x003e:
        r3.close();	 Catch:{ Throwable -> 0x004e }
    L_0x0041:
        throw r0;	 Catch:{ Exception -> 0x0023 }
    L_0x0042:
        r4 = move-exception;
        com.facebook.p030a.C0145a.m1312a(r2, r4);	 Catch:{ Throwable -> 0x0036, all -> 0x0047 }
        goto L_0x0035;
    L_0x0047:
        r0 = move-exception;
        r2 = r1;
        goto L_0x003c;
    L_0x004a:
        r4.close();	 Catch:{ Throwable -> 0x0036, all -> 0x0047 }
        goto L_0x0035;
    L_0x004e:
        r3 = move-exception;
        com.facebook.p030a.C0145a.m1312a(r2, r3);	 Catch:{ Exception -> 0x0023 }
        goto L_0x0041;
    L_0x0053:
        r3.close();	 Catch:{ Exception -> 0x0023 }
        goto L_0x0041;
    L_0x0057:
        r0 = move-exception;
        r2 = r1;
        goto L_0x0030;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.b.o.a(java.io.File):java.lang.String");
    }

    private void m1425b(C0173d c0173d) {
        Object obj;
        if (C0184o.m1429c(c0173d.m1378a(C0191v.ACRA_REPORT_FILENAME)).equals(this.f701t)) {
            obj = null;
        } else {
            obj = 1;
        }
        String str = (String) c0173d.get(C0191v.REPORT_ID);
        if (str == null || str.length() == 0) {
            for (Entry entry : this.f692g.entrySet()) {
                if (((C0191v) entry.getKey()).equals(C0191v.APP_VERSION_NAME)) {
                    if (obj == null) {
                        c0173d.put((Enum) entry.getKey(), entry.getValue());
                    }
                } else if (c0173d.get(entry.getKey()) == null) {
                    c0173d.put((Enum) entry.getKey(), entry.getValue());
                }
            }
        }
        CharSequence e = m1433e();
        str = (String) c0173d.get(C0191v.UID);
        if (!TextUtils.isEmpty(e) && TextUtils.isEmpty(str)) {
            c0173d.put(C0191v.UID, e);
        }
    }

    private static String m1429c(String str) {
        if (str != null) {
            Matcher matcher = f678c.matcher(str);
            if (matcher.matches()) {
                return matcher.group(1);
            }
        }
        return "";
    }

    private static String m1406a(InputStream inputStream, int i) {
        GZIPOutputStream gZIPOutputStream;
        Throwable th;
        int i2 = 0;
        byte[] bArr = new byte[i];
        int i3 = 0;
        while (i - i3 > 0) {
            i2 = inputStream.read(bArr, i3, i - i3);
            if (i2 == -1) {
                break;
            }
            i3 += i2;
        }
        if (i2 == 0) {
            return "";
        }
        OutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            gZIPOutputStream = new GZIPOutputStream(byteArrayOutputStream);
            try {
                gZIPOutputStream.write(bArr, 0, bArr.length);
                gZIPOutputStream.finish();
                String encodeToString = Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0);
                gZIPOutputStream.close();
                return encodeToString;
            } catch (Throwable th2) {
                th = th2;
                if (gZIPOutputStream != null) {
                    gZIPOutputStream.close();
                }
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            gZIPOutputStream = null;
            if (gZIPOutputStream != null) {
                gZIPOutputStream.close();
            }
            throw th;
        }
    }

    private static File m1402a(Context context, String str, String str2) {
        return new File(context.getDir(str, 0), str2);
    }

    private static void m1426b(File file) {
        if (file != null && !file.delete() && file.exists()) {
            Log.w(C0148a.f621a, "Could not delete error report: " + file.getName());
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final com.facebook.p031b.C0183n m1456b() {
        /*
        r4 = this;
        r1 = 1;
        r0 = 0;
        r2 = new com.facebook.p031b.C0182m[r1];
        r3 = com.facebook.p031b.C0182m.NATIVE_CRASH_REPORT;
        r2[r0] = r3;
        r2 = r4.m1418a(r2);
        r4.f690e = r2;
        r2 = r4.f690e;
        if (r2 != 0) goto L_0x0023;
    L_0x0012:
        r2 = 2;
        r2 = new com.facebook.p031b.C0182m[r2];
        r3 = com.facebook.p031b.C0182m.ACRA_CRASH_REPORT;
        r2[r0] = r3;
        r3 = com.facebook.p031b.C0182m.ANR_REPORT;
        r2[r1] = r3;
        r2 = r4.m1418a(r2);
        if (r2 == 0) goto L_0x0024;
    L_0x0023:
        r0 = r1;
    L_0x0024:
        if (r0 == 0) goto L_0x002d;
    L_0x0026:
        r0 = f679j;
        r0 = r4.m1420b(r0);
    L_0x002c:
        return r0;
    L_0x002d:
        r0 = 0;
        goto L_0x002c;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.b.o.b():com.facebook.b.n");
    }

    private boolean m1418a(C0182m... c0182mArr) {
        if (this.f698o == null) {
            Log.e(C0148a.f621a, "Trying to get ACRA reports but ACRA is not initialized.");
            return false;
        }
        for (C0182m c0182m : c0182mArr) {
            File dir = this.f698o.getDir(c0182m.f669d, 0);
            if (dir != null && C0184o.m1417a(dir, c0182m.f672g)) {
                return true;
            }
        }
        return false;
    }

    private static boolean m1417a(File file, String[] strArr) {
        if (file == null) {
            return false;
        }
        String[] list = file.list();
        if (list == null || list.length == 0) {
            return false;
        }
        if (strArr == null || strArr.length == 0) {
            return true;
        }
        for (String str : list) {
            for (String endsWith : strArr) {
                if (str.endsWith(endsWith)) {
                    return true;
                }
            }
        }
        return false;
    }

    private C0183n m1420b(C0182m... c0182mArr) {
        C0183n c0183n = new C0183n(this, c0182mArr);
        c0183n.start();
        return c0183n;
    }

    private void m1424b(C0149c c0149c) {
        this.f691f.add(c0149c);
    }

    private void m1447r() {
        this.f691f.clear();
    }

    public final void m1454a(C0149c c0149c) {
        m1447r();
        m1424b(c0149c);
    }

    private static C0191v[] m1430c(Throwable th) {
        if (th instanceof C0188s) {
            return C0148a.f623c;
        }
        if (th instanceof OutOfMemoryError) {
            return C0148a.f623c;
        }
        return C0148a.f622b;
    }

    private static Throwable m1432d(Throwable th) {
        if (!(th instanceof C0188s)) {
            while (th.getCause() != null) {
                th = th.getCause();
            }
        }
        return th;
    }

    private boolean m1434e(Throwable th) {
        boolean z = true;
        synchronized (this.f696l) {
            if (this.f695k) {
                z = false;
            } else {
                if (th instanceof OutOfMemoryError) {
                    this.f695k = true;
                }
            }
        }
        return z;
    }
}
