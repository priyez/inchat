package com.facebook.lite.net;

import java.io.DataInputStream;
import java.io.OutputStream;

/* renamed from: com.facebook.lite.net.i */
public interface C0403i {
    public static final long[] f1626a;
    public static final int f1627b;

    int m2847a(String str);

    int m2848a(String str, int i, int i2);

    void m2849a(int i);

    void m2850a(int i, String str, String str2);

    int m2851b(int i);

    DataInputStream m2852c(int i);

    OutputStream m2853d(int i);

    void m2854e(int i);

    static {
        f1626a = new long[]{50, 5000, 10000, 20000};
        f1627b = 4;
    }
}
