package com.facebook.p038e;

import android.content.Context;

/* renamed from: com.facebook.e.l */
public interface C0247l {
    void m1652a(C0249i c0249i, Context context, C0253n c0253n);
}
