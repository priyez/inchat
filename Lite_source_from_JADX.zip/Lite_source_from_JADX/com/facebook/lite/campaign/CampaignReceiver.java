package com.facebook.lite.campaign;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.facebook.lite.C0342f;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p053b.C0302p;

public class CampaignReceiver extends BroadcastReceiver {
    private static final String f1223a;

    static {
        f1223a = CampaignReceiver.class.getSimpleName();
    }

    public void onReceive(Context context, Intent intent) {
        Log.i(f1223a, "noncelogin/receive intent");
        CharSequence stringExtra = intent.getStringExtra("referrer");
        if (!C0302p.m2177b(stringExtra)) {
            m2210a(context, stringExtra);
        }
    }

    private static void m2210a(Context context, String str) {
        C0342f c = ClientApplication.m1691c();
        if (c == null || c.m2387S() == null) {
            C0300n.m2151l(context, str);
        } else if (!c.m2384P()) {
            c.m2387S().m2691c(str);
        }
    }
}
