package com.facebook.rti.push.service;

import org.json.JSONObject;

/* renamed from: com.facebook.rti.push.service.g */
public final class C0737g {
    private String f3168a;
    private String f3169b;

    public final String m3963a() {
        JSONObject jSONObject = new JSONObject();
        jSONObject.putOpt("pkg_name", this.f3168a);
        jSONObject.putOpt("appid", this.f3169b);
        return jSONObject.toString();
    }

    public C0737g(String str, String str2) {
        this.f3168a = str;
        this.f3169b = str2;
    }
}
