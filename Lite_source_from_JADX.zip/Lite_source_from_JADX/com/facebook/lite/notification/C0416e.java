package com.facebook.lite.notification;

import java.util.ArrayList;

/* renamed from: com.facebook.lite.notification.e */
final class C0416e extends ArrayList {
    C0416e() {
        add("com.htc.launcher");
        add("com.sec.android.app.twlauncher");
        add("com.sec.android.app.launcher");
    }
}
