package com.facebook.lite.p068p;

import android.text.TextUtils;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.URL;

/* renamed from: com.facebook.lite.p.b */
final class C0428b implements Runnable {
    final /* synthetic */ C0429c f1712a;
    private final Socket f1713b;

    public C0428b(C0429c c0429c, Socket socket) {
        this.f1712a = c0429c;
        this.f1713b = socket;
    }

    public final void run() {
        Throwable e;
        Exception e2;
        HttpURLConnection a;
        try {
            a = m2945a(this.f1713b.getInputStream());
            try {
                m2946a(this.f1713b.getOutputStream(), a);
                try {
                    if (!this.f1713b.isClosed()) {
                        this.f1713b.close();
                    }
                } catch (Throwable e3) {
                    this.f1712a.f1719f.m124a((short) 295, null, e3);
                }
                if (a != null) {
                    try {
                        if (a.getInputStream() != null) {
                            a.getInputStream().close();
                        }
                    } catch (Throwable e32) {
                        this.f1712a.f1719f.m124a((short) 295, null, e32);
                    }
                }
            } catch (Exception e4) {
                e2 = e4;
                try {
                    this.f1712a.f1719f.m126a((short) 3, (short) 295, e2.getMessage());
                    try {
                        if (!this.f1713b.isClosed()) {
                            this.f1713b.close();
                        }
                    } catch (Throwable e322) {
                        this.f1712a.f1719f.m124a((short) 295, null, e322);
                    }
                    if (a == null) {
                        try {
                            if (a.getInputStream() != null) {
                                a.getInputStream().close();
                            }
                        } catch (Throwable e3222) {
                            this.f1712a.f1719f.m124a((short) 295, null, e3222);
                        }
                    }
                } catch (Throwable th) {
                    e3222 = th;
                    try {
                        if (!this.f1713b.isClosed()) {
                            this.f1713b.close();
                        }
                    } catch (Throwable e5) {
                        this.f1712a.f1719f.m124a((short) 295, null, e5);
                    }
                    if (a != null) {
                        try {
                            if (a.getInputStream() != null) {
                                a.getInputStream().close();
                            }
                        } catch (Throwable e6) {
                            this.f1712a.f1719f.m124a((short) 295, null, e6);
                        }
                    }
                    throw e3222;
                }
            }
        } catch (Exception e7) {
            e2 = e7;
            a = null;
            this.f1712a.f1719f.m126a((short) 3, (short) 295, e2.getMessage());
            if (this.f1713b.isClosed()) {
                this.f1713b.close();
            }
            if (a == null) {
            }
            if (a.getInputStream() != null) {
                a.getInputStream().close();
            }
        } catch (Throwable th2) {
            e3222 = th2;
            a = null;
            if (this.f1713b.isClosed()) {
                this.f1713b.close();
            }
            if (a != null) {
                if (a.getInputStream() != null) {
                    a.getInputStream().close();
                }
            }
            throw e3222;
        }
    }

    private static void m2947a(PrintStream printStream) {
        printStream.print("\r\n");
    }

    private static void m2948a(PrintStream printStream, String str) {
        printStream.print(str);
        C0428b.m2947a(printStream);
    }

    private HttpURLConnection m2945a(InputStream inputStream) {
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(this.f1712a.f1724k).openConnection();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
        bufferedReader.readLine();
        long j = 0;
        long f = this.f1712a.f1723j - 1;
        while (true) {
            String readLine = bufferedReader.readLine();
            if (TextUtils.isEmpty(readLine)) {
                break;
            }
            int indexOf = readLine.indexOf(58);
            if (indexOf != -1) {
                String substring = readLine.substring(0, indexOf);
                readLine = readLine.substring(indexOf + 1).trim();
                if (!"Range".equals(substring)) {
                    httpURLConnection.setRequestProperty(substring, readLine);
                } else if (readLine != null && readLine.startsWith("bytes=")) {
                    String substring2 = readLine.substring(6);
                    int indexOf2 = substring2.indexOf(45);
                    if (indexOf2 < 0) {
                        indexOf2 = substring2.length();
                    }
                    j = Long.parseLong(substring2.substring(0, indexOf2));
                    readLine = substring2.substring(indexOf2 + 1);
                    if (readLine.length() > 0) {
                        f = Long.parseLong(readLine);
                    }
                }
            }
        }
        if (j < f) {
            httpURLConnection.setRequestProperty("Range", "bytes=" + j + "-" + f);
        }
        httpURLConnection.setConnectTimeout(this.f1712a.f1716c);
        httpURLConnection.setReadTimeout(this.f1712a.f1720g);
        httpURLConnection.connect();
        return httpURLConnection;
    }

    private void m2946a(OutputStream outputStream, HttpURLConnection httpURLConnection) {
        PrintStream printStream = new PrintStream(outputStream, false, "UTF-8");
        C0428b.m2948a(printStream, "HTTP/1.1 " + httpURLConnection.getResponseCode() + " " + httpURLConnection.getResponseMessage());
        int i = 0;
        while (true) {
            String headerFieldKey = httpURLConnection.getHeaderFieldKey(i);
            String headerField = httpURLConnection.getHeaderField(i);
            if (headerFieldKey == null && headerField == null) {
                break;
            }
            if (headerFieldKey != null) {
                C0428b.m2948a(printStream, headerFieldKey + ": " + headerField);
            }
            i++;
        }
        C0428b.m2947a(printStream);
        printStream.flush();
        InputStream inputStream = httpURLConnection.getInputStream();
        byte[] bArr = new byte[this.f1712a.f1715b];
        while (true) {
            int read = inputStream.read(bArr);
            if (read != -1) {
                outputStream.write(bArr, 0, read);
            } else {
                outputStream.flush();
                return;
            }
        }
    }
}
