package com.facebook.lite.p049a;

import android.util.Log;
import com.facebook.lite.p049a.p050a.C0261a;
import com.p026b.p027a.C0132d;

/* renamed from: com.facebook.lite.a.g */
final class C0278g extends C0263a {
    final /* synthetic */ C0280i f1062a;
    private final byte[] f1063b;
    private final C0261a f1064c;
    private final int f1065d;

    public C0278g(C0280i c0280i, int i, long j, byte[] bArr, C0261a c0261a) {
        this.f1062a = c0280i;
        super(j);
        this.f1065d = i;
        this.f1063b = bArr;
        this.f1064c = c0261a;
    }

    public final int m1870a(Object obj) {
        return m1821a() > ((C0278g) obj).m1821a() ? 1 : -1;
    }

    public final void run() {
        try {
            C0132d a = this.f1064c.m1806d().m1289a(Integer.toString(this.f1065d));
            if (a != null) {
                a.m1248a(this.f1063b);
                a.m1249b();
            }
        } catch (Throwable e) {
            Log.e(C0280i.f1070a, C0280i.m1873a(this.f1064c.m1804b()) + "can't save image", e);
        }
    }
}
