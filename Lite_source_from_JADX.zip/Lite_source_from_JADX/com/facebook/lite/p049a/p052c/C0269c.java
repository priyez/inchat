package com.facebook.lite.p049a.p052c;

/* renamed from: com.facebook.lite.a.c.c */
public enum C0269c {
    DISK,
    MEM
}
