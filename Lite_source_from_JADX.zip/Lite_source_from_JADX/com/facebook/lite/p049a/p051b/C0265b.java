package com.facebook.lite.p049a.p051b;

import com.p008a.p009a.p010a.p021k.C0069b;
import com.p008a.p009a.p010a.p022l.C0080i;
import com.p008a.p009a.p010a.p022l.C0093w;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* renamed from: com.facebook.lite.a.b.b */
public class C0265b implements C0069b {
    private static final String f1008a;
    private final short f1009b;
    private final int f1010c;
    private int f1011d;
    private final int[] f1012e;
    private final Set f1013f;
    private final C0093w f1014g;
    private final C0080i f1015h;
    private int f1016i;
    private final byte f1017j;
    private final int f1018k;

    static {
        f1008a = C0265b.class.getSimpleName();
    }

    public C0265b(C0093w c0093w, C0080i c0080i, int i, int[] iArr, short s, byte b) {
        int i2 = 0;
        this.f1015h = c0080i;
        this.f1018k = iArr.length;
        this.f1013f = new HashSet();
        this.f1014g = c0093w;
        this.f1010c = i;
        this.f1011d = 0;
        this.f1009b = s;
        this.f1016i = 0;
        this.f1017j = b;
        while (i2 < iArr.length) {
            this.f1013f.add(Integer.valueOf(iArr[i2]));
            i2++;
        }
        this.f1012e = iArr;
    }

    public final int m1829a() {
        return this.f1010c;
    }

    public final int[] m1832b() {
        return this.f1012e;
    }

    public final int m1833c() {
        return this.f1016i;
    }

    public final String[] m1835d() {
        return new String[]{String.valueOf(this.f1011d), String.valueOf(this.f1018k)};
    }

    public final byte m1836e() {
        return this.f1017j;
    }

    public final boolean m1830a(int i) {
        if (i != this.f1010c) {
            return false;
        }
        this.f1016i = 2;
        return true;
    }

    public final boolean m1831b(int i) {
        if (m1834c(i)) {
            Iterator it = this.f1013f.iterator();
            if (it.hasNext()) {
                this.f1015h.m618a(((Integer) it.next()).intValue(), this.f1017j, false);
                return true;
            }
        }
        return false;
    }

    public final boolean m1834c(int i) {
        if (this.f1016i == 2 || !this.f1013f.remove(Integer.valueOf(i))) {
            return false;
        }
        this.f1011d++;
        this.f1016i = 1;
        m1828f();
        new StringBuilder("downloadflow/Sending ").append(this.f1011d).append("/").append(this.f1018k).append(" ").append(i);
        return true;
    }

    private void m1828f() {
        this.f1014g.m729c(this.f1009b);
    }
}
