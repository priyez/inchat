package com.facebook.lite.p049a.p052c;

import com.facebook.p038e.p040b.p041a.C0221c;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/* renamed from: com.facebook.lite.a.c.d */
public class C0270d {
    private static final String f1037a;
    private static Map f1038b;
    private static boolean f1039c;
    private static Set f1040d;

    static {
        f1037a = C0270d.class.getSimpleName();
        f1040d = new HashSet();
    }

    private C0270d() {
    }

    public static void m1844a(int i) {
        f1040d.add(Integer.valueOf(i));
    }

    private static C0267a m1852d(int i) {
        switch ((-1073741824 & i) >>> 30) {
            case 1:
                return C0267a.SMALL;
            case 2:
                return C0267a.MEDIUM;
            case 3:
                return C0267a.LARGE;
            default:
                return C0267a.NONE;
        }
    }

    public static boolean m1849b(int i) {
        return f1040d.contains(Integer.valueOf(i));
    }

    public static void m1845a(C0269c c0269c, int i) {
        if (f1039c) {
            ((C0268b) ((Map) C0270d.m1847b().get(c0269c)).get(C0270d.m1852d(i))).m1841e();
        } else {
            ((C0268b) ((Map) C0270d.m1847b().get(c0269c)).get(C0267a.NONE)).m1841e();
        }
    }

    public static void m1848b(C0269c c0269c, int i) {
        if (f1039c) {
            ((C0268b) ((Map) C0270d.m1847b().get(c0269c)).get(C0270d.m1852d(i))).m1840d();
        } else {
            ((C0268b) ((Map) C0270d.m1847b().get(c0269c)).get(C0267a.NONE)).m1840d();
        }
    }

    public static void m1851c(C0269c c0269c, int i) {
        if (f1039c) {
            ((C0268b) ((Map) C0270d.m1847b().get(c0269c)).get(C0270d.m1852d(i))).m1842f();
        } else {
            ((C0268b) ((Map) C0270d.m1847b().get(c0269c)).get(C0267a.NONE)).m1842f();
        }
    }

    public static void m1850c(int i) {
        f1040d.remove(Integer.valueOf(i));
    }

    public static void m1846a(boolean z) {
        f1039c = z;
    }

    public static void m1843a() {
        for (C0269c c0269c : C0269c.values()) {
            for (C0267a c0267a : C0267a.values()) {
                C0221c.f837b.m1539b(c0269c, c0267a, ((C0268b) ((Map) f1038b.get(c0269c)).get(c0267a)).m1838b());
                C0221c.f837b.m1540c(c0269c, c0267a, ((C0268b) ((Map) f1038b.get(c0269c)).get(c0267a)).m1839c());
                C0221c.f837b.m1538a(c0269c, c0267a, ((C0268b) ((Map) f1038b.get(c0269c)).get(c0267a)).m1837a());
            }
        }
    }

    private static Map m1847b() {
        if (f1038b == null) {
            f1038b = new HashMap();
            for (C0269c c0269c : C0269c.values()) {
                Map hashMap = new HashMap();
                f1038b.put(c0269c, hashMap);
                for (C0267a c0267a : C0267a.values()) {
                    hashMap.put(c0267a, new C0268b(c0269c, c0267a, (byte) 0));
                }
            }
        }
        return f1038b;
    }
}
