package com.facebook.lite;

import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import com.facebook.lite.p059m.C0387i;

/* renamed from: com.facebook.lite.s */
final class C0456s implements OnClickListener {
    final /* synthetic */ C0458u f1817a;

    C0456s(C0458u c0458u) {
        this.f1817a = c0458u;
    }

    public final void onClick(View view) {
        if (this.f1817a.f1822d.f988t != null && this.f1817a.f1822d.f988t.isShowing()) {
            this.f1817a.f1822d.f988t.dismiss();
        }
        C0387i S = ClientApplication.m1691c().m2387S();
        if (S == null) {
            Log.e(MainActivity.f966a, "Client session null, not able to set left button");
            this.f1817a.f1822d.finish();
            return;
        }
        S.m2639N().m171a(S.m2653a(true, true));
    }
}
