package com.facebook.rti.push.service;

/* renamed from: com.facebook.rti.push.service.c */
public enum C0733c {
    JSON_PARSE_ERROR,
    UNEXPECTED_TOPIC
}
