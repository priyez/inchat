package com.facebook.lite;

public final class aq {
    public static final int nativeDialogStyle = 2131230720;
}
