package com.facebook.p038e.p040b.p041a;

import android.content.Context;
import com.facebook.p038e.p040b.C0214a;
import com.facebook.p038e.p040b.C0222b;
import com.facebook.p038e.p040b.C0223c;
import com.facebook.p038e.p040b.p041a.p042a.C0218a;
import com.facebook.p038e.p040b.p041a.p042a.C0219b;
import com.facebook.p038e.p040b.p041a.p042a.p043a.C0216b;

/* renamed from: com.facebook.e.b.a.c */
public final class C0221c {
    public static C0219b f836a;
    public static C0218a f837b;
    public static C0216b f838c;

    public static void m1551a(C0222b c0222b, Context context) {
        C0223c c0223c = C0223c.HOURLY;
        C0214a c0219b = new C0219b(context);
        f836a = c0219b;
        c0222b.m1553a(c0223c, c0219b);
        c0223c = C0223c.DAILY;
        c0219b = new C0218a(context);
        f837b = c0219b;
        c0222b.m1553a(c0223c, c0219b);
        c0223c = C0223c.HOURLY;
        c0219b = new C0216b(context);
        f838c = c0219b;
        c0222b.m1553a(c0223c, c0219b);
    }
}
