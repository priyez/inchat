package com.facebook.lite.p057e;

import com.facebook.lite.widget.InlineTextBox;

/* renamed from: com.facebook.lite.e.e */
final class C0324e implements Runnable {
    final /* synthetic */ InlineTextBox f1282a;
    final /* synthetic */ C0327g f1283b;

    C0324e(C0327g c0327g, InlineTextBox inlineTextBox) {
        this.f1283b = c0327g;
        this.f1282a = inlineTextBox;
    }

    public final void run() {
        this.f1282a.m3223a(false, null);
    }
}
