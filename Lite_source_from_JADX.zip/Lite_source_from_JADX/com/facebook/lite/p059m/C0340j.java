package com.facebook.lite.p059m;

/* renamed from: com.facebook.lite.m.j */
public interface C0340j {
    void m2346R();

    void m2347f(String str);
}
