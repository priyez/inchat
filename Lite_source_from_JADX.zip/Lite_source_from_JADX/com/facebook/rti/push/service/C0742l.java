package com.facebook.rti.push.service;

import p006c.p007a.C0003a;

/* renamed from: com.facebook.rti.push.service.l */
final class C0742l implements C0003a {
    final /* synthetic */ FbnsService f3182a;

    C0742l(FbnsService fbnsService) {
        this.f3182a = fbnsService;
    }

    public final /* synthetic */ Object m3971b() {
        return C0742l.m3970a();
    }

    private static Boolean m3970a() {
        return Boolean.valueOf(false);
    }
}
