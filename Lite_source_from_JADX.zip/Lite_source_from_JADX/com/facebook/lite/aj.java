package com.facebook.lite;

final class aj implements Runnable {
    final /* synthetic */ MainActivity f1155a;

    aj(MainActivity mainActivity) {
        this.f1155a = mainActivity;
    }

    public final void run() {
        this.f1155a.f981m.setVisibility(8);
    }
}
