package com.facebook.lite.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.opengl.GLUtils;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import javax.microedition.khronos.opengles.GL11;
import javax.microedition.khronos.opengles.GL11Ext;

public class GL11RendererView extends AbstractGLRendererView {
    private int f1915a;
    private int f1916b;

    public GL11RendererView(Context context) {
        super(context);
        this.f1915a = -1;
        this.f1916b = -1;
    }

    private static boolean m3190b(GL10 gl10) {
        String glGetString = gl10.glGetString(7939);
        return glGetString.contains("GL_OES_draw_texture") && glGetString.contains("GL_EXT_texture_format_BGRA8888") && ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN;
    }

    public void onSurfaceChanged(GL10 gl10, int i, int i2) {
        gl10.glViewport(0, 0, i, i2);
        int highestOneBit = Integer.highestOneBit(getFixedWidth()) << 1;
        int highestOneBit2 = Integer.highestOneBit(getFixedHeight()) << 1;
        gl10.glBindTexture(3553, this.f1916b);
        gl10.glTexImage2D(3553, 0, 32993, highestOneBit, highestOneBit2, 0, 32993, 5121, null);
        if (m3154c()) {
            gl10.glBindTexture(3553, this.f1915a);
            gl10.glTexImage2D(3553, 0, 6408, highestOneBit, highestOneBit2, 0, 6408, 5121, null);
        }
    }

    public void onSurfaceCreated(GL10 gl10, EGLConfig eGLConfig) {
        if (m3190b(gl10)) {
            gl10.glEnable(3553);
            gl10.glDisable(3008);
            gl10.glDisable(3042);
            gl10.glDisable(2884);
            gl10.glDisable(3058);
            gl10.glDisable(2903);
            gl10.glDisable(2929);
            gl10.glDisable(3024);
            gl10.glDisable(2912);
            gl10.glDisable(2896);
            gl10.glDisable(2848);
            gl10.glDisable(32925);
            gl10.glDisable(2977);
            gl10.glDisable(2832);
            gl10.glDisable(34913);
            gl10.glDisable(32823);
            gl10.glDisable(32826);
            gl10.glDisable(32926);
            gl10.glDisable(32927);
            gl10.glDisable(32928);
            gl10.glDisable(3089);
            gl10.glDisable(2960);
            gl10.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
            gl10.glHint(3152, 4353);
            gl10.glPixelStorei(3317, 1);
            int[] iArr = new int[1];
            gl10.glGenTextures(1, iArr, 0);
            gl10.glBindTexture(3553, iArr[0]);
            this.f1916b = iArr[0];
            gl10.glTexParameterf(3553, 10241, 9728.0f);
            gl10.glTexParameterf(3553, 10240, 9728.0f);
            gl10.glTexParameterf(3553, 10242, 33071.0f);
            gl10.glTexParameterf(3553, 10243, 33071.0f);
            if (m3154c()) {
                gl10.glEnable(3008);
                gl10.glAlphaFunc(516, 0.1f);
                iArr = new int[1];
                gl10.glGenTextures(1, iArr, 0);
                gl10.glBindTexture(3553, iArr[0]);
                this.f1915a = iArr[0];
                gl10.glTexParameterf(3553, 10241, 9728.0f);
                gl10.glTexParameterf(3553, 10240, 9728.0f);
                gl10.glTexParameterf(3553, 10242, 33071.0f);
                gl10.glTexParameterf(3553, 10243, 33071.0f);
                return;
            }
            return;
        }
        getLogger().m125a((short) 2, (short) 267);
        m3152b();
    }

    protected final void m3192a(GL10 gl10, Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        gl10.glBindTexture(3553, this.f1915a);
        ((GL11) gl10).glTexParameteriv(3553, 35741, new int[]{0, height, width, -height}, 0);
        GLUtils.texSubImage2D(3553, 0, 0, 0, bitmap, 6408, 5121);
        ((GL11Ext) gl10).glDrawTexiOES(getRealWidth() - width, getRealHeight() - height, 0, width, height);
    }

    protected final void m3193a(GL10 gl10, IntBuffer intBuffer) {
        gl10.glBindTexture(3553, this.f1916b);
        ((GL11) gl10).glTexParameteriv(3553, 35741, new int[]{0, getRealHeight(), getRealWidth(), -getRealHeight()}, 0);
        gl10.glTexSubImage2D(3553, 0, 0, 0, getFixedWidth(), getFixedHeight(), 32993, 5121, intBuffer);
        ((GL11Ext) gl10).glDrawTexiOES(0, 0, 0, getRealWidth(), getRealHeight());
    }

    protected final void m3194b(int i) {
        super.m3153b(i);
        if (m3155d()) {
            setDebugFlags(1);
        }
    }

    protected final void m3191a(GL10 gl10) {
        gl10.glFlush();
        int glGetError = gl10.glGetError();
        switch (glGetError) {
            case 1280:
                getLogger().m125a((short) 2, (short) 260);
                break;
            case 1281:
                getLogger().m125a((short) 2, (short) 261);
                break;
            case 1282:
                getLogger().m125a((short) 2, (short) 262);
                break;
            case 1283:
                getLogger().m125a((short) 2, (short) 263);
                break;
            case 1284:
                getLogger().m125a((short) 2, (short) 264);
                break;
            case 1285:
                getLogger().m125a((short) 2, (short) 266);
                break;
        }
        if (glGetError != 0) {
            m3152b();
        }
    }
}
