package com.facebook.lite.p063k;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract.CommonDataKinds.Email;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.ContactsContract.Contacts;
import android.util.Log;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/* renamed from: com.facebook.lite.k.a */
public final class C0368a {
    private final Context f1432a;

    public C0368a(Context context) {
        this.f1432a = context.getApplicationContext();
    }

    public final Collection m2539a() {
        if (this.f1432a.checkCallingOrSelfPermission("android.permission.READ_CONTACTS") != 0) {
            return Collections.emptySet();
        }
        ContentResolver contentResolver = this.f1432a.getContentResolver();
        Object hashMap = new HashMap();
        Cursor query = contentResolver.query(Contacts.CONTENT_URI, new String[]{"_id", "display_name"}, null, null, null);
        if (query == null) {
            return Collections.emptySet();
        }
        while (query.moveToNext()) {
            try {
                hashMap.put(Long.valueOf(query.getLong(query.getColumnIndex("_id"))), new C0369b(query.getString(query.getColumnIndex("display_name"))));
            } catch (Throwable e) {
                Log.e("PhonebookUtils", "contacts/failed while interacting over contacts. ", e);
            } finally {
                query.close();
            }
        }
        C0368a.m2537a(contentResolver, hashMap);
        C0368a.m2538b(contentResolver, hashMap);
        return hashMap.values();
    }

    private static void m2537a(ContentResolver contentResolver, Map map) {
        String[] strArr = new String[]{"contact_id", "data1"};
        Set hashSet = new HashSet();
        Cursor query = contentResolver.query(Email.CONTENT_URI, strArr, null, null, null);
        if (query != null) {
            while (query.moveToNext()) {
                try {
                    Long valueOf = Long.valueOf(query.getLong(query.getColumnIndex("contact_id")));
                    if (map.get(valueOf) != null) {
                        String string = query.getString(query.getColumnIndex("data1"));
                        if (!hashSet.contains(string)) {
                            hashSet.add(string);
                            ((C0369b) map.get(valueOf)).m2541a(string);
                        }
                    }
                } catch (Throwable e) {
                    Log.e("PhonebookUtils", "contacts/failed while interacting over contact's emails.", e);
                    return;
                } finally {
                    query.close();
                }
            }
        }
    }

    private static void m2538b(ContentResolver contentResolver, Map map) {
        String[] strArr = new String[]{"contact_id", "data1"};
        Set hashSet = new HashSet();
        Cursor query = contentResolver.query(Phone.CONTENT_URI, strArr, null, null, null);
        if (query != null) {
            while (query.moveToNext()) {
                try {
                    Long valueOf = Long.valueOf(query.getLong(query.getColumnIndex("contact_id")));
                    if (map.get(valueOf) != null) {
                        String string = query.getString(query.getColumnIndex("data1"));
                        if (!hashSet.contains(string)) {
                            hashSet.add(string);
                            ((C0369b) map.get(valueOf)).m2542b(string);
                        }
                    }
                } catch (Throwable e) {
                    Log.e("PhonebookUtils", "contacts/failed while interacting over contact's telephones.", e);
                    return;
                } finally {
                    query.close();
                }
            }
        }
    }
}
