package com.facebook.lite.p058f;

import android.util.Log;
import com.facebook.lite.aw;
import com.facebook.lite.p053b.C0294h;
import com.p008a.p009a.p010a.p016h.C0051c;
import com.p008a.p009a.p010a.p023m.C0115e;
import com.p008a.p009a.p010a.p023m.C0116b;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.facebook.lite.f.d */
public final class C0336d {
    public static final boolean f1316a;
    private C0334b f1317b;
    private final C0337e f1318c;
    private final int f1319d;
    private int f1320e;
    private final Map f1321f;

    static {
        f1316a = aw.f1162a;
    }

    public C0336d() {
        this.f1319d = C0294h.m1951a();
        int a = C0339g.m2341a();
        this.f1318c = new C0337e(a);
        this.f1321f = new HashMap();
        this.f1317b = new C0334b(this, a);
    }

    public final Map m2333a() {
        Map unmodifiableMap;
        synchronized (this) {
            m2332d();
            m2330b();
            unmodifiableMap = Collections.unmodifiableMap(this.f1321f);
        }
        return unmodifiableMap;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void m2335a(com.p008a.p009a.p010a.p016h.C0051c r4) {
        /*
        r3 = this;
        monitor-enter(r3);	 Catch:{ IOException -> 0x0025, ClassNotFoundException -> 0x0030, ClassCastException -> 0x002e }
        r0 = "DataUsageRecord";
        r0 = r4.m336b(r0);	 Catch:{ all -> 0x0022 }
        if (r0 != 0) goto L_0x000b;
    L_0x0009:
        monitor-exit(r3);	 Catch:{ all -> 0x0022 }
    L_0x000a:
        return;
    L_0x000b:
        r1 = new java.io.ObjectInputStream;	 Catch:{ all -> 0x0022 }
        r2 = new java.io.ByteArrayInputStream;	 Catch:{ all -> 0x0022 }
        r2.<init>(r0);	 Catch:{ all -> 0x0022 }
        r1.<init>(r2);	 Catch:{ all -> 0x0022 }
        r2 = r3.f1318c;	 Catch:{ all -> 0x0022 }
        r0 = r1.readObject();	 Catch:{ all -> 0x0022 }
        r0 = (com.facebook.lite.p058f.C0337e) r0;	 Catch:{ all -> 0x0022 }
        r2.m2339a(r0);	 Catch:{ all -> 0x0022 }
        monitor-exit(r3);	 Catch:{ all -> 0x0022 }
        goto L_0x000a;
    L_0x0022:
        r0 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x0022 }
        throw r0;	 Catch:{ IOException -> 0x0025, ClassNotFoundException -> 0x0030, ClassCastException -> 0x002e }
    L_0x0025:
        r0 = move-exception;
    L_0x0026:
        r0 = "DataUsageRecord";
        r1 = "failing when loading from persistence ";
        android.util.Log.w(r0, r1);
        goto L_0x000a;
    L_0x002e:
        r0 = move-exception;
        goto L_0x0026;
    L_0x0030:
        r0 = move-exception;
        goto L_0x0026;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.f.d.a(com.a.a.a.h.c):void");
    }

    public final void m2336b(C0051c c0051c) {
        synchronized (this) {
            m2332d();
            m2330b();
            C0115e c = m2331c();
            this.f1318c.m2338a();
            c0051c.m335a("DataUsageRecord", c);
        }
    }

    public final void m2334a(int i) {
        int b = C0336d.m2329b(i);
        if (this.f1320e != b) {
            synchronized (this) {
                m2332d();
                this.f1320e = b;
            }
        }
    }

    private static int m2329b(int i) {
        if (i == 0 || i == 4 || i == 5 || i == 2) {
            return C0335c.f1313a;
        }
        return C0335c.f1314b;
    }

    private void m2330b() {
        this.f1318c.m2340a(this.f1317b.f1310e, this.f1317b.f1309d);
        C0339g.m2345a(this.f1321f, this.f1317b.f1310e);
        this.f1317b = this.f1317b.m2325b();
    }

    private C0333a m2327a(long j, long j2) {
        long j3;
        long j4 = j < 0 ? 0 : j;
        if (j2 < 0) {
            j3 = 0;
        } else {
            j3 = j2;
        }
        if (this.f1320e == C0335c.f1314b) {
            return new C0333a(j4, 0, j3, 0);
        }
        return new C0333a(0, j4, 0, j3);
    }

    private C0116b m2331c() {
        try {
            OutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
            objectOutputStream.writeObject(this.f1318c);
            objectOutputStream.close();
            return new C0116b(byteArrayOutputStream.toByteArray());
        } catch (IOException e) {
            Log.w("DataUsageRecord", "failing when writing to persistence ");
            return new C0116b();
        }
    }

    private void m2332d() {
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis < this.f1317b.f1312g || currentTimeMillis > this.f1317b.f1311f) {
            m2330b();
        } else {
            this.f1317b.m2324a();
        }
    }
}
