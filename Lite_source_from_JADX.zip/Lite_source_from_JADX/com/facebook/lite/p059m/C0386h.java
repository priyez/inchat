package com.facebook.lite.p059m;

import com.p008a.p009a.p010a.p012b.C0017i;

/* renamed from: com.facebook.lite.m.h */
final class C0386h extends Thread implements C0017i {
    final /* synthetic */ C0387i f1482a;
    private final int f1483b;
    private final String[] f1484c;
    private final String[] f1485d;
    private boolean f1486e;
    private final byte[] f1487f;
    private final int f1488g;
    private final boolean f1489h;
    private final long f1490i;
    private int f1491j;
    private final String f1492k;

    public C0386h(C0387i c0387i, int i, String str, boolean z, String[] strArr, String[] strArr2, byte[] bArr) {
        this.f1482a = c0387i;
        this.f1486e = false;
        this.f1491j = -1;
        this.f1488g = i;
        this.f1492k = str;
        this.f1489h = z;
        this.f1484c = strArr;
        this.f1485d = strArr2;
        this.f1487f = bArr;
        Long c = c0387i.m2647V().m365c(42);
        if (c == null) {
            this.f1490i = 30000;
        } else {
            this.f1490i = c.longValue();
        }
        Integer a = c0387i.m2647V().m356a(44);
        if (a == null) {
            this.f1483b = 2048;
        } else {
            this.f1483b = a.intValue();
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void run() {
        /*
        r11 = this;
        r10 = -1;
        r6 = 0;
        r2 = 0;
        monitor-enter(r11);
        r0 = r11.f1482a;	 Catch:{ all -> 0x003c }
        r0 = r0.f1499E;	 Catch:{ all -> 0x003c }
        r4 = r11.f1490i;	 Catch:{ all -> 0x003c }
        r0 = r0.m155a(r11, r4);	 Catch:{ all -> 0x003c }
        r11.f1491j = r0;	 Catch:{ all -> 0x003c }
        r0 = 1;
        r11.f1486e = r0;	 Catch:{ all -> 0x003c }
        monitor-exit(r11);	 Catch:{ all -> 0x003c }
        r0 = r11.f1482a;	 Catch:{ Exception -> 0x0189, all -> 0x017b }
        r0 = r0.f1532p;	 Catch:{ Exception -> 0x0189, all -> 0x017b }
        r1 = r11.f1492k;	 Catch:{ Exception -> 0x0189, all -> 0x017b }
        r8 = r0.m2847a(r1);	 Catch:{ Exception -> 0x0189, all -> 0x017b }
        r0 = r2;
    L_0x0023:
        r1 = r11.f1484c;	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        r1 = r1.length;	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        if (r0 >= r1) goto L_0x003f;
    L_0x0028:
        r1 = r11.f1482a;	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        r1 = r1.f1532p;	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        r3 = r11.f1484c;	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        r3 = r3[r0];	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        r4 = r11.f1485d;	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        r4 = r4[r0];	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        r1.m2850a(r8, r3, r4);	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        r0 = r0 + 1;
        goto L_0x0023;
    L_0x003c:
        r0 = move-exception;
        monitor-exit(r11);	 Catch:{ all -> 0x003c }
        throw r0;
    L_0x003f:
        r0 = r11.f1487f;	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        if (r0 == 0) goto L_0x01a7;
    L_0x0043:
        r0 = r11.f1482a;	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        r0 = r0.f1532p;	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        r0.m2854e(r8);	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        r0 = r11.f1482a;	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        r0 = r0.f1532p;	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        r1 = r0.m2853d(r8);	 Catch:{ Exception -> 0x0190, all -> 0x017f }
        r0 = r11.f1487f;	 Catch:{ Exception -> 0x0197, all -> 0x0182 }
        r1.write(r0);	 Catch:{ Exception -> 0x0197, all -> 0x0182 }
        r1.close();	 Catch:{ Exception -> 0x0197, all -> 0x0182 }
        r7 = r1;
    L_0x005f:
        r0 = r11.f1482a;	 Catch:{ Exception -> 0x013f, all -> 0x0185 }
        r0 = r0.f1532p;	 Catch:{ Exception -> 0x013f, all -> 0x0185 }
        r4 = r0.m2851b(r8);	 Catch:{ Exception -> 0x013f, all -> 0x0185 }
        r0 = 200; // 0xc8 float:2.8E-43 double:9.9E-322;
        if (r4 != r0) goto L_0x0123;
    L_0x006d:
        r0 = r11.f1489h;	 Catch:{ Exception -> 0x013f, all -> 0x0185 }
        if (r0 == 0) goto L_0x01a4;
    L_0x0071:
        r0 = r11.f1482a;	 Catch:{ Exception -> 0x013f, all -> 0x0185 }
        r0 = r0.f1532p;	 Catch:{ Exception -> 0x013f, all -> 0x0185 }
        r6 = r0.m2852c(r8);	 Catch:{ Exception -> 0x013f, all -> 0x0185 }
        r0 = r11.f1483b;	 Catch:{ Exception -> 0x00d7, all -> 0x0185 }
        r0 = new byte[r0];	 Catch:{ Exception -> 0x00d7, all -> 0x0185 }
        r1 = r2;
    L_0x0080:
        r2 = r11.f1483b;	 Catch:{ Exception -> 0x00d7, all -> 0x0185 }
        if (r1 >= r2) goto L_0x008f;
    L_0x0084:
        r2 = r11.f1483b;	 Catch:{ Exception -> 0x00d7, all -> 0x0185 }
        r2 = r2 - r1;
        r2 = r6.read(r0, r1, r2);	 Catch:{ Exception -> 0x00d7, all -> 0x0185 }
        if (r2 < 0) goto L_0x008f;
    L_0x008d:
        r1 = r1 + r2;
        goto L_0x0080;
    L_0x008f:
        r6.close();	 Catch:{ Exception -> 0x00d7, all -> 0x0185 }
        r2 = r11.f1483b;	 Catch:{ Exception -> 0x00d7, all -> 0x0185 }
        if (r1 >= r2) goto L_0x01a1;
    L_0x0096:
        r5 = new byte[r1];	 Catch:{ Exception -> 0x00d7, all -> 0x0185 }
        r2 = 0;
        r3 = 0;
        java.lang.System.arraycopy(r0, r2, r5, r3, r1);	 Catch:{ Exception -> 0x00d7, all -> 0x0185 }
    L_0x009d:
        monitor-enter(r11);	 Catch:{ Exception -> 0x00d7, all -> 0x0185 }
        r0 = r11.f1486e;	 Catch:{ all -> 0x00d4 }
        if (r0 == 0) goto L_0x00b2;
    L_0x00a2:
        r0 = r11.f1482a;	 Catch:{ all -> 0x00d4 }
        r0 = r0.f1499E;	 Catch:{ all -> 0x00d4 }
        r1 = r11.f1488g;	 Catch:{ all -> 0x00d4 }
        r2 = 0;
        r3 = 0;
        r0.m163a(r1, r2, r3, r4, r5);	 Catch:{ all -> 0x00d4 }
        r0 = 0;
        r11.f1486e = r0;	 Catch:{ all -> 0x00d4 }
    L_0x00b2:
        monitor-exit(r11);	 Catch:{ all -> 0x00d4 }
    L_0x00b3:
        if (r6 == 0) goto L_0x00b8;
    L_0x00b5:
        r6.close();	 Catch:{ Exception -> 0x016b }
    L_0x00b8:
        if (r7 == 0) goto L_0x00bd;
    L_0x00ba:
        r7.close();	 Catch:{ Exception -> 0x016e }
    L_0x00bd:
        if (r8 == r10) goto L_0x00c8;
    L_0x00bf:
        r0 = r11.f1482a;	 Catch:{ Exception -> 0x019e }
        r0 = r0.f1532p;	 Catch:{ Exception -> 0x019e }
        r0.m2849a(r8);	 Catch:{ Exception -> 0x019e }
    L_0x00c8:
        r0 = r11.f1482a;
        r0 = r0.f1499E;
        r1 = r11.f1491j;
        r0.m181a(r1);
    L_0x00d3:
        return;
    L_0x00d4:
        r0 = move-exception;
        monitor-exit(r11);	 Catch:{ all -> 0x00d4 }
        throw r0;	 Catch:{ Exception -> 0x00d7, all -> 0x0185 }
    L_0x00d7:
        r0 = move-exception;
        r9 = r8;
        r8 = r6;
        r6 = r0;
    L_0x00db:
        monitor-enter(r11);	 Catch:{ all -> 0x0147 }
        r0 = r11.f1486e;	 Catch:{ all -> 0x0144 }
        if (r0 == 0) goto L_0x00f5;
    L_0x00e0:
        r0 = r11.f1482a;	 Catch:{ all -> 0x0144 }
        r0 = r0.f1499E;	 Catch:{ all -> 0x0144 }
        r1 = r11.f1488g;	 Catch:{ all -> 0x0144 }
        r2 = 1;
        r3 = r6.toString();	 Catch:{ all -> 0x0144 }
        r4 = 0;
        r5 = 0;
        r0.m163a(r1, r2, r3, r4, r5);	 Catch:{ all -> 0x0144 }
        r0 = 0;
        r11.f1486e = r0;	 Catch:{ all -> 0x0144 }
    L_0x00f5:
        monitor-exit(r11);	 Catch:{ all -> 0x0144 }
        r0 = r11.f1482a;	 Catch:{ all -> 0x0147 }
        r0 = r0.f1520Z;	 Catch:{ all -> 0x0147 }
        r1 = 153; // 0x99 float:2.14E-43 double:7.56E-322;
        r2 = 0;
        r0.m124a(r1, r2, r6);	 Catch:{ all -> 0x0147 }
        if (r8 == 0) goto L_0x0107;
    L_0x0104:
        r8.close();	 Catch:{ Exception -> 0x0171 }
    L_0x0107:
        if (r7 == 0) goto L_0x010c;
    L_0x0109:
        r7.close();	 Catch:{ Exception -> 0x0173 }
    L_0x010c:
        if (r9 == r10) goto L_0x0117;
    L_0x010e:
        r0 = r11.f1482a;	 Catch:{ Exception -> 0x0187 }
        r0 = r0.f1532p;	 Catch:{ Exception -> 0x0187 }
        r0.m2849a(r9);	 Catch:{ Exception -> 0x0187 }
    L_0x0117:
        r0 = r11.f1482a;
        r0 = r0.f1499E;
        r1 = r11.f1491j;
        r0.m181a(r1);
        goto L_0x00d3;
    L_0x0123:
        monitor-enter(r11);	 Catch:{ Exception -> 0x013f, all -> 0x0185 }
        r0 = r11.f1486e;	 Catch:{ all -> 0x013c }
        if (r0 == 0) goto L_0x0139;
    L_0x0128:
        r0 = r11.f1482a;	 Catch:{ all -> 0x013c }
        r0 = r0.f1499E;	 Catch:{ all -> 0x013c }
        r1 = r11.f1488g;	 Catch:{ all -> 0x013c }
        r2 = 0;
        r3 = 0;
        r5 = 0;
        r0.m163a(r1, r2, r3, r4, r5);	 Catch:{ all -> 0x013c }
        r0 = 0;
        r11.f1486e = r0;	 Catch:{ all -> 0x013c }
    L_0x0139:
        monitor-exit(r11);	 Catch:{ all -> 0x013c }
        goto L_0x00b3;
    L_0x013c:
        r0 = move-exception;
        monitor-exit(r11);	 Catch:{ all -> 0x013c }
        throw r0;	 Catch:{ Exception -> 0x013f, all -> 0x0185 }
    L_0x013f:
        r0 = move-exception;
        r9 = r8;
        r8 = r6;
        r6 = r0;
        goto L_0x00db;
    L_0x0144:
        r0 = move-exception;
        monitor-exit(r11);	 Catch:{ all -> 0x0144 }
        throw r0;	 Catch:{ all -> 0x0147 }
    L_0x0147:
        r0 = move-exception;
        r6 = r8;
        r8 = r9;
    L_0x014a:
        if (r6 == 0) goto L_0x014f;
    L_0x014c:
        r6.close();	 Catch:{ Exception -> 0x0175 }
    L_0x014f:
        if (r7 == 0) goto L_0x0154;
    L_0x0151:
        r7.close();	 Catch:{ Exception -> 0x0177 }
    L_0x0154:
        if (r8 == r10) goto L_0x015f;
    L_0x0156:
        r1 = r11.f1482a;	 Catch:{ Exception -> 0x0179 }
        r1 = r1.f1532p;	 Catch:{ Exception -> 0x0179 }
        r1.m2849a(r8);	 Catch:{ Exception -> 0x0179 }
    L_0x015f:
        r1 = r11.f1482a;
        r1 = r1.f1499E;
        r2 = r11.f1491j;
        r1.m181a(r2);
        throw r0;
    L_0x016b:
        r0 = move-exception;
        goto L_0x00b8;
    L_0x016e:
        r0 = move-exception;
        goto L_0x00bd;
    L_0x0171:
        r0 = move-exception;
        goto L_0x0107;
    L_0x0173:
        r0 = move-exception;
        goto L_0x010c;
    L_0x0175:
        r1 = move-exception;
        goto L_0x014f;
    L_0x0177:
        r1 = move-exception;
        goto L_0x0154;
    L_0x0179:
        r1 = move-exception;
        goto L_0x015f;
    L_0x017b:
        r0 = move-exception;
        r7 = r6;
        r8 = r10;
        goto L_0x014a;
    L_0x017f:
        r0 = move-exception;
        r7 = r6;
        goto L_0x014a;
    L_0x0182:
        r0 = move-exception;
        r7 = r1;
        goto L_0x014a;
    L_0x0185:
        r0 = move-exception;
        goto L_0x014a;
    L_0x0187:
        r0 = move-exception;
        goto L_0x0117;
    L_0x0189:
        r0 = move-exception;
        r7 = r6;
        r8 = r6;
        r9 = r10;
        r6 = r0;
        goto L_0x00db;
    L_0x0190:
        r0 = move-exception;
        r7 = r6;
        r9 = r8;
        r8 = r6;
        r6 = r0;
        goto L_0x00db;
    L_0x0197:
        r0 = move-exception;
        r7 = r1;
        r9 = r8;
        r8 = r6;
        r6 = r0;
        goto L_0x00db;
    L_0x019e:
        r0 = move-exception;
        goto L_0x00c8;
    L_0x01a1:
        r5 = r0;
        goto L_0x009d;
    L_0x01a4:
        r5 = r6;
        goto L_0x009d;
    L_0x01a7:
        r7 = r6;
        goto L_0x005f;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.m.h.run():void");
    }

    public final synchronized void m2564a() {
        if (this.f1486e) {
            this.f1482a.f1499E.m163a(this.f1488g, false, null, 0, null);
            this.f1486e = false;
        }
    }

    public final synchronized void m2565d(int i) {
        if (i == this.f1491j) {
            m2564a();
        }
    }
}
