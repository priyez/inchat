package com.facebook.p038e.p045d;

import android.content.Context;
import android.content.res.Resources.NotFoundException;
import android.telephony.TelephonyManager;

/* renamed from: com.facebook.e.d.l */
public final class C0242l {
    public static String m1632a(int i) {
        switch (i) {
            case 1:
                return "GPRS";
            case 2:
                return "EDGE";
            case 3:
                return "UMTS";
            case 4:
                return "CDMA";
            case 5:
                return "EVDO_0";
            case 6:
                return "EVDO_A";
            case 7:
                return "1xRTT";
            case 8:
                return "HSDPA";
            case 9:
                return "HSUPA";
            case 10:
                return "HSPA";
            case 11:
                return "IDEN";
            case 12:
                return "EVDO_B";
            case 13:
                return "LTE";
            case 14:
                return "EHRPD";
            case 15:
                return "HSPAP";
            default:
                return "UNKNOWN";
        }
    }

    private static String m1636b(int i) {
        switch (i) {
            case 0:
                return "NONE";
            case 1:
                return "GSM";
            case 2:
                return "CDMA";
            case 3:
                return "SIP";
            default:
                return "UNKNOWN";
        }
    }

    public static String m1633a(TelephonyManager telephonyManager) {
        return C0242l.m1636b(C0242l.m1635b(telephonyManager));
    }

    public static int m1631a(Context context) {
        try {
            Context applicationContext = context.getApplicationContext();
            if (applicationContext == null) {
                return -1;
            }
            return ((TelephonyManager) applicationContext.getSystemService("phone")).getNetworkType();
        } catch (NotFoundException e) {
            return -1;
        }
    }

    public static int m1634b(Context context) {
        try {
            Context applicationContext = context.getApplicationContext();
            if (applicationContext == null) {
                return -1;
            }
            return ((TelephonyManager) applicationContext.getSystemService("phone")).getPhoneType();
        } catch (NotFoundException e) {
            return -1;
        }
    }

    private static int m1635b(TelephonyManager telephonyManager) {
        try {
            return telephonyManager.getPhoneType();
        } catch (NotFoundException e) {
            return -1;
        }
    }
}
