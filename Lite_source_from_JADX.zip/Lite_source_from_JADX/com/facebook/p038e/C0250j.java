package com.facebook.p038e;

import com.facebook.p038e.p039a.C0207d;
import com.facebook.p038e.p039a.C0209b;
import com.facebook.p038e.p039a.C0210c;

/* renamed from: com.facebook.e.j */
public final class C0250j {
    public static C0209b m1671a(C0249i c0249i) {
        C0209b c0209b = new C0209b();
        c0209b.m1513a(new C0210c("name"), new C0210c(c0249i.m1669c()));
        c0209b.m1513a(new C0210c("time"), new C0210c(((double) c0249i.m1670d()) / 1000.0d));
        if (c0249i.m1668b() != null) {
            c0209b.m1513a(new C0210c("module"), new C0210c(c0249i.m1668b()));
        }
        C0207d a = c0249i.m1660a();
        if (!a.m1514a()) {
            c0209b.m1513a(new C0210c("extra"), a);
        }
        return c0209b;
    }
}
