package com.p028c.p029a;

/* renamed from: com.c.a.b */
final class C0141b {
    long f606a;
    boolean f607b;
    C0141b f608c;

    C0141b() {
    }
}
