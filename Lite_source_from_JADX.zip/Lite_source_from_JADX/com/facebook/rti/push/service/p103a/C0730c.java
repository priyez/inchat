package com.facebook.rti.push.service.p103a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import com.facebook.rti.p046a.p074f.C0527a;
import com.facebook.rti.p046a.p075g.C0528c;
import com.facebook.rti.p078b.p080b.p091g.C0614b;
import com.facebook.rti.p078b.p093d.C0619c;
import java.util.List;

/* renamed from: com.facebook.rti.push.service.a.c */
public class C0730c {
    private static final String f3123a;
    private final Context f3124b;
    private final C0614b f3125c;
    private final BroadcastReceiver f3126d;
    private final SharedPreferences f3127e;
    private C0619c f3128f;

    static {
        f3123a = C0730c.class.getSimpleName();
    }

    public C0730c(Context context, C0614b c0614b, SharedPreferences sharedPreferences) {
        this.f3124b = context;
        this.f3125c = c0614b;
        this.f3127e = sharedPreferences;
        this.f3128f = new C0619c(this.f3127e.getString("fbns_shared_id", ""), this.f3127e.getString("fbns_shared_secret", ""), this.f3127e.getLong("fbns_shared_timestamp", Long.MAX_VALUE));
        this.f3126d = new C0729b(this);
    }

    public final void m3954a() {
        Intent intent = new Intent("com.facebook.rti.fbns.intent.SHARE_IDS");
        List b = this.f3125c.m3526b(intent);
        b.remove(this.f3124b.getPackageName());
        if (!b.isEmpty()) {
            C0527a.m3338b(f3123a, "requesting device id from %d receivers", Integer.valueOf(b.size()));
            this.f3125c.m3521a(intent, b, this.f3126d);
        }
    }

    static /* synthetic */ void m3952a(C0730c c0730c, C0619c c0619c) {
        if (!c0619c.m3546d() && c0619c.m3545c() < c0730c.f3128f.m3545c()) {
            c0730c.f3128f = c0619c;
            C0528c.m3345a(c0730c.f3127e.edit().putString("fbns_shared_id", c0730c.f3128f.m3543a()).putString("fbns_shared_secret", c0730c.f3128f.m3544b()).putLong("fbns_shared_timestamp", c0730c.f3128f.m3545c()));
        }
    }
}
