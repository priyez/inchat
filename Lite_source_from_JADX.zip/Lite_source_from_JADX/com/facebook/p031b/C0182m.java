package com.facebook.p031b;

/* renamed from: com.facebook.b.m */
public enum C0182m {
    ACRA_CRASH_REPORT("acra-reports", 1048576, null, ".stacktrace", ".temp_stacktrace"),
    NATIVE_CRASH_REPORT("minidumps", 8388608, C0191v.MINIDUMP, ".dmp"),
    ANR_REPORT("traces", 524288, C0191v.SIGQUIT, ".stacktrace", ".temp_stacktrace");
    
    private final String f669d;
    private final long f670e;
    private final C0191v f671f;
    private final String[] f672g;

    private C0182m(String str, long j, C0191v c0191v, String... strArr) {
        this.f669d = str;
        this.f670e = j;
        this.f671f = c0191v;
        this.f672g = strArr;
    }
}
