package com.facebook.lite.p053b;

import com.p008a.p009a.p010a.p022l.C0080i;
import com.p008a.p009a.p010a.p022l.C0088r;
import com.p008a.p009a.p010a.p023m.C0114f;
import com.p008a.p009a.p010a.p023m.C0123k;

/* renamed from: com.facebook.lite.b.g */
public class C0293g extends C0088r {
    private static final String f1173f;

    static {
        f1173f = C0293g.class.getSimpleName();
    }

    private C0293g(C0114f c0114f, int i) {
        super(c0114f, new C0292f(i, new C0123k()));
    }

    public static C0088r m1947a(int i, short s, int i2, int i3) {
        return new C0088r(i, s, i2, i3, new C0292f(C0088r.m744a(i), new C0123k()));
    }

    public static C0088r m1948a(C0114f c0114f, C0080i c0080i) {
        int g = c0114f.m1121g();
        C0088r a = c0080i.m621a(g, true);
        if (a != null) {
            C0088r.m746a(c0114f);
        } else {
            a = new C0293g(c0114f, g);
            c0080i.m624a(g, a);
        }
        a.m753b(c0114f);
        return a;
    }
}
