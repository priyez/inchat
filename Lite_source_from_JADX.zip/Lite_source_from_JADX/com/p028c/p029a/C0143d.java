package com.p028c.p029a;

/* renamed from: com.c.a.d */
final class C0143d {
    private final C0142c f610a;
    private C0141b f611b;
    private C0141b f612c;
    private int f613d;
    private int f614e;

    C0143d() {
        this.f610a = new C0142c();
    }

    final void m1307a(long j, boolean z) {
        m1305a(j - 500000000);
        C0141b a = this.f610a.m1303a();
        a.f606a = j;
        a.f607b = z;
        a.f608c = null;
        if (this.f612c != null) {
            this.f612c.f608c = a;
        }
        this.f612c = a;
        if (this.f611b == null) {
            this.f611b = a;
        }
        this.f613d++;
        if (z) {
            this.f614e++;
        }
    }

    final void m1306a() {
        while (this.f611b != null) {
            C0141b c0141b = this.f611b;
            this.f611b = c0141b.f608c;
            this.f610a.m1304a(c0141b);
        }
        this.f612c = null;
        this.f613d = 0;
        this.f614e = 0;
    }

    private void m1305a(long j) {
        while (this.f613d >= 4 && this.f611b != null && j - this.f611b.f606a > 0) {
            C0141b c0141b = this.f611b;
            if (c0141b.f607b) {
                this.f614e--;
            }
            this.f613d--;
            this.f611b = c0141b.f608c;
            if (this.f611b == null) {
                this.f612c = null;
            }
            this.f610a.m1304a(c0141b);
        }
    }

    final boolean m1308b() {
        return this.f612c != null && this.f611b != null && this.f612c.f606a - this.f611b.f606a >= 250000000 && this.f614e >= (this.f613d >> 1) + (this.f613d >> 2);
    }
}
