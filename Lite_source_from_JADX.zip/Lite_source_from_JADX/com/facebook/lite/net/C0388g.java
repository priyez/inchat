package com.facebook.lite.net;

import android.content.Context;

/* renamed from: com.facebook.lite.net.g */
public interface C0388g {
    void m2716a(Context context);
}
