package com.facebook.lite.p053b;

import android.util.Log;
import com.p008a.p009a.p010a.p014e.C0045a;

/* renamed from: com.facebook.lite.b.e */
public final class C0291e extends C0045a {
    public final void m1941a(String str, String str2) {
        Log.i(str, str2);
    }
}
