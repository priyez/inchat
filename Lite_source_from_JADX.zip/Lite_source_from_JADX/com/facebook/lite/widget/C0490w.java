package com.facebook.lite.widget;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import com.facebook.lite.p053b.C0294h;

/* renamed from: com.facebook.lite.widget.w */
final class C0490w implements OnClickListener {
    final /* synthetic */ Context f2110a;
    final /* synthetic */ InlineTextBox f2111b;

    C0490w(InlineTextBox inlineTextBox, Context context) {
        this.f2111b = inlineTextBox;
        this.f2110a = context;
    }

    public final void onClick(View view) {
        this.f2111b.m3214d();
        C0294h.m1954a(this.f2111b.getContext(), this.f2111b.f1946s);
    }
}
