package com.facebook.lite.p049a.p052c;

/* renamed from: com.facebook.lite.a.c.f */
public final class C0272f {
    private final int f1042a;
    private final int f1043b;
    private final int f1044c;
    private final int f1045d;

    C0272f(int i, int i2, int i3, int i4) {
        this.f1042a = i4;
        this.f1043b = i;
        this.f1044c = i3;
        this.f1045d = i2;
    }

    public final int m1855a() {
        return this.f1042a;
    }

    public final int m1856b() {
        return this.f1043b;
    }

    public final int m1857c() {
        return this.f1044c;
    }

    public final int m1858d() {
        return this.f1045d;
    }
}
