package com.facebook.p038e.p039a;

/* renamed from: com.facebook.e.a.d */
public interface C0207d {
}
