package com.facebook.p038e;

import android.content.Context;
import android.util.Log;
import com.facebook.lite.aw;
import com.facebook.lite.p059m.C0380b;
import com.facebook.lite.p062j.C0356d;
import com.facebook.lite.p062j.C0357e;
import java.util.Collections;
import java.util.Map;

/* renamed from: com.facebook.e.h */
public class C0248h implements C0247l {
    private static final String f924a;
    private static final C0248h f925b;
    private final Map f926c;
    private int f927d;
    private C0252m f928e;
    private int f929f;
    private C0357e f930g;

    static {
        f924a = C0248h.class.getSimpleName();
        f925b = new C0248h();
    }

    private C0248h() {
        this.f926c = Collections.unmodifiableMap(new C0245f(this, System.currentTimeMillis()));
    }

    public static C0248h m1653a() {
        return f925b;
    }

    private boolean m1655b() {
        return this.f928e != null && C0380b.m2558a().m2562b();
    }

    private void m1654a(C0249i c0249i) {
        String c = c0249i.m1669c();
        if (this.f926c.containsKey(c)) {
            C0246g c0246g = (C0246g) this.f926c.get(c);
            if (c0246g == null) {
                Log.w(f924a, "honeyanalytics/" + c + " not found for throttling counter.");
                return;
            }
            long currentTimeMillis = System.currentTimeMillis();
            if (currentTimeMillis - c0246g.f923c.get() > (c0246g.f922b ? 3600000 : 86400000)) {
                c0246g.f921a.set(0);
                c0246g.f923c.set(currentTimeMillis);
            }
            c0246g.f921a.getAndIncrement();
            return;
        }
        Log.w(f924a, "honeyanalytics/" + c + " is not listed for throttling counter.");
    }

    private boolean m1656b(C0249i c0249i) {
        boolean z = true;
        boolean z2 = false;
        String c = c0249i.m1669c();
        if (this.f926c.containsKey(c)) {
            C0246g c0246g = (C0246g) this.f926c.get(c);
            if (c0246g.f922b) {
                z2 = c0246g.f921a.get() > this.f927d;
            } else {
                if (c0246g.f921a.get() <= this.f929f) {
                    z = false;
                }
                z2 = z;
            }
            if (z2) {
                new StringBuilder("honeyanalytics/").append(c).append(" is throttled.");
            } else {
                new StringBuilder("honeyanalytics/").append(c).append(" is not throttled.");
            }
        } else {
            Log.w(f924a, "honeyanalytics/" + c + " is not listed for throttling.");
        }
        return z2;
    }

    public final void m1657a(C0249i c0249i, Context context) {
        m1658a(c0249i, context, C0253n.BEST_EFFORT);
    }

    public final void m1658a(C0249i c0249i, Context context, C0253n c0253n) {
        if (aw.f1162a) {
            C0356d c0356d = C0356d.DISCARDED;
            if (m1655b()) {
                if (!m1656b(c0249i) && this.f928e.m1682a(c0249i)) {
                    c0356d = C0356d.NORMAL;
                }
                m1654a(c0249i);
            } else if (c0253n.m1683a() && C0255p.m1686a().m1687a(context, c0249i)) {
                c0356d = C0356d.OFFLINE;
            }
            if (this.f930g != null) {
                this.f930g.m2512a(c0249i, c0356d);
            }
        } else if (m1655b()) {
            if (!m1656b(c0249i)) {
                this.f928e.m1682a(c0249i);
            }
            m1654a(c0249i);
        } else if (c0253n.m1683a()) {
            C0255p.m1686a().m1687a(context, c0249i);
        }
    }

    public final void m1659a(C0252m c0252m, C0357e c0357e, int i, int i2) {
        this.f928e = c0252m;
        this.f930g = c0357e;
        this.f929f = i;
        this.f927d = i2;
    }
}
