package com.facebook.lite.net;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

/* renamed from: com.facebook.lite.net.h */
public final class C0405h {
    static String m2872a(String str, boolean z, Context context) {
        return context.getSharedPreferences(C0405h.m2870a(context), 0).getString(C0405h.m2871a(str, z), "");
    }

    static void m2873a(String str, boolean z, String str2, Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(C0405h.m2870a(context), 0);
        Editor edit = sharedPreferences.edit();
        if (sharedPreferences.getAll().size() >= 8) {
            edit.clear();
        }
        edit.putString(C0405h.m2871a(str, z), str2);
        edit.commit();
    }

    private static String m2870a(Context context) {
        return context.getPackageName() + "_dns_cache";
    }

    private static String m2871a(String str, boolean z) {
        return str + "/" + z;
    }
}
