package com.facebook.p038e.p040b;

/* renamed from: com.facebook.e.b.b */
public interface C0222b {
    void m1552a();

    void m1553a(C0223c c0223c, C0214a c0214a);
}
