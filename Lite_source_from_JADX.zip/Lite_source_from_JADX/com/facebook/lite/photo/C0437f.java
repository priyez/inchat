package com.facebook.lite.photo;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import com.facebook.lite.ao;
import com.facebook.lite.ap;
import com.facebook.lite.as;
import java.util.List;

/* renamed from: com.facebook.lite.photo.f */
final class C0437f extends ArrayAdapter {
    final /* synthetic */ AlbumGalleryActivity f1763a;

    public C0437f(AlbumGalleryActivity albumGalleryActivity, Context context, List list) {
        this.f1763a = albumGalleryActivity;
        super(context, 0, list);
    }

    public final View getView(int i, View view, ViewGroup viewGroup) {
        C0438g c0438g;
        if (view == null) {
            view = this.f1763a.getLayoutInflater().inflate(ap.gallery_item, viewGroup, false);
            c0438g = new C0438g();
            c0438g.f1764a = (ImageView) view.findViewById(as.gallery_item_image);
            c0438g.f1765b = (ImageView) view.findViewById(as.selected_border);
            view.setTag(c0438g);
        } else {
            c0438g = (C0438g) view.getTag();
        }
        GalleryItem galleryItem = (GalleryItem) getItem(i);
        if (galleryItem != null) {
            AlbumGalleryActivity.m2973b(galleryItem, c0438g.f1765b);
            if (this.f1763a.f1727b && i == 0) {
                c0438g.f1764a.setImageResource(ao.camera_button);
                this.f1763a.f1743r.f1805e.put(c0438g.f1764a, Integer.valueOf(galleryItem.m2991b()));
            } else {
                Bitmap a = this.f1763a.f1743r.m3081a(c0438g.f1764a, galleryItem.m2991b());
                if (a == null || a.isRecycled()) {
                    c0438g.f1764a.setImageResource(17170445);
                    this.f1763a.f1743r.m3085a(c0438g.f1764a, Integer.valueOf(galleryItem.m2991b()));
                } else {
                    c0438g.f1764a.setImageBitmap(a);
                }
            }
        }
        view.setOnTouchListener(new C0436e(this, galleryItem, i));
        return view;
    }
}
