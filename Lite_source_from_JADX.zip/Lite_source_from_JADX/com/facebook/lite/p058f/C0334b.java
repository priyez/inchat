package com.facebook.lite.p058f;

import com.facebook.lite.p053b.C0294h;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* renamed from: com.facebook.lite.f.b */
final class C0334b {
    final /* synthetic */ C0336d f1306a;
    private long f1307b;
    private long f1308c;
    private final int f1309d;
    private final Map f1310e;
    private final long f1311f;
    private final long f1312g;

    public C0334b(C0336d c0336d, int i) {
        this.f1306a = c0336d;
        this.f1309d = i;
        this.f1307b = C0294h.m1952a(c0336d.f1319d);
        this.f1308c = C0294h.m1961b(c0336d.f1319d);
        List a = C0339g.m2344a(i);
        this.f1312g = ((Long) a.get(0)).longValue();
        this.f1311f = ((Long) a.get(1)).longValue();
        this.f1310e = new HashMap();
    }

    private void m2320a(C0338f c0338f, C0333a c0333a) {
        if (this.f1310e.containsKey(c0338f)) {
            ((C0333a) this.f1310e.get(c0338f)).m2318a(c0333a);
        } else {
            this.f1310e.put(c0338f, c0333a);
        }
    }

    public final void m2324a() {
        long j = this.f1307b;
        long j2 = this.f1308c;
        this.f1307b = C0294h.m1952a(this.f1306a.f1319d);
        this.f1308c = C0294h.m1961b(this.f1306a.f1319d);
        m2320a(C0338f.TOTAL, this.f1306a.m2327a(this.f1307b - j, this.f1308c - j2));
    }

    public final C0334b m2325b() {
        long currentTimeMillis = System.currentTimeMillis();
        int a = (currentTimeMillis < this.f1312g || currentTimeMillis > this.f1311f) ? C0339g.m2341a() : this.f1309d;
        C0334b c0334b = new C0334b(this.f1306a, a);
        c0334b.m2320a(C0338f.TOTAL, this.f1306a.m2327a(c0334b.f1307b - this.f1307b, c0334b.f1308c - this.f1308c));
        return c0334b;
    }
}
