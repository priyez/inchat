package com.facebook.rti.push.service;

import p006c.p007a.C0003a;

/* renamed from: com.facebook.rti.push.service.k */
final class C0741k implements C0003a {
    final /* synthetic */ FbnsService f3181a;

    C0741k(FbnsService fbnsService) {
        this.f3181a = fbnsService;
    }

    public final /* bridge */ /* synthetic */ Object m3969b() {
        return null;
    }
}
