package com.facebook.rti.push.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.facebook.rti.p046a.p074f.C0527a;
import com.facebook.rti.push.p048a.C0727d;

public class MqttSystemBroadcastReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        C0527a.m3338b("MqttSystemBroadcastReceiver", "onReceive %s", intent);
        if (intent != null) {
            C0727d.m3932b(context, intent.getAction());
        }
    }
}
