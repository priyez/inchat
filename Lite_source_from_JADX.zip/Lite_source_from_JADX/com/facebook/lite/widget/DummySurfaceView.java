package com.facebook.lite.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;

public class DummySurfaceView extends SurfaceView implements Callback {
    private volatile boolean f1895a;
    private final Object f1896b;

    public DummySurfaceView(Context context) {
        this(context, null);
    }

    public DummySurfaceView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public DummySurfaceView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1896b = new Object();
        getHolder().addCallback(this);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.SurfaceHolder m3166a() {
        /*
        r2 = this;
        r1 = r2.f1896b;
        monitor-enter(r1);
    L_0x0003:
        r0 = r2.f1895a;	 Catch:{ all -> 0x0015 }
        if (r0 != 0) goto L_0x000f;
    L_0x0007:
        r0 = r2.f1896b;	 Catch:{ InterruptedException -> 0x000d }
        r0.wait();	 Catch:{ InterruptedException -> 0x000d }
        goto L_0x0003;
    L_0x000d:
        r0 = move-exception;
        goto L_0x0003;
    L_0x000f:
        monitor-exit(r1);	 Catch:{ all -> 0x0015 }
        r0 = r2.getHolder();
        return r0;
    L_0x0015:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0015 }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.widget.DummySurfaceView.a():android.view.SurfaceHolder");
    }

    public final void m3167a(int i) {
        post(new C0477h(this, i));
    }

    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
    }

    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        synchronized (this.f1896b) {
            this.f1895a = true;
            this.f1896b.notifyAll();
        }
    }

    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
    }
}
