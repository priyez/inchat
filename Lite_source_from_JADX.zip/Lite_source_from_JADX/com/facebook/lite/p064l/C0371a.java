package com.facebook.lite.p064l;

import java.util.List;

/* renamed from: com.facebook.lite.l.a */
final class C0371a implements Runnable {
    final /* synthetic */ List f1438a;
    final /* synthetic */ C0377g f1439b;

    C0371a(C0377g c0377g, List list) {
        this.f1439b = c0377g;
        this.f1438a = list;
    }

    public final void run() {
        this.f1439b.m2547a(this.f1438a);
    }
}
