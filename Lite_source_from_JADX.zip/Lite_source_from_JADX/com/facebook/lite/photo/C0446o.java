package com.facebook.lite.photo;

import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;

/* renamed from: com.facebook.lite.photo.o */
final class C0446o implements OnClickListener {
    final /* synthetic */ PreviewActivity f1789a;

    C0446o(PreviewActivity previewActivity) {
        this.f1789a = previewActivity;
    }

    public final void onClick(View view) {
        Intent putExtra = new Intent().putExtra("selected", true);
        putExtra.putExtra("user_rotate_degree", this.f1789a.f1754e);
        this.f1789a.setResult(-1, putExtra);
        this.f1789a.finish();
    }
}
