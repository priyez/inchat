package com.facebook.lite.p053b;

import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p022l.C0076e;
import com.p008a.p009a.p010a.p022l.C0093w;
import com.p008a.p009a.p010a.p023m.C0114f;
import com.p008a.p009a.p010a.p023m.C0116b;

/* renamed from: com.facebook.lite.b.l */
final class C0298l extends C0297k implements C0076e {
    final boolean f1177c;
    boolean f1178d;
    int f1179e;
    final boolean f1180f;
    byte f1181g;
    final C0093w f1182h;
    private byte[] f1183i;
    private int f1184j;
    private int f1185k;
    private int f1186l;
    private int f1187m;
    private final int f1188n;
    private int f1189o;

    private C0298l(byte b, int i, C0093w c0093w, int i2, byte[] bArr, boolean z, boolean z2) {
        this.f1178d = false;
        this.f1181g = b;
        m1211a(i);
        this.f1182h = c0093w;
        this.f1179e = i2;
        this.f1183i = bArr;
        this.f1180f = z;
        this.f1177c = z2;
        this.f1188n = i;
    }

    private C0298l(int i, int i2, byte[] bArr, int i3, int i4) {
        this.f1178d = false;
        this.f1181g = (byte) 1;
        m1211a(i);
        this.f1182h = null;
        this.f1179e = i2;
        this.f1183i = bArr;
        this.f1180f = true;
        this.f1177c = false;
        this.f1185k = i3;
        this.f1184j = i4;
        this.f1188n = i;
    }

    public final int m2001a() {
        return this.f1183i.length - 19;
    }

    public final int m2004b() {
        return this.f1184j;
    }

    public final byte[] m2005c() {
        return this.f1183i;
    }

    public final int m2006d() {
        return this.f1188n;
    }

    public final int m2007e() {
        return this.f1189o;
    }

    public final int m2008f() {
        return this.f1185k;
    }

    public final int m2009g() {
        return this.f1186l;
    }

    public final int m2010h() {
        return this.f1187m;
    }

    public final int m2002a(byte[] bArr) {
        int i = this.f1179e;
        this.f1179e = bArr.length + 86;
        this.f1183i = bArr;
        return i;
    }

    static C0298l m1999k() {
        return new C0298l((byte) 3, 0, null, 72, null, false, false);
    }

    static C0298l m1997b(int i) {
        return new C0298l((byte) 1, i, null, 72, null, false, false);
    }

    static C0298l m1994a(int i, byte[] bArr) {
        return new C0298l((byte) 1, i, null, bArr.length + 86, bArr, false, false);
    }

    static C0298l m1995a(int i, byte[] bArr, int i2, int i3) {
        return new C0298l(i, bArr.length + 86, bArr, i2, i3);
    }

    static C0298l m1993a(int i, C0093w c0093w, int i2, boolean z, boolean z2) {
        return new C0298l((byte) 0, i, c0093w, i2 + 72, null, z, z2);
    }

    final boolean m2003a(C0022b c0022b) {
        if (!(this.f1183i == null || this.f1183i.length != 0 || c0022b == null)) {
            c0022b.m124a((short) 297, "Res Type" + this.f1181g + " ID:" + this.f1188n, new Exception("Image Buffer length is 0 "));
        }
        return this.f1183i == null || this.f1183i.length <= 0 || this.f1183i[this.f1183i.length - 1] == null;
    }

    private void m2000l() {
        C0114f c0116b = new C0116b(this.f1183i);
        c0116b.m1115c(m2001a());
        this.f1189o = c0116b.m1127m();
        this.f1185k = c0116b.m1122h();
        this.f1184j = c0116b.m1122h();
        this.f1186l = c0116b.m1122h();
        this.f1187m = c0116b.m1122h();
    }
}
