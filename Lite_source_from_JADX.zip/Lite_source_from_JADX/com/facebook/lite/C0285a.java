package com.facebook.lite;

import android.os.AsyncTask;
import android.util.Log;
import com.facebook.lite.p055c.C0305a;
import com.facebook.lite.photo.C0444m;
import com.facebook.lite.photo.GalleryItem;
import com.facebook.p038e.C0251k;
import java.util.ArrayList;
import java.util.List;

/* renamed from: com.facebook.lite.a */
final class C0285a extends AsyncTask {
    final /* synthetic */ List f1101a;
    final /* synthetic */ String[] f1102b;
    final /* synthetic */ C0251k f1103c;
    final /* synthetic */ int[] f1104d;
    final /* synthetic */ C0342f f1105e;

    C0285a(C0342f c0342f, List list, String[] strArr, C0251k c0251k, int[] iArr) {
        this.f1105e = c0342f;
        this.f1101a = list;
        this.f1102b = strArr;
        this.f1103c = c0251k;
        this.f1104d = iArr;
    }

    protected final /* synthetic */ Object doInBackground(Object[] objArr) {
        return m1924a();
    }

    protected final /* synthetic */ void onPostExecute(Object obj) {
        m1925a((List) obj);
    }

    private List m1924a() {
        List arrayList = new ArrayList();
        for (int i = 0; i < this.f1101a.size(); i++) {
            arrayList.add(C0444m.m3057a(this.f1105e.f1371u, this.f1105e.f1369s.m2648W(), this.f1102b[i], this.f1103c, this.f1104d[i]));
        }
        return arrayList;
    }

    private void m1925a(List list) {
        if (list == null) {
            Log.e(C0342f.f1331b, "gallery/unable to read photo.");
            this.f1105e.f1369s.m2639N().m168a(C0342f.f1335f);
            this.f1103c.m1681b("handling_succeeded", false);
            C0251k.m1672a(this.f1103c, this.f1105e.f1371u);
            return;
        }
        try {
            C0305a F = this.f1105e.f1369s.m2631F();
            int i = 0;
            short s = (short) 0;
            while (i < list.size()) {
                short s2;
                byte[] bArr = (byte[]) list.get(i);
                if (bArr == null) {
                    this.f1103c.m1681b("handling_succeeded_" + i, false);
                    s2 = s;
                } else {
                    int[] a = this.f1105e.f1369s.m2682a(bArr);
                    int c = F.m2195c();
                    this.f1105e.f1369s.m2714w().m619a(c, (byte[]) list.get(i), a[0], a[1]);
                    F.m2189a(c, (GalleryItem) this.f1101a.get(i));
                    s2 = (short) (s + 1);
                }
                i++;
                s = s2;
            }
            this.f1105e.f1369s.a_().m428c(s);
            this.f1105e.f1369s.m2639N().m168a(this.f1105e.f1355J);
            this.f1105e.f1369s.aa().m945J();
        } catch (Throwable e) {
            this.f1105e.f1375y.m124a((short) 152, "", e);
            this.f1105e.f1369s.m2639N().m168a(C0342f.f1335f);
        }
        this.f1103c.m1681b("handling_succeeded", true);
        C0251k.m1672a(this.f1103c, this.f1105e.f1371u);
    }
}
