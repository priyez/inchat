package com.facebook.lite.p053b;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.TrafficStats;
import android.os.Build.VERSION;
import android.os.Process;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import com.facebook.lite.ClientApplication;
import com.p008a.p009a.p010a.p012b.C0025b;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;
import java.util.UUID;

/* renamed from: com.facebook.lite.b.h */
public class C0294h {
    private static final String f1174a;

    static {
        f1174a = C0294h.class.getName();
    }

    private C0294h() {
    }

    public static boolean m1958a(Context context, Intent intent) {
        List queryIntentActivities = context.getPackageManager().queryIntentActivities(intent, 65536);
        return (queryIntentActivities == null || queryIntentActivities.isEmpty()) ? false : true;
    }

    private static void m1955a(Context context, Class cls) {
        PendingIntent service = PendingIntent.getService(context, 1, new Intent(context, cls), 134217728);
        service.cancel();
        ((AlarmManager) context.getSystemService("alarm")).cancel(service);
    }

    public static void m1957a(C0025b c0025b) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) ClientApplication.m1690b().getApplicationContext().getSystemService("connectivity")).getActiveNetworkInfo();
        if (activeNetworkInfo == null) {
            c0025b.m213p();
        } else {
            new StringBuilder("conn/active network:").append(activeNetworkInfo.getTypeName()).append("|isconnected:").append(activeNetworkInfo.isConnected());
        }
    }

    public static float m1949a(float f, Context context) {
        return f / (((float) context.getResources().getDisplayMetrics().densityDpi) / 160.0f);
    }

    public static float m1950a(Location location, Location location2) {
        float[] fArr = new float[1];
        Location.distanceBetween(location.getLatitude(), location.getLongitude(), location2.getLatitude(), location2.getLongitude(), fArr);
        return fArr[0];
    }

    public static String m1953a(Context context) {
        return Secure.getString(context.getContentResolver(), "android_id");
    }

    @SuppressLint({"NewApi"})
    public static Point m1963b(Context context) {
        Point point = new Point();
        Display o = C0294h.m1985o(context);
        if (VERSION.SDK_INT >= 13) {
            o.getSize(point);
            point.y -= C0294h.m1986p(context);
        } else {
            point.x = o.getWidth();
            point.y = o.getHeight() - C0294h.m1986p(context);
        }
        return point;
    }

    public static long m1952a(int i) {
        return TrafficStats.getUidRxBytes(i);
    }

    public static long m1961b(int i) {
        return TrafficStats.getUidTxBytes(i);
    }

    public static int m1967c(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (Throwable e) {
            Log.e(f1174a, "androidutil/package name not found.", e);
            return -1;
        }
    }

    @SuppressLint({"NewApi"})
    private static Display m1985o(Context context) {
        if (VERSION.SDK_INT > 17) {
            return ((DisplayManager) context.getSystemService("display")).getDisplay(0);
        }
        return ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
    }

    public static int m1951a() {
        return Process.myUid();
    }

    public static C0289c m1969d(Context context) {
        try {
            return C0290d.m1939a(context);
        } catch (Throwable e) {
            Log.e(f1174a, "googleadinfo/InterruptedException occurred.", e);
            return null;
        } catch (Throwable e2) {
            Log.e(f1174a, "googleadinfo/Could not connect to Google Play services.", e2);
            return null;
        }
    }

    public static String m1971e(Context context) {
        CharSequence installerPackageName = context.getPackageManager().getInstallerPackageName(context.getPackageName());
        if (C0302p.m2177b(installerPackageName)) {
            return "UNKNOWN";
        }
        return installerPackageName;
    }

    public static String m1973f(Context context) {
        return ((TelephonyManager) context.getSystemService("phone")).getNetworkOperator();
    }

    public static int m1975g(Context context) {
        int refreshRate = (int) C0294h.m1985o(context).getRefreshRate();
        return refreshRate == 0 ? 60 : refreshRate;
    }

    public static String m1977h(Context context) {
        String E = C0300n.m2077E(context);
        return E == null ? ClientApplication.m1691c().m2450h() : E;
    }

    public static String m1979i(Context context) {
        return ((TelephonyManager) context.getSystemService("phone")).getSimOperator();
    }

    private static int m1986p(Context context) {
        int identifier = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        return identifier > 0 ? context.getResources().getDimensionPixelSize(identifier) : 0;
    }

    public static long m1980j(Context context) {
        return (long) ((((ActivityManager) context.getSystemService("activity")).getMemoryClass() * 1024) * 1024);
    }

    public static TimeZone m1964b() {
        return TimeZone.getDefault();
    }

    public static String m1968c() {
        TimeZone b = C0294h.m1964b();
        if (b == null) {
            return null;
        }
        return b.getID();
    }

    public static String m1970d() {
        String property = System.getProperty("http.agent");
        if (property == null) {
            property = "";
        }
        if (property.length() > 512) {
            return property.substring(0, 512);
        }
        return property;
    }

    public static String m1981k(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (Throwable e) {
            Log.e(f1174a, "androidutil/package name not found.", e);
            return null;
        }
    }

    public static boolean m1982l(Context context) {
        return !C0300n.m2092a(context).equals(C0294h.m1953a(context));
    }

    public static boolean m1983m(Context context) {
        return C0300n.m2112c(context) != C0294h.m1967c(context);
    }

    public static void m1954a(Context context, View view) {
        ((InputMethodManager) context.getSystemService("input_method")).hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static boolean m1984n(Context context) {
        List runningTasks = ((ActivityManager) context.getSystemService("activity")).getRunningTasks(1);
        if (runningTasks.isEmpty()) {
            return false;
        }
        return ((RunningTaskInfo) runningTasks.get(0)).topActivity.getPackageName().equalsIgnoreCase(context.getPackageName());
    }

    public static boolean m1959a(MotionEvent motionEvent, View view) {
        return C0294h.m1960a(motionEvent, view, 0);
    }

    public static boolean m1960a(MotionEvent motionEvent, View view, int i) {
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        int[] iArr = new int[2];
        view.getLocationOnScreen(iArr);
        int i2 = iArr[0];
        int i3 = iArr[1];
        int width = view.getWidth();
        int height = view.getHeight();
        if (x < ((float) (i2 + 0)) || x > ((float) ((i2 + width) + 0)) || y < ((float) (i3 - i)) || y > ((float) ((i3 + height) + 0))) {
            return false;
        }
        return true;
    }

    public static boolean m1972e() {
        ConnectivityManager connectivityManager = (ConnectivityManager) ClientApplication.m1690b().getApplicationContext().getSystemService("connectivity");
        NetworkInfo networkInfo = connectivityManager.getNetworkInfo(0);
        NetworkInfo networkInfo2 = connectivityManager.getNetworkInfo(1);
        NetworkInfo networkInfo3 = connectivityManager.getNetworkInfo(6);
        return (networkInfo != null && networkInfo.isConnectedOrConnecting()) || ((networkInfo2 != null && networkInfo2.isConnectedOrConnecting()) || (networkInfo3 != null && networkInfo3.isConnectedOrConnecting()));
    }

    public static boolean m1974f() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) ClientApplication.m1690b().getApplicationContext().getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public static boolean m1976g() {
        if (C0294h.m1972e()) {
            return ((ConnectivityManager) ClientApplication.m1690b().getApplicationContext().getSystemService("connectivity")).getNetworkInfo(1).isConnectedOrConnecting();
        }
        return false;
    }

    public static UUID m1978h() {
        if (VERSION.SDK_INT < 9) {
            return UUID.randomUUID();
        }
        ThreadPolicy allowThreadDiskReads = StrictMode.allowThreadDiskReads();
        try {
            UUID randomUUID = UUID.randomUUID();
            return randomUUID;
        } finally {
            StrictMode.setThreadPolicy(allowThreadDiskReads);
        }
    }

    public static void m1956a(Context context, Class cls, int i) {
        C0294h.m1955a(context, cls);
        C0294h.m1966b(context, cls, i);
    }

    public static void m1966b(Context context, Class cls, int i) {
        ((AlarmManager) context.getSystemService("alarm")).set(1, ((GregorianCalendar) Calendar.getInstance()).getTimeInMillis() + ((long) i), PendingIntent.getService(context, 1, new Intent(context, cls), 134217728));
    }

    public static void m1965b(Context context, View view) {
        ((InputMethodManager) context.getSystemService("input_method")).showSoftInput(view, 1);
    }

    public static long m1962b(Location location, Location location2) {
        return location2.getTime() - location.getTime();
    }
}
