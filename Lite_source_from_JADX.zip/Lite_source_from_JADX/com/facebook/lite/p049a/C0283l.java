package com.facebook.lite.p049a;

import java.util.LinkedHashMap;

/* renamed from: com.facebook.lite.a.l */
public class C0283l {
    private int f1093a;
    private int f1094b;
    private final LinkedHashMap f1095c;
    private int f1096d;
    private int f1097e;
    private int f1098f;
    private int f1099g;

    public C0283l(int i) {
        if (i <= 0) {
            throw new IllegalArgumentException("maxSize <= 0");
        }
        this.f1096d = i;
        this.f1095c = new LinkedHashMap(0, 0.75f, true);
    }

    public final Object m1918a(Object obj) {
        if (obj == null) {
            throw new NullPointerException("key == null");
        }
        synchronized (this) {
            Object obj2 = this.f1095c.get(obj);
            if (obj2 != null) {
                this.f1094b++;
                return obj2;
            }
            this.f1097e++;
            return null;
        }
    }

    public final Object m1919a(Object obj, Object obj2) {
        if (obj == null || obj2 == null) {
            throw new NullPointerException("key == null || value == null");
        }
        Object put;
        synchronized (this) {
            this.f1098f++;
            this.f1099g += m1917b(obj, obj2);
            put = this.f1095c.put(obj, obj2);
            if (put != null) {
                this.f1099g -= m1917b(obj, put);
            }
        }
        if (put != null) {
            m1921c(put);
        }
        m1916a(this.f1096d);
        return put;
    }

    public final Object m1920b(Object obj) {
        if (obj == null) {
            throw new NullPointerException("key == null");
        }
        Object remove;
        synchronized (this) {
            remove = this.f1095c.remove(obj);
            if (remove != null) {
                this.f1099g -= m1917b(obj, remove);
            }
        }
        if (remove != null) {
            m1921c(remove);
        }
        return remove;
    }

    public final synchronized String toString() {
        String format;
        int i = 0;
        synchronized (this) {
            int i2 = this.f1094b + this.f1097e;
            if (i2 != 0) {
                i = (this.f1094b * 100) / i2;
            }
            format = String.format("LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]", new Object[]{Integer.valueOf(this.f1096d), Integer.valueOf(this.f1094b), Integer.valueOf(this.f1097e), Integer.valueOf(i)});
        }
        return format;
    }

    protected void m1921c(Object obj) {
    }

    protected int m1922d(Object obj) {
        return 1;
    }

    private int m1917b(Object obj, Object obj2) {
        int d = m1922d(obj2);
        if (d >= 0) {
            return d;
        }
        throw new IllegalStateException("Negative size: " + obj + "=" + obj2);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m1916a(int r4) {
        /*
        r3 = this;
    L_0x0000:
        monitor-enter(r3);
        r0 = r3.f1099g;	 Catch:{ all -> 0x0032 }
        if (r0 < 0) goto L_0x0011;
    L_0x0005:
        r0 = r3.f1095c;	 Catch:{ all -> 0x0032 }
        r0 = r0.isEmpty();	 Catch:{ all -> 0x0032 }
        if (r0 == 0) goto L_0x0035;
    L_0x000d:
        r0 = r3.f1099g;	 Catch:{ all -> 0x0032 }
        if (r0 == 0) goto L_0x0035;
    L_0x0011:
        r0 = new java.lang.IllegalStateException;	 Catch:{ all -> 0x0032 }
        r1 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0032 }
        r1.<init>();	 Catch:{ all -> 0x0032 }
        r2 = r3.getClass();	 Catch:{ all -> 0x0032 }
        r2 = r2.getName();	 Catch:{ all -> 0x0032 }
        r1 = r1.append(r2);	 Catch:{ all -> 0x0032 }
        r2 = ".sizeOf() is reporting inconsistent results!";
        r1 = r1.append(r2);	 Catch:{ all -> 0x0032 }
        r1 = r1.toString();	 Catch:{ all -> 0x0032 }
        r0.<init>(r1);	 Catch:{ all -> 0x0032 }
        throw r0;	 Catch:{ all -> 0x0032 }
    L_0x0032:
        r0 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x0032 }
        throw r0;
    L_0x0035:
        r0 = r3.f1099g;	 Catch:{ all -> 0x0032 }
        if (r0 <= r4) goto L_0x0041;
    L_0x0039:
        r0 = r3.f1095c;	 Catch:{ all -> 0x0032 }
        r0 = r0.isEmpty();	 Catch:{ all -> 0x0032 }
        if (r0 == 0) goto L_0x0043;
    L_0x0041:
        monitor-exit(r3);	 Catch:{ all -> 0x0032 }
        return;
    L_0x0043:
        r0 = r3.f1095c;	 Catch:{ all -> 0x0032 }
        r0 = r0.entrySet();	 Catch:{ all -> 0x0032 }
        r0 = r0.iterator();	 Catch:{ all -> 0x0032 }
        r0 = r0.next();	 Catch:{ all -> 0x0032 }
        r0 = (java.util.Map.Entry) r0;	 Catch:{ all -> 0x0032 }
        r1 = r0.getKey();	 Catch:{ all -> 0x0032 }
        r0 = r0.getValue();	 Catch:{ all -> 0x0032 }
        r2 = r3.f1095c;	 Catch:{ all -> 0x0032 }
        r2.remove(r1);	 Catch:{ all -> 0x0032 }
        r2 = r3.f1099g;	 Catch:{ all -> 0x0032 }
        r1 = r3.m1917b(r1, r0);	 Catch:{ all -> 0x0032 }
        r1 = r2 - r1;
        r3.f1099g = r1;	 Catch:{ all -> 0x0032 }
        r1 = r3.f1093a;	 Catch:{ all -> 0x0032 }
        r1 = r1 + 1;
        r3.f1093a = r1;	 Catch:{ all -> 0x0032 }
        monitor-exit(r3);	 Catch:{ all -> 0x0032 }
        r3.m1921c(r0);
        goto L_0x0000;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.a.l.a(int):void");
    }
}
