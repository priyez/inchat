package com.facebook.lite.p056d;

/* renamed from: com.facebook.lite.d.e */
final class C0312e {
    private static final C0313f f1227a;

    static {
        f1227a = new C0313f();
    }
}
