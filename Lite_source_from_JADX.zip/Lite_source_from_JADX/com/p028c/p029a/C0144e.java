package com.p028c.p029a;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

/* renamed from: com.c.a.e */
public final class C0144e implements SensorEventListener {
    private final C0143d f615a;
    private final C0140a f616b;
    private SensorManager f617c;
    private Sensor f618d;

    public C0144e(C0140a c0140a) {
        this.f615a = new C0143d();
        this.f616b = c0140a;
    }

    public final boolean m1311a(SensorManager sensorManager) {
        if (this.f618d != null) {
            return true;
        }
        this.f618d = sensorManager.getDefaultSensor(1);
        if (this.f618d != null) {
            this.f617c = sensorManager;
            sensorManager.registerListener(this, this.f618d, 0);
        }
        if (this.f618d == null) {
            return false;
        }
        return true;
    }

    public final void m1310a() {
        if (this.f618d != null) {
            this.f617c.unregisterListener(this, this.f618d);
            this.f617c = null;
            this.f618d = null;
        }
    }

    public final void onSensorChanged(SensorEvent sensorEvent) {
        boolean a = C0144e.m1309a(sensorEvent);
        this.f615a.m1307a(sensorEvent.timestamp, a);
        if (this.f615a.m1308b()) {
            this.f615a.m1306a();
            this.f616b.m1302a();
        }
    }

    private static boolean m1309a(SensorEvent sensorEvent) {
        float f = sensorEvent.values[0];
        float f2 = sensorEvent.values[1];
        float f3 = sensorEvent.values[2];
        if (Math.sqrt((double) (((f * f) + (f2 * f2)) + (f3 * f3))) > 13.0d) {
            return true;
        }
        return false;
    }

    public final void onAccuracyChanged(Sensor sensor, int i) {
    }
}
