package com.facebook.lite.photo;

import android.os.Parcel;
import android.os.Parcelable.Creator;

/* renamed from: com.facebook.lite.photo.h */
final class C0439h implements Creator {
    C0439h() {
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return C0439h.m3013a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return C0439h.m3014a(i);
    }

    private static GalleryItem m3013a(Parcel parcel) {
        return new GalleryItem(parcel);
    }

    private static GalleryItem[] m3014a(int i) {
        return new GalleryItem[i];
    }
}
