package com.facebook.lite.p049a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import com.facebook.lite.p053b.C0301o;

/* renamed from: com.facebook.lite.a.m */
public class C0284m extends BroadcastReceiver {
    private static final String f1100a;

    static {
        f1100a = C0284m.class.getSimpleName();
    }

    public static IntentFilter m1923a() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.MEDIA_MOUNTED");
        intentFilter.addAction("android.intent.action.MEDIA_UNMOUNTED");
        intentFilter.addDataScheme("file");
        return intentFilter;
    }

    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if ("android.intent.action.MEDIA_MOUNTED".equals(action)) {
            C0301o.m2172a(true);
        } else if ("android.intent.action.MEDIA_UNMOUNTED".equals(action)) {
            C0301o.m2172a(false);
        }
    }
}
