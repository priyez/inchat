package com.facebook.lite.p058f;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* renamed from: com.facebook.lite.f.e */
public final class C0337e implements Serializable {
    private int f1322a;
    private List f1323b;
    private final int f1324c;

    public C0337e(int i) {
        this.f1324c = 70;
        this.f1323b = m2337b();
        this.f1322a = i;
    }

    public final void m2338a() {
        this.f1323b = m2337b();
    }

    public final void m2339a(C0337e c0337e) {
        if (c0337e != null) {
            for (int i = 0; i < c0337e.f1324c; i++) {
                Map map = (Map) c0337e.f1323b.get(i);
                int i2 = this.f1322a - (c0337e.f1322a - i);
                if (i2 >= 0 && i2 < this.f1324c) {
                    C0339g.m2345a((Map) this.f1323b.get(i2), map);
                }
            }
        }
    }

    public final void m2340a(Map map, int i) {
        int i2 = i - this.f1322a;
        if (Math.abs(i2) >= this.f1324c) {
            this.f1323b = m2337b();
        } else {
            List arrayList;
            int i3;
            if (i2 > 0) {
                arrayList = new ArrayList(this.f1324c);
                for (i3 = 0; i3 < i2; i3++) {
                    arrayList.add(new HashMap());
                }
                arrayList.addAll(i2, this.f1323b.subList(0, this.f1324c - i2));
            } else if (i2 < 0) {
                arrayList = new ArrayList(this.f1324c);
                arrayList.addAll(0, this.f1323b.subList(Math.abs(i2), this.f1324c));
                for (i3 = 0; i3 < (-i2); i3++) {
                    arrayList.add(new HashMap());
                }
            }
            this.f1323b = arrayList;
        }
        C0339g.m2345a((Map) this.f1323b.get(0), map);
        this.f1322a = i;
    }

    private List m2337b() {
        List arrayList = new ArrayList(this.f1324c);
        for (int i = 0; i < this.f1324c; i++) {
            arrayList.add(new HashMap());
        }
        return arrayList;
    }
}
