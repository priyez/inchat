package com.facebook.lite.photo;

import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Matrix;
import android.hardware.Camera;
import android.hardware.Camera.Size;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Environment;
import android.provider.MediaStore.Images.Media;
import android.util.DisplayMetrics;
import android.util.Log;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p053b.C0301o;
import com.facebook.lite.p059m.C0387i;
import com.facebook.p038e.C0251k;
import com.p008a.p009a.p010a.C0033c;
import com.p008a.p009a.p010a.C0044d;
import com.p008a.p009a.p010a.p011a.C0007d;
import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p023m.C0123k;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/* renamed from: com.facebook.lite.photo.m */
public class C0444m {
    private static final String f1783a;
    private static volatile Integer f1784b;

    static {
        f1783a = C0444m.class.getSimpleName();
    }

    private C0444m() {
    }

    private static int m3036a(Context context, Options options, int i, int i2) {
        int i3 = options.outHeight;
        int i4 = options.outWidth;
        if (i <= 0 || i2 <= 0) {
            DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
            i = displayMetrics.widthPixels;
            i2 = displayMetrics.heightPixels;
        }
        if (i3 <= i2 && i4 <= i) {
            return 1;
        }
        int ceil = (int) Math.ceil((double) (((float) i3) / ((float) i2)));
        i3 = (int) Math.ceil((double) (((float) i4) / ((float) i)));
        return ceil < i3 ? ceil : i3;
    }

    public static Bitmap m3040a(Context context, byte[] bArr, int i, int i2, int i3) {
        Options options = new Options();
        options.inJustDecodeBounds = true;
        options.inPreferredConfig = Config.RGB_565;
        options.inDither = true;
        BitmapFactory.decodeByteArray(bArr, 0, i, options);
        options.inSampleSize = C0444m.m3036a(context, options, i2, i3);
        options.inJustDecodeBounds = false;
        Bitmap bitmap = null;
        try {
            bitmap = BitmapFactory.decodeByteArray(bArr, 0, i, options);
        } catch (Throwable e) {
            Log.e(f1783a, "photo/out of memory while decoding bitmap from byte array.", e);
            C0444m.m3053a((short) 273, e);
        }
        return bitmap;
    }

    public static Bitmap m3039a(Context context, String str, int i, int i2) {
        Options options = new Options();
        options.inJustDecodeBounds = true;
        options.inPreferredConfig = Config.RGB_565;
        options.inDither = true;
        BitmapFactory.decodeFile(str, options);
        options.inSampleSize = C0444m.m3036a(context, options, i, i2);
        options.inJustDecodeBounds = false;
        Bitmap bitmap = null;
        try {
            bitmap = BitmapFactory.decodeFile(str, options);
        } catch (Throwable e) {
            Log.e(f1783a, "photo/out of memory while decoding bitmap from file.", e);
            C0444m.m3053a((short) 274, e);
        }
        return bitmap;
    }

    public static Bitmap m3038a(Context context, ContentResolver contentResolver, Uri uri, int i, int i2) {
        Bitmap bitmap = null;
        InputStream a = C0444m.m3047a(contentResolver, uri);
        if (a != null) {
            Options options = new Options();
            options.inJustDecodeBounds = true;
            options.inPreferredConfig = Config.RGB_565;
            options.inDither = true;
            BitmapFactory.decodeStream(a, bitmap, options);
            C0444m.m3052a(a);
            a = C0444m.m3047a(contentResolver, uri);
            if (a != null) {
                options.inSampleSize = C0444m.m3036a(context, options, i, i2);
                options.inJustDecodeBounds = false;
                try {
                    bitmap = BitmapFactory.decodeStream(a, null, options);
                } catch (Throwable e) {
                    Log.e(f1783a, "photo/out of memory while decoding bitmap from input stream.", e);
                    C0444m.m3053a((short) 275, e);
                } finally {
                    C0444m.m3052a(a);
                }
            }
        }
        return bitmap;
    }

    private static int m3035a(int i) {
        if (i == 6) {
            return 90;
        }
        if (i == 3) {
            return 180;
        }
        if (i == 8) {
            return 270;
        }
        return 0;
    }

    public static Bitmap m3044a(String str, C0251k c0251k, Context context, int i) {
        Bitmap a = C0444m.m3039a(context, str, C0300n.m2120d(context), C0300n.m2102b(context));
        if (a == null) {
            c0251k.m1681b("decoding_succeeded", false);
            return null;
        }
        c0251k.m1681b("decoding_succeeded", true);
        return C0444m.m3043a(str, a, c0251k, i);
    }

    public static byte[] m3057a(Context context, int i, String str, C0251k c0251k, int i2) {
        Bitmap a = C0444m.m3044a(str, c0251k, context, i2);
        c0251k.m1679b("photo_quality", (long) i);
        OutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        if (a == null) {
            return null;
        }
        a.compress(CompressFormat.JPEG, i, byteArrayOutputStream);
        a.recycle();
        byte[] toByteArray = byteArrayOutputStream.toByteArray();
        try {
            byteArrayOutputStream.close();
            return toByteArray;
        } catch (Throwable e) {
            Log.e(f1783a, "gallery/unable to close photo byte stream.", e);
            return toByteArray;
        }
    }

    private static boolean m3056a(File file, File file2) {
        FileInputStream fileInputStream;
        FileInputStream fileInputStream2;
        BufferedInputStream bufferedInputStream;
        FileInputStream fileInputStream3;
        BufferedInputStream bufferedInputStream2;
        FileInputStream fileInputStream4;
        BufferedInputStream bufferedInputStream3;
        FileInputStream fileInputStream5;
        Throwable th;
        BufferedInputStream bufferedInputStream4 = null;
        if (file == file2 || file.equals(file2)) {
            return true;
        }
        long length = file.length();
        long length2 = file2.length();
        if (length != 0 && length2 != 0 && length != length2) {
            return false;
        }
        try {
            fileInputStream = new FileInputStream(file);
            try {
                fileInputStream2 = new FileInputStream(file);
                try {
                    bufferedInputStream = new BufferedInputStream(fileInputStream);
                } catch (IOException e) {
                    fileInputStream3 = fileInputStream2;
                    bufferedInputStream2 = null;
                    fileInputStream4 = fileInputStream;
                    bufferedInputStream3 = null;
                    fileInputStream5 = fileInputStream4;
                    if (bufferedInputStream3 != null) {
                        try {
                            bufferedInputStream3.close();
                        } catch (IOException e2) {
                            return false;
                        }
                    }
                    if (bufferedInputStream2 != null) {
                        bufferedInputStream2.close();
                    }
                    if (fileInputStream5 != null) {
                        fileInputStream5.close();
                    }
                    if (fileInputStream3 == null) {
                        return false;
                    }
                    fileInputStream3.close();
                    return false;
                } catch (Throwable th2) {
                    th = th2;
                    bufferedInputStream = null;
                    if (bufferedInputStream != null) {
                        try {
                            bufferedInputStream.close();
                        } catch (IOException e3) {
                            throw th;
                        }
                    }
                    if (bufferedInputStream4 != null) {
                        bufferedInputStream4.close();
                    }
                    if (fileInputStream != null) {
                        fileInputStream.close();
                    }
                    if (fileInputStream2 != null) {
                        fileInputStream2.close();
                    }
                    throw th;
                }
            } catch (IOException e4) {
                fileInputStream3 = null;
                bufferedInputStream2 = null;
                fileInputStream4 = fileInputStream;
                bufferedInputStream3 = null;
                fileInputStream5 = fileInputStream4;
                if (bufferedInputStream3 != null) {
                    bufferedInputStream3.close();
                }
                if (bufferedInputStream2 != null) {
                    bufferedInputStream2.close();
                }
                if (fileInputStream5 != null) {
                    fileInputStream5.close();
                }
                if (fileInputStream3 == null) {
                    return false;
                }
                fileInputStream3.close();
                return false;
            } catch (Throwable th3) {
                th = th3;
                fileInputStream2 = null;
                bufferedInputStream = null;
                if (bufferedInputStream != null) {
                    bufferedInputStream.close();
                }
                if (bufferedInputStream4 != null) {
                    bufferedInputStream4.close();
                }
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
                if (fileInputStream2 != null) {
                    fileInputStream2.close();
                }
                throw th;
            }
            try {
                BufferedInputStream bufferedInputStream5 = new BufferedInputStream(fileInputStream2);
                try {
                    byte[] bArr = new byte[4096];
                    byte[] bArr2 = new byte[4096];
                    int read;
                    do {
                        read = bufferedInputStream.read(bArr);
                        if (!(read == bufferedInputStream5.read(bArr2) && Arrays.equals(bArr, bArr2))) {
                            try {
                                bufferedInputStream.close();
                                bufferedInputStream5.close();
                                fileInputStream.close();
                                fileInputStream2.close();
                                return false;
                            } catch (IOException e5) {
                                return false;
                            }
                        }
                    } while (read == 4096);
                    try {
                        bufferedInputStream.close();
                        bufferedInputStream5.close();
                        fileInputStream.close();
                        fileInputStream2.close();
                    } catch (IOException e6) {
                    }
                    return true;
                } catch (IOException e7) {
                    fileInputStream3 = fileInputStream2;
                    fileInputStream5 = fileInputStream;
                    bufferedInputStream2 = bufferedInputStream5;
                    bufferedInputStream3 = bufferedInputStream;
                    if (bufferedInputStream3 != null) {
                        bufferedInputStream3.close();
                    }
                    if (bufferedInputStream2 != null) {
                        bufferedInputStream2.close();
                    }
                    if (fileInputStream5 != null) {
                        fileInputStream5.close();
                    }
                    if (fileInputStream3 == null) {
                        return false;
                    }
                    fileInputStream3.close();
                    return false;
                } catch (Throwable th4) {
                    th = th4;
                    bufferedInputStream4 = bufferedInputStream5;
                    if (bufferedInputStream != null) {
                        bufferedInputStream.close();
                    }
                    if (bufferedInputStream4 != null) {
                        bufferedInputStream4.close();
                    }
                    if (fileInputStream != null) {
                        fileInputStream.close();
                    }
                    if (fileInputStream2 != null) {
                        fileInputStream2.close();
                    }
                    throw th;
                }
            } catch (IOException e8) {
                fileInputStream3 = fileInputStream2;
                bufferedInputStream2 = null;
                fileInputStream5 = fileInputStream;
                bufferedInputStream3 = bufferedInputStream;
                if (bufferedInputStream3 != null) {
                    bufferedInputStream3.close();
                }
                if (bufferedInputStream2 != null) {
                    bufferedInputStream2.close();
                }
                if (fileInputStream5 != null) {
                    fileInputStream5.close();
                }
                if (fileInputStream3 == null) {
                    return false;
                }
                fileInputStream3.close();
                return false;
            } catch (Throwable th5) {
                th = th5;
                if (bufferedInputStream != null) {
                    bufferedInputStream.close();
                }
                if (bufferedInputStream4 != null) {
                    bufferedInputStream4.close();
                }
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
                if (fileInputStream2 != null) {
                    fileInputStream2.close();
                }
                throw th;
            }
        } catch (IOException e9) {
            fileInputStream3 = null;
            bufferedInputStream2 = null;
            bufferedInputStream3 = null;
            if (bufferedInputStream3 != null) {
                bufferedInputStream3.close();
            }
            if (bufferedInputStream2 != null) {
                bufferedInputStream2.close();
            }
            if (fileInputStream5 != null) {
                fileInputStream5.close();
            }
            if (fileInputStream3 == null) {
                return false;
            }
            fileInputStream3.close();
            return false;
        } catch (Throwable th6) {
            th = th6;
            fileInputStream2 = null;
            fileInputStream = null;
            bufferedInputStream = null;
            if (bufferedInputStream != null) {
                bufferedInputStream.close();
            }
            if (bufferedInputStream4 != null) {
                bufferedInputStream4.close();
            }
            if (fileInputStream != null) {
                fileInputStream.close();
            }
            if (fileInputStream2 != null) {
                fileInputStream2.close();
            }
            throw th;
        }
    }

    public static Uri m3046a(boolean z) {
        if (z) {
            return C0444m.m3061c();
        }
        return Uri.parse("content://com.facebook.lite.media/" + C0294h.m1978h() + ".jpg");
    }

    private static Uri m3045a(Context context, File file) {
        Uri uri = null;
        String absolutePath = file.getAbsolutePath();
        Cursor query = context.getContentResolver().query(Media.EXTERNAL_CONTENT_URI, new String[]{"_id"}, "_data=? ", new String[]{absolutePath}, null);
        if (query != null) {
            try {
                int columnIndex = query.getColumnIndex("_id");
                if (columnIndex >= 0 && query.moveToNext()) {
                    uri = Uri.withAppendedPath(Media.EXTERNAL_CONTENT_URI, String.valueOf(query.getInt(columnIndex)));
                    if (query != null) {
                        query.close();
                    }
                } else if (query != null) {
                    query.close();
                }
            } catch (Throwable th) {
                if (query != null) {
                    query.close();
                }
            }
        } else if (query != null) {
            query.close();
        }
        return uri;
    }

    private static File m3064d(Context context) {
        File file = null;
        Cursor query = context.getContentResolver().query(Media.EXTERNAL_CONTENT_URI, new String[]{"_id", "_data"}, null, null, "_id DESC");
        if (query != null) {
            try {
                if (query.getCount() > 0) {
                    if (query.moveToFirst()) {
                        file = new File(query.getString(query.getColumnIndex("_data")));
                        if (query != null) {
                            query.close();
                        }
                    } else if (query != null) {
                        query.close();
                    }
                    return file;
                }
            } catch (Throwable th) {
                if (query != null) {
                    query.close();
                }
            }
        }
        if (query != null) {
            query.close();
        }
        return file;
    }

    public static String m3048a(Context context, Uri uri) {
        String str = null;
        if (uri == null) {
            Log.e(f1783a, "photo/photo uri null.");
        } else {
            Cursor query = context.getContentResolver().query(uri, new String[]{"_data"}, null, null, null);
            if (query == null) {
                try {
                    str = uri.getPath();
                    if (query != null) {
                        query.close();
                    }
                } catch (Throwable th) {
                    if (query != null) {
                        query.close();
                    }
                }
            } else {
                int columnIndexOrThrow = query.getColumnIndexOrThrow("_data");
                if (columnIndexOrThrow >= 0 && query.moveToNext()) {
                    str = query.getString(columnIndexOrThrow);
                }
                if (query != null) {
                    query.close();
                }
            }
        }
        return str;
    }

    public static Bitmap m3043a(String str, Bitmap bitmap, C0251k c0251k, int i) {
        try {
            ExifInterface exifInterface = new ExifInterface(str);
            if (c0251k != null) {
                c0251k.m1681b("exif_availability", true);
            }
            int a = C0444m.m3035a(exifInterface.getAttributeInt("Orientation", 1));
            if (c0251k != null) {
                c0251k.m1679b("rotation_degrees", (long) a);
            }
            Bitmap a2 = C0444m.m3042a(bitmap, a + i);
            if (bitmap != a2) {
                bitmap.recycle();
            }
            if (c0251k != null) {
                c0251k.m1681b("out_of_memory", false);
            }
            return a2;
        } catch (Throwable e) {
            if (c0251k != null) {
                c0251k.m1681b("exif_availability", false);
            }
            Log.e(f1783a, "photoUtil/unable to get exif to rotate the photo.", e);
            return bitmap;
        } catch (Throwable e2) {
            if (c0251k != null) {
                c0251k.m1681b("out_of_memory", true);
            }
            Log.e(f1783a, "photoUtil/out of memory while rotating the photo.", e2);
            C0444m.m3053a((short) 276, e2);
            return bitmap;
        }
    }

    public static boolean m3055a(Context context) {
        File externalStoragePublicDirectory;
        if (VERSION.SDK_INT >= 8) {
            externalStoragePublicDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        } else {
            externalStoragePublicDirectory = Environment.getExternalStorageDirectory();
        }
        long a = C0301o.m2169a(externalStoragePublicDirectory);
        int e = C0444m.m3065e(context);
        if (e == -1 || a >= ((long) e)) {
            return true;
        }
        return false;
    }

    public static boolean m3060b(Context context) {
        long a = C0301o.m2169a(context.getFilesDir());
        int e = C0444m.m3065e(context);
        if (e == -1 || a >= ((long) e)) {
            return true;
        }
        return false;
    }

    public static boolean m3054a() {
        return "mounted".equals(Environment.getExternalStorageState());
    }

    public static boolean m3063c(Context context) {
        PackageManager packageManager = context.getPackageManager();
        return VERSION.SDK_INT < 7 || packageManager.hasSystemFeature("android.hardware.camera") || packageManager.hasSystemFeature("android.hardware.camera.front");
    }

    public static void m3051a(C0044d c0044d, C0387i c0387i, C0007d c0007d, Context context) {
        C0251k c0251k = new C0251k("ema_photo_perf");
        c0251k.m1679b("imageHash", (long) (c0044d.f218b & 1073741823));
        c0251k.m1679b("bucket", (long) (c0044d.f218b >>> 30));
        c0251k.m1679b("width", (long) c0044d.f224h);
        c0251k.m1679b("height", (long) c0044d.f217a);
        c0251k.m1679b("transparency", (long) c0044d.f222f);
        c0251k.m1679b("requestType", (long) c0044d.f220d);
        c0251k.m1679b("totalLength", (long) c0044d.f221e);
        c0251k.m1679b("userWaitingTime", (long) c0044d.f223g);
        c0251k.m1679b("pendingRequestTIme", (long) c0044d.f219c);
        c0251k.m1679b("imageId", (long) c0044d.f218b);
        if (c0387i.m2712u() != null) {
            c0251k.m1680b("locale", c0387i.m2712u().m390h());
            c0251k.m1680b("country", c0387i.m2712u().m388f());
        }
        if (c0007d != null) {
            c0251k.m1680b("currentConnectionQuality", c0007d.m53a().toString());
            c0251k.m1679b("currentConnectionBandwidth", (long) c0007d.m56b());
        }
        C0123k a = c0044d.m312a();
        if (a != null) {
            for (int i = 0; i < a.m1222c(); i++) {
                C0033c c0033c = (C0033c) a.m1220b(i);
                if (c0033c != null) {
                    c0251k.m1679b("lengthPart" + i, (long) c0033c.f105a);
                    c0251k.m1679b("waitingTimePart" + i, (long) c0033c.f109e);
                    c0251k.m1679b("pendingRequestTime" + i, (long) c0033c.f106b);
                }
            }
        }
        c0251k.toString();
        C0251k.m1672a(c0251k, context);
    }

    public static void m3059b(Context context, Uri uri) {
        if (uri != null) {
            Cursor query = context.getContentResolver().query(uri, new String[]{"_id"}, null, null, null);
            if (query != null) {
                try {
                    int columnIndex = query.getColumnIndex("_id");
                    if (columnIndex >= 0 && query.moveToNext()) {
                        columnIndex = query.getInt(columnIndex);
                        context.getContentResolver().delete(Media.EXTERNAL_CONTENT_URI, "_id=?", new String[]{Long.toString((long) columnIndex)});
                    }
                    if (query != null) {
                        query.close();
                    }
                } catch (Throwable th) {
                    if (query != null) {
                        query.close();
                    }
                }
            } else if (query != null) {
                query.close();
            }
        }
    }

    public static Bitmap m3042a(Bitmap bitmap, int i) {
        if (bitmap == null || i % 360 == 0) {
            return bitmap;
        }
        Matrix matrix = new Matrix();
        matrix.postRotate((float) i);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    public static Bitmap m3041a(Bitmap bitmap) {
        Bitmap createScaledBitmap;
        int height = bitmap.getHeight() / 2048;
        int width = bitmap.getWidth() / 2048;
        if (height <= 1 && width <= 1) {
            height = 1;
        } else if (height <= width) {
            height = width;
        }
        try {
            createScaledBitmap = Bitmap.createScaledBitmap(bitmap, bitmap.getWidth() / height, bitmap.getHeight() / height, false);
        } catch (IllegalArgumentException e) {
            createScaledBitmap = bitmap;
        } catch (Throwable e2) {
            C0444m.m3053a((short) 277, e2);
            createScaledBitmap = bitmap;
        }
        if (createScaledBitmap != bitmap) {
            bitmap.recycle();
        }
        return createScaledBitmap;
    }

    public static Uri m3062c(Context context, Uri uri) {
        if (uri == null) {
            return null;
        }
        File d = C0444m.m3064d(context);
        if (d == null) {
            return uri;
        }
        String a = C0444m.m3048a(context, uri);
        File file = new File(a);
        if (a == null || a.equals(d.getAbsolutePath()) || !C0444m.m3056a(file, d)) {
            return uri;
        }
        C0444m.m3059b(context, uri);
        file.delete();
        return C0444m.m3045a(context, d);
    }

    private static int m3037a(Camera camera) {
        List supportedPictureSizes = camera.getParameters().getSupportedPictureSizes();
        if (supportedPictureSizes == null) {
            return -1;
        }
        int i = 0;
        for (int i2 = 0; i2 < supportedPictureSizes.size(); i2++) {
            Size size = (Size) supportedPictureSizes.get(i2);
            int i3 = size.width * size.height;
            if (i3 > i) {
                i = i3;
            }
        }
        return (int) (((long) (i * 4)) / 1048576);
    }

    private static void m3052a(InputStream inputStream) {
        try {
            inputStream.close();
        } catch (Throwable e) {
            Log.e(f1783a, "photo/fail to close photo input stream.", e);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static int m3058b() {
        /*
        r0 = -1;
        r2 = 0;
        r1 = android.os.Build.VERSION.SDK_INT;
        r3 = 9;
        if (r1 >= r3) goto L_0x002b;
    L_0x0008:
        r2 = android.hardware.Camera.open();	 Catch:{ RuntimeException -> 0x0016 }
        r0 = com.facebook.lite.photo.C0444m.m3037a(r2);	 Catch:{ RuntimeException -> 0x0016 }
        if (r2 == 0) goto L_0x0015;
    L_0x0012:
        r2.release();
    L_0x0015:
        return r0;
    L_0x0016:
        r1 = move-exception;
        r3 = f1783a;	 Catch:{ all -> 0x0024 }
        r4 = "photo/camera failed to open.";
        android.util.Log.e(r3, r4, r1);	 Catch:{ all -> 0x0024 }
        if (r2 == 0) goto L_0x0015;
    L_0x0020:
        r2.release();
        goto L_0x0015;
    L_0x0024:
        r0 = move-exception;
        if (r2 == 0) goto L_0x002a;
    L_0x0027:
        r2.release();
    L_0x002a:
        throw r0;
    L_0x002b:
        r4 = android.hardware.Camera.getNumberOfCameras();
        r1 = 0;
        r3 = r1;
        r1 = r0;
    L_0x0032:
        if (r3 >= r4) goto L_0x0068;
    L_0x0034:
        r0 = android.hardware.Camera.open(r3);	 Catch:{ RuntimeException -> 0x0063, all -> 0x0061 }
        r2 = com.facebook.lite.photo.C0444m.m3037a(r0);	 Catch:{ RuntimeException -> 0x004a }
        r1 = java.lang.Math.max(r1, r2);	 Catch:{ RuntimeException -> 0x004a }
        if (r0 == 0) goto L_0x0045;
    L_0x0042:
        r0.release();
    L_0x0045:
        r2 = r3 + 1;
        r3 = r2;
        r2 = r0;
        goto L_0x0032;
    L_0x004a:
        r2 = move-exception;
    L_0x004b:
        r5 = f1783a;	 Catch:{ all -> 0x0058 }
        r6 = "photo/camera failed to open.";
        android.util.Log.e(r5, r6, r2);	 Catch:{ all -> 0x0058 }
        if (r0 == 0) goto L_0x0045;
    L_0x0054:
        r0.release();
        goto L_0x0045;
    L_0x0058:
        r1 = move-exception;
        r2 = r0;
        r0 = r1;
    L_0x005b:
        if (r2 == 0) goto L_0x0060;
    L_0x005d:
        r2.release();
    L_0x0060:
        throw r0;
    L_0x0061:
        r0 = move-exception;
        goto L_0x005b;
    L_0x0063:
        r0 = move-exception;
        r7 = r0;
        r0 = r2;
        r2 = r7;
        goto L_0x004b;
    L_0x0068:
        r0 = r1;
        goto L_0x0015;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.photo.m.b():int");
    }

    private static Uri m3061c() {
        File file;
        File file2;
        if (VERSION.SDK_INT >= 8) {
            file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "facebook");
        } else {
            file = new File(Environment.getExternalStorageDirectory(), "facebook");
        }
        if (!file.exists()) {
            file.mkdirs();
        }
        Random random = new Random();
        do {
            file2 = new File(file, C0444m.m3049a("FB_IMG", (System.currentTimeMillis() * 10000) + ((long) random.nextInt(9999)), ".jpg"));
        } while (file2.exists());
        new StringBuilder("photo/next file to use for photo: ").append(Uri.fromFile(file2).getPath());
        return Uri.fromFile(file2);
    }

    private static String m3049a(String str, long j, String str2) {
        return str + "_" + j + str2;
    }

    private static int m3065e(Context context) {
        synchronized (C0444m.class) {
            if (f1784b == null) {
                f1784b = Integer.valueOf(C0444m.m3066f(context));
            }
        }
        new StringBuilder("photo/loaded largest supported picture size from shared prefs: ").append(f1784b);
        return f1784b.intValue();
    }

    private static int m3066f(Context context) {
        int w = C0300n.m2165w(context);
        if (w != Integer.MIN_VALUE) {
            return w;
        }
        w = C0444m.m3058b();
        C0444m.m3050a(context, w);
        return w;
    }

    private static InputStream m3047a(ContentResolver contentResolver, Uri uri) {
        try {
            return contentResolver.openInputStream(uri);
        } catch (Throwable e) {
            Log.e(f1783a, "photo/fail to open photo input stream.", e);
            return null;
        }
    }

    private static void m3053a(short s, Throwable th) {
        C0022b T = ClientApplication.m1691c().m2388T();
        if (T != null) {
            T.m124a(s, null, th);
        }
    }

    private static void m3050a(Context context, int i) {
        C0300n.m2121d(context, i);
    }
}
