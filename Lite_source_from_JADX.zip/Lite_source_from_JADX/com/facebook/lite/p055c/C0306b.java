package com.facebook.lite.p055c;

import com.facebook.lite.p059m.C0387i;
import com.facebook.lite.photo.GalleryItem;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/* renamed from: com.facebook.lite.c.b */
public final class C0306b {
    public static ArrayList m2207a(List list, C0305a c0305a, C0387i c0387i) {
        if (c0305a == null || c0387i == null) {
            return null;
        }
        Set<Integer> hashSet = new HashSet(c0305a.m2198d());
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < list.size(); i++) {
            GalleryItem galleryItem = (GalleryItem) list.get(i);
            int b = galleryItem.m2991b();
            if (hashSet.contains(Integer.valueOf(b))) {
                hashSet.remove(Integer.valueOf(b));
                c0305a.m2191a(galleryItem);
            } else {
                arrayList.add(galleryItem);
            }
        }
        for (Integer intValue : hashSet) {
            int d = c0305a.m2197d(intValue.intValue());
            c0305a.m2187a(d);
            c0387i.m2714w().m634g(d);
        }
        c0305a.m2205j();
        return arrayList;
    }
}
