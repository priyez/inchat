package com.facebook.lite.p064l;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.widget.EditText;
import java.util.ArrayList;
import java.util.List;

/* renamed from: com.facebook.lite.l.b */
final class C0372b implements OnClickListener {
    final /* synthetic */ EditText f1440a;
    final /* synthetic */ List f1441b;
    final /* synthetic */ C0377g f1442c;

    C0372b(C0377g c0377g, EditText editText, List list) {
        this.f1442c = c0377g;
        this.f1440a = editText;
        this.f1441b = list;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        this.f1442c.f1453d = false;
        Intent intent = new Intent("android.intent.action.SEND_MULTIPLE");
        intent.setType("message/rfc822");
        intent.putExtra("android.intent.extra.EMAIL", C0377g.f1451b);
        intent.putExtra("android.intent.extra.SUBJECT", "Facebook Lite Bug Report");
        if (this.f1440a.getText() == null) {
            this.f1440a.setText("");
        }
        intent.putExtra("android.intent.extra.TEXT", this.f1440a.getText().toString());
        intent.putParcelableArrayListExtra("android.intent.extra.STREAM", (ArrayList) this.f1441b);
        this.f1442c.f1452c.startActivity(intent);
        this.f1440a.clearFocus();
    }
}
