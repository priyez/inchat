package com.facebook.lite.p053b;

import com.p008a.p009a.p010a.p023m.C0122j;

/* renamed from: com.facebook.lite.b.k */
public class C0297k extends C0122j {
    C0297k f1175a;
    C0297k f1176b;

    public C0297k() {
        this.f1175a = null;
        this.f1176b = null;
    }
}
