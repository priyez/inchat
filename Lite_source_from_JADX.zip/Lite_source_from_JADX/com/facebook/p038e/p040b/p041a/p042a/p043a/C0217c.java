package com.facebook.p038e.p040b.p041a.p042a.p043a;

/* renamed from: com.facebook.e.b.a.a.a.c */
public enum C0217c {
    DECODED_IMAGE_ERROR,
    RECEIVED_IMAGE,
    REQUEST_FAIL,
    REQUEST_SEND_OUT,
    USED
}
