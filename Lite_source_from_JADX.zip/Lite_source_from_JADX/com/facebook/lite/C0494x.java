package com.facebook.lite;

import android.graphics.Bitmap;
import com.p008a.p009a.p010a.p022l.C0076e;

/* renamed from: com.facebook.lite.x */
final class C0494x implements Runnable {
    final /* synthetic */ Bitmap f2116a;
    final /* synthetic */ C0076e f2117b;
    final /* synthetic */ MainActivity f2118c;

    C0494x(MainActivity mainActivity, Bitmap bitmap, C0076e c0076e) {
        this.f2118c = mainActivity;
        this.f2116a = bitmap;
        this.f2117b = c0076e;
    }

    public final void run() {
        this.f2118c.f985q.m3250a(this.f2116a, this.f2117b.m593d());
    }
}
