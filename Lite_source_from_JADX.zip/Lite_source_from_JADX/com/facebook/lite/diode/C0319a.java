package com.facebook.lite.diode;

import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.StatFs;
import android.util.Log;

/* renamed from: com.facebook.lite.diode.a */
public class C0319a {
    private static final String f1266a;

    static {
        f1266a = C0319a.class.getSimpleName();
    }

    private C0319a() {
    }

    public static String m2269a(Context context, String str) {
        if (str != null && str.startsWith("messenger.diode.status.")) {
            return Byte.toString(C0319a.m2266a(context.getContentResolver(), str.substring(23)));
        } else if ("messenger.diode.store".equals(str)) {
            return Boolean.toString(C0319a.m2270a(context));
        } else {
            if ("messenger.diode.freespace".equals(str)) {
                return Long.toString(C0319a.m2268a());
            }
            return null;
        }
    }

    private static byte m2266a(ContentResolver contentResolver, String str) {
        Cursor query;
        try {
            String str2 = "{\"userId\": \"" + str + "\"}";
            query = contentResolver.query(Uri.parse("content://com.facebook.orca.notify.MessengerLoggedInUserProvider/logged_in_user"), null, str2, null, null);
            if (query == null) {
                return (byte) 1;
            }
            byte a = C0319a.m2267a(query);
            query.close();
            return a;
        } catch (Throwable e) {
            Log.e(f1266a, "Cursor error", e);
            return (byte) 0;
        } catch (Throwable th) {
            query.close();
        }
    }

    private static long m2268a() {
        try {
            StatFs statFs = new StatFs(Environment.getDataDirectory().getPath());
            return ((long) statFs.getBlockSize()) * ((long) statFs.getAvailableBlocks());
        } catch (Throwable e) {
            Log.e(f1266a, "Free space error", e);
            return 0;
        }
    }

    private static byte m2267a(Cursor cursor) {
        int i = 0;
        if (!cursor.moveToNext()) {
            return (byte) 0;
        }
        int columnCount = cursor.getColumnCount();
        int i2 = columnCount > 0 ? cursor.getInt(0) > 0 ? 1 : 0 : 0;
        if (columnCount >= 3 && cursor.getInt(2) > 0) {
            i = 1;
        }
        if (i2 != 0) {
            return (byte) 3;
        }
        return i != 0 ? (byte) 4 : (byte) 2;
    }

    private static boolean m2270a(Context context) {
        try {
            for (PackageInfo packageInfo : context.getPackageManager().getInstalledPackages(8192)) {
                if (!"com.google.market".equals(packageInfo.packageName)) {
                    if ("com.android.vending".equals(packageInfo.packageName)) {
                    }
                }
                return true;
            }
        } catch (Throwable e) {
            Log.e(f1266a, "Play store error", e);
        }
        return false;
    }
}
