package com.facebook.p031b.p034c;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.util.UUID;

/* renamed from: com.facebook.b.c.h */
public final class C0161h {
    private static String f632a;

    static {
        f632a = null;
    }

    public static synchronized String m1348a(Context context) {
        String str;
        synchronized (C0161h.class) {
            if (f632a == null) {
                File filesDir = context.getFilesDir();
                if (filesDir == null) {
                    str = "n/a";
                } else {
                    File file = new File(filesDir.getParent(), "ACRA-INSTALLATION");
                    try {
                        if (!file.exists()) {
                            C0161h.m1350b(file);
                        }
                        f632a = C0161h.m1349a(file);
                    } catch (Exception e) {
                        str = "n/a";
                    }
                }
            }
            str = f632a;
        }
        return str;
    }

    private static String m1349a(File file) {
        RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r");
        try {
            byte[] bArr = new byte[((int) randomAccessFile.length())];
            randomAccessFile.readFully(bArr);
            String str = new String(bArr);
            return str;
        } finally {
            randomAccessFile.close();
        }
    }

    private static void m1350b(File file) {
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        try {
            fileOutputStream.write(UUID.randomUUID().toString().getBytes());
        } finally {
            fileOutputStream.close();
        }
    }
}
