package com.facebook.lite.p049a;

import java.util.concurrent.ThreadFactory;

/* renamed from: com.facebook.lite.a.e */
final class C0276e implements ThreadFactory {
    final /* synthetic */ C0280i f1053a;

    C0276e(C0280i c0280i) {
        this.f1053a = c0280i;
    }

    public final Thread newThread(Runnable runnable) {
        Thread thread = new Thread(runnable);
        thread.setPriority(1);
        return thread;
    }
}
