package com.facebook.lite.notification;

import com.facebook.lite.notification.SystemTrayNotification.NotificationType;
import java.util.HashMap;

/* renamed from: com.facebook.lite.notification.h */
final class C0419h extends HashMap {
    C0419h() {
        put("mention", NotificationType.MENTION);
        put("close_friend_activity", NotificationType.CLOSE_FRIEND_ACTIVITY);
        put("story_reshare", NotificationType.STORY_RESHARE);
        put("added_profile_info", NotificationType.ADDED_PROFILE_INFO);
        put("like", NotificationType.LIKE);
        put("like_tagged", NotificationType.LIKE);
        put("msg", NotificationType.MSG);
        put("friend", NotificationType.FRIEND_REQUEST);
        put("friend_confirmed", NotificationType.FRIEND_CONFIRMATION);
        put("wall", NotificationType.WALL);
        put("place_tagged_in_checkin", NotificationType.WALL);
        put("tagged_with_story", NotificationType.WALL);
        put("photo_tag", NotificationType.TAG);
        put("photo_tagged_by_non_owner", NotificationType.TAG);
        put("share_wall_create", NotificationType.TAG);
        put("event_invite", NotificationType.EVENT);
        put("event_wall", NotificationType.EVENT);
        put("event_admin", NotificationType.EVENT);
        put("event_name_change", NotificationType.EVENT);
        put("event_description_mention", NotificationType.EVENT);
        put("event_mall_comment", NotificationType.EVENT);
        put("event_mall_reply", NotificationType.EVENT);
        put("event_photo_change", NotificationType.EVENT);
        put("event_cancel", NotificationType.EVENT);
        put("event_update", NotificationType.EVENT);
        put("event_user_invited", NotificationType.EVENT);
        put("plan_reminder", NotificationType.EVENT);
        put("plan_edited", NotificationType.EVENT);
        put("plan_user_joined", NotificationType.EVENT);
        put("plan_admin_added", NotificationType.EVENT);
        put("plan_mall_activity", NotificationType.EVENT);
        put("feed_comment", NotificationType.COMMENT);
        put("photo_comment", NotificationType.COMMENT);
        put("note_comment", NotificationType.COMMENT);
        put("share_comment", NotificationType.COMMENT);
        put("photo_album_comment", NotificationType.COMMENT);
        put("photo_comment_tagged", NotificationType.COMMENT);
        put("photo_reply", NotificationType.COMMENT);
        put("photo_album_reply", NotificationType.COMMENT);
        put("feed_comment_reply", NotificationType.COMMENT);
        put("comment_mention", NotificationType.COMMENT);
        put("mentions_comment", NotificationType.COMMENT);
        put("group_activity", NotificationType.GROUP);
        put("group_added_to_group", NotificationType.GROUP);
        put("group_comment", NotificationType.GROUP);
        put("group_comment_reply", NotificationType.GROUP);
        put("group_mall_plan", NotificationType.GROUP);
        put("birthday_reminder", NotificationType.BIRTHDAY_REMINDER);
        put("notify_me", NotificationType.NOTIFY_ME);
        put("friend_activity", NotificationType.FRIEND_ACTIVITY);
        put("stale_email", NotificationType.STALE_EMAIL);
    }
}
