package com.facebook.lite.widget;

final class ab implements CharSequence {
    final /* synthetic */ ac f2023a;
    private final CharSequence f2024b;

    public ab(ac acVar, CharSequence charSequence) {
        this.f2023a = acVar;
        this.f2024b = charSequence;
    }

    public final char charAt(int i) {
        return this.f2024b.charAt(i);
    }

    public final int length() {
        return this.f2024b.length();
    }

    public final CharSequence subSequence(int i, int i2) {
        return this.f2024b.subSequence(i, i2);
    }
}
