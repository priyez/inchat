package com.facebook.rti.p078b.p093d;

import android.util.Pair;

/* renamed from: com.facebook.rti.b.d.c */
public final class C0619c extends Pair {
    public static final C0619c f2530a;
    private final long f2531b;

    static {
        f2530a = new C0619c("", "", Long.MAX_VALUE);
    }

    public final String m3543a() {
        return (String) this.first;
    }

    public final String m3544b() {
        return (String) this.second;
    }

    public final long m3545c() {
        return this.f2531b;
    }

    public final boolean m3546d() {
        return f2530a.equals(this);
    }

    public final String toString() {
        return "MqttDeviceIdAndSecret{id=" + ((String) this.first) + "secret=" + ((String) this.second) + "mTimestamp=" + this.f2531b + '}';
    }

    public C0619c(String str, String str2, long j) {
        if (str == null) {
            str = "";
        }
        if (str2 == null) {
            str2 = "";
        }
        super(str, str2);
        this.f2531b = j;
    }
}
