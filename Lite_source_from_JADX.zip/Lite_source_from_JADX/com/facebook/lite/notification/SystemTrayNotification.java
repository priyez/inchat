package com.facebook.lite.notification;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.Log;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class SystemTrayNotification implements Parcelable {
    public static final Map f1678a;
    private static final String f1679b;
    private final String f1680c;
    private final boolean f1681d;
    private final String f1682e;
    private final String f1683f;
    private final Map f1684g;
    private final long f1685h;
    private final long f1686i;
    private final String f1687j;
    private final int f1688k;

    public enum NotificationType implements Parcelable {
        ADDED_PROFILE_INFO(999),
        BIRTHDAY_REMINDER(120008),
        CLOSE_FRIEND_ACTIVITY(999),
        COMMENT(120006),
        DEFAULT_PUSH_OF_JEWEL_NOTIF(999),
        EVENT(120005),
        FRIEND_ACTIVITY(999),
        FRIEND_CONFIRMATION(999),
        FRIEND_REQUEST(2),
        GROUP(120007),
        LIKE(120001),
        MENTION(999),
        MSG(120002),
        NOTIFY_ME(999),
        STALE_EMAIL(999),
        STORY_RESHARE(999),
        TAG(120004),
        WALL(120003);
        
        public static final Creator CREATOR;
        private int f1677s;

        static {
            CREATOR = new C0420i();
        }

        private NotificationType(int i) {
            this.f1677s = i;
        }

        public final int describeContents() {
            return 0;
        }

        public final int m2903a() {
            return this.f1677s;
        }

        public final void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(ordinal());
            parcel.writeInt(this.f1677s);
        }

        private void m2901a(int i) {
            this.f1677s = i;
        }
    }

    static {
        f1679b = SystemTrayNotification.class.getSimpleName();
        f1678a = new C0419h();
    }

    private SystemTrayNotification(String str, long j, String str2, int i, long j2, String str3, Map map, boolean z, String str4) {
        this.f1687j = str;
        this.f1685h = j;
        this.f1682e = str2;
        this.f1688k = i;
        this.f1686i = j2;
        this.f1680c = str3;
        this.f1684g = map;
        this.f1681d = z;
        this.f1683f = str4;
    }

    public static SystemTrayNotification m2904a(String str) {
        String str2;
        String str3;
        boolean z;
        String str4 = null;
        long j = 0;
        String str5 = null;
        int i = 0;
        long j2 = -1;
        String str6 = null;
        Map map = null;
        try {
            JSONObject jSONObject = new JSONObject(str);
            if (jSONObject.has("type")) {
                str4 = jSONObject.getString("type");
            }
            try {
                boolean z2;
                if (jSONObject.has("time")) {
                    j = jSONObject.getLong("time");
                }
                if (jSONObject.has("message")) {
                    str5 = jSONObject.getString("message");
                }
                if (jSONObject.has("unread_count")) {
                    i = jSONObject.getInt("unread_count");
                }
                if (jSONObject.has("target_uid") && jSONObject.getLong("target_uid") > 0) {
                    j2 = jSONObject.getLong("target_uid");
                }
                if (jSONObject.has("href")) {
                    str6 = jSONObject.getString("href");
                }
                if (jSONObject.has("params")) {
                    JSONObject jSONObject2 = jSONObject.getJSONObject("params");
                    if (jSONObject2 != null) {
                        Iterator keys = jSONObject2.keys();
                        if (keys != null) {
                            Map hashMap = new HashMap();
                            while (keys.hasNext()) {
                                try {
                                    str2 = (String) keys.next();
                                    hashMap.put(str2, jSONObject2.get(str2));
                                } catch (JSONException e) {
                                    map = hashMap;
                                    str2 = str4;
                                }
                            }
                            map = hashMap;
                        }
                    }
                }
                if (jSONObject.has("is_logged_out_push")) {
                    z2 = jSONObject.getBoolean("is_logged_out_push");
                } else {
                    z2 = false;
                }
                str3 = str4;
                z = z2;
            } catch (JSONException e2) {
                str2 = str4;
                Log.e(f1679b, "notification/decode notification json failed.");
                z = false;
                str3 = str2;
                return new SystemTrayNotification(str3, j, str5, i, j2, str6, map, z, str);
            }
        } catch (JSONException e3) {
            str2 = null;
            Log.e(f1679b, "notification/decode notification json failed.");
            z = false;
            str3 = str2;
            return new SystemTrayNotification(str3, j, str5, i, j2, str6, map, z, str);
        }
        return new SystemTrayNotification(str3, j, str5, i, j2, str6, map, z, str);
    }

    private static NotificationType m2905b(String str) {
        if (str != null) {
            int indexOf = str.indexOf(58);
            if (indexOf >= 0) {
                str = str.substring(0, indexOf);
            }
            NotificationType notificationType = (NotificationType) f1678a.get(str);
            if (notificationType != null) {
                return notificationType;
            }
        }
        return NotificationType.DEFAULT_PUSH_OF_JEWEL_NOTIF;
    }

    public int describeContents() {
        return 0;
    }

    public final String m2906a() {
        return this.f1682e;
    }

    public final NotificationType m2907b() {
        return m2905b(this.f1687j);
    }

    public final String m2908c() {
        return this.f1683f;
    }

    public final String m2909d() {
        return (String) this.f1684g.get("PushNotifID");
    }

    public final long m2910e() {
        return this.f1685h;
    }

    public final long m2911f() {
        return this.f1686i;
    }

    public final String m2912g() {
        return (String) this.f1684g.get("tid");
    }

    public final String m2913h() {
        return this.f1687j;
    }

    public final boolean m2914i() {
        return this.f1681d;
    }

    public final boolean m2915j() {
        return this.f1686i != -1;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f1687j);
        parcel.writeLong(this.f1685h);
        parcel.writeString(this.f1682e);
        parcel.writeInt(this.f1688k);
        parcel.writeLong(this.f1686i);
        parcel.writeString(this.f1680c);
        parcel.writeMap(this.f1684g);
        parcel.writeByte((byte) (this.f1681d ? 1 : 0));
    }
}
