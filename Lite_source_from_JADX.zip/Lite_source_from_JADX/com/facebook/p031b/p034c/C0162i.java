package com.facebook.p031b.p034c;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import com.facebook.p031b.C0148a;

/* renamed from: com.facebook.b.c.i */
public final class C0162i {
    private final Context f633a;

    public C0162i(Context context) {
        this.f633a = context;
    }

    public final boolean m1352a(String str) {
        PackageManager packageManager = this.f633a.getPackageManager();
        if (packageManager == null) {
            return false;
        }
        try {
            if (packageManager.checkPermission(str, this.f633a.getPackageName()) == 0) {
                return true;
            }
            return false;
        } catch (RuntimeException e) {
            return false;
        }
    }

    public final PackageInfo m1351a() {
        return m1353b(this.f633a.getPackageName());
    }

    public final PackageInfo m1353b(String str) {
        PackageInfo packageInfo = null;
        PackageManager packageManager = this.f633a.getPackageManager();
        if (packageManager != null) {
            try {
                packageInfo = packageManager.getPackageInfo(str, 0);
            } catch (NameNotFoundException e) {
                String str2 = C0148a.f621a;
                new StringBuilder("Failed to find PackageInfo for current App : ").append(this.f633a.getPackageName());
            } catch (RuntimeException e2) {
            }
        }
        return packageInfo;
    }
}
