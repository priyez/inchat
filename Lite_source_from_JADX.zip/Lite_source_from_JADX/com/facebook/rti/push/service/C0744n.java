package com.facebook.rti.push.service;

import com.facebook.rti.p046a.p074f.C0527a;
import com.facebook.rti.p078b.p096g.C0716y;

/* renamed from: com.facebook.rti.push.service.n */
final class C0744n implements C0716y {
    final /* synthetic */ FbnsService f3184a;

    C0744n(FbnsService fbnsService) {
        this.f3184a = fbnsService;
    }

    public final void m3972a() {
        C0527a.m3338b("FbnsService", "Publish successful", new Object[0]);
        this.f3184a.f3114u.m3957a(C0732b.REQUEST_SENT_SUCCESS, null);
    }

    public final void m3973b() {
        C0527a.m3338b("FbnsService", "Publish failed", new Object[0]);
        this.f3184a.f3114u.m3957a(C0732b.REQUEST_SENT_FAIL, null);
    }
}
