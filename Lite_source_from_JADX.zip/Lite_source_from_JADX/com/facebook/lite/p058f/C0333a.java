package com.facebook.lite.p058f;

import java.io.Serializable;

/* renamed from: com.facebook.lite.f.a */
public final class C0333a implements Serializable {
    private long f1302a;
    private long f1303b;
    private long f1304c;
    private long f1305d;

    public C0333a(C0333a c0333a) {
        this(c0333a.m2316c(), c0333a.m2314a(), c0333a.m2317d(), c0333a.m2315b());
    }

    public C0333a(long j, long j2, long j3, long j4) {
        this.f1302a = j2;
        this.f1303b = j4;
        this.f1304c = j;
        this.f1305d = j3;
    }

    private long m2314a() {
        return this.f1302a;
    }

    private long m2315b() {
        return this.f1303b;
    }

    private long m2316c() {
        return this.f1304c;
    }

    private long m2317d() {
        return this.f1305d;
    }

    public final void m2318a(C0333a c0333a) {
        this.f1302a += c0333a.f1302a;
        this.f1303b += c0333a.f1303b;
        this.f1304c += c0333a.f1304c;
        this.f1305d += c0333a.f1305d;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("D=w").append(C0339g.m2342a(m2316c())).append("+m").append(C0339g.m2342a(m2314a()));
        stringBuilder.append(" U=w").append(C0339g.m2342a(m2317d())).append("+m").append(C0339g.m2342a(m2315b()));
        return stringBuilder.toString();
    }
}
