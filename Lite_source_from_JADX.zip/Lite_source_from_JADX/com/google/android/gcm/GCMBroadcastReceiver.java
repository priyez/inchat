package com.google.android.gcm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class GCMBroadcastReceiver extends BroadcastReceiver {
    private static boolean f3202a;

    static {
        f3202a = false;
    }

    public final void onReceive(Context context, Intent intent) {
        new StringBuilder("onReceive: ").append(intent.getAction());
        if (!f3202a) {
            f3202a = true;
            String name = getClass().getName();
            if (!name.equals(GCMBroadcastReceiver.class.getName())) {
                C0751b.m3999a(name);
            }
        }
        C0259a.m1709a(context, intent, m3990a(context));
        setResult(-1, null, null);
    }

    private static String m3990a(Context context) {
        return m3991b(context);
    }

    private static String m3991b(Context context) {
        return context.getPackageName() + ".GCMIntentService";
    }
}
