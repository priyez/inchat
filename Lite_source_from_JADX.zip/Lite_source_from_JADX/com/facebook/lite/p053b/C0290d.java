package com.facebook.lite.p053b;

import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Looper;
import java.io.IOException;

/* renamed from: com.facebook.lite.b.d */
public class C0290d {
    private static final String f1169a;

    static {
        f1169a = C0290d.class.getName();
    }

    private C0290d() {
    }

    public static C0289c m1939a(Context context) {
        C0289c c0289c;
        if (Looper.myLooper() == Looper.getMainLooper()) {
            throw new IllegalStateException("Cannot be called from the main thread.");
        }
        ServiceConnection c0287a = new C0287a();
        Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
        intent.setPackage("com.google.android.gms");
        if (context.getApplicationContext().bindService(intent, c0287a, 1)) {
            try {
                C0288b c0288b = new C0288b(c0287a.m1934a());
                c0289c = new C0289c(c0288b.m1935a(), c0288b.m1936b());
                return c0289c;
            } finally {
                c0289c = context.getApplicationContext();
                c0289c.unbindService(c0287a);
            }
        } else {
            throw new IOException("Google Play connection failed.");
        }
    }
}
