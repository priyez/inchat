package com.facebook.rti.p046a.p074f;

import android.text.TextUtils;
import android.util.Log;

/* renamed from: com.facebook.rti.a.f.a */
public final class C0527a {
    private static volatile int f2213a;
    private static String f2214b;

    static {
        f2213a = 5;
    }

    public static void m3334a() {
        f2213a = 2;
    }

    public static void m3335a(String str) {
        f2214b = str;
    }

    public static void m3336a(String str, String str2, Object... objArr) {
        if (f2213a <= 2) {
            if (!TextUtils.isEmpty(f2214b)) {
                new StringBuilder(f2214b).append(":").append(str);
            }
            String.format(null, str2, objArr);
        }
    }

    public static void m3338b(String str, String str2, Object... objArr) {
        if (f2213a <= 3) {
            if (!TextUtils.isEmpty(f2214b)) {
                new StringBuilder(f2214b).append(":").append(str);
            }
            String.format(null, str2, objArr);
        }
    }

    public static void m3340c(String str, String str2, Object... objArr) {
        if (f2213a <= 3) {
            if (!TextUtils.isEmpty(f2214b)) {
                new StringBuilder(f2214b).append(":").append(str);
            }
            String.format(null, str2, objArr);
        }
    }

    public static void m3342d(String str, String str2, Object... objArr) {
        if (f2213a <= 4) {
            if (!TextUtils.isEmpty(f2214b)) {
                str = new StringBuilder(f2214b).append(":").append(str).toString();
            }
            Log.i(str, String.format(null, str2, objArr));
        }
    }

    public static void m3343e(String str, String str2, Object... objArr) {
        if (f2213a <= 5) {
            if (!TextUtils.isEmpty(f2214b)) {
                str = new StringBuilder(f2214b).append(":").append(str).toString();
            }
            Log.w(str, String.format(null, str2, objArr));
        }
    }

    public static void m3337a(String str, Throwable th, String str2, Object... objArr) {
        if (f2213a <= 5) {
            if (!TextUtils.isEmpty(f2214b)) {
                str = new StringBuilder(f2214b).append(":").append(str).toString();
            }
            Log.w(str, String.format(null, str2, objArr), th);
        }
    }

    public static void m3344f(String str, String str2, Object... objArr) {
        if (f2213a <= 6) {
            if (!TextUtils.isEmpty(f2214b)) {
                str = new StringBuilder(f2214b).append(":").append(str).toString();
            }
            Log.e(str, String.format(null, str2, objArr));
        }
    }

    public static void m3339b(String str, Throwable th, String str2, Object... objArr) {
        if (f2213a <= 6) {
            if (!TextUtils.isEmpty(f2214b)) {
                str = new StringBuilder(f2214b).append(":").append(str).toString();
            }
            Log.e(str, String.format(null, str2, objArr), th);
        }
    }

    public static void m3341c(String str, Throwable th, String str2, Object... objArr) {
        if (!TextUtils.isEmpty(f2214b)) {
            str = new StringBuilder(f2214b).append(":").append(str).toString();
        }
        Log.wtf(str, String.format(null, str2, objArr), th);
    }
}
