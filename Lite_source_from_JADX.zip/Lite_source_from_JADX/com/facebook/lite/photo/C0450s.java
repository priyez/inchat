package com.facebook.lite.photo;

import android.graphics.Bitmap;
import android.os.Build.VERSION;
import com.facebook.lite.p049a.C0283l;

/* renamed from: com.facebook.lite.photo.s */
final class C0450s extends C0283l {
    final /* synthetic */ C0453w f1793a;

    C0450s(C0453w c0453w, int i) {
        this.f1793a = c0453w;
        super(i);
    }

    protected final /* synthetic */ int m3077d(Object obj) {
        return C0450s.m3076a((Bitmap) obj);
    }

    private static int m3076a(Bitmap bitmap) {
        if (VERSION.SDK_INT >= 12) {
            return bitmap.getByteCount();
        }
        return bitmap.getRowBytes() * bitmap.getHeight();
    }
}
