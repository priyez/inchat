package com.facebook.p031b;

/* renamed from: com.facebook.b.g */
public interface C0176g {
    RuntimeException m1384a();
}
