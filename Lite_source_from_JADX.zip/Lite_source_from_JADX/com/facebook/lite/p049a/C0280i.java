package com.facebook.lite.p049a;

import android.content.Context;
import android.util.Log;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.p049a.p050a.C0261a;
import com.facebook.lite.p049a.p052c.C0271e;
import com.facebook.lite.p049a.p052c.C0273g;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p053b.C0301o;
import com.facebook.lite.p053b.C0302p;
import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p018f.C0047a;
import com.p008a.p009a.p010a.p018f.C0048b;
import com.p008a.p009a.p010a.p022l.C0078g;
import com.p026b.p027a.C0134f;
import com.p026b.p027a.C0135g;
import com.p026b.p027a.C0136h;
import com.p026b.p027a.C0139k;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;

/* renamed from: com.facebook.lite.a.i */
public class C0280i implements C0078g {
    private static final String f1070a;
    private static C0280i f1071b;
    private final String f1072c;
    private final Context f1073d;
    private boolean f1074e;
    private final Map f1075f;
    private final C0022b f1076g;
    private final C0274c f1077h;
    private final PriorityBlockingQueue f1078i;

    static {
        f1070a = C0280i.class.getSimpleName();
    }

    private C0280i(Context context, String str, C0022b c0022b) {
        this.f1078i = new PriorityBlockingQueue();
        this.f1076g = c0022b;
        this.f1072c = str;
        this.f1073d = context;
        this.f1075f = new ConcurrentHashMap();
        this.f1077h = new C0274c(this, TimeUnit.SECONDS, this.f1078i, new C0276e(this));
        m1888f();
        m1876a(new C0047a((byte) 0, false, true, 10485760, new byte[0]), str);
    }

    public static C0280i m1872a(Context context, C0022b c0022b) {
        if (f1071b == null) {
            String a = C0301o.m2171a(context);
            if (a != null) {
                synchronized (C0280i.class) {
                    if (f1071b == null) {
                        f1071b = new C0280i(context, a, c0022b);
                    }
                }
            }
        }
        return f1071b;
    }

    private static String m1887e() {
        return "diskcache/";
    }

    public static String m1873a(byte b) {
        return String.format("diskcache/%d/", new Object[]{Byte.valueOf(b)});
    }

    public static int m1871a(Object obj) {
        if (obj instanceof C0266b) {
            return 2;
        }
        if (obj instanceof C0277f) {
            return 1;
        }
        if (obj instanceof C0278g) {
            return 0;
        }
        if (obj instanceof C0279h) {
            return -1;
        }
        if (obj instanceof C0275d) {
            return -2;
        }
        return Integer.MIN_VALUE;
    }

    public static boolean m1881b(byte b) {
        if (b == -1 || b < null) {
            return false;
        }
        return true;
    }

    private void m1884c(byte b) {
        C0261a c0261a = (C0261a) this.f1075f.get(Byte.valueOf(b));
        C0135g d = c0261a.m1806d();
        long b2 = C0301o.m2170a(this.f1072c) < 1 ? d.m1292b() : (long) c0261a.m1808f();
        if (b2 != d.m1288a()) {
            new StringBuilder().append(C0280i.m1873a(b)).append("set max size to:").append(b2);
            d.m1290a(b2);
        }
    }

    private void m1875a(C0047a c0047a) {
        m1876a(c0047a, this.f1072c);
    }

    public final void m1890a(int i, byte b) {
        C0261a d = m1885d(b);
        if (d != null) {
            this.f1077h.execute(new C0275d(this, i, System.currentTimeMillis(), d));
        }
    }

    public final long m1889a() {
        return C0301o.m2170a(this.f1072c);
    }

    public final void m1895b() {
        this.f1077h.m1866b();
    }

    public final void m1897c() {
        this.f1077h.m1865a();
    }

    public final boolean m1896b(int i, byte b) {
        C0261a d = m1885d(b);
        try {
            if (d.m1806d().m1293b(Integer.toString(i)) != null) {
                return true;
            }
            return false;
        } catch (Throwable e) {
            this.f1076g.m124a((short) 162, null, e);
            Log.e(f1070a, C0280i.m1873a(d.m1804b()) + " can't get snapshot:" + i);
            return false;
        }
    }

    public final boolean m1898c(int i, byte b) {
        return m1894a(i, 0, false, b);
    }

    public final boolean m1894a(int i, int i2, boolean z, byte b) {
        C0261a d = m1885d(b);
        if (d == null) {
            return false;
        }
        d.m1811i();
        if (d.m1806d() == null) {
            new StringBuilder().append(C0280i.m1873a(b)).append("not initiated/can't request image");
            return false;
        } else if (!C0301o.m2173a()) {
            new StringBuilder().append(C0280i.m1873a(b)).append("ext storage not mounted/can't request image");
            return false;
        } else if (m1879a(d, i, i2, z, false, (byte) 0)) {
            return true;
        } else {
            if (this.f1074e) {
                for (byte valueOf : d.m1803a()) {
                    C0261a c0261a = (C0261a) this.f1075f.get(Byte.valueOf(valueOf));
                    if (c0261a != null && m1879a(c0261a, i, i2, z, true, b)) {
                        return true;
                    }
                }
            }
            return false;
        }
    }

    public final void m1891a(int i, byte[] bArr, byte b) {
        C0261a d = m1885d(b);
        if (d == null) {
            new StringBuilder().append(C0280i.m1873a(b)).append("setFile, default image cache does not exist");
        } else if (d.m1806d() == null) {
            new StringBuilder().append(C0280i.m1873a(b)).append("setFile, diskLruCache does not exist");
        } else {
            m1884c(d.m1804b());
            this.f1077h.execute(new C0278g(this, i, System.currentTimeMillis(), bArr, d));
        }
    }

    public final boolean m1893a(int i, byte b, byte b2) {
        if (!this.f1074e || b == b2) {
            return false;
        }
        C0261a c0261a = (C0261a) this.f1075f.get(Byte.valueOf(b));
        C0261a c0261a2 = (C0261a) this.f1075f.get(Byte.valueOf(b2));
        if (c0261a == null || c0261a2 == null) {
            return false;
        }
        try {
            if (c0261a.m1806d().m1293b(Integer.toString(i)) == null) {
                return false;
            }
            this.f1077h.execute(new C0279h(this, i, c0261a, c0261a2, System.currentTimeMillis()));
            return true;
        } catch (Throwable e) {
            this.f1076g.m124a((short) 162, null, e);
            Log.e(f1070a, C0280i.m1873a(c0261a.m1804b()) + " can't get snapshot:" + i);
            return false;
        }
    }

    public final void m1899w() {
        int i = 0;
        Context applicationContext = ClientApplication.m1690b().getApplicationContext();
        this.f1074e = C0300n.m2157o(applicationContext);
        CharSequence p = C0300n.m2158p(applicationContext);
        new StringBuilder().append(C0280i.m1887e()).append("loaded attribute map from SP: ").append(p);
        new StringBuilder().append(C0280i.m1887e()).append("genericCache enabled: ").append(this.f1074e);
        if (m1885d((byte) 0) != null && !C0302p.m2175a(p)) {
            synchronized (f1071b) {
                C0048b a = C0271e.m1854a(p);
                if (a == null) {
                    return;
                }
                C0047a[] a2 = a.m329a();
                int length = a2.length;
                while (i < length) {
                    m1875a(a2[i]);
                    i++;
                }
            }
        }
    }

    public final void m1892a(Context context) {
        try {
            String a = C0273g.m1861a(this.f1075f, C0300n.m2159q(context));
            for (Entry value : this.f1075f.entrySet()) {
                C0261a c0261a = (C0261a) value.getValue();
                c0261a.m1812j();
                c0261a.m1813k();
                c0261a.m1814l();
            }
            C0300n.m2145i(context, a);
        } catch (JSONException e) {
            Log.e(f1070a, "diskcache/json parsing error, cannot save to shared preferences for reporting ");
        }
    }

    private void m1876a(C0047a c0047a, String str) {
        if (this.f1075f.get(Byte.valueOf(c0047a.m325b())) == null && (c0047a.m325b() == null || this.f1074e)) {
            this.f1077h.execute(new C0266b(this, c0047a, str, System.currentTimeMillis()));
        } else if (this.f1075f.get(Byte.valueOf(c0047a.m325b())) != null) {
            m1880b(c0047a);
        }
    }

    private boolean m1879a(C0261a c0261a, int i, int i2, boolean z, boolean z2, byte b) {
        try {
            C0134f b2 = c0261a.m1806d().m1293b(Integer.toString(i));
            if (b2 != null) {
                synchronized (this.f1078i) {
                    this.f1077h.execute(new C0277f(this, i, System.currentTimeMillis(), b2, c0261a, i2, z, z2, b));
                }
                return true;
            }
        } catch (Throwable e) {
            this.f1076g.m124a((short) 162, null, e);
            Log.e(f1070a, C0280i.m1873a(c0261a.m1804b()) + " can't get snapshot:" + i);
        }
        return false;
    }

    private C0261a m1885d(byte b) {
        C0261a c0261a = this.f1074e ? (C0261a) this.f1075f.get(Byte.valueOf(b)) : (C0261a) this.f1075f.get(Byte.valueOf((byte) 0));
        if (c0261a == null) {
            return (C0261a) this.f1075f.get(Byte.valueOf((byte) 0));
        }
        return c0261a;
    }

    private void m1888f() {
        String m = C0300n.m2152m(ClientApplication.m1690b().getApplicationContext());
        if (m != null) {
            try {
                C0139k.m1301a(new File(m));
                C0300n.m2138g(ClientApplication.m1690b().getApplicationContext(), null);
            } catch (IOException e) {
                this.f1076g.m126a((short) 2, (short) 291, e.getMessage());
                Log.e(f1070a, "diskcache/delete file failed after restart/" + m);
            }
        }
    }

    private void m1878a(String str, C0136h c0136h) {
        C0300n.m2138g(this.f1073d, str);
        this.f1076g.m126a((short) 2, (short) 290, c0136h.m1295a());
        Log.e(f1070a, "diskcache/cannot delete file/" + c0136h.m1295a());
    }

    private void m1880b(C0047a c0047a) {
        C0261a d = m1885d(c0047a.m325b());
        if (d != null) {
            d.m1801a(c0047a);
        }
    }
}
