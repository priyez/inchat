package com.facebook.p031b.p034c;

import java.io.FilterWriter;
import java.io.Writer;

/* renamed from: com.facebook.b.c.r */
final class C0171r extends FilterWriter {
    private static final byte[] f646a;
    private char f647b;

    static {
        f646a = new byte[]{(byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70, (byte) 71, (byte) 72, (byte) 73, (byte) 74, (byte) 75, (byte) 76, (byte) 77, (byte) 78, (byte) 79, (byte) 80, (byte) 81, (byte) 82, (byte) 83, (byte) 84, (byte) 85, (byte) 86, (byte) 87, (byte) 88, (byte) 89, (byte) 90};
    }

    public C0171r(Writer writer) {
        super(writer);
        this.f647b = '\u0000';
    }

    private void m1364a(byte b) {
        this.out.write(37);
        this.out.write(f646a[(b >> 4) & 15]);
        this.out.write(f646a[b & 15]);
    }

    private void m1367b(byte b) {
        if ((b >= 97 && b <= 122) || ((b >= 65 && b <= 90) || ((b >= 48 && b <= 57) || b == 46 || b == 45 || b == 42 || b == 95))) {
            this.out.write(b);
        } else if (b == 32) {
            this.out.write(43);
        } else {
            m1364a(b);
        }
    }

    private static int m1362a(char c, char c2) {
        return ((c << 10) + c2) - 56613888;
    }

    private static boolean m1365a(char c) {
        return (c & 1024) == 0;
    }

    private static boolean m1368b(char c) {
        return (c & 1024) != 0;
    }

    private static boolean m1369c(char c) {
        return (63488 & c) == 55296;
    }

    private void m1363a() {
        if (this.f647b != '\u0000') {
            m1364a((byte) 63);
            m1366b();
        }
    }

    private void m1366b() {
        this.f647b = '\u0000';
    }

    public final void close() {
        flush();
    }

    public final void flush() {
        m1363a();
        super.flush();
    }

    public final void write(String str, int i, int i2) {
        synchronized (this.lock) {
            for (int i3 = i; i3 < i + i2; i3++) {
                write(str.charAt(i3));
            }
        }
    }

    public final void write(char[] cArr, int i, int i2) {
        synchronized (this.lock) {
            for (int i3 = i; i3 < i + i2; i3++) {
                write(cArr[i3]);
            }
        }
    }

    public final void write(int i) {
        char c = (char) i;
        if (this.f647b != '\u0000') {
            if (C0171r.m1369c(c) && C0171r.m1368b(c)) {
                int a = C0171r.m1362a(this.f647b, c);
                m1364a((byte) ((a >> 18) | 240));
                m1364a((byte) (((a >> 12) & 63) | 128));
                m1364a((byte) (((a >> 6) & 63) | 128));
                m1364a((byte) ((a & 63) | 128));
                m1366b();
                return;
            }
            m1364a((byte) 63);
            m1366b();
            write(c);
        } else if ((c & 65535) < 128) {
            m1367b((byte) c);
        } else if ((c & 65535) < 2048) {
            m1364a((byte) ((c >> 6) | 192));
            m1364a((byte) ((c & 63) | 128));
        } else if (!C0171r.m1369c(c)) {
            m1364a((byte) ((c >> 12) | 224));
            m1364a((byte) (((c >> 6) & 63) | 128));
            m1364a((byte) ((c & 63) | 128));
        } else if (C0171r.m1365a(c)) {
            this.f647b = c;
        } else {
            m1364a((byte) 63);
        }
    }
}
