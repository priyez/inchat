package com.facebook.lite.photo;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore.Images.Media;
import android.provider.MediaStore.Images.Thumbnails;
import android.util.Log;
import android.util.SparseArray;
import com.facebook.lite.p049a.C0283l;
import com.facebook.lite.p053b.C0294h;
import java.util.WeakHashMap;

/* renamed from: com.facebook.lite.photo.w */
public class C0453w extends HandlerThread {
    private static final String f1799f;
    private static C0283l f1800g;
    ContentResolver f1801a;
    Handler f1802b;
    C0433v f1803c;
    Handler f1804d;
    WeakHashMap f1805e;
    private final Context f1806h;
    private final SparseArray f1807i;
    private final SparseArray f1808j;

    static {
        f1799f = C0453w.class.getSimpleName();
        f1800g = null;
    }

    public C0453w(Handler handler, ContentResolver contentResolver, Context context) {
        super(f1799f);
        this.f1805e = new WeakHashMap();
        this.f1807i = new SparseArray();
        this.f1808j = new SparseArray();
        this.f1804d = handler;
        this.f1801a = contentResolver;
        this.f1806h = context;
        if (f1800g == null) {
            long j = C0294h.m1980j(context);
            f1800g = new C0450s(this, j / 10 > 2147483647L ? Integer.MAX_VALUE : (int) (j / 10));
        }
    }

    public final void m3082a() {
        if (this.f1802b != null) {
            this.f1802b.removeMessages(0);
        }
        this.f1805e.clear();
    }

    public final void m3086b() {
        for (int i = 0; i < this.f1808j.size(); i++) {
            f1800g.m1920b(Integer.valueOf(this.f1808j.keyAt(i)));
        }
        this.f1808j.clear();
        this.f1807i.clear();
    }

    public final Bitmap m3081a(Object obj, int i) {
        if (this.f1807i.get(i) != null) {
            return null;
        }
        Bitmap bitmap = (Bitmap) f1800g.m1918a(Integer.valueOf(i));
        if (bitmap == null || bitmap.isRecycled()) {
            if (bitmap != null && bitmap.isRecycled()) {
                f1800g.m1920b(bitmap);
            }
            return null;
        }
        this.f1805e.put(obj, Integer.valueOf(i));
        return bitmap;
    }

    public final void m3085a(Object obj, Integer num) {
        Log.i(f1799f, "thumbnail/got an origId:" + num);
        if (obj != null) {
            this.f1805e.put(obj, num);
            if (this.f1802b != null) {
                this.f1802b.obtainMessage(0, obj).sendToTarget();
            }
        }
    }

    public final void m3083a(int i, int i2) {
        if (i2 == 0) {
            this.f1808j.remove(i);
        } else {
            this.f1808j.put(i, Integer.valueOf(i2));
        }
        this.f1807i.put(i, Integer.valueOf(i2));
    }

    public final void m3084a(C0433v c0433v) {
        this.f1803c = c0433v;
    }

    protected void onLooperPrepared() {
        this.f1802b = new C0451t(this);
        if (!this.f1805e.isEmpty()) {
            for (Object obtainMessage : this.f1805e.keySet()) {
                this.f1802b.obtainMessage(0, obtainMessage).sendToTarget();
            }
            Log.i(f1799f, "thumbnail/handle request before Handler initialized");
        }
    }

    private void m3079a(Object obj) {
        if (obj != null) {
            Integer num = (Integer) this.f1805e.get(obj);
            if (num != null && num.intValue() >= 0) {
                Integer num2 = (Integer) this.f1808j.get(num.intValue());
                Bitmap a = C0444m.m3043a(C0444m.m3048a(this.f1806h, Uri.withAppendedPath(Media.EXTERNAL_CONTENT_URI, Integer.toString(num.intValue()))), Thumbnails.getThumbnail(this.f1801a, (long) num.intValue(), 1, null), null, num2 == null ? 0 : num2.intValue());
                this.f1807i.remove(num.intValue());
                if (!(a == null || a.isRecycled())) {
                    f1800g.m1919a(num, a);
                }
                this.f1804d.post(new C0452u(this, obj, num, a));
            }
        }
    }
}
