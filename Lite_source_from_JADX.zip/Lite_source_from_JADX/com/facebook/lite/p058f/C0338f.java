package com.facebook.lite.p058f;

/* renamed from: com.facebook.lite.f.f */
public enum C0338f {
    TOTAL,
    VIDEO
}
