package com.facebook.rti.p046a.p069a;

import android.content.Context;
import java.io.File;

/* renamed from: com.facebook.rti.a.a.h */
final class C0504h {
    private final File f2149a;

    public C0504h(Context context) {
        this.f2149a = new File(context.getFilesDir(), "mqtt_analytics");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void m3307a(com.facebook.rti.p046a.p069a.C0503g r8) {
        /*
        r7 = this;
        r6 = 1;
        r5 = 0;
        r0 = r7.f2149a;
        r0 = r0.exists();
        if (r0 != 0) goto L_0x001b;
    L_0x000a:
        r0 = r7.f2149a;
        r0 = r0.mkdir();
        if (r0 != 0) goto L_0x001b;
    L_0x0012:
        r0 = "AnalyticsStorage";
        r1 = "Unable to open analytics storage.";
        r2 = new java.lang.Object[r5];
        com.facebook.rti.p046a.p074f.C0527a.m3344f(r0, r1, r2);
    L_0x001b:
        r1 = new java.io.File;
        r0 = r7.f2149a;
        r2 = "%s_%d.batch";
        r3 = 2;
        r3 = new java.lang.Object[r3];
        r4 = r8.m3303c();
        r4 = r4.toString();
        r3[r5] = r4;
        r4 = r8.m3305d();
        r4 = java.lang.Integer.valueOf(r4);
        r3[r6] = r4;
        r4 = 0;
        r2 = java.lang.String.format(r4, r2, r3);
        r1.<init>(r0, r2);
        r0 = r1.exists();
        if (r0 == 0) goto L_0x0062;
    L_0x0046:
        r0 = "AnalyticsStorage";
        r2 = "Duplicate file %s";
        r3 = new java.lang.Object[r6];
        r3[r5] = r1;
        com.facebook.rti.p046a.p074f.C0527a.m3338b(r0, r2, r3);
        r0 = r1.delete();
        if (r0 != 0) goto L_0x0062;
    L_0x0057:
        r0 = "AnalyticsStorage";
        r2 = "File %s was not deleted";
        r3 = new java.lang.Object[r6];
        r3[r5] = r1;
        com.facebook.rti.p046a.p074f.C0527a.m3343e(r0, r2, r3);
    L_0x0062:
        r2 = java.lang.System.currentTimeMillis();
        r8.m3297a(r2);
        r2 = new java.io.FileOutputStream;	 Catch:{ FileNotFoundException -> 0x0080 }
        r2.<init>(r1);	 Catch:{ FileNotFoundException -> 0x0080 }
        r1 = new java.io.OutputStreamWriter;	 Catch:{ UnsupportedEncodingException -> 0x008d }
        r0 = "UTF8";
        r1.<init>(r2, r0);	 Catch:{ UnsupportedEncodingException -> 0x008d }
        r0 = r8.toString();	 Catch:{ IOException -> 0x00b1 }
        r1.write(r0);	 Catch:{ IOException -> 0x00b1 }
        r1.close();	 Catch:{ IOException -> 0x00a6 }
    L_0x007f:
        return;
    L_0x0080:
        r0 = move-exception;
        r2 = "AnalyticsStorage";
        r3 = "Batch file creation failed %s";
        r4 = new java.lang.Object[r6];
        r4[r5] = r1;
        com.facebook.rti.p046a.p074f.C0527a.m3337a(r2, r0, r3, r4);
        goto L_0x007f;
    L_0x008d:
        r0 = move-exception;
        r1 = "AnalyticsStorage";
        r3 = "UTF8 encoding is not supported";
        r4 = new java.lang.Object[r5];
        com.facebook.rti.p046a.p074f.C0527a.m3337a(r1, r0, r3, r4);
        r2.close();	 Catch:{ IOException -> 0x009b }
        goto L_0x007f;
    L_0x009b:
        r0 = move-exception;
        r1 = "AnalyticsStorage";
        r2 = "failed to close output stream";
        r3 = new java.lang.Object[r5];
        com.facebook.rti.p046a.p074f.C0527a.m3337a(r1, r0, r2, r3);
        goto L_0x007f;
    L_0x00a6:
        r0 = move-exception;
        r1 = "AnalyticsStorage";
        r2 = "failed to close writer";
        r3 = new java.lang.Object[r5];
        com.facebook.rti.p046a.p074f.C0527a.m3337a(r1, r0, r2, r3);
        goto L_0x007f;
    L_0x00b1:
        r0 = move-exception;
        r2 = "AnalyticsStorage";
        r3 = "failed to write session to file";
        r4 = 0;
        r4 = new java.lang.Object[r4];	 Catch:{ all -> 0x00cb }
        com.facebook.rti.p046a.p074f.C0527a.m3337a(r2, r0, r3, r4);	 Catch:{ all -> 0x00cb }
        r1.close();	 Catch:{ IOException -> 0x00c0 }
        goto L_0x007f;
    L_0x00c0:
        r0 = move-exception;
        r1 = "AnalyticsStorage";
        r2 = "failed to close writer";
        r3 = new java.lang.Object[r5];
        com.facebook.rti.p046a.p074f.C0527a.m3337a(r1, r0, r2, r3);
        goto L_0x007f;
    L_0x00cb:
        r0 = move-exception;
        r1.close();	 Catch:{ IOException -> 0x00d0 }
    L_0x00cf:
        throw r0;
    L_0x00d0:
        r1 = move-exception;
        r2 = "AnalyticsStorage";
        r3 = "failed to close writer";
        r4 = new java.lang.Object[r5];
        com.facebook.rti.p046a.p074f.C0527a.m3337a(r2, r1, r3, r4);
        goto L_0x00cf;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.rti.a.a.h.a(com.facebook.rti.a.a.g):void");
    }
}
