package com.facebook.lite.webview;

import android.content.Intent;
import android.net.Uri;
import android.webkit.WebBackForwardList;
import android.webkit.WebHistoryItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import com.facebook.lite.ClientApplication;

/* renamed from: com.facebook.lite.webview.b */
final class C0467b extends WebViewClient {
    final /* synthetic */ FbWebView f1854a;

    private C0467b(FbWebView fbWebView) {
        this.f1854a = fbWebView;
    }

    public final void onPageFinished(WebView webView, String str) {
        if ("about:blank".equalsIgnoreCase(str)) {
            this.f1854a.clearHistory();
            this.f1854a.clearCache(true);
        } else if (this.f1854a.canGoBackOrForward(-1) && !this.f1854a.canGoBackOrForward(-2)) {
            WebBackForwardList copyBackForwardList = this.f1854a.copyBackForwardList();
            if (copyBackForwardList != null && copyBackForwardList.getSize() > 0) {
                WebHistoryItem itemAtIndex = copyBackForwardList.getItemAtIndex(0);
                if (itemAtIndex != null && "about:blank".equalsIgnoreCase(itemAtIndex.getUrl())) {
                    this.f1854a.clearHistory();
                }
            }
        }
    }

    public final void onReceivedError(WebView webView, int i, String str, String str2) {
        Toast.makeText(this.f1854a.getContext(), "Error: " + str, 0).show();
    }

    public final boolean shouldOverrideUrlLoading(WebView webView, String str) {
        Uri parse = Uri.parse(str);
        String scheme = parse.getScheme();
        if ("fblite".equalsIgnoreCase(scheme)) {
            C0467b.m3136a("d", str);
            return true;
        } else if ("fb".equalsIgnoreCase(scheme) && this.f1854a.f1850c) {
            C0467b.m3136a("fb", str);
            return true;
        } else {
            String host = parse.getHost();
            C0468c[] values = C0468c.values();
            int length = values.length;
            int i = 0;
            while (i < length) {
                if (!values[i].m3137a(host)) {
                    i++;
                } else if (!this.f1854a.f1849b) {
                    return false;
                } else {
                    C0467b.m3136a("facebook", str);
                    return true;
                }
            }
            if (this.f1854a.f1851d) {
                C0467b.m3136a("generic", str);
                return true;
            }
            this.f1854a.getContext().startActivity(new Intent("android.intent.action.VIEW", parse).addFlags(268435456));
            return true;
        }
    }

    private static void m3136a(String str, String str2) {
        ClientApplication.m1691c().m2387S().m2639N().m180a(new String[]{str, str2});
    }
}
