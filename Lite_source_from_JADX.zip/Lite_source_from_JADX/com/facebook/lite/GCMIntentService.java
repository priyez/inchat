package com.facebook.lite;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.facebook.lite.deviceid.C0317a;
import com.facebook.lite.notification.C0415d;
import com.facebook.lite.notification.C0422k;
import com.facebook.lite.p053b.C0300n;
import com.google.android.gcm.C0259a;
import com.google.android.gcm.C0751b;

public class GCMIntentService extends C0259a {
    private static final String f961a;

    static {
        f961a = GCMIntentService.class.getSimpleName();
    }

    public GCMIntentService() {
        super("15057814354");
    }

    public final void m1722a(String str) {
        Log.i(f961a, "push/received error: " + str);
        C0415d.m2918a().m104a(0, 0, "GCM:" + str);
    }

    protected final void m1719a() {
        Log.i(f961a, "push/received deleted messages notification.");
    }

    protected final void m1721a(Context context, Intent intent) {
        Log.i(f961a, "push/received message.");
        C0300n.m2141h(context, System.currentTimeMillis());
        C0422k.m2934a(context, intent.getStringExtra("notification"));
    }

    protected final boolean m1723a(Context context, String str) {
        Log.i(f961a, "push/received recoverable error: " + str);
        return super.m1717a(context, str);
    }

    protected final void m1724b(Context context, String str) {
        Log.i(f961a, "push/device registered: token = " + str);
        C0415d.m2923a(context, str, C0317a.m2260a(context).m2262a().f786a, "GCM");
    }

    protected final void m1720a(Context context) {
        if (C0751b.m4009j(context)) {
            C0415d.m2924b(context);
            Log.i(f961a, "push/device unregistered.");
            return;
        }
        Log.i(f961a, "push/ignoring unregister callback.");
    }
}
