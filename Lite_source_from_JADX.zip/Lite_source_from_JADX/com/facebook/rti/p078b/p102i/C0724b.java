package com.facebook.rti.p078b.p102i;

import android.content.Intent;
import com.facebook.rti.p046a.p047b.C0516d;
import com.facebook.rti.p046a.p074f.C0527a;
import com.facebook.rti.p046a.p076h.C0532b;
import com.facebook.rti.p078b.p080b.p084d.C0589k;

/* renamed from: com.facebook.rti.b.i.b */
public class C0724b {
    public static final String f3101a;
    public static final String f3102b;
    public static final String f3103c;
    private final C0516d f3104d;
    private final C0589k f3105e;
    private final C0532b f3106f;
    private volatile long f3107g;

    static {
        f3101a = C0724b.class.getCanonicalName() + ".ACTIVITY_MAYBE_CHANGED";
        f3102b = C0724b.class.getCanonicalName() + ".USER_ENTERED_DEVICE";
        f3103c = C0724b.class.getCanonicalName() + ".USER_LEFT_DEVICE";
    }

    public C0724b(C0516d c0516d, C0589k c0589k, C0532b c0532b) {
        this.f3104d = c0516d;
        this.f3105e = c0589k;
        this.f3106f = c0532b;
        this.f3105e.m3493a(new C0723a(this));
    }

    public final boolean m3924a() {
        return this.f3105e.m3494a();
    }

    static /* synthetic */ void m3922a(C0724b c0724b) {
        C0527a.m3336a("DeviceUserInteractionManager", "onScreenOn", new Object[0]);
        c0724b.f3104d.m3315a(new Intent(f3102b));
        c0724b.f3104d.m3315a(new Intent(f3101a));
    }

    static /* synthetic */ void m3923b(C0724b c0724b) {
        C0527a.m3336a("DeviceUserInteractionManager", "onScreenOff", new Object[0]);
        c0724b.f3107g = c0724b.f3106f.m3351a();
        c0724b.f3104d.m3315a(new Intent(f3103c));
        c0724b.f3104d.m3315a(new Intent(f3101a));
    }
}
