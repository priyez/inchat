package com.facebook.lite.widget;

import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;

/* renamed from: com.facebook.lite.widget.n */
final class C0483n extends SimpleOnGestureListener {
    final /* synthetic */ FbVideoView f2099a;

    C0483n(FbVideoView fbVideoView) {
        this.f2099a = fbVideoView;
    }

    public final boolean onSingleTapUp(MotionEvent motionEvent) {
        if (this.f2099a.f1898b.isShowing()) {
            this.f2099a.f1898b.hide();
        } else {
            this.f2099a.f1898b.show();
        }
        return super.onSingleTapUp(motionEvent);
    }
}
