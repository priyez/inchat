package com.facebook.lite;

import android.database.sqlite.SQLiteDiskIOException;
import com.facebook.p031b.C0184o;
import com.facebook.p038e.C0254o;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.Thread.UncaughtExceptionHandler;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.facebook.lite.i */
final class C0352i implements UncaughtExceptionHandler {
    private final UncaughtExceptionHandler f1396a;
    private final C0184o f1397b;

    public C0352i(C0184o c0184o) {
        this.f1396a = Thread.getDefaultUncaughtExceptionHandler();
        this.f1397b = c0184o;
    }

    public final void uncaughtException(Thread thread, Throwable th) {
        Map hashMap = new HashMap();
        hashMap.put(IllegalArgumentException.class.getSimpleName(), "android.os.StatFs.native_setup");
        hashMap.put(NoSuchFieldError.class.getSimpleName(), "android.database.sqlite.SQLiteDatabase.openDatabase");
        hashMap.put(SQLiteDiskIOException.class.getSimpleName(), "android.database.sqlite.SQLiteDatabase.native_setLocale");
        Writer stringWriter = new StringWriter();
        th.printStackTrace(new PrintWriter(stringWriter));
        String stringWriter2 = stringWriter.toString();
        String simpleName = th.getClass().getSimpleName();
        if (th instanceof OutOfMemoryError) {
            C0254o.m1684a();
        }
        String str = (String) hashMap.get(simpleName);
        if (str == null || !stringWriter2.contains(str)) {
            this.f1396a.uncaughtException(thread, th);
        } else {
            this.f1397b.m1448a(th);
        }
    }
}
