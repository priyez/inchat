package com.facebook.p037d;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/* renamed from: com.facebook.d.a */
public abstract class C0199a extends BroadcastReceiver {
    protected abstract C0202d m1497a(Context context);

    public void onReceive(Context context, Intent intent) {
        C0202d a = m1497a(context);
        if ("com.facebook.GET_PHONE_ID".equals(intent.getAction()) && a != null && C0200b.m1499a(context, getResultExtras(true))) {
            Bundle bundle = new Bundle();
            bundle.putLong("timestamp", a.f787b);
            setResult(-1, a.f786a, bundle);
        }
    }
}
