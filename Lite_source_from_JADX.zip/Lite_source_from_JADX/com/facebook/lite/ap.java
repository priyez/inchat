package com.facebook.lite;

public final class ap {
    public static final int album_gallery_activity = 2130903040;
    public static final int clientmain_activity = 2130903041;
    public static final int contact_list_item = 2130903042;
    public static final int custom_dialog = 2130903043;
    public static final int floating_textbox = 2130903044;
    public static final int full_screen_video = 2130903045;
    public static final int gallery_item = 2130903046;
    public static final int inline_textbox = 2130903047;
    public static final int multi_picker_preview = 2130903048;
}
