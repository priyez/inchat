package com.facebook.lite;

import com.facebook.lite.widget.C0476g;

/* renamed from: com.facebook.lite.w */
final class C0465w implements Runnable {
    final /* synthetic */ C0476g f1846a;
    final /* synthetic */ MainActivity f1847b;

    C0465w(MainActivity mainActivity, C0476g c0476g) {
        this.f1847b = mainActivity;
        this.f1846a = c0476g;
    }

    public final void run() {
        this.f1846a.notifyDataSetChanged();
    }
}
