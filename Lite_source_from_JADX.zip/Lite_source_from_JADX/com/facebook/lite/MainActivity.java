package com.facebook.lite;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import com.facebook.lite.autoupdate.PersistentUpdatingBroadcastReceiver;
import com.facebook.lite.net.C0403i;
import com.facebook.lite.p049a.C0284m;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p053b.C0302p;
import com.facebook.lite.p057e.C0323d;
import com.facebook.lite.p057e.C0329i;
import com.facebook.lite.p058f.C0336d;
import com.facebook.lite.p059m.C0387i;
import com.facebook.lite.p064l.C0377g;
import com.facebook.lite.p065n.C0391a;
import com.facebook.lite.webview.FbWebView;
import com.facebook.lite.widget.BannerView;
import com.facebook.lite.widget.C0469r;
import com.facebook.lite.widget.C0476g;
import com.facebook.lite.widget.ConnectivityBar;
import com.facebook.lite.widget.DummySurfaceView;
import com.facebook.lite.widget.FbVideoView;
import com.facebook.lite.widget.FloatingTextBox;
import com.facebook.lite.widget.GL11RendererView;
import com.facebook.lite.widget.InlineTextBox;
import com.facebook.lite.widget.PhotoView;
import com.facebook.lite.widget.SoftwareRendererView;
import com.facebook.lite.widget.ae;
import com.facebook.p038e.C0251k;
import com.facebook.p038e.C0253n;
import com.facebook.rti.push.p048a.C0727d;
import com.google.android.gcm.C0751b;
import com.p008a.p009a.p010a.p012b.C0011a;
import com.p008a.p009a.p010a.p012b.C0019m;
import com.p008a.p009a.p010a.p016h.C0051c;
import com.p008a.p009a.p010a.p022l.C0076e;
import com.p008a.p009a.p010a.p023m.C0099a;
import java.util.Arrays;
import java.util.Locale;

public class MainActivity extends C0260h {
    private static final String f966a;
    private long f967A;
    private float f968B;
    private float f969C;
    private boolean f970b;
    private AlertDialog f971c;
    private BroadcastReceiver f972d;
    private BannerView f973e;
    private ConnectivityBar f974f;
    private DummySurfaceView f975g;
    private FloatingTextBox f976h;
    private boolean f977i;
    private InlineTextBox f978j;
    private ListView f979k;
    private long f980l;
    private RelativeLayout f981m;
    private String f982n;
    private C0284m f983o;
    private ae f984p;
    private PhotoView f985q;
    private boolean f986r;
    private C0377g f987s;
    private ae f988t;
    private C0469r f989u;
    private Uri f990v;
    private boolean f991w;
    private FbVideoView f992x;
    private FbWebView f993y;
    private boolean f994z;

    public MainActivity() {
        this.f970b = true;
        this.f994z = true;
        this.f968B = 0.0f;
        this.f969C = 0.0f;
    }

    static {
        f966a = MainActivity.class.getSimpleName();
    }

    public final void m1785c() {
        startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"));
    }

    public final void m1780a(String str) {
        runOnUiThread(new C0378l(this, str));
    }

    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (!this.f976h.m3189c()) {
            return super.dispatchTouchEvent(motionEvent);
        }
        if (!this.f976h.m3186a(motionEvent)) {
            return false;
        }
        if (this.f976h.m3188b(motionEvent)) {
            motionEvent.setAction(99);
            C0294h.m1954a((Context) this, this.f976h);
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public final void m1773a(int i, String str, String str2, String str3, int i2) {
        runOnUiThread(new ab(this, i, str, str2, str3, i2));
    }

    public final void m1774a(int i, String str, String str2, String str3, int i2, boolean z, int i3, int i4, int i5, int i6, String str4, String str5, C0329i c0329i, boolean z2, int i7, short s, String str6, C0099a c0099a, C0099a c0099a2, C0099a c0099a3, String str7, Long l, C0323d c0323d) {
        runOnUiThread(new af(this, i, str, str2, str3, i2, z, i3, i4, i5, i6, str4, str5, c0329i, z2, i7, s, str6, c0099a, c0099a2, c0099a3, str7, l, c0323d));
    }

    public final void m1779a(C0076e c0076e, int i, byte b, boolean z, boolean z2, boolean z3) {
        this.f986r = z2;
        byte[] c = c0076e.m592c();
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(c, 0, c.length);
        if (decodeByteArray != null) {
            runOnUiThread(new ah(this, decodeByteArray, c0076e, i, b, z, z3));
        }
    }

    public final void m1777a(View view, boolean z) {
        this.f989u.m3139a(view, z);
    }

    public final BannerView m1786d() {
        return this.f973e;
    }

    public final ConnectivityBar m1787e() {
        return this.f974f;
    }

    public final DummySurfaceView m1788f() {
        return this.f975g;
    }

    public final InlineTextBox m1789g() {
        return this.f978j;
    }

    public final C0469r m1790h() {
        return this.f989u;
    }

    public final void m1791i() {
        if (this.f973e != null) {
            runOnUiThread(new ai(this));
        }
    }

    public final void m1792j() {
        if (this.f984p != null) {
            this.f984p.dismiss();
        }
        if (this.f988t != null) {
            this.f988t.dismiss();
        }
    }

    public final void m1793k() {
        if (this.f981m != null && this.f981m.getVisibility() == 0) {
            runOnUiThread(new aj(this));
        }
    }

    public final void m1794l() {
        if (this.f978j != null && this.f976h != null) {
            runOnUiThread(new ak(this));
        }
    }

    public final void m1795m() {
        this.f992x.m3176a();
    }

    public final void m1796n() {
        if (this.f993y != null && this.f993y.getVisibility() == 0) {
            runOnUiThread(new al(this));
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        C0342f c = ClientApplication.m1691c();
        c.m2403a(SystemClock.elapsedRealtime());
        c.m2412a(this);
        Point b = C0294h.m1963b((Context) this);
        C0300n.m2107b((Context) this, b.x);
        C0300n.m2140h((Context) this, b.y);
        Intent intent = getIntent();
        if (m1741a(intent)) {
            C0342f.m2355a(true);
            setIntent(null);
        }
        c.m2436c(intent);
        setContentView(ap.clientmain_activity);
        m1797o();
        this.f973e = (BannerView) findViewById(as.banner_view);
        this.f975g = (DummySurfaceView) findViewById(as.dummy_surfaceview);
        this.f993y = (FbWebView) findViewById(as.webview);
        this.f981m = (RelativeLayout) findViewById(as.loading);
        this.f985q = (PhotoView) findViewById(as.zoomView);
        this.f992x = (FbVideoView) findViewById(as.videoview);
        this.f978j = (InlineTextBox) findViewById(as.inline_textbox);
        this.f976h = (FloatingTextBox) findViewById(as.floating_textbox);
        this.f974f = (ConnectivityBar) findViewById(as.connectivity_bar);
        this.f979k = (ListView) findViewById(as.inline_textbox_contact_list);
        m1768u();
        if (aw.f1162a) {
            PersistentUpdatingBroadcastReceiver.class.getName();
            this.f972d = new am(this);
            registerReceiver(this.f972d, new IntentFilter("com.facebook.lite.NEW_VERSION_DOWNLOADED"));
            c.m2390V();
            this.f987s = new C0377g(this);
        }
        if (bundle != null) {
            if (aw.f1162a) {
                this.f990v = (Uri) bundle.getParcelable("state_update_uri");
            }
            this.f977i = bundle.getBoolean("state_has_loggedin_since_startup", false);
            this.f991w = bundle.getBoolean("state_user_turn_off_data_wifi");
            this.f982n = bundle.getString("state_locale");
        }
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i == 4) {
            if (this.f993y != null && this.f993y.getVisibility() == 0 && this.f993y.canGoBack()) {
                return true;
            }
            if (this.f992x.getVisibility() == 0) {
                this.f992x.m3176a();
            }
        }
        if (this.f985q != null && this.f985q.getVisibility() == 0) {
            return this.f986r;
        }
        if (Arrays.binarySearch(C0367j.f1431a, i) >= 0) {
            C0019m t = m1767t();
            if (t != null) {
                t.m113b(i);
                return true;
            }
        }
        return false;
    }

    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (i == 4) {
            if (this.f978j != null && this.f978j.m3224b()) {
                this.f978j.m3221a();
                return true;
            } else if (this.f976h != null && this.f976h.m3189c()) {
                this.f976h.m3187b();
                return true;
            } else if (this.f993y != null && this.f993y.getVisibility() == 0 && this.f993y.canGoBack()) {
                this.f993y.goBack();
                return true;
            } else if (this.f985q != null && this.f985q.getVisibility() == 0) {
                m1766s();
                return true;
            }
        }
        if (Arrays.binarySearch(C0367j.f1431a, i) >= 0) {
            C0019m t = m1767t();
            if (t != null) {
                t.m118o();
                return true;
            }
        }
        return false;
    }

    public void onOptionsMenuClosed(Menu menu) {
        menu.clear();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putParcelable("state_update_uri", this.f990v);
        bundle.putSerializable("state_has_loggedin_since_startup", Boolean.valueOf(this.f977i));
        bundle.putSerializable("state_user_turn_off_data_wifi", Boolean.valueOf(this.f991w));
        bundle.putSerializable("state_locale", this.f982n);
    }

    public boolean onTrackballEvent(MotionEvent motionEvent) {
        C0019m t = m1767t();
        if (t == null) {
            return false;
        }
        if (motionEvent.getAction() == 0) {
            t.m113b(23);
        } else if (motionEvent.getAction() == 2) {
            long currentTimeMillis = System.currentTimeMillis();
            if (currentTimeMillis - this.f967A > 500) {
                this.f968B = 0.0f;
                this.f969C = 0.0f;
            }
            this.f967A = currentTimeMillis;
            this.f968B += motionEvent.getX();
            this.f969C += motionEvent.getY();
            if (this.f968B >= 1.0f) {
                t.m113b(22);
                this.f968B = 0.0f;
                t.m118o();
            } else if (this.f968B <= -1.0f) {
                t.m113b(21);
                this.f968B = 0.0f;
                t.m118o();
            }
            if (this.f969C >= 1.0f) {
                t.m113b(20);
                this.f969C = 0.0f;
                t.m118o();
            } else if (this.f969C <= -1.0f) {
                t.m113b(19);
                this.f969C = 0.0f;
                t.m118o();
            }
        }
        return true;
    }

    public final void m1797o() {
        int C = C0300n.m2075C(this);
        int D = C0300n.m2076D(this);
        FrameLayout frameLayout = (FrameLayout) findViewById(as.main_layout);
        if (this.f989u != null) {
            frameLayout.removeView(this.f989u.m3138a());
        }
        C0469r a = m1733a(D);
        if (a == null) {
            a = m1733a(C);
        }
        if (a == null) {
            a = new SoftwareRendererView(this);
        }
        new StringBuilder("Using ").append(a.getClass().getSimpleName());
        frameLayout.addView(a.m3138a(), 0);
        this.f989u = a;
    }

    public final void m1772a(int i, int i2, int i3, int i4, boolean z, int i5, int i6, int i7) {
        runOnUiThread(new C0390m(this, i3, i4, i, i2, z, i6, i7, i5));
    }

    public final void m1798p() {
        if (this.f981m != null && this.f981m.getVisibility() != 0) {
            runOnUiThread(new C0392n(this));
        }
    }

    public final void m1782a(boolean z, boolean z2) {
        if (this.f970b && !isFinishing()) {
            boolean z3;
            String a = C0302p.m2174a(C0294h.m1977h(getApplicationContext()));
            boolean z4 = a.length() > 0 && !a.equals(this.f982n);
            Object obj;
            if (z != this.f977i) {
                obj = 1;
            } else {
                obj = null;
            }
            Object obj2;
            if (z2 != this.f991w) {
                obj2 = 1;
            } else {
                obj2 = null;
            }
            if (this.f984p == null || r2 != null || r3 != null || z4) {
                z3 = true;
            } else {
                z3 = false;
            }
            runOnUiThread(new C0455r(this, z3, z, z2, z4, a));
        }
    }

    public final void m1784b(boolean z, boolean z2) {
        this.f984p.show();
        C0251k c0251k = new C0251k("ema_no_connectivity_dialog");
        c0251k.m1681b("already_logged_in", z);
        c0251k.m1681b("data_and_wifi_disabled", z2);
        c0251k.m1681b("dialog_shown", true);
        C0251k.m1673a(c0251k, ClientApplication.m1691c().m2377I(), C0253n.MUST_HAVE);
    }

    public final void m1775a(int i, boolean z) {
        boolean z2 = false;
        if (this.f970b && !isFinishing()) {
            boolean z3 = z != this.f977i;
            boolean z4;
            if (i == C0403i.f1627b) {
                z4 = true;
            } else {
                z4 = false;
            }
            if (this.f984p == null || r3 || z3 || this.f994z) {
                z2 = true;
            }
            runOnUiThread(new C0458u(this, z2, z, i));
        }
    }

    public final void m1781a(boolean z) {
        this.f988t.show();
        C0251k c0251k = new C0251k("ema_retry_connectivity_dialog");
        c0251k.m1681b("already_logged_in", z);
        c0251k.m1681b("dialog_shown", true);
        C0251k.m1673a(c0251k, ClientApplication.m1691c().m2377I(), C0253n.MUST_HAVE);
    }

    public final void m1771a(int i, int i2, int i3, int i4, String str, long j, int i5, int i6, int i7, boolean z, String str2) {
        this.f992x.m3177a(i, i2, i3, i4, str, j, ClientApplication.m1691c().m2388T(), i5, i6, i7, z, str2);
    }

    public final void m1776a(Uri uri, int i, int i2, int i3, int i4, boolean z, boolean z2, boolean z3) {
        runOnUiThread(new C0464v(this, i3, i4, i, i2, z, z2, z3, uri, ClientApplication.m1691c().m2387S().m2640O()));
        C0251k c0251k = new C0251k("ema_show_webview");
        c0251k.m1680b("uri", String.valueOf(uri));
        C0251k.m1672a(c0251k, getApplicationContext());
    }

    public final void m1783b(boolean z) {
        if (z && this.f979k != null) {
            C0476g c0476g = (C0476g) this.f979k.getAdapter();
            if (c0476g != null) {
                runOnUiThread(new C0465w(this, c0476g));
            }
        }
    }

    public final void m1778a(C0076e c0076e) {
        if (c0076e != null && this.f985q != null && this.f985q.getVisibility() == 0 && c0076e.m593d() != this.f985q.getCurrImageId() && c0076e.m593d() == this.f985q.getTargetImageId()) {
            runOnUiThread(new C0494x(this, BitmapFactory.decodeByteArray(c0076e.m592c(), 0, c0076e.m590a()), c0076e));
        }
    }

    public final boolean m1799q() {
        return this.f970b;
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        ClientApplication.m1691c().m2398a(i, i2, intent);
    }

    protected void onDestroy() {
        C0751b.m4003d(getApplicationContext());
        m1770w();
        if (aw.f1162a) {
            if (this.f972d != null) {
                unregisterReceiver(this.f972d);
            }
            ComponentName componentName = new ComponentName(getApplicationContext(), PersistentUpdatingBroadcastReceiver.class);
            PackageManager packageManager = getApplicationContext().getPackageManager();
            if (packageManager.getComponentEnabledSetting(componentName) == 1) {
                packageManager.setComponentEnabledSetting(componentName, 2, 1);
            }
        }
        super.onDestroy();
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null) {
            C0342f c = ClientApplication.m1691c();
            if (c == null) {
                return;
            }
            if (m1741a(intent)) {
                setIntent(null);
                if (!c.m2458p()) {
                    C0342f.m2355a(true);
                }
            } else if (ClientApplication.m1691c().m2424a(intent)) {
                setIntent(null);
            }
        }
    }

    protected void onPause() {
        super.onPause();
        this.f970b = false;
        if (this.f989u != null) {
            this.f989u.onPause();
        }
        if (this.f971c != null && this.f971c.isShowing()) {
            this.f971c.dismiss();
        }
        if (this.f984p != null && this.f984p.isShowing()) {
            this.f984p.dismiss();
        }
        if (this.f988t != null && this.f988t.isShowing()) {
            this.f988t.dismiss();
        }
        if (aw.f1162a) {
            this.f987s.m2557c();
        }
        if (this.f978j.m3224b()) {
            C0294h.m1954a((Context) this, this.f978j);
        }
        if (this.f976h.m3189c()) {
            C0294h.m1954a((Context) this, this.f976h);
        }
        if (this.f992x.getVisibility() == 0) {
            this.f992x.m3178b();
        }
        if (C0336d.f1316a) {
            C0051c c = ClientApplication.m1691c();
            if (c.m2387S() != null) {
                c.m2387S().m2636K().m2336b(c);
            }
        }
        this.f985q.m3252a(false);
        ClientApplication.m1691c().m2392X();
        if (ClientApplication.m1691c().m2387S() != null) {
            ClientApplication.m1691c().m2387S().m2639N().m168a(C0011a.m70a());
        }
    }

    protected void onResume() {
        super.onResume();
        C0051c c = ClientApplication.m1691c();
        C0387i S = c.m2387S();
        S.m2639N().m215r();
        this.f989u.onResume();
        ClientApplication.m1690b();
        ClientApplication.m1693e().m2387S().aa().m1033r(ConnectivityBar.getType());
        if (C0336d.f1316a) {
            S.m2636K().m2335a(c);
        }
        this.f970b = true;
        if (aw.f1162a) {
            this.f987s.m2556b();
        }
        if (this.f985q.getVisibility() == 0) {
            this.f985q.m3252a(true);
        }
        if (this.f992x.getVisibility() == 0) {
            this.f992x.m3179c();
        }
        if (m1740a((Context) this)) {
            if (this.f978j.m3224b()) {
                this.f978j.requestFocus();
                C0294h.m1965b((Context) this, this.f978j);
            }
            if (this.f976h.m3189c()) {
                this.f976h.requestFocus();
                C0294h.m1965b((Context) this, this.f976h);
            }
        }
    }

    protected void onStart() {
        super.onStart();
        C0727d.m3928a(getApplicationContext());
        ClientApplication.m1691c().m2389U();
    }

    private ae m1732a(String str, String str2) {
        ae aeVar = new ae(this, aq.nativeDialogStyle);
        aeVar.m3270b(str);
        aeVar.m3268a(str2);
        aeVar.setCanceledOnTouchOutside(false);
        int width = getWindowManager().getDefaultDisplay().getWidth();
        LayoutParams layoutParams = new LayoutParams();
        layoutParams.copyFrom(aeVar.getWindow().getAttributes());
        layoutParams.width = (int) (((double) width) * 0.9d);
        layoutParams.height = -2;
        aeVar.getWindow().setAttributes(layoutParams);
        return aeVar;
    }

    private void m1766s() {
        m1769v();
        this.f985q.m3248a();
        m1777a(null, false);
        this.f985q.m3252a(false);
    }

    private static C0019m m1767t() {
        C0387i S = ClientApplication.m1691c().m2387S();
        return S == null ? null : S.m2651Z();
    }

    private static boolean m1741a(Intent intent) {
        if (intent != null && "dialtone".equals(intent.getScheme()) && "start".equals(intent.getData().getHost())) {
            return true;
        }
        return false;
    }

    private C0469r m1733a(int i) {
        switch (i) {
            case 0:
                return null;
            case 1:
                return new SoftwareRendererView(this);
            case 2:
                return new GL11RendererView(this);
            case 3:
                throw new RuntimeException("Not implemented.");
            default:
                throw new RuntimeException("Unknown renderer type.");
        }
    }

    private void m1768u() {
        if (VERSION.SDK_INT >= 9) {
            new StringBuilder("storage/removable:").append(Environment.isExternalStorageRemovable());
            if (!Environment.isExternalStorageRemovable()) {
                return;
            }
        }
        if (VERSION.SDK_INT >= 11) {
            new StringBuilder("storage/emulated:").append(Environment.isExternalStorageEmulated());
            if (Environment.isExternalStorageEmulated()) {
                return;
            }
        }
        this.f983o = new C0284m();
        registerReceiver(this.f983o, C0284m.m1923a());
    }

    private void m1737a(ae aeVar) {
        if (aeVar != null && aeVar.isShowing()) {
            aeVar.dismiss();
        }
        C0387i S = ClientApplication.m1691c().m2387S();
        if (S == null) {
            Log.e(f966a, "Client session null, not able to set EXIT action");
            finish();
            return;
        }
        S.m2627B();
    }

    private void m1738a(ae aeVar, String str) {
        if ("right".equals(str)) {
            aeVar.m3272c(C0391a.m2719a(2), new C0495y(this, aeVar));
        } else if ("central".equals(str)) {
            aeVar.m3269a(C0391a.m2719a(2), new C0496z(this, aeVar));
        }
    }

    private void m1748b(String str) {
        if (!C0302p.m2177b((CharSequence) str)) {
            Locale locale;
            String[] split = str.split("_");
            if (split.length == 1) {
                locale = new Locale(str);
            } else if (split.length == 2) {
                String str2 = split[0];
                String str3 = split[1];
                locale = new Locale(str2, str3);
                C0391a.m2721a(str2, str3);
            } else {
                locale = Locale.ENGLISH;
            }
            Locale.setDefault(locale);
            Configuration configuration = new Configuration();
            configuration.locale = locale;
            getResources().updateConfiguration(configuration, getResources().getDisplayMetrics());
        }
    }

    private void m1747b(ae aeVar) {
        if (aeVar != null && aeVar.isShowing()) {
            aeVar.dismiss();
        }
        if (ClientApplication.m1691c().m2387S() == null) {
            Log.e(f966a, "Client session null, not able to set OK action");
            finish();
        }
    }

    private void m1739a(ae aeVar, String str, boolean z, String str2) {
        if ("right".equals(str2)) {
            aeVar.m3272c(str, new aa(this, aeVar, z));
        } else if ("central".equals(str2)) {
            aeVar.m3269a(str, new ac(this, aeVar, z));
        }
    }

    private void m1769v() {
        runOnUiThread(new ad(this));
    }

    private boolean m1740a(Context context) {
        if (this.f990v == null) {
            return false;
        }
        if (this.f971c == null) {
            this.f971c = new Builder(context).setTitle(context.getString(an.app_name)).setMessage(context.getString(an.dialog_update)).setCancelable(false).setPositiveButton(context.getString(an.dialog_install), new ae(this, context)).create();
        }
        if (isFinishing()) {
            return false;
        }
        this.f971c.show();
        return true;
    }

    private void m1770w() {
        if (this.f983o != null) {
            unregisterReceiver(this.f983o);
        }
    }
}
