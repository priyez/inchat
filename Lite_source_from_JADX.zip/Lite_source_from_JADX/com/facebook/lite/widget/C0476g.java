package com.facebook.lite.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.facebook.lite.ap;
import com.facebook.lite.as;
import com.facebook.lite.photo.C0443l;
import com.p008a.p009a.p010a.p022l.C0076e;
import com.p008a.p009a.p010a.p022l.C0080i;
import com.p008a.p009a.p010a.p023m.C0119g;
import java.util.List;
import java.util.Set;

/* renamed from: com.facebook.lite.widget.g */
public final class C0476g extends ArrayAdapter {
    private final Context f2083a;
    private final List f2084b;
    private final C0443l f2085c;
    private final List f2086d;
    private final C0080i f2087e;
    private int f2088f;
    private final List f2089g;
    private boolean f2090h;

    public C0476g(Context context, List list, List list2, List list3, C0443l c0443l, C0080i c0080i) {
        super(context, ap.contact_list_item, list);
        this.f2083a = context;
        this.f2085c = c0443l;
        this.f2087e = c0080i;
        this.f2089g = list;
        this.f2086d = list3;
        this.f2084b = list2;
    }

    public final View getView(int i, View view, ViewGroup viewGroup) {
        TextView textView;
        ImageView imageView;
        boolean z = false;
        LayoutInflater layoutInflater = (LayoutInflater) this.f2083a.getSystemService("layout_inflater");
        ImageView imageView2;
        if (view == null) {
            view = layoutInflater.inflate(ap.contact_list_item, null, true);
            textView = (TextView) view.findViewById(as.contact_list_text);
            imageView2 = (ImageView) view.findViewById(as.contact_list_image);
            textView.getLayoutParams().height = this.f2088f;
            imageView2.getLayoutParams().height = this.f2088f;
            imageView2.getLayoutParams().width = this.f2088f;
            C0475f c0475f = new C0475f();
            c0475f.f2082b = textView;
            c0475f.f2081a = imageView2;
            view.setTag(c0475f);
            this.f2090h = false;
            imageView = imageView2;
        } else {
            C0475f c0475f2 = (C0475f) view.getTag();
            TextView textView2 = c0475f2.f2082b;
            imageView2 = c0475f2.f2081a;
            this.f2090h = true;
            imageView = imageView2;
            textView = textView2;
        }
        m3283a(textView, i);
        imageView.setVisibility(0);
        int intValue = ((Integer) this.f2086d.get(i)).intValue();
        C0076e e = this.f2087e.m632e(intValue);
        C0119g a = C0119g.m1184a(intValue, this.f2088f, this.f2088f, this.f2088f, this.f2088f, false, 0, true);
        if (e != null) {
            byte[] c = e.m592c();
            Bitmap b = this.f2085c.m3034b(c, c.length, intValue, a);
            if (b != null) {
                imageView.setImageBitmap(b);
                z = true;
            }
        }
        if (!z) {
            imageView.setImageBitmap(null);
        }
        return view;
    }

    public final void m3284a(List list, List list2, List list3, Set set, int i) {
        this.f2084b.clear();
        this.f2089g.clear();
        this.f2086d.clear();
        this.f2088f = i;
        for (int i2 = 0; i2 < list.size(); i2++) {
            if (!set.contains(list.get(i2))) {
                this.f2084b.add(list.get(i2));
                this.f2089g.add(list2.get(i2));
                this.f2086d.add(list3.get(i2));
            }
        }
        notifyDataSetChanged();
    }

    private void m3283a(TextView textView, int i) {
        textView.setText((CharSequence) this.f2089g.get(i));
        textView.setGravity(19);
        textView.setTypeface(null, 0);
        textView.setTag(Long.valueOf(((Long) this.f2084b.get(i)).longValue()));
    }
}
