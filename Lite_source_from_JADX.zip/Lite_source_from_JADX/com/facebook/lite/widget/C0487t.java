package com.facebook.lite.widget;

import android.view.View;
import android.view.View.OnFocusChangeListener;
import com.facebook.lite.p053b.C0294h;

/* renamed from: com.facebook.lite.widget.t */
final class C0487t implements OnFocusChangeListener {
    final /* synthetic */ InlineTextBox f2106a;

    C0487t(InlineTextBox inlineTextBox) {
        this.f2106a = inlineTextBox;
    }

    public final void onFocusChange(View view, boolean z) {
        if (z) {
            C0294h.m1965b(this.f2106a.getContext(), this.f2106a.f1946s);
        }
    }
}
