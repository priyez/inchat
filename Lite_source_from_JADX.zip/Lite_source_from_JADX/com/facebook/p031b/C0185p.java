package com.facebook.p031b;

/* renamed from: com.facebook.b.p */
public interface C0185p {
}
