package com.facebook.rti.p046a.p076h;

/* renamed from: com.facebook.rti.a.h.a */
public interface C0531a {
    long m3350a();
}
