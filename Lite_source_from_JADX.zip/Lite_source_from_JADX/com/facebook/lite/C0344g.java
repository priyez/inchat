package com.facebook.lite;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* renamed from: com.facebook.lite.g */
final class C0344g extends BroadcastReceiver {
    C0344g() {
    }

    public final void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.intent.action.TIME_SET")) {
            C0260h.f963b.m1577c(System.currentTimeMillis());
        }
    }
}
