package com.facebook.lite.notification;

import com.facebook.lite.notification.SystemTrayNotification.NotificationType;

/* renamed from: com.facebook.lite.notification.j */
final /* synthetic */ class C0421j {
    static final /* synthetic */ int[] f1704a;

    static {
        f1704a = new int[NotificationType.values().length];
        try {
            f1704a[NotificationType.MSG.ordinal()] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            f1704a[NotificationType.FRIEND_REQUEST.ordinal()] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            f1704a[NotificationType.EVENT.ordinal()] = 3;
        } catch (NoSuchFieldError e3) {
        }
    }
}
