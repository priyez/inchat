package com.facebook.lite.p064l;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.widget.EditText;

/* renamed from: com.facebook.lite.l.c */
final class C0373c implements OnClickListener {
    final /* synthetic */ EditText f1443a;
    final /* synthetic */ C0377g f1444b;

    C0373c(C0377g c0377g, EditText editText) {
        this.f1444b = c0377g;
        this.f1443a = editText;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        this.f1444b.f1453d = false;
        dialogInterface.dismiss();
        this.f1443a.clearFocus();
    }
}
