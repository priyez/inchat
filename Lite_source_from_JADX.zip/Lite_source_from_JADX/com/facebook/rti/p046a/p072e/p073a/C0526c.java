package com.facebook.rti.p046a.p072e.p073a;

/* renamed from: com.facebook.rti.a.e.a.c */
final class C0526c extends C0524b {
    private final Object f2212a;

    C0526c(Object obj) {
        this.f2212a = obj;
    }

    public final boolean m3332a() {
        return true;
    }

    public final Object m3333b() {
        return this.f2212a;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof C0526c)) {
            return false;
        }
        return this.f2212a.equals(((C0526c) obj).f2212a);
    }

    public final int hashCode() {
        return 1502476572 + this.f2212a.hashCode();
    }

    public final String toString() {
        return "Optional.of(" + this.f2212a + ")";
    }
}
