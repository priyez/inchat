package com.facebook.rti.push.service;

/* renamed from: com.facebook.rti.push.service.a */
public enum C0731a {
    NOTIFICATION_RECEIVED,
    DUPLICATED_NOTIFICATION
}
