package com.facebook.p031b;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.EnumMap;

/* renamed from: com.facebook.b.d */
public final class C0173d extends EnumMap {
    private static String f658b;
    protected C0173d f659a;

    public C0173d() {
        super(C0191v.class);
    }

    private static void m1376a(Appendable appendable, String str, boolean z) {
        int i;
        int length = str.length();
        if (z || length <= 0 || str.charAt(0) != ' ') {
            i = 0;
        } else {
            appendable.append("\\ ");
            i = 1;
        }
        while (i < length) {
            char charAt = str.charAt(i);
            switch (charAt) {
                case '\t':
                    appendable.append("\\t");
                    break;
                case '\n':
                    appendable.append("\\n");
                    break;
                case '\f':
                    appendable.append("\\f");
                    break;
                case '\r':
                    appendable.append("\\r");
                    break;
                default:
                    if ((z && charAt == ' ') || charAt == '\\' || charAt == '#' || charAt == '!' || charAt == ':') {
                        appendable.append('\\');
                    }
                    if (charAt >= ' ' && charAt <= '~') {
                        appendable.append(charAt);
                        break;
                    }
                    CharSequence toHexString = Integer.toHexString(charAt);
                    appendable.append("\\u");
                    for (int i2 = 0; i2 < 4 - toHexString.length(); i2++) {
                        appendable.append('0');
                    }
                    appendable.append(toHexString);
                    break;
            }
            i++;
        }
    }

    public final String m1378a(C0191v c0191v) {
        String str = (String) super.get(c0191v);
        if (str != null || this.f659a == null) {
            return str;
        }
        return this.f659a.m1378a(c0191v);
    }

    public final synchronized void m1381a(InputStream inputStream) {
        BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
        bufferedInputStream.mark(Integer.MAX_VALUE);
        boolean a = C0173d.m1377a(bufferedInputStream);
        bufferedInputStream.reset();
        if (a) {
            m1374a(new InputStreamReader(bufferedInputStream));
        } else {
            m1374a(new InputStreamReader(bufferedInputStream, "ISO8859-1"));
        }
    }

    private static boolean m1377a(BufferedInputStream bufferedInputStream) {
        byte read;
        do {
            read = (byte) bufferedInputStream.read();
            if (read == -1 || read == 35 || read == 10 || read == 61) {
                return false;
            }
        } while (read != 21);
        return true;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private synchronized void m1374a(java.io.Reader r14) {
        /*
        r13 = this;
        monitor-enter(r13);
        r6 = 0;
        r5 = 0;
        r4 = 0;
        r0 = 40;
        r3 = new char[r0];	 Catch:{ all -> 0x004f }
        r2 = 0;
        r1 = -1;
        r0 = 1;
        r9 = new java.io.BufferedReader;	 Catch:{ all -> 0x004f }
        r9.<init>(r14);	 Catch:{ all -> 0x004f }
        r7 = r0;
        r0 = r1;
        r1 = r4;
        r4 = r5;
        r5 = r6;
        r6 = r3;
    L_0x0016:
        r3 = r9.read();	 Catch:{ all -> 0x004f }
        r8 = -1;
        if (r3 == r8) goto L_0x013e;
    L_0x001d:
        if (r3 == 0) goto L_0x013e;
    L_0x001f:
        r3 = (char) r3;	 Catch:{ all -> 0x004f }
        r8 = r6.length;	 Catch:{ all -> 0x004f }
        if (r2 != r8) goto L_0x01a1;
    L_0x0023:
        r8 = r6.length;	 Catch:{ all -> 0x004f }
        r8 = r8 * 2;
        r8 = new char[r8];	 Catch:{ all -> 0x004f }
        r10 = 0;
        r11 = 0;
        java.lang.System.arraycopy(r6, r10, r8, r11, r2);	 Catch:{ all -> 0x004f }
    L_0x002d:
        r6 = 2;
        if (r5 != r6) goto L_0x019a;
    L_0x0030:
        r6 = 16;
        r6 = java.lang.Character.digit(r3, r6);	 Catch:{ all -> 0x004f }
        if (r6 < 0) goto L_0x0044;
    L_0x0038:
        r4 = r4 << 4;
        r6 = r6 + r4;
        r4 = r1 + 1;
        r1 = 4;
        if (r4 >= r1) goto L_0x0197;
    L_0x0040:
        r1 = r4;
        r4 = r6;
        r6 = r8;
        goto L_0x0016;
    L_0x0044:
        r5 = 4;
        if (r1 > r5) goto L_0x0052;
    L_0x0047:
        r0 = new java.lang.IllegalArgumentException;	 Catch:{ all -> 0x004f }
        r1 = "luni.09";
        r0.<init>(r1);	 Catch:{ all -> 0x004f }
        throw r0;	 Catch:{ all -> 0x004f }
    L_0x004f:
        r0 = move-exception;
        monitor-exit(r13);
        throw r0;
    L_0x0052:
        r5 = r4;
        r4 = r1;
    L_0x0054:
        r6 = 0;
        r1 = r2 + 1;
        r10 = (char) r5;
        r8[r2] = r10;	 Catch:{ all -> 0x004f }
        r2 = 10;
        if (r3 == r2) goto L_0x0062;
    L_0x005e:
        r2 = 133; // 0x85 float:1.86E-43 double:6.57E-322;
        if (r3 != r2) goto L_0x0190;
    L_0x0062:
        r2 = r6;
    L_0x0063:
        r6 = 1;
        if (r2 != r6) goto L_0x00a3;
    L_0x0066:
        r2 = 0;
        switch(r3) {
            case 10: goto L_0x0084;
            case 13: goto L_0x007c;
            case 98: goto L_0x008c;
            case 102: goto L_0x008f;
            case 110: goto L_0x0092;
            case 114: goto L_0x0095;
            case 116: goto L_0x0098;
            case 117: goto L_0x009b;
            case 133: goto L_0x0084;
            default: goto L_0x006a;
        };	 Catch:{ all -> 0x004f }
    L_0x006a:
        r6 = 0;
        r7 = 4;
        if (r2 != r7) goto L_0x0071;
    L_0x006e:
        r0 = 0;
        r2 = r0;
        r0 = r1;
    L_0x0071:
        r7 = r1 + 1;
        r8[r1] = r3;	 Catch:{ all -> 0x004f }
        r1 = r4;
        r4 = r5;
        r5 = r2;
        r2 = r7;
        r7 = r6;
        r6 = r8;
        goto L_0x0016;
    L_0x007c:
        r2 = 3;
        r6 = r8;
        r12 = r1;
        r1 = r4;
        r4 = r5;
        r5 = r2;
        r2 = r12;
        goto L_0x0016;
    L_0x0084:
        r2 = 5;
        r6 = r8;
        r12 = r1;
        r1 = r4;
        r4 = r5;
        r5 = r2;
        r2 = r12;
        goto L_0x0016;
    L_0x008c:
        r3 = 8;
        goto L_0x006a;
    L_0x008f:
        r3 = 12;
        goto L_0x006a;
    L_0x0092:
        r3 = 10;
        goto L_0x006a;
    L_0x0095:
        r3 = 13;
        goto L_0x006a;
    L_0x0098:
        r3 = 9;
        goto L_0x006a;
    L_0x009b:
        r2 = 2;
        r4 = 0;
        r6 = r8;
        r5 = r2;
        r2 = r1;
        r1 = r4;
        goto L_0x0016;
    L_0x00a3:
        switch(r3) {
            case 10: goto L_0x00e1;
            case 13: goto L_0x00ed;
            case 33: goto L_0x00c3;
            case 35: goto L_0x00c3;
            case 58: goto L_0x0128;
            case 61: goto L_0x0128;
            case 92: goto L_0x011b;
            case 133: goto L_0x00ed;
            default: goto L_0x00a6;
        };	 Catch:{ all -> 0x004f }
    L_0x00a6:
        r6 = java.lang.Character.isWhitespace(r3);	 Catch:{ all -> 0x004f }
        if (r6 == 0) goto L_0x0135;
    L_0x00ac:
        r6 = 3;
        if (r2 != r6) goto L_0x00b0;
    L_0x00af:
        r2 = 5;
    L_0x00b0:
        if (r1 == 0) goto L_0x0188;
    L_0x00b2:
        if (r1 == r0) goto L_0x0188;
    L_0x00b4:
        r6 = 5;
        if (r2 == r6) goto L_0x0188;
    L_0x00b7:
        r6 = -1;
        if (r0 != r6) goto L_0x0135;
    L_0x00ba:
        r2 = 4;
        r6 = r8;
        r12 = r1;
        r1 = r4;
        r4 = r5;
        r5 = r2;
        r2 = r12;
        goto L_0x0016;
    L_0x00c3:
        if (r7 == 0) goto L_0x00a6;
    L_0x00c5:
        r3 = r9.read();	 Catch:{ all -> 0x004f }
        r6 = -1;
        if (r3 == r6) goto L_0x0188;
    L_0x00cc:
        r3 = (char) r3;	 Catch:{ all -> 0x004f }
        r6 = 13;
        if (r3 == r6) goto L_0x0188;
    L_0x00d1:
        r6 = 10;
        if (r3 == r6) goto L_0x0188;
    L_0x00d5:
        r6 = 133; // 0x85 float:1.86E-43 double:6.57E-322;
        if (r3 != r6) goto L_0x00c5;
    L_0x00d9:
        r6 = r8;
        r12 = r1;
        r1 = r4;
        r4 = r5;
        r5 = r2;
        r2 = r12;
        goto L_0x0016;
    L_0x00e1:
        r3 = 3;
        if (r2 != r3) goto L_0x00ed;
    L_0x00e4:
        r2 = 5;
        r6 = r8;
        r12 = r1;
        r1 = r4;
        r4 = r5;
        r5 = r2;
        r2 = r12;
        goto L_0x0016;
    L_0x00ed:
        r6 = 0;
        r2 = 1;
        if (r1 > 0) goto L_0x00f5;
    L_0x00f1:
        if (r1 != 0) goto L_0x0111;
    L_0x00f3:
        if (r0 != 0) goto L_0x0111;
    L_0x00f5:
        r3 = -1;
        if (r0 != r3) goto L_0x00f9;
    L_0x00f8:
        r0 = r1;
    L_0x00f9:
        r3 = new java.lang.String;	 Catch:{ all -> 0x004f }
        r7 = 0;
        r3.<init>(r8, r7, r1);	 Catch:{ all -> 0x004f }
        r1 = com.facebook.p031b.C0191v.class;
        r7 = 0;
        r7 = r3.substring(r7, r0);	 Catch:{ all -> 0x004f }
        r1 = java.lang.Enum.valueOf(r1, r7);	 Catch:{ all -> 0x004f }
        r0 = r3.substring(r0);	 Catch:{ all -> 0x004f }
        r13.put(r1, r0);	 Catch:{ all -> 0x004f }
    L_0x0111:
        r0 = -1;
        r1 = 0;
        r7 = r2;
        r2 = r1;
        r1 = r4;
        r4 = r5;
        r5 = r6;
        r6 = r8;
        goto L_0x0016;
    L_0x011b:
        r3 = 4;
        if (r2 != r3) goto L_0x011f;
    L_0x011e:
        r0 = r1;
    L_0x011f:
        r2 = 1;
        r6 = r8;
        r12 = r1;
        r1 = r4;
        r4 = r5;
        r5 = r2;
        r2 = r12;
        goto L_0x0016;
    L_0x0128:
        r6 = -1;
        if (r0 != r6) goto L_0x00a6;
    L_0x012b:
        r2 = 0;
        r0 = r1;
        r6 = r8;
        r12 = r1;
        r1 = r4;
        r4 = r5;
        r5 = r2;
        r2 = r12;
        goto L_0x0016;
    L_0x0135:
        r6 = 5;
        if (r2 == r6) goto L_0x013b;
    L_0x0138:
        r6 = 3;
        if (r2 != r6) goto L_0x006a;
    L_0x013b:
        r2 = 0;
        goto L_0x006a;
    L_0x013e:
        r3 = 2;
        if (r5 != r3) goto L_0x014c;
    L_0x0141:
        r3 = 4;
        if (r1 > r3) goto L_0x014c;
    L_0x0144:
        r0 = new java.lang.IllegalArgumentException;	 Catch:{ all -> 0x004f }
        r1 = "luni.08";
        r0.<init>(r1);	 Catch:{ all -> 0x004f }
        throw r0;	 Catch:{ all -> 0x004f }
    L_0x014c:
        r1 = -1;
        if (r0 != r1) goto L_0x0186;
    L_0x014f:
        if (r2 <= 0) goto L_0x0186;
    L_0x0151:
        r1 = r2;
    L_0x0152:
        if (r1 < 0) goto L_0x0184;
    L_0x0154:
        r3 = new java.lang.String;	 Catch:{ all -> 0x004f }
        r0 = 0;
        r3.<init>(r6, r0, r2);	 Catch:{ all -> 0x004f }
        r0 = com.facebook.p031b.C0191v.class;
        r2 = 0;
        r2 = r3.substring(r2, r1);	 Catch:{ all -> 0x004f }
        r0 = java.lang.Enum.valueOf(r0, r2);	 Catch:{ all -> 0x004f }
        r0 = (com.facebook.p031b.C0191v) r0;	 Catch:{ all -> 0x004f }
        r1 = r3.substring(r1);	 Catch:{ all -> 0x004f }
        r2 = 1;
        if (r5 != r2) goto L_0x0181;
    L_0x016e:
        r2 = new java.lang.StringBuilder;	 Catch:{ all -> 0x004f }
        r2.<init>();	 Catch:{ all -> 0x004f }
        r1 = r2.append(r1);	 Catch:{ all -> 0x004f }
        r2 = "\u0000";
        r1 = r1.append(r2);	 Catch:{ all -> 0x004f }
        r1 = r1.toString();	 Catch:{ all -> 0x004f }
    L_0x0181:
        r13.put(r0, r1);	 Catch:{ all -> 0x004f }
    L_0x0184:
        monitor-exit(r13);
        return;
    L_0x0186:
        r1 = r0;
        goto L_0x0152;
    L_0x0188:
        r6 = r8;
        r12 = r1;
        r1 = r4;
        r4 = r5;
        r5 = r2;
        r2 = r12;
        goto L_0x0016;
    L_0x0190:
        r2 = r1;
        r1 = r4;
        r4 = r5;
        r5 = r6;
        r6 = r8;
        goto L_0x0016;
    L_0x0197:
        r5 = r6;
        goto L_0x0054;
    L_0x019a:
        r12 = r2;
        r2 = r5;
        r5 = r4;
        r4 = r1;
        r1 = r12;
        goto L_0x0063;
    L_0x01a1:
        r8 = r6;
        goto L_0x002d;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.b.d.a(java.io.Reader):void");
    }

    public final String m1379a(C0191v c0191v, String str, Writer writer) {
        String str2 = (String) put(c0191v, str);
        if (writer != null) {
            m1375a(writer, c0191v, str);
        }
        return str2;
    }

    static {
        f658b = "\n";
    }

    public static Writer m1373a(OutputStream outputStream) {
        try {
            return new OutputStreamWriter(outputStream, "ISO8859_1");
        } catch (UnsupportedEncodingException e) {
            return null;
        }
    }

    private synchronized void m1375a(Writer writer, C0191v c0191v, String str) {
        String c0191v2 = c0191v.toString();
        if (str == null) {
            str = "";
        }
        int length = (c0191v2.length() + str.length()) + 1;
        Appendable stringBuilder = new StringBuilder(length + (length / 5));
        C0173d.m1376a(stringBuilder, c0191v2, true);
        stringBuilder.append('=');
        C0173d.m1376a(stringBuilder, str, false);
        stringBuilder.append(f658b);
        writer.write(stringBuilder.toString());
        writer.flush();
    }

    public final void m1380a(C0173d c0173d) {
        for (C0191v c0191v : c0173d.keySet()) {
            if (m1378a(c0191v) == null) {
                put(c0191v, c0173d.m1378a(c0191v));
            }
        }
    }
}
