package com.facebook.p038e.p040b.p041a.p042a.p043a;

import android.content.Context;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.p053b.C0294h;
import com.facebook.p038e.C0253n;
import com.facebook.p038e.p040b.p041a.C0215a;
import com.facebook.p038e.p040b.p041a.C0220b;
import com.facebook.p038e.p040b.p041a.C0221c;
import com.facebook.p038e.p045d.C0242l;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

/* renamed from: com.facebook.e.b.a.a.a.b */
public final class C0216b extends C0215a {
    private static int f813a;
    private static Map f814b;
    private static Map f815c;
    private final C0220b f816d;
    private final C0220b f817e;
    private final C0220b f818f;
    private final C0220b f819g;
    private final Map f820h;
    private final C0220b f821i;
    private final C0220b f822j;

    static {
        f813a = 60000;
        f814b = new ConcurrentHashMap();
        f815c = new ConcurrentHashMap();
    }

    public C0216b(Context context) {
        super("image_instrument", C0253n.MUST_HAVE);
        this.f820h = new HashMap();
        this.f816d = new C0220b(context, "decode_fail");
        this.f817e = new C0220b(context, "received_image");
        this.f821i = new C0220b(context, "total_request");
        this.f822j = new C0220b(context, "used_image");
        this.f818f = new C0220b(context, "request_fail");
        this.f819g = new C0220b(context, "request_send_out");
        this.f820h.put(C0217c.DECODED_IMAGE_ERROR, this.f816d);
        this.f820h.put(C0217c.RECEIVED_IMAGE, this.f817e);
        this.f820h.put(C0217c.REQUEST_FAIL, this.f818f);
        this.f820h.put(C0217c.REQUEST_SEND_OUT, this.f819g);
        this.f820h.put(C0217c.USED, this.f822j);
    }

    public static void m1532d() {
        f814b.clear();
        f815c.clear();
    }

    public static void m1527a(int i) {
        C0213a c0213a = (C0213a) f814b.get(Integer.valueOf(i));
        if (c0213a != null) {
            if (c0213a.f808l.equals(C0217c.RECEIVED_IMAGE) || c0213a.f808l.equals(C0217c.USED)) {
                c0213a.f808l = C0217c.DECODED_IMAGE_ERROR;
            } else if (!c0213a.f808l.equals(C0217c.DECODED_IMAGE_ERROR)) {
                f814b.remove(Integer.valueOf(i));
            }
        }
    }

    private static int m1535f() {
        long currentTimeMillis = System.currentTimeMillis();
        int i = 0;
        for (Entry entry : f815c.entrySet()) {
            if (!((C0213a) entry.getValue()).f808l.equals(C0217c.REQUEST_SEND_OUT) || currentTimeMillis - ((C0213a) entry.getValue()).f807k <= ((long) f813a)) {
                i++;
            } else {
                ((C0213a) entry.getValue()).f808l = C0217c.REQUEST_FAIL;
            }
        }
        return i;
    }

    public static C0213a m1526a(int i, int i2, int i3, int i4, int i5, long j) {
        C0213a c0213a = (C0213a) f815c.get(Integer.valueOf(i));
        if (c0213a == null) {
            return null;
        }
        f815c.remove(Integer.valueOf(i));
        f814b.put(Integer.valueOf(i), c0213a);
        if (c0213a.f808l.equals(C0217c.REQUEST_SEND_OUT) || c0213a.f808l.equals(C0217c.REQUEST_FAIL)) {
            c0213a.f808l = C0217c.RECEIVED_IMAGE;
            c0213a.f800d = (int) (j - c0213a.f807k);
            c0213a.f810n = i2;
            c0213a.f798b = i3;
            c0213a.f802f = i4;
            c0213a.f809m = i5;
            c0213a.f805i = C0216b.m1535f();
            c0213a.f797a = ClientApplication.m1691c().m2378J().m44a();
            c0213a.f804h = C0242l.m1634b(ClientApplication.m1691c().m2377I());
            c0213a.f803g = C0242l.m1631a(ClientApplication.m1691c().m2377I());
            c0213a.f801e = C0294h.m1976g();
            return c0213a;
        }
        f815c.remove(Integer.valueOf(i));
        return null;
    }

    public static void m1534e() {
        long currentTimeMillis = System.currentTimeMillis();
        for (Entry value : f814b.entrySet()) {
            C0221c.f838c.m1529a(((C0213a) value.getValue()).f808l);
        }
        for (Entry value2 : f815c.entrySet()) {
            if (currentTimeMillis - ((C0213a) value2.getValue()).f807k > ((long) f813a)) {
                ((C0213a) value2.getValue()).f808l = C0217c.REQUEST_FAIL;
            }
            C0221c.f838c.m1529a(((C0213a) value2.getValue()).f808l);
        }
        C0221c.f838c.m1533d(f814b.size() + f815c.size());
    }

    public static void m1528a(int i, long j) {
        if (f815c.get(Integer.valueOf(i)) != null) {
            f815c.remove(Integer.valueOf(i));
        }
        f815c.put(Integer.valueOf(i), C0213a.m1519a(i, j, C0216b.m1535f()));
    }

    public static void m1530b(int i) {
        if (f813a < i) {
            f813a = i;
        }
    }

    public static C0213a m1531c(int i) {
        C0213a c0213a = (C0213a) f814b.get(Integer.valueOf(i));
        if (c0213a == null) {
            return null;
        }
        if (c0213a.f808l.equals(C0217c.USED)) {
            return null;
        }
        if (c0213a.f808l.equals(C0217c.RECEIVED_IMAGE)) {
            c0213a.f808l = C0217c.USED;
            return c0213a;
        }
        f814b.remove(Integer.valueOf(i));
        return null;
    }

    private void m1529a(C0217c c0217c) {
        if (this.f820h.get(c0217c) != null) {
            ((C0220b) this.f820h.get(c0217c)).m1547a(1);
        }
    }

    private void m1533d(int i) {
        this.f821i.m1547a(i);
    }

    protected final C0220b[] m1536c() {
        return new C0220b[]{this.f821i, this.f817e, this.f816d, this.f822j, this.f818f, this.f819g};
    }
}
