package com.facebook.rti.p046a.p072e.p073a;

import java.io.Serializable;

/* renamed from: com.facebook.rti.a.e.a.b */
public abstract class C0524b implements Serializable {
    public abstract boolean m3328a();

    public abstract Object m3329b();

    public static C0524b m3327c() {
        return C0525a.f2211a;
    }

    public static C0524b m3325a(Object obj) {
        if (obj != null) {
            return new C0526c(obj);
        }
        throw new NullPointerException();
    }

    public static C0524b m3326b(Object obj) {
        if (obj == null) {
            return C0525a.f2211a;
        }
        return new C0526c(obj);
    }

    C0524b() {
    }
}
