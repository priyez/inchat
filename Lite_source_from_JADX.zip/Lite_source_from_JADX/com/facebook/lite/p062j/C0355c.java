package com.facebook.lite.p062j;

/* renamed from: com.facebook.lite.j.c */
public final class C0355c {
    private final int f1400a;
    private final String f1401b;

    public C0355c(String str, int i) {
        this.f1401b = str;
        this.f1400a = i;
    }

    public final int m2501a() {
        return this.f1400a;
    }

    public final String m2502b() {
        return this.f1401b;
    }
}
