package com.facebook.lite.p062j;

import com.facebook.lite.ClientApplication;
import com.facebook.lite.widget.C0469r;

/* renamed from: com.facebook.lite.j.l */
final class C0364l implements C0358i {
    final /* synthetic */ C0366n f1422a;

    private C0364l(C0366n c0366n) {
        this.f1422a = c0366n;
    }

    public final String m2529a(StringBuilder stringBuilder) {
        C0469r h = ClientApplication.m1692d().m1790h();
        stringBuilder.append("Renderer: ");
        stringBuilder.append(h.getClass().getSimpleName());
        return stringBuilder.toString();
    }
}
