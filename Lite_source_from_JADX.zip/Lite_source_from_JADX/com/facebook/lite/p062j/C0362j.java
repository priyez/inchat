package com.facebook.lite.p062j;

import com.facebook.lite.p067o.C0424b;
import java.util.HashMap;

/* renamed from: com.facebook.lite.j.j */
public final class C0362j {
    private final C0424b f1416a;
    private final C0424b f1417b;
    private volatile Integer f1418c;
    private final C0424b f1419d;
    private final HashMap f1420e;

    public C0362j() {
        this.f1416a = new C0424b(8);
        this.f1417b = new C0424b(5);
        this.f1418c = Integer.valueOf(-1);
        this.f1419d = new C0424b(5);
        this.f1420e = new HashMap();
    }

    public final void m2521a(int i) {
        synchronized (this.f1416a) {
            this.f1416a.m2941a(i);
        }
    }

    public final void m2523b(int i) {
        synchronized (this.f1417b) {
            this.f1417b.m2941a(i);
        }
    }

    public final void m2525c(int i) {
        synchronized (this.f1419d) {
            this.f1419d.m2941a(i);
        }
    }

    public final int m2520a() {
        int a;
        synchronized (this.f1416a) {
            a = this.f1416a.m2940a();
        }
        return a;
    }

    public final int m2522b() {
        int a;
        synchronized (this.f1417b) {
            a = this.f1417b.m2940a();
        }
        return a;
    }

    public final int m2524c() {
        return this.f1418c.intValue();
    }

    public final int m2526d() {
        int a;
        synchronized (this.f1419d) {
            a = this.f1419d.m2940a();
        }
        return a;
    }

    public final void m2527d(int i) {
        this.f1418c = Integer.valueOf(i);
    }
}
