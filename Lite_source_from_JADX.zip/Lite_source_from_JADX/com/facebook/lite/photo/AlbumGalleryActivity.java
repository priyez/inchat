package com.facebook.lite.photo;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore.Images.Media;
import android.util.Log;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.facebook.lite.C0260h;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.MainActivity;
import com.facebook.lite.ao;
import com.facebook.lite.ap;
import com.facebook.lite.as;
import com.facebook.lite.p059m.C0387i;
import com.facebook.lite.widget.HorizontalProgressBar;
import java.util.ArrayList;
import java.util.Iterator;

public class AlbumGalleryActivity extends C0260h {
    private static final String f1726a;
    private boolean f1727b;
    private C0437f f1728c;
    private String f1729d;
    private GalleryItem f1730e;
    private int f1731f;
    private boolean f1732g;
    private GridView f1733h;
    private Handler f1734i;
    private ArrayList f1735j;
    private RelativeLayout f1736k;
    private HorizontalProgressBar f1737l;
    private TextView f1738m;
    private C0445n f1739n;
    private GalleryItem f1740o;
    private String f1741p;
    private String f1742q;
    private C0453w f1743r;
    private Runnable f1744s;

    static {
        f1726a = AlbumGalleryActivity.class.getSimpleName();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(ap.album_gallery_activity);
        ClientApplication.m1691c().m2413a(this);
        this.f1736k = (RelativeLayout) findViewById(as.loading);
        int intExtra = getIntent().getIntExtra("multi_picker_max_selected", 1);
        this.f1735j = getIntent().getParcelableArrayListExtra("selected_items");
        if (this.f1735j == null) {
            this.f1735j = new ArrayList();
        }
        this.f1739n = new C0445n(intExtra, this.f1735j);
        CharSequence stringExtra = getIntent().getStringExtra("title_text");
        CharSequence stringExtra2 = getIntent().getStringExtra("button_text");
        this.f1742q = getIntent().getStringExtra("preview_select");
        this.f1741p = getIntent().getStringExtra("preview_rotate");
        this.f1729d = getIntent().getStringExtra("button_color");
        this.f1727b = getIntent().getBooleanExtra("camera_enabled", false);
        this.f1731f = getIntent().getIntExtra("composer_screen_id", -1);
        new C0435d().execute(new Void[0]);
        this.f1733h = (GridView) findViewById(as.grid_view);
        this.f1738m = (TextView) findViewById(as.multipicker_next);
        this.f1737l = (HorizontalProgressBar) findViewById(as.progress_bar);
        TextView textView = (TextView) findViewById(as.upload_photo_text);
        if (stringExtra != null && stringExtra.length() > 0) {
            textView.setText(stringExtra);
        }
        if (stringExtra2 != null && stringExtra2.length() > 0) {
            this.f1738m.setText(stringExtra2);
        }
        if (this.f1729d != null && this.f1729d.length() > 0) {
            this.f1738m.setBackgroundColor(Color.parseColor(this.f1729d));
        }
        if (this.f1738m != null) {
            this.f1738m.setOnClickListener(new C0431a(this));
        }
        this.f1734i = new Handler();
        this.f1744s = new C0432b(this);
        this.f1743r = new C0453w(new Handler(), getContentResolver(), getApplicationContext());
        this.f1743r.m3084a(new C0434c(this));
        this.f1743r.start();
        this.f1743r.getLooper();
        Log.i(f1726a, "gallery/gallery background thread started.");
    }

    public void onDestroy() {
        super.onDestroy();
        this.f1743r.quit();
        this.f1743r.m3086b();
        Log.i(f1726a, "gallery/background thread destroy.");
    }

    public void onPause() {
        super.onPause();
        overridePendingTransition(0, 0);
    }

    public void onResume() {
        super.onResume();
        overridePendingTransition(0, 0);
    }

    public void onStop() {
        super.onStop();
        this.f1743r.m3082a();
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i2 == -1) {
            switch (i) {
                case 0:
                    Intent putExtra = new Intent().putExtra("camera_result", true);
                    if (ClientApplication.m1691c().m2387S() == null) {
                        putExtra = new Intent(this, MainActivity.class);
                        putExtra.putExtra("camera_result", true);
                        putExtra.setAction("com.facebook.lite.CAMERA");
                        putExtra.setType("image/jpeg");
                        startActivity(putExtra);
                        finish();
                    } else if (!ClientApplication.m1691c().m2387S().ap() || this.f1731f <= 0) {
                        setResult(-1, putExtra);
                        finish();
                    } else {
                        C0387i S = ClientApplication.m1691c().m2387S();
                        if (S == null) {
                            finish();
                        }
                        this.f1732g = true;
                        this.f1736k.setVisibility(0);
                        ClientApplication.m1691c().m2431b(putExtra);
                        S.aa().m1019k(this.f1731f);
                    }
                case 1:
                    int intExtra = intent.getIntExtra("user_rotate_degree", 0);
                    if (intExtra != 0) {
                        intExtra = (intExtra + this.f1740o.m2995d()) % 360;
                        this.f1743r.m3083a(this.f1740o.m2991b(), intExtra);
                        this.f1740o.m2994c(intExtra);
                    }
                    if (!this.f1740o.m2996e()) {
                        this.f1739n.m3070b(this.f1740o);
                    }
                    this.f1728c.notifyDataSetChanged();
                default:
            }
        } else if (i2 != 0) {
        } else {
            if (i == 0) {
                ClientApplication.m1691c().m2398a(i, i2, intent);
            } else if (i == 1) {
                this.f1728c.notifyDataSetChanged();
            }
        }
    }

    private Cursor m2974c() {
        return getApplicationContext().getContentResolver().query(Media.EXTERNAL_CONTENT_URI, new String[]{"_id"}, "", null, "_id DESC");
    }

    private boolean m2967a(int i, GalleryItem galleryItem) {
        if ((this.f1727b && i == 0) || galleryItem == null) {
            return false;
        }
        Intent intent = new Intent(getApplicationContext(), PreviewActivity.class);
        intent.putExtra("preview_id", galleryItem.m2991b());
        intent.putExtra("preview_select", this.f1742q);
        intent.putExtra("preview_rotate", this.f1741p);
        intent.putExtra("button_color", this.f1729d);
        intent.putExtra("user_rotate_degree", galleryItem.m2995d());
        startActivityForResult(intent, 1);
        return true;
    }

    private boolean m2976d() {
        ArrayList a = this.f1739n.m3067a();
        if (a.size() != this.f1735j.size()) {
            return true;
        }
        Iterator it = a.iterator();
        while (it.hasNext()) {
            if (!this.f1735j.contains((GalleryItem) it.next())) {
                return true;
            }
        }
        return false;
    }

    private boolean m2968a(int i, GalleryItem galleryItem, View view) {
        if (this.f1727b && i == 0) {
            if (this.f1739n.m3069b()) {
                this.f1739n.m3071c();
                return false;
            } else if (this.f1730e.m2996e()) {
                return false;
            } else {
                ClientApplication.m1691c().m2385Q();
                return false;
            }
        } else if (galleryItem == null) {
            return false;
        } else {
            if (galleryItem.m2996e()) {
                this.f1739n.m3068a(galleryItem);
            } else {
                this.f1739n.m3070b(galleryItem);
            }
            if (!this.f1735j.contains(galleryItem) && galleryItem.m2996e()) {
                this.f1730e.m2990a(Integer.MAX_VALUE);
            } else if (this.f1735j.contains(galleryItem) && !galleryItem.m2996e()) {
                this.f1730e.m2990a(Integer.MAX_VALUE);
            } else if (!m2976d()) {
                this.f1730e.m2989a();
            }
            this.f1728c.notifyDataSetChanged();
            m2973b(galleryItem, ((C0438g) view.getTag()).f1765b);
            return true;
        }
    }

    private static void m2973b(GalleryItem galleryItem, ImageView imageView) {
        if (galleryItem.m2996e()) {
            if (galleryItem.m2991b() == -1) {
                imageView.setBackgroundColor(Color.parseColor("#88000000"));
            } else {
                imageView.setBackgroundResource(ao.single_selection_mark);
            }
            imageView.setVisibility(0);
            return;
        }
        imageView.setVisibility(4);
    }
}
