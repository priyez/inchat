package com.facebook.lite.widget;

/* renamed from: com.facebook.lite.widget.i */
final class C0478i implements Runnable {
    final /* synthetic */ FbVideoView f2093a;

    C0478i(FbVideoView fbVideoView) {
        this.f2093a = fbVideoView;
    }

    public final void run() {
        this.f2093a.f1904h.setVisibility(8);
        this.f2093a.f1899c.setVisibility(8);
        this.f2093a.setVisibility(8);
    }
}
