package com.facebook.rti.p046a.p047b;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.SparseArray;
import com.facebook.rti.p046a.p074f.C0527a;

/* renamed from: com.facebook.rti.a.b.e */
public abstract class C0256e extends BroadcastReceiver {
    private static final SparseArray f948a;
    private static int f949b;

    static {
        f948a = new SparseArray();
        f949b = 1;
    }

    public static ComponentName m1696a(Context context, Intent intent) {
        synchronized (f948a) {
            int i = f949b;
            int i2 = f949b + 1;
            f949b = i2;
            if (i2 <= 0) {
                f949b = 1;
            }
            intent.putExtra("android.support.content.wakelockid", i);
            ComponentName startService = context.startService(intent);
            if (startService == null) {
                return null;
            }
            WakeLock newWakeLock = ((PowerManager) context.getSystemService("power")).newWakeLock(1, "wake:" + startService.flattenToShortString());
            newWakeLock.setReferenceCounted(false);
            newWakeLock.acquire(60000);
            f948a.put(i, newWakeLock);
            return startService;
        }
    }

    public static boolean m1697a(Intent intent) {
        int intExtra = intent.getIntExtra("android.support.content.wakelockid", 0);
        if (intExtra == 0) {
            return false;
        }
        synchronized (f948a) {
            WakeLock wakeLock = (WakeLock) f948a.get(intExtra);
            if (wakeLock != null) {
                wakeLock.release();
                f948a.remove(intExtra);
                return true;
            }
            C0527a.m3343e("WakefulBroadcastReceiver", "No active wake lock id #%s", Integer.valueOf(intExtra));
            return true;
        }
    }
}
