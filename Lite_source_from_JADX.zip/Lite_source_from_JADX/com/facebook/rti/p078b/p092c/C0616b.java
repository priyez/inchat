package com.facebook.rti.p078b.p092c;

import com.facebook.rti.p078b.p080b.p081a.C0539a;
import com.facebook.rti.p078b.p080b.p084d.C0583e;
import java.util.Map;

/* renamed from: com.facebook.rti.b.c.b */
public final class C0616b extends C0615a {
    private C0583e f2526b;

    public C0616b(C0539a c0539a, C0583e c0583e) {
        super(c0539a);
        this.f2526b = c0583e;
    }

    protected final String m3533a() {
        return "MqttNetworkManagerMonitor";
    }

    protected final boolean m3534b(Map map) {
        boolean b = this.f2526b.m3482b();
        if (!b) {
            m3530a(map, this.f2526b.m3483c());
        }
        return b;
    }
}
