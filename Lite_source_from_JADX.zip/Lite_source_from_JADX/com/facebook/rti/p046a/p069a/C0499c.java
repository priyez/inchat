package com.facebook.rti.p046a.p069a;

import android.util.Base64;
import com.facebook.rti.p046a.p074f.C0527a;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.DeflaterOutputStream;

/* renamed from: com.facebook.rti.a.a.c */
public class C0499c {
    private static final String f2129a;
    private final String f2130b;
    private final C0502f f2131c;
    private final String f2132d;

    static {
        f2129a = C0499c.class.getSimpleName();
    }

    public C0499c(String str, C0502f c0502f, String str2) {
        this.f2130b = str;
        this.f2131c = c0502f;
        this.f2132d = str2;
    }

    public final int m3288a(String str) {
        Map hashMap = new HashMap();
        hashMap.put("method", "logging.clientevent");
        hashMap.put("format", "json");
        hashMap.put("access_token", this.f2130b);
        try {
            String str2 = "message";
            if (str == null) {
                C0527a.m3343e(f2129a, "Json data cannot be null", new Object[0]);
            }
            byte[] bytes = str.getBytes("UTF-8");
            OutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(byteArrayOutputStream);
            deflaterOutputStream.write(bytes);
            deflaterOutputStream.close();
            hashMap.put(str2, Base64.encodeToString(byteArrayOutputStream.toByteArray(), 2));
            hashMap.put("compressed", "1");
        } catch (Throwable e) {
            C0527a.m3339b(f2129a, e, "Unable to compress message to Json object, using original message", new Object[0]);
            hashMap.put("message", str);
        }
        return this.f2131c.m3295a(hashMap, this.f2132d);
    }
}
