package com.facebook.lite.widget;

import android.widget.ImageView;
import android.widget.TextView;

/* renamed from: com.facebook.lite.widget.f */
final class C0475f {
    ImageView f2081a;
    TextView f2082b;

    C0475f() {
    }
}
