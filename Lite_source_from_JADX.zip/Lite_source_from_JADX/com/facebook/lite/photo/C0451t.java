package com.facebook.lite.photo;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

/* renamed from: com.facebook.lite.photo.t */
final class C0451t extends Handler {
    final /* synthetic */ C0453w f1794a;

    C0451t(C0453w c0453w) {
        this.f1794a = c0453w;
    }

    public final void handleMessage(Message message) {
        if (message.what == 0) {
            Object obj = message.obj;
            if (obj != null) {
                Log.i(C0453w.f1799f, "thumbnail/got a request for origId: " + this.f1794a.f1805e.get(obj));
                this.f1794a.m3079a(obj);
            }
        }
    }
}
