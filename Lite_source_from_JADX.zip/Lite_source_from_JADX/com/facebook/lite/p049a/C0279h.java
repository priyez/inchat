package com.facebook.lite.p049a;

import android.util.Log;
import com.facebook.lite.p049a.p050a.C0261a;
import com.p026b.p027a.C0132d;
import com.p026b.p027a.C0134f;

/* renamed from: com.facebook.lite.a.h */
final class C0279h extends C0263a {
    final /* synthetic */ C0280i f1066a;
    private final int f1067b;
    private final C0261a f1068c;
    private final C0261a f1069d;

    public C0279h(C0280i c0280i, int i, C0261a c0261a, C0261a c0261a2, long j) {
        this.f1066a = c0280i;
        super(j);
        this.f1067b = i;
        this.f1068c = c0261a;
        this.f1069d = c0261a2;
    }

    public final void run() {
        try {
            C0134f b = this.f1068c.m1806d().m1293b(Integer.toString(this.f1067b));
            if (b != null) {
                byte[] a = b.m1264a();
                try {
                    C0132d a2 = this.f1069d.m1806d().m1289a(Integer.toString(this.f1067b));
                    if (a2 != null) {
                        a2.m1248a(a);
                        a2.m1249b();
                        try {
                            this.f1068c.m1806d().m1294c(Integer.toString(this.f1067b));
                            C0280i.f1070a;
                            new StringBuilder().append(C0280i.m1873a(this.f1069d.m1804b())).append("transferfiletask success from: ").append(this.f1068c.m1804b()).append(" fileId: ").append(this.f1067b);
                        } catch (Throwable e) {
                            Log.e(C0280i.f1070a, C0280i.m1873a(this.f1069d.m1804b()) + "transferfiletask/could not remove " + this.f1067b, e);
                        }
                    }
                } catch (Throwable e2) {
                    Log.e(C0280i.f1070a, C0280i.m1873a(this.f1069d.m1804b()) + "transferfiletask/could not write " + this.f1067b, e2);
                }
            }
        } catch (Throwable e22) {
            Log.e(C0280i.f1070a, C0280i.m1873a(this.f1068c.m1804b()) + "transferfiletask/could not retrieve " + this.f1067b, e22);
        }
    }
}
