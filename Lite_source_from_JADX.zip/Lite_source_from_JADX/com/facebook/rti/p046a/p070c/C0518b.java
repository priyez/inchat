package com.facebook.rti.p046a.p070c;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* renamed from: com.facebook.rti.a.c.b */
public final class C0518b {
    private static final ThreadFactory f2190a;
    private static final BlockingQueue f2191b;
    private static final Executor f2192c;

    public static Executor m3316a() {
        return f2192c;
    }

    static {
        f2190a = new C0517a();
        f2191b = new LinkedBlockingQueue(10);
        f2192c = new ThreadPoolExecutor(5, 128, 1, TimeUnit.SECONDS, f2191b, f2190a);
    }
}
