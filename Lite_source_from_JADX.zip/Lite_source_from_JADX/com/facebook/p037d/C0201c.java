package com.facebook.p037d;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/* renamed from: com.facebook.d.c */
public final class C0201c {
    private static final Set f785a;

    static {
        f785a = new HashSet(Arrays.asList(new String[]{"ijxLJi1yGs1JpL-X1SExmchvork", "xW-31ZG6ZwTfBH_Zj1NTcv6gAhE", "OKD31QX-GP7GT780Psqq8xDb15k", "Sr9mhPKOEwo6NysnYn803dZ3UiY", "Xo8WBi6jzSxKDVR4drqm84yr9iU"}));
    }

    public static boolean m1502a(String str) {
        return f785a.contains(str);
    }
}
