package com.facebook.lite.p056d;

import android.content.Context;
import com.facebook.lite.p053b.C0296j;
import org.json.JSONObject;

/* renamed from: com.facebook.lite.d.h */
public final class C0315h extends C0309a {
    private boolean f1234b;
    private boolean f1235c;
    private boolean f1236d;
    private boolean f1237e;
    private boolean f1238f;
    private boolean f1239g;
    private boolean f1240h;
    private boolean f1241i;
    private boolean f1242j;
    private boolean f1243k;
    private boolean f1244l;
    private boolean f1245m;
    private boolean f1246n;

    public static C0315h m2235b(Context context) {
        return (C0315h) C0315h.m2234b().m2216a(context);
    }

    public static C0315h m2234b() {
        return C0314g.f1233a;
    }

    public final String m2236a() {
        return "push_feedback";
    }

    public final boolean m2238c() {
        return this.f1234b;
    }

    public final boolean m2239d() {
        return this.f1235c;
    }

    public final boolean m2240e() {
        return this.f1236d;
    }

    public final boolean m2241f() {
        return this.f1237e;
    }

    public final boolean m2242g() {
        return this.f1238f;
    }

    public final boolean m2243h() {
        return this.f1239g;
    }

    public final boolean m2244i() {
        return this.f1240h;
    }

    public final boolean m2245j() {
        return this.f1241i;
    }

    public final boolean m2246k() {
        return this.f1242j;
    }

    public final boolean m2247l() {
        return this.f1243k;
    }

    public final boolean m2248m() {
        return this.f1244l;
    }

    public final boolean m2249n() {
        return this.f1245m;
    }

    public final boolean m2250o() {
        return this.f1246n;
    }

    protected final void m2237a(JSONObject jSONObject) {
        this.f1234b = C0296j.m1991a(jSONObject, "disable_all_types", false);
        this.f1235c = C0296j.m1991a(jSONObject, "disable_birthday_type", false);
        this.f1236d = C0296j.m1991a(jSONObject, "disable_comment_type", false);
        this.f1237e = C0296j.m1991a(jSONObject, "disable_event_type", false);
        this.f1238f = C0296j.m1991a(jSONObject, "disable_friend_confirmation_type", false);
        this.f1239g = C0296j.m1991a(jSONObject, "disable_friend_request_type", false);
        this.f1240h = C0296j.m1991a(jSONObject, "disable_group_type", false);
        this.f1241i = C0296j.m1991a(jSONObject, "disable_lights", false);
        this.f1242j = C0296j.m1991a(jSONObject, "disable_message_type", false);
        this.f1243k = C0296j.m1991a(jSONObject, "disable_photo_tag_type", false);
        this.f1244l = C0296j.m1991a(jSONObject, "disable_sound", false);
        this.f1245m = C0296j.m1991a(jSONObject, "disable_vibrate", false);
        this.f1246n = C0296j.m1991a(jSONObject, "disable_wall_post_type", false);
    }
}
