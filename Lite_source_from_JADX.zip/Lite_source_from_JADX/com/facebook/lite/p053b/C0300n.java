package com.facebook.lite.p053b;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.facebook.lite.net.p066a.C0394b;
import com.facebook.lite.p055c.C0305a;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/* renamed from: com.facebook.lite.b.n */
public final class C0300n {
    public static int m2090a(Context context, String str) {
        String str2 = "counter_" + str;
        int b = C0300n.m2103b(context, str2, 0);
        C0300n.m2116c(context, str2, 0);
        return b;
    }

    public static String m2092a(Context context) {
        return C0300n.m2106b(context, "android_id", "");
    }

    public static int m2102b(Context context) {
        return C0300n.m2103b(context, "view_height", 0);
    }

    public static int m2112c(Context context) {
        return C0300n.m2103b(context, "app_version_code", 0);
    }

    public static int m2120d(Context context) {
        return C0300n.m2103b(context, "view_width", 0);
    }

    public static long m2125e(Context context) {
        return C0300n.m2104b(context, "auto_update_scheduled_timestamp", 0);
    }

    public static long m2130f(Context context) {
        return C0300n.m2104b(context, "generic_cache_last_report_date", 0);
    }

    public static String m2135g(Context context) {
        return C0300n.m2106b(context, "camera_uri", null);
    }

    public static C0305a m2139h(Context context) {
        String b = C0300n.m2106b(context, "client_composer_state", null);
        if (b == null || b.length() == 0) {
            return new C0305a();
        }
        return C0305a.m2185a(b);
    }

    public static String m2105b(Context context, String str) {
        return C0300n.m2106b(context, str, null);
    }

    public static long m2143i(Context context) {
        return C0300n.m2104b(context, "current_user_id", 0);
    }

    public static String m2146j(Context context) {
        return C0300n.m2106b(context, "device_id", null);
    }

    public static long m2148k(Context context) {
        return C0300n.m2104b(context, "device_id_generated_timestamp", Long.MAX_VALUE);
    }

    public static long m2150l(Context context) {
        return C0300n.m2104b(context, "deivce_id_last_sync_timestamp", 0);
    }

    public static String m2152m(Context context) {
        return C0300n.m2106b(context, "fail_to_delete_disk_cache_file", null);
    }

    public static int m2154n(Context context) {
        return C0300n.m2103b(context, "font_cache_version", -1);
    }

    public static boolean m2157o(Context context) {
        return C0300n.m2101a(context, "generic_cache_enabled", false);
    }

    public static String m2158p(Context context) {
        return C0300n.m2106b(context, "generic_cache_id_attribute_map_json", null);
    }

    public static String m2159q(Context context) {
        return C0300n.m2106b(context, "generic_cache_stats", null);
    }

    public static String m2160r(Context context) {
        return C0300n.m2106b(context, "google_ad_id", null);
    }

    public static boolean m2161s(Context context) {
        return C0300n.m2101a(context, "google_opt_out_interest_based_ads", false);
    }

    public static String m2162t(Context context) {
        return C0300n.m2106b(context, "installation_source", null);
    }

    public static Map m2163u(Context context) {
        Map hashMap = new HashMap();
        SharedPreferences sharedPreferences = context.getSharedPreferences("vip_pool_cache", 0);
        if (sharedPreferences != null) {
            for (Entry entry : sharedPreferences.getAll().entrySet()) {
                hashMap.put((String) entry.getKey(), C0394b.valueOf((String) entry.getValue()));
            }
        }
        return hashMap;
    }

    public static boolean m2164v(Context context) {
        return C0300n.m2101a(context, "gl_debug_mode", false);
    }

    public static int m2165w(Context context) {
        return C0300n.m2103b(context, "largest_supported_picture_size", Integer.MIN_VALUE);
    }

    public static long m2166x(Context context) {
        return C0300n.m2104b(context, "battery_status", Long.MIN_VALUE);
    }

    public static long m2167y(Context context) {
        return C0300n.m2104b(context, "last_device_info", Long.MIN_VALUE);
    }

    public static long m2113c(Context context, String str) {
        return C0300n.m2104b(context, "periodic_report_timestamp_" + str, 0);
    }

    public static String m2168z(Context context) {
        return C0300n.m2106b(context, "uid_and_nonce", null);
    }

    public static long m2073A(Context context) {
        return C0300n.m2104b(context, "push_received_timestamp", Long.MAX_VALUE);
    }

    public static long m2074B(Context context) {
        return C0300n.m2104b(context, "push_registered_timestamp", Long.MAX_VALUE);
    }

    public static int m2075C(Context context) {
        return C0300n.m2103b(context, "renderer_type", 0);
    }

    public static int m2076D(Context context) {
        return C0300n.m2103b(context, "renderer_type_override", 0);
    }

    public static String m2077E(Context context) {
        return C0300n.m2106b(context, "server_locale", null);
    }

    private static SharedPreferences m2089Q(Context context) {
        return context.getSharedPreferences(context.getPackageName(), 0);
    }

    public static int m2078F(Context context) {
        return C0300n.m2103b(context, "soft_keyboard_height", 0);
    }

    public static String m2079G(Context context) {
        return C0300n.m2106b(context, "sso_token", "");
    }

    public static boolean m2080H(Context context) {
        return C0300n.m2101a(context, "tcp_nodelay", false);
    }

    public static int m2081I(Context context) {
        return C0300n.m2103b(context, "android_transition_steps", 8);
    }

    public static int m2082J(Context context) {
        return C0300n.m2103b(context, "android_transition_time", 160);
    }

    public static int m2091a(Context context, String str, int i) {
        String str2 = "counter_" + str;
        int b = C0300n.m2103b(context, str2, 0) + i;
        C0300n.m2116c(context, str2, b);
        return b;
    }

    public static boolean m2083K(Context context) {
        return C0300n.m2101a(context, "push_reception_enabled", true);
    }

    public static boolean m2084L(Context context) {
        return C0300n.m2101a(context, "push_registration_enabled", true);
    }

    public static void m2085M(Context context) {
        C0300n.m2156o(context, "uid_and_nonce");
    }

    public static void m2086N(Context context) {
        C0300n.m2118c(context, "camera_uri", null);
    }

    public static void m2087O(Context context) {
        C0300n.m2118c(context, "client_composer_state", null);
    }

    public static void m2088P(Context context) {
        C0300n.m2145i(context, null);
    }

    public static void m2123d(Context context, String str) {
        C0300n.m2118c(context, "android_id", str);
    }

    public static void m2093a(Context context, int i) {
        C0300n.m2116c(context, "app_version_code", i);
    }

    public static void m2107b(Context context, int i) {
        C0300n.m2116c(context, "view_width", i);
    }

    public static void m2094a(Context context, long j) {
        C0300n.m2117c(context, "auto_update_scheduled_timestamp", j);
    }

    public static void m2108b(Context context, long j) {
        C0300n.m2117c(context, "battery_status", j);
    }

    public static void m2115c(Context context, long j) {
        C0300n.m2117c(context, "generic_cache_last_report_date", j);
    }

    public static void m2128e(Context context, String str) {
        C0300n.m2118c(context, "camera_uri", str);
    }

    public static void m2095a(Context context, C0305a c0305a) {
        C0300n.m2118c(context, "client_composer_state", c0305a == null ? "" : c0305a.m2206k());
    }

    public static void m2098a(Context context, String str, String str2) {
        Editor edit = C0300n.m2089Q(context).edit();
        edit.putString(str, str2);
        edit.commit();
    }

    public static void m2122d(Context context, long j) {
        C0300n.m2117c(context, "current_user_id", j);
    }

    public static void m2133f(Context context, String str) {
        C0300n.m2118c(context, "device_id", str);
    }

    public static void m2127e(Context context, long j) {
        C0300n.m2117c(context, "device_id_generated_timestamp", j);
    }

    public static void m2132f(Context context, long j) {
        C0300n.m2117c(context, "deivce_id_last_sync_timestamp", j);
    }

    public static void m2138g(Context context, String str) {
        C0300n.m2118c(context, "fail_to_delete_disk_cache_file", str);
    }

    public static void m2114c(Context context, int i) {
        C0300n.m2116c(context, "font_cache_version", i);
    }

    public static void m2100a(Context context, boolean z) {
        C0300n.m2110b(context, "generic_cache_enabled", z);
    }

    public static void m2142h(Context context, String str) {
        C0300n.m2118c(context, "generic_cache_id_attribute_map_json", str);
    }

    public static void m2145i(Context context, String str) {
        C0300n.m2118c(context, "generic_cache_stats", str);
    }

    public static void m2147j(Context context, String str) {
        C0300n.m2118c(context, "google_ad_id", str);
    }

    public static void m2111b(Context context, boolean z) {
        C0300n.m2110b(context, "google_opt_out_interest_based_ads", z);
    }

    public static void m2149k(Context context, String str) {
        C0300n.m2118c(context, "installation_source", str);
    }

    public static void m2099a(Context context, Map map) {
        Editor edit = context.getSharedPreferences("vip_pool_cache", 0).edit();
        for (Entry entry : map.entrySet()) {
            edit.putString((String) entry.getKey(), ((C0394b) entry.getValue()).name());
        }
        edit.commit();
    }

    public static void m2119c(Context context, boolean z) {
        C0300n.m2110b(context, "gl_debug_mode", z);
    }

    public static void m2121d(Context context, int i) {
        C0300n.m2116c(context, "largest_supported_picture_size", i);
    }

    public static void m2137g(Context context, long j) {
        C0300n.m2117c(context, "last_device_info", j);
    }

    public static void m2097a(Context context, String str, long j) {
        C0300n.m2117c(context, "periodic_report_timestamp_" + str, j);
    }

    public static void m2151l(Context context, String str) {
        C0300n.m2118c(context, "uid_and_nonce", str);
    }

    public static void m2141h(Context context, long j) {
        C0300n.m2117c(context, "push_received_timestamp", j);
    }

    public static void m2124d(Context context, boolean z) {
        C0300n.m2110b(context, "push_reception_enabled", z);
    }

    public static void m2129e(Context context, boolean z) {
        C0300n.m2110b(context, "push_registration_enabled", z);
    }

    public static void m2144i(Context context, long j) {
        C0300n.m2117c(context, "push_registered_timestamp", j);
    }

    public static void m2126e(Context context, int i) {
        C0300n.m2116c(context, "renderer_type", i);
    }

    public static void m2131f(Context context, int i) {
        C0300n.m2116c(context, "renderer_type_override", i);
    }

    public static void m2153m(Context context, String str) {
        C0300n.m2118c(context, "server_locale", str);
    }

    public static void m2136g(Context context, int i) {
        C0300n.m2116c(context, "soft_keyboard_height", i);
    }

    public static void m2155n(Context context, String str) {
        C0300n.m2118c(context, "sso_token", str);
    }

    public static void m2134f(Context context, boolean z) {
        C0300n.m2110b(context, "tcp_nodelay", z);
    }

    public static void m2096a(Context context, Integer num) {
        C0300n.m2116c(context, "android_transition_steps", num.intValue());
    }

    public static void m2109b(Context context, Integer num) {
        C0300n.m2116c(context, "android_transition_time", num.intValue());
    }

    public static void m2140h(Context context, int i) {
        C0300n.m2116c(context, "view_height", i);
    }

    private static boolean m2101a(Context context, String str, boolean z) {
        return C0300n.m2089Q(context).getBoolean(str, z);
    }

    private static int m2103b(Context context, String str, int i) {
        return C0300n.m2089Q(context).getInt(str, i);
    }

    private static long m2104b(Context context, String str, long j) {
        return C0300n.m2089Q(context).getLong(str, j);
    }

    private static String m2106b(Context context, String str, String str2) {
        return C0300n.m2089Q(context).getString(str, str2);
    }

    private static void m2156o(Context context, String str) {
        C0300n.m2089Q(context).edit().remove(str).commit();
    }

    private static void m2110b(Context context, String str, boolean z) {
        Editor edit = C0300n.m2089Q(context).edit();
        edit.putBoolean(str, z);
        edit.commit();
    }

    private static void m2116c(Context context, String str, int i) {
        Editor edit = C0300n.m2089Q(context).edit();
        edit.putInt(str, i);
        edit.commit();
    }

    private static void m2117c(Context context, String str, long j) {
        Editor edit = C0300n.m2089Q(context).edit();
        edit.putLong(str, j);
        edit.commit();
    }

    private static void m2118c(Context context, String str, String str2) {
        Editor edit = C0300n.m2089Q(context).edit();
        edit.putString(str, str2);
        edit.commit();
    }
}
