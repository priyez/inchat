package com.facebook.lite.notification;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.facebook.lite.notification.SystemTrayNotification.NotificationType;

/* renamed from: com.facebook.lite.notification.i */
final class C0420i implements Creator {
    C0420i() {
    }

    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        return C0420i.m2930a(parcel);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return C0420i.m2931a(i);
    }

    private static NotificationType m2930a(Parcel parcel) {
        NotificationType notificationType = NotificationType.values()[parcel.readInt()];
        notificationType.m2901a(parcel.readInt());
        return notificationType;
    }

    private static NotificationType[] m2931a(int i) {
        return new NotificationType[i];
    }
}
