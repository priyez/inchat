package com.facebook.p031b.p033b;

import android.net.Uri;
import com.facebook.p031b.C0148a;
import com.facebook.p031b.C0173d;
import com.facebook.p031b.C0191v;
import com.facebook.p031b.p034c.C0160g;
import java.net.Proxy;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.facebook.b.b.b */
public final class C0151b implements C0150a {
    private Uri f626a;
    private Proxy f627b;

    public C0151b(String str) {
        this.f626a = Uri.parse(str);
    }

    public final void m1335a(C0173d c0173d) {
        try {
            Map a = C0151b.m1334a((Map) c0173d);
            URL url = new URL(this.f626a.toString());
            String str = C0148a.f621a;
            new StringBuilder("Connect to ").append(url.toString());
            C0160g.m1346a(a, url, C0148a.m1327a().m1316c(), this.f627b);
        } catch (Throwable e) {
            throw new C0152d("Error while sending report to Http Post Form.", e);
        }
    }

    public final boolean m1336a(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        if (str.equals(this.f626a.getHost())) {
            return true;
        }
        this.f626a = this.f626a.buildUpon().authority(str).build();
        return true;
    }

    private static Map m1334a(Map map) {
        Map hashMap = new HashMap(map.size());
        for (C0191v c0191v : C0148a.f622b) {
            String str = (String) map.get(c0191v);
            if (!(str == null || str.isEmpty())) {
                hashMap.put(c0191v.toString(), str);
            }
        }
        return hashMap;
    }
}
