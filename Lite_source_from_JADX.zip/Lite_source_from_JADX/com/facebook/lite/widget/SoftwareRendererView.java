package com.facebook.lite.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.os.Build.VERSION;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.Choreographer.FrameCallback;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p059m.C0387i;
import com.facebook.lite.p062j.C0353a;
import com.facebook.lite.p062j.C0362j;
import com.facebook.lite.p062j.C0366n;
import com.facebook.lite.ui.C0460b;
import com.facebook.lite.ui.C0462d;
import com.p008a.p009a.p010a.p012b.C0019m;
import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p022l.C0094y;

public class SoftwareRendererView extends SurfaceView implements Callback, C0469r {
    private boolean f2003a;
    private final long f2004b;
    private boolean f2005c;
    private View f2006d;
    private volatile int f2007e;
    private final SurfaceHolder f2008f;
    private long f2009g;
    private C0022b f2010h;
    private C0362j f2011i;
    private boolean f2012j;
    private C0353a f2013k;
    private C0353a f2014l;
    private FrameCallback f2015m;
    private int f2016n;
    private int f2017o;
    private C0462d f2018p;
    private C0019m f2019q;
    private volatile int f2020r;
    private C0094y f2021s;

    public SoftwareRendererView(Context context) {
        this(context, null);
    }

    public SoftwareRendererView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public SoftwareRendererView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f2008f = getHolder();
        this.f2008f.addCallback(this);
        if (VERSION.SDK_INT >= 16) {
            this.f2015m = new ao(this);
            this.f2015m.doFrame(0);
        }
        this.f2004b = (long) (1000 / C0294h.m1975g(context));
    }

    public final View m3257a() {
        return this;
    }

    public Bitmap getScreenshot() {
        return Bitmap.createBitmap(this.f2021s.m1031q(), this.f2020r, this.f2007e, Config.ARGB_8888);
    }

    public void onPause() {
    }

    public void onResume() {
    }

    public final void m3258a(int i) {
        C0300n.m2136g(getContext(), i);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.f2005c) {
            if (this.f2006d == null) {
                this.f2005c = false;
            } else {
                this.f2006d.dispatchTouchEvent(motionEvent);
                return true;
            }
        }
        if (!this.f2003a) {
            return super.onTouchEvent(motionEvent);
        }
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        switch (motionEvent.getAction() & 255) {
            case 0:
                try {
                    this.f2019q.m114b((int) x, (int) y);
                    return true;
                } catch (Throwable th) {
                    this.f2010h.m124a((short) 102, null, th);
                    return true;
                }
            case 1:
                try {
                    this.f2019q.m116c((int) x, (int) y);
                    return true;
                } catch (Throwable th2) {
                    this.f2010h.m124a((short) 102, null, th2);
                    return true;
                }
            case 2:
                try {
                    this.f2019q.m112a((int) x, (int) y);
                    return true;
                } catch (Throwable th22) {
                    this.f2010h.m124a((short) 102, null, th22);
                    return true;
                }
            case 5:
                try {
                    this.f2019q.m119q();
                    return true;
                } catch (Throwable th222) {
                    this.f2010h.m124a((short) 102, null, th222);
                    return true;
                }
            case 99:
                try {
                    this.f2019q.m117d((int) x, (int) y);
                    return true;
                } catch (Throwable th2222) {
                    this.f2010h.m124a((short) 102, null, th2222);
                    return true;
                }
            default:
                return true;
        }
    }

    public final void m3260a(int[] iArr) {
        if (this.f2003a && this.f2021s != null && iArr != null && iArr.length >= this.f2020r * this.f2007e) {
            long uptimeMillis = SystemClock.uptimeMillis();
            Canvas lockCanvas = this.f2008f.lockCanvas();
            if (lockCanvas != null) {
                lockCanvas.drawBitmap(iArr, 0, this.f2020r, 0, 0, this.f2020r, this.f2007e, false, null);
                if (this.f2016n > 0) {
                    this.f2013k.m2498a(lockCanvas);
                }
                if (this.f2017o > 0) {
                    this.f2014l.m2498a(lockCanvas);
                }
                this.f2008f.unlockCanvasAndPost(lockCanvas);
                m3256a(uptimeMillis, SystemClock.uptimeMillis());
            }
        }
    }

    public final void m3259a(View view, boolean z) {
        this.f2005c = z;
        this.f2006d = view;
    }

    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
        if (this.f2021s != null) {
            m3260a(this.f2021s.m1031q());
        }
    }

    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        this.f2018p = new C0462d(getResources(), this);
        this.f2020r = C0300n.m2120d(getContext());
        this.f2007e = C0300n.m2102b(getContext());
        C0387i S = ClientApplication.m1691c().m2387S();
        this.f2019q = S.m2651Z();
        this.f2021s = S.aa();
        this.f2010h = S.m2642Q();
        this.f2013k = S.m2645T();
        this.f2014l = S.m2646U();
        this.f2011i = ((C0366n) this.f2014l).m2535a();
        if (!this.f2012j) {
            this.f2012j = true;
            this.f2017o = this.f2014l.m2497a(this.f2020r);
            this.f2016n = this.f2013k.m2497a(this.f2020r);
        }
        this.f2021s.m987b(true, this.f2020r * this.f2007e);
        this.f2003a = true;
    }

    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        this.f2003a = false;
    }

    protected void onMeasure(int i, int i2) {
        if (this.f2018p != null) {
            this.f2018p.m3126a(this, i2);
        }
        super.onMeasure(i, i2);
    }

    private void m3256a(long j, long j2) {
        this.f2011i.m2523b((int) (j2 - j));
        if (this.f2021s.m940E()) {
            this.f2011i.m2525c((int) ((this.f2004b + this.f2009g) - ((C0460b) this.f2021s).m3101V()));
        }
    }
}
