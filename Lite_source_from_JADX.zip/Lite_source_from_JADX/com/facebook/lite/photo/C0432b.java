package com.facebook.lite.photo;

/* renamed from: com.facebook.lite.photo.b */
final class C0432b implements Runnable {
    final /* synthetic */ AlbumGalleryActivity f1757a;

    C0432b(AlbumGalleryActivity albumGalleryActivity) {
        this.f1757a = albumGalleryActivity;
    }

    public final void run() {
        if (!this.f1757a.f1737l.m3196a()) {
            this.f1757a.f1737l.m3197b();
            this.f1757a.f1734i.postDelayed(this.f1757a.f1744s, 25);
        }
    }
}
