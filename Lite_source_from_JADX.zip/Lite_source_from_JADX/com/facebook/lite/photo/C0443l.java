package com.facebook.lite.photo;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Matrix.ScaleToFit;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Build.VERSION;
import android.util.Log;
import com.facebook.lite.p049a.C0283l;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p053b.C0300n;
import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p023m.C0119g;
import java.io.File;
import java.io.RandomAccessFile;
import java.nio.Buffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* renamed from: com.facebook.lite.photo.l */
public class C0443l {
    private static C0283l f1774a;
    private static final String f1775b;
    private final Context f1776c;
    private final Set f1777d;
    private final C0022b f1778e;
    private final ThreadPoolExecutor f1779f;
    private int f1780g;
    private int f1781h;
    private final PriorityBlockingQueue f1782i;

    static {
        f1774a = null;
        f1775b = C0443l.class.getSimpleName();
    }

    public C0443l(Context context, C0022b c0022b) {
        this.f1777d = new HashSet();
        this.f1780g = 0;
        this.f1781h = 0;
        this.f1776c = context;
        if (f1774a == null) {
            long j = C0294h.m1980j(context);
            f1774a = new C0440i(this, j / 8 > 2147483647L ? Integer.MAX_VALUE : (int) (j / 8));
        }
        this.f1782i = new PriorityBlockingQueue();
        this.f1778e = c0022b;
        this.f1779f = new ThreadPoolExecutor(1, 1, 2147483647L, TimeUnit.SECONDS, this.f1782i, new C0441j(this));
    }

    public static Bitmap m3022a(Bitmap bitmap, int i, int i2, int i3, int i4, int i5, int i6, C0022b c0022b) {
        boolean z = false;
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        boolean z2 = (width == i && height == i2) ? false : true;
        if (!(i == i5 && i2 == i6)) {
            z = true;
        }
        if (z2 && z) {
            Matrix matrix = new Matrix();
            Bitmap createBitmap;
            if (matrix.setRectToRect(new RectF(0.0f, 0.0f, (float) width, (float) height), new RectF(0.0f, 0.0f, (float) i, (float) i2), ScaleToFit.FILL)) {
                createBitmap = Bitmap.createBitmap(i5, i6, Config.ARGB_8888);
                Canvas canvas = new Canvas(createBitmap);
                Paint paint = new Paint();
                canvas.translate((float) (-i3), (float) (-i4));
                paint.setFilterBitmap(true);
                canvas.drawBitmap(bitmap, matrix, paint);
                return createBitmap;
            }
            c0022b.m126a((short) 3, (short) 270, "setRectToRect failed");
            createBitmap = Bitmap.createScaledBitmap(bitmap, i, i2, true);
            bitmap = Bitmap.createBitmap(createBitmap, i3, i4, i5, i6);
            if (createBitmap == bitmap) {
                return bitmap;
            }
            createBitmap.recycle();
            return bitmap;
        } else if (z2) {
            return Bitmap.createScaledBitmap(bitmap, i, i2, true);
        } else {
            if (z) {
                return Bitmap.createBitmap(bitmap, i3, i4, i5, i6);
            }
            return bitmap;
        }
    }

    @TargetApi(12)
    private static void m3025a(Bitmap bitmap) {
        if (bitmap.isMutable() && VERSION.SDK_INT >= 12) {
            bitmap.setHasAlpha(true);
        }
    }

    public final void m3033a(byte[] bArr, int i, int i2, C0119g c0119g) {
        try {
            synchronized (this.f1782i) {
                if (!this.f1777d.contains(c0119g)) {
                    this.f1779f.execute(new C0442k(this, bArr, i, i2, c0119g, System.currentTimeMillis()));
                    this.f1777d.add(c0119g);
                }
            }
        } catch (Throwable e) {
            this.f1778e.m124a((short) 259, " create decode image thread error", e);
            Log.e(f1775b, "create decode image thread error:" + c0119g.toString());
        }
    }

    public final Bitmap m3032a(byte[] bArr, int i) {
        Options options = new Options();
        options.inPreferredConfig = Config.ARGB_8888;
        if (VERSION.SDK_INT >= 11) {
            options.inMutable = true;
        }
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(bArr, 0, i, options);
        if (decodeByteArray == null) {
            decodeByteArray = C0444m.m3040a(this.f1776c, bArr, bArr.length, C0300n.m2120d(this.f1776c), C0300n.m2102b(this.f1776c));
        }
        if (decodeByteArray == null) {
            return null;
        }
        C0443l.m3025a(decodeByteArray);
        if (decodeByteArray.isMutable() && decodeByteArray.getConfig() == Config.ARGB_8888 && decodeByteArray.hasAlpha()) {
            return decodeByteArray;
        }
        return C0443l.m3021a(this.f1776c, decodeByteArray, this.f1778e);
    }

    public final Bitmap m3034b(byte[] bArr, int i, int i2, C0119g c0119g) {
        Bitmap a = m3031a(c0119g);
        if (a != null) {
            return a;
        }
        m3033a(bArr, i, i2, c0119g);
        return null;
    }

    public static void m3026a(C0119g c0119g, Bitmap bitmap) {
        if (c0119g.m1193i()) {
            f1774a.m1919a(c0119g, bitmap);
        }
    }

    public final Bitmap m3031a(C0119g c0119g) {
        Bitmap bitmap = (Bitmap) f1774a.m1918a((Object) c0119g);
        this.f1780g++;
        if (bitmap == null || bitmap.isRecycled()) {
            return null;
        }
        this.f1781h++;
        new StringBuilder("fetched decoded image for: ").append(c0119g.toString()).append(" ").append(this.f1781h).append(" / ").append(this.f1780g).append(" Ratio:").append((((double) this.f1781h) * 1.0d) / ((((double) this.f1780g) * 1.0d) + 1.0d));
        return bitmap;
    }

    private static Bitmap m3021a(Context context, Bitmap bitmap, C0022b c0022b) {
        File createTempFile;
        Exception e;
        Bitmap b;
        Throwable th;
        File file = null;
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        File externalCacheDir = context.getExternalCacheDir();
        if (externalCacheDir == null) {
            externalCacheDir = context.getCacheDir();
        }
        try {
            createTempFile = File.createTempFile("tempBitmap" + Long.toString(System.currentTimeMillis()), null, externalCacheDir);
            try {
                createTempFile.deleteOnExit();
                RandomAccessFile randomAccessFile = new RandomAccessFile(createTempFile, "rw");
                FileChannel channel = randomAccessFile.getChannel();
                Buffer map = channel.map(MapMode.READ_WRITE, 0, (long) (bitmap.getRowBytes() * height));
                bitmap.copyPixelsToBuffer(map);
                bitmap.recycle();
                Bitmap createBitmap = Bitmap.createBitmap(width, height, Config.ARGB_8888);
                map.position(0);
                createBitmap.copyPixelsFromBuffer(map);
                channel.close();
                randomAccessFile.close();
                if (createTempFile != null) {
                    createTempFile.delete();
                }
                return createBitmap;
            } catch (Exception e2) {
                e = e2;
                file = createTempFile;
                try {
                    c0022b.m126a((short) 3, (short) 271, e.toString());
                    new StringBuilder("convertToMutable failed: ").append(e.toString());
                    b = C0443l.m3027b(bitmap);
                    if (file != null) {
                        return b;
                    }
                    file.delete();
                    return b;
                } catch (Throwable th2) {
                    th = th2;
                    createTempFile = file;
                    if (createTempFile != null) {
                        createTempFile.delete();
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                if (createTempFile != null) {
                    createTempFile.delete();
                }
                throw th;
            }
        } catch (Exception e3) {
            e = e3;
            c0022b.m126a((short) 3, (short) 271, e.toString());
            new StringBuilder("convertToMutable failed: ").append(e.toString());
            b = C0443l.m3027b(bitmap);
            if (file != null) {
                return b;
            }
            file.delete();
            return b;
        } catch (Throwable th4) {
            th = th4;
            createTempFile = null;
            if (createTempFile != null) {
                createTempFile.delete();
            }
            throw th;
        }
    }

    private static Bitmap m3027b(Bitmap bitmap) {
        Bitmap createBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Config.ARGB_8888);
        new Canvas(createBitmap).drawBitmap(bitmap, new Matrix(), null);
        bitmap.recycle();
        return createBitmap;
    }
}
