package com.facebook.lite.p049a.p052c;

import android.util.Log;
import com.p008a.p009a.p010a.p018f.C0047a;
import com.p008a.p009a.p010a.p018f.C0048b;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: com.facebook.lite.a.c.e */
public class C0271e {
    private static final String f1041a;

    static {
        f1041a = C0271e.class.getSimpleName();
    }

    private C0271e() {
    }

    public static C0048b m1854a(String str) {
        if (str == null || str.trim().length() == 0) {
            Log.e(f1041a, "fromJson/null or empty raw json ");
            return null;
        }
        try {
            JSONObject jSONObject = new JSONObject(str);
            int i = jSONObject.getInt("version");
            JSONArray jSONArray = jSONObject.getJSONArray("idMap");
            C0047a[] c0047aArr = new C0047a[jSONArray.length()];
            for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                c0047aArr[i2] = C0271e.m1853a(jSONArray.getJSONObject(i2), i);
            }
            return new C0048b(c0047aArr, i);
        } catch (Throwable e) {
            Log.e(f1041a, "fromJson/error parsing: " + str, e);
            return null;
        }
    }

    private static C0047a m1853a(JSONObject jSONObject, int i) {
        int i2 = 0;
        if (jSONObject == null) {
            throw new JSONException("Null cache config");
        }
        boolean z;
        byte[] bArr;
        byte b = (byte) jSONObject.getInt("cacheId");
        boolean z2 = jSONObject.getBoolean("isPersisted");
        if (i > 0) {
            z = jSONObject.getBoolean("isImage");
        } else {
            z = false;
        }
        int i3 = jSONObject.getInt("maxSize");
        if (jSONObject.has("backupCacheId")) {
            JSONArray jSONArray = jSONObject.getJSONArray("backupCacheId");
            bArr = new byte[jSONArray.length()];
            while (i2 < jSONArray.length()) {
                bArr[i2] = (byte) jSONArray.getInt(i2);
                i2++;
            }
        } else {
            bArr = new byte[0];
        }
        return new C0047a(b, z2, z, i3, bArr);
    }
}
