package com.facebook.lite.p067o;

import java.io.ByteArrayOutputStream;

/* renamed from: com.facebook.lite.o.a */
public final class C0423a extends ByteArrayOutputStream {
    public C0423a() {
        super(1024);
    }

    public final byte[] m2939a() {
        return this.buf;
    }
}
