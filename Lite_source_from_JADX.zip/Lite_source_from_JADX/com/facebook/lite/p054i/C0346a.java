package com.facebook.lite.p054i;

/* renamed from: com.facebook.lite.i.a */
final class C0346a implements Runnable {
    final /* synthetic */ C0351g f1380a;

    C0346a(C0351g c0351g) {
        this.f1380a = c0351g;
    }

    public final void run() {
        if (this.f1380a.f1390e.getAndSet(false)) {
            this.f1380a.f1388c.m2180a();
            this.f1380a.m2488e();
        }
    }
}
