package com.facebook.lite.p061h;

import android.os.SystemClock;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.p059m.C0387i;
import com.p008a.p009a.p010a.p013c.C0032d;
import com.p008a.p009a.p010a.p016h.C0055g;
import java.util.HashSet;
import java.util.Set;

/* renamed from: com.facebook.lite.h.a */
public final class C0345a extends C0032d {
    private final Set f1379a;

    public C0345a(C0387i c0387i, C0055g c0055g) {
        super(c0387i, c0387i.m2639N(), c0387i.m2642Q(), c0387i.m2647V(), c0055g, c0387i.m2635J());
        this.f1379a = new HashSet();
    }

    public static int m2471b() {
        return (int) (SystemClock.elapsedRealtime() - ClientApplication.m1691c().m2376H());
    }

    public final synchronized void m2472c(int i) {
        if (!this.f1379a.contains(Integer.valueOf(i))) {
            this.f1379a.add(Integer.valueOf(i));
            m244a(i, C0345a.m2471b());
        }
    }
}
