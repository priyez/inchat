package com.facebook.p031b;

import android.content.Context;
import android.provider.Settings.Secure;
import android.provider.Settings.System;
import android.util.Log;
import java.lang.reflect.Field;

/* renamed from: com.facebook.b.w */
public final class C0192w {
    public static String m1464a(Context context) {
        StringBuilder stringBuilder = new StringBuilder();
        for (Field field : System.class.getFields()) {
            if (!field.isAnnotationPresent(Deprecated.class) && field.getType() == String.class) {
                try {
                    String string = System.getString(context.getContentResolver(), (String) field.get(null));
                    if (string != null) {
                        stringBuilder.append(field.getName()).append("=").append(string).append("\n");
                    }
                } catch (Throwable e) {
                    Log.w(C0148a.f621a, "Error : ", e);
                } catch (Throwable e2) {
                    Log.w(C0148a.f621a, "Error : ", e2);
                }
            }
        }
        return stringBuilder.toString();
    }

    public static String m1466b(Context context) {
        StringBuilder stringBuilder = new StringBuilder();
        for (Field field : Secure.class.getFields()) {
            if (!field.isAnnotationPresent(Deprecated.class) && field.getType() == String.class && C0192w.m1465a(field)) {
                try {
                    String string = Secure.getString(context.getContentResolver(), (String) field.get(null));
                    if (string != null) {
                        stringBuilder.append(field.getName()).append("=").append(string).append("\n");
                    }
                } catch (Throwable e) {
                    Log.w(C0148a.f621a, "Error : ", e);
                } catch (Throwable e2) {
                    Log.w(C0148a.f621a, "Error : ", e2);
                }
            }
        }
        return stringBuilder.toString();
    }

    private static boolean m1465a(Field field) {
        if (field == null || field.getName().startsWith("WIFI_AP")) {
            return false;
        }
        return true;
    }
}
