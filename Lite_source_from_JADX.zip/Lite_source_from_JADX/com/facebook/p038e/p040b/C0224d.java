package com.facebook.p038e.p040b;

import android.content.Context;
import com.facebook.lite.p053b.C0300n;
import com.facebook.p038e.C0247l;
import com.facebook.p038e.C0249i;
import com.facebook.rti.p046a.p076h.C0531a;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* renamed from: com.facebook.e.b.d */
public final class C0224d implements C0222b {
    private final C0531a f844a;
    private final Context f845b;
    private final C0247l f846c;
    private final Map f847d;
    private final Map f848e;

    public C0224d(Context context, C0247l c0247l, C0531a c0531a) {
        int i = 0;
        this.f847d = new HashMap();
        this.f848e = new HashMap();
        this.f845b = context.getApplicationContext();
        this.f846c = c0247l;
        this.f844a = c0531a;
        for (C0223c c0223c : C0223c.values()) {
            this.f847d.put(c0223c, Long.valueOf(C0300n.m2113c(context, c0223c.name())));
        }
        C0223c[] values = C0223c.values();
        int length = values.length;
        while (i < length) {
            this.f848e.put(values[i], new ArrayList());
            i++;
        }
    }

    public final void m1556a(C0223c c0223c, C0214a c0214a) {
        ((ArrayList) this.f848e.get(c0223c)).add(c0214a);
    }

    public final synchronized void m1555a() {
        long a = this.f844a.m3350a();
        for (C0223c c0223c : C0223c.values()) {
            if (a - ((Long) this.f847d.get(c0223c)).longValue() >= c0223c.m1554a()) {
                this.f847d.put(c0223c, Long.valueOf(a));
                C0300n.m2097a(this.f845b, c0223c.name(), a);
                Iterator it = ((ArrayList) this.f848e.get(c0223c)).iterator();
                while (it.hasNext()) {
                    C0214a c0214a = (C0214a) it.next();
                    C0249i b = c0214a.m1521b();
                    if (b != null) {
                        this.f846c.m1652a(b, this.f845b, c0214a.m1520a());
                    }
                }
            }
        }
    }
}
