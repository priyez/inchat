package com.facebook.p031b.p034c;

/* renamed from: com.facebook.b.c.m */
public final class C0166m {
    public final String f639a;
    public final long f640b;

    public final String toString() {
        return String.format("[%d] %s", new Object[]{Long.valueOf(this.f640b), this.f639a});
    }
}
