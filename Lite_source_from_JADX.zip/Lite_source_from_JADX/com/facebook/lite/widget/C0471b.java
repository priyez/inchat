package com.facebook.lite.widget;

import com.facebook.lite.ClientApplication;

/* renamed from: com.facebook.lite.widget.b */
final class C0471b implements Runnable {
    final /* synthetic */ AbstractGLRendererView f2075a;

    C0471b(AbstractGLRendererView abstractGLRendererView) {
        this.f2075a = abstractGLRendererView;
    }

    public final void run() {
        ClientApplication.m1692d().m1797o();
    }
}
