package com.facebook.lite.p056d;

import android.content.Context;
import com.facebook.lite.p053b.C0296j;
import org.json.JSONObject;

/* renamed from: com.facebook.lite.d.f */
public final class C0313f extends C0309a {
    private boolean f1228b;
    private int f1229c;
    private int f1230d;
    private int f1231e;
    private long f1232f;

    public static C0313f m2224b(Context context) {
        return (C0313f) C0313f.m2223b().m2216a(context);
    }

    public static C0313f m2223b() {
        return C0312e.f1227a;
    }

    public final int m2228c() {
        return this.f1229c;
    }

    public final int m2229d() {
        return this.f1230d;
    }

    public final String m2226a() {
        return "logging";
    }

    public final int m2230e() {
        return this.f1231e;
    }

    public final long m2231f() {
        return this.f1232f;
    }

    public final boolean m2232g() {
        return this.f1228b;
    }

    protected final void m2227a(JSONObject jSONObject) {
        this.f1230d = C0296j.m1989a(jSONObject, "low_freq_daily", 10);
        this.f1229c = C0296j.m1989a(jSONObject, "high_freq_hourly", 10);
        this.f1232f = C0296j.m1990a(jSONObject, "periodic_interval");
        this.f1228b = C0296j.m1991a(jSONObject, "enable_honey", true);
        this.f1231e = C0296j.m1989a(jSONObject, "offline_log_size", 20480);
        m2225h();
    }

    private void m2225h() {
        if (this.f1229c < 0) {
            this.f1229c = 10;
        }
        if (this.f1230d < 0) {
            this.f1230d = 10;
        }
        if (this.f1231e > 1048576 || this.f1231e < 0) {
            this.f1231e = 20480;
        }
    }
}
