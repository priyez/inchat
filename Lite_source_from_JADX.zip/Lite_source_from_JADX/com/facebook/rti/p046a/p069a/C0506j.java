package com.facebook.rti.p046a.p069a;

import android.content.Context;
import com.facebook.rti.p046a.p074f.C0527a;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import p006c.p007a.C0003a;

/* renamed from: com.facebook.rti.a.a.j */
public class C0506j {
    private static final String f2150a;
    private final File f2151b;
    private final C0499c f2152c;

    static {
        f2150a = C0506j.class.getSimpleName();
    }

    public C0506j(Context context, C0003a c0003a, String str, String str2, String str3) {
        this.f2152c = new C0499c(str2 + "|" + str3, new C0502f(c0003a), str);
        this.f2151b = new File(context.getFilesDir(), "mqtt_analytics");
    }

    public final boolean m3310a() {
        C0527a.m3336a(f2150a, "Attempting to upload analytics", new Object[0]);
        if (this.f2151b.exists()) {
            File[] listFiles = this.f2151b.listFiles();
            if (listFiles == null) {
                C0527a.m3336a(f2150a, "Analytics directory error", new Object[0]);
                if (!this.f2151b.exists()) {
                    C0527a.m3344f(f2150a, "directory_not_found", new Object[0]);
                    return true;
                } else if (this.f2151b.isFile()) {
                    C0527a.m3344f(f2150a, "directory_is_file", new Object[0]);
                    return true;
                } else {
                    C0527a.m3344f(f2150a, "directory_unknown_error", new Object[0]);
                    return true;
                }
            }
            for (File a : listFiles) {
                if (!m3308a(a)) {
                    return false;
                }
            }
            return true;
        }
        C0527a.m3336a(f2150a, "No analytics directory exists, nothing to do", new Object[0]);
        return true;
    }

    private boolean m3308a(File file) {
        C0527a.m3336a(f2150a, "Uploading file %s", file);
        try {
            int a = this.f2152c.m3288a(C0506j.m3309b(file));
            if (a == 200) {
                C0527a.m3336a(f2150a, "Successful upload", new Object[0]);
                if (!file.delete()) {
                    C0527a.m3343e(f2150a, "File %s was not deleted", file);
                }
            } else {
                C0527a.m3336a(f2150a, "Unsuccessful upload. response code=%d", Integer.valueOf(a));
            }
            if (a == 200) {
                return true;
            }
            return false;
        } catch (Throwable e) {
            C0527a.m3339b(f2150a, e, "Unable to read file", new Object[0]);
            return false;
        }
    }

    private static String m3309b(File file) {
        Throwable th;
        Reader inputStreamReader;
        try {
            inputStreamReader = new InputStreamReader(new FileInputStream(file), "UTF-8");
            try {
                StringBuilder stringBuilder = new StringBuilder();
                char[] cArr = new char[1024];
                while (true) {
                    int read = inputStreamReader.read(cArr);
                    if (read == -1) {
                        break;
                    }
                    stringBuilder.append(cArr, 0, read);
                }
                String stringBuilder2 = stringBuilder.toString();
                try {
                    inputStreamReader.close();
                } catch (IOException e) {
                }
                return stringBuilder2;
            } catch (Throwable th2) {
                th = th2;
                if (inputStreamReader != null) {
                    try {
                        inputStreamReader.close();
                    } catch (IOException e2) {
                    }
                }
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            inputStreamReader = null;
            if (inputStreamReader != null) {
                inputStreamReader.close();
            }
            throw th;
        }
    }
}
