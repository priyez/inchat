package com.facebook.rti.push.service;

import android.content.Context;
import android.text.TextUtils;
import com.facebook.rti.p046a.p069a.C0498b;
import com.facebook.rti.p046a.p069a.C0500d;
import com.facebook.rti.p046a.p074f.C0527a;
import com.facebook.rti.p046a.p076h.C0532b;
import com.facebook.rti.p078b.p080b.p084d.C0583e;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/* renamed from: com.facebook.rti.push.service.d */
public final class C0734d {
    private final String f3154a;
    private final C0583e f3155b;
    private final C0532b f3156c;
    private final C0500d f3157d;
    private final long f3158e;

    public C0734d(Context context, C0583e c0583e, C0532b c0532b, C0500d c0500d) {
        this.f3154a = context.getPackageName();
        this.f3155b = c0583e;
        this.f3156c = c0532b;
        this.f3157d = c0500d;
        this.f3158e = this.f3156c.m3351a();
    }

    public final void m3958a(C0733c c0733c, String str) {
        String[] strArr = new String[]{"event_type", c0733c.name()};
        Map hashMap = new HashMap();
        for (int i = 0; i < 2; i += 2) {
            Object obj = strArr[0];
            if (obj == null) {
                obj = "";
            }
            Object obj2 = strArr[1];
            if (obj2 == null) {
                obj2 = "";
            }
            hashMap.put(obj, obj2);
        }
        if (!TextUtils.isEmpty(str)) {
            hashMap.put("event_extra_info", str);
        }
        m3955a("fbns_service_event", hashMap);
    }

    public final void m3957a(C0732b c0732b, String str) {
        String[] strArr = new String[]{"event_type", c0732b.name()};
        Map hashMap = new HashMap();
        for (int i = 0; i < 2; i += 2) {
            Object obj = strArr[0];
            if (obj == null) {
                obj = "";
            }
            Object obj2 = strArr[1];
            if (obj2 == null) {
                obj2 = "";
            }
            hashMap.put(obj, obj2);
        }
        if (!TextUtils.isEmpty(str)) {
            hashMap.put("event_extra_info", str);
        }
        m3955a("fbns_registration_event", hashMap);
    }

    public final void m3956a(C0731a c0731a, String str, String str2, long j, boolean z, long j2) {
        String[] strArr = new String[]{"event_type", c0731a.name()};
        Map hashMap = new HashMap();
        for (int i = 0; i < 2; i += 2) {
            Object obj = strArr[0];
            if (obj == null) {
                obj = "";
            }
            Object obj2 = strArr[1];
            if (obj2 == null) {
                obj2 = "";
            }
            hashMap.put(obj, obj2);
        }
        if (!TextUtils.isEmpty(str)) {
            hashMap.put("event_extra_info", str);
        }
        if (!TextUtils.isEmpty(str2)) {
            hashMap.put("is_buffered", str2);
        }
        long a = this.f3156c.m3351a();
        hashMap.put("s_boot_ms", String.valueOf(a));
        hashMap.put("s_svc_ms", String.valueOf(a - this.f3158e));
        hashMap.put("s_mqtt_ms", String.valueOf(a - j));
        hashMap.put("s_net_ms", String.valueOf(a - this.f3155b.m3487g()));
        if (j2 > 0) {
            hashMap.put("is_scr_on", String.valueOf(z));
            hashMap.put("s_scr_ms", String.valueOf(a - j2));
        }
        m3955a("fbns_message_event", hashMap);
    }

    public final void m3959a(String str) {
        String[] strArr = new String[]{"event_type", "verify_sender_failed"};
        Map hashMap = new HashMap();
        for (int i = 0; i < 2; i += 2) {
            Object obj = strArr[0];
            if (obj == null) {
                obj = "";
            }
            Object obj2 = strArr[1];
            if (obj2 == null) {
                obj2 = "";
            }
            hashMap.put(obj, obj2);
        }
        if (!TextUtils.isEmpty(str)) {
            hashMap.put("event_extra_info", str);
        }
        m3955a("fbns_auth_intent_event", hashMap);
    }

    private void m3955a(String str, Map map) {
        C0527a.m3336a("FbnsAnalyticsLogger", "Event name: %s, Event parameters: %s", str, map);
        C0498b c0498b = new C0498b(str, this.f3154a);
        for (Entry entry : map.entrySet()) {
            c0498b.m3286a(entry.getKey().toString(), entry.getValue() == null ? "" : entry.getValue().toString());
        }
        this.f3157d.m3290a(c0498b);
    }
}
