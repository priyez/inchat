package com.facebook.p031b.p034c;

import java.util.LinkedList;
import java.util.Queue;

/* renamed from: com.facebook.b.c.n */
public final class C0167n {
    public static int f641a;
    protected final int f642b;
    private Queue f643c;

    static {
        f641a = 0;
    }

    public C0167n(int i) {
        this.f642b = i;
        m1358a();
    }

    public final synchronized String toString() {
        return m1359a(f641a);
    }

    public final synchronized String m1359a(int i) {
        StringBuilder stringBuilder;
        int i2;
        stringBuilder = new StringBuilder();
        if (i <= f641a) {
            i2 = 0;
        } else {
            i2 = Math.max(this.f643c.size() - i, 0);
        }
        int i3 = 0;
        for (C0166m c0166m : this.f643c) {
            if (i3 >= i2) {
                stringBuilder.append(c0166m.toString()).append('\n');
            }
            i3++;
        }
        return stringBuilder.toString();
    }

    private synchronized void m1358a() {
        this.f643c = new LinkedList();
    }
}
