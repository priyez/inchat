package com.facebook.lite.p068p;

import com.p008a.p009a.p010a.p014e.C0022b;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* renamed from: com.facebook.lite.p.c */
public class C0429c {
    private static final String f1714a;
    private final int f1715b;
    private final int f1716c;
    private final ExecutorService f1717d;
    private volatile boolean f1718e;
    private final C0022b f1719f;
    private final int f1720g;
    private final ServerSocket f1721h;
    private final Thread f1722i;
    private final long f1723j;
    private final String f1724k;

    static {
        f1714a = C0429c.class.getSimpleName();
    }

    public C0429c(String str, int i, int i2, int i3, C0022b c0022b, long j) {
        this.f1724k = str;
        this.f1715b = i;
        this.f1716c = i2;
        this.f1720g = i3;
        this.f1719f = c0022b;
        this.f1723j = j;
        this.f1721h = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"));
        this.f1717d = Executors.newFixedThreadPool(1);
        this.f1722i = new C0427a();
    }

    public final String m2959a() {
        return "http://127.0.0.1:" + this.f1721h.getLocalPort();
    }

    public final boolean m2960b() {
        return this.f1718e;
    }

    public final void m2961c() {
        if (this.f1718e) {
            throw new IllegalStateException("Start video server when it is already one running");
        }
        this.f1718e = true;
        this.f1722i.start();
    }

    public final void m2962d() {
        if (this.f1718e) {
            this.f1718e = false;
            try {
                if (!this.f1721h.isClosed()) {
                    this.f1721h.close();
                }
            } catch (Throwable e) {
                this.f1719f.m124a((short) 294, null, e);
            }
            this.f1717d.shutdownNow();
            return;
        }
        throw new IllegalStateException("Stop video server that already been stoped");
    }
}
