package com.facebook.p031b;

/* renamed from: com.facebook.b.s */
public interface C0188s {
    String m1458a();
}
