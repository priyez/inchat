package com.facebook.lite.p062j;

/* renamed from: com.facebook.lite.j.g */
final class C0360g implements C0358i {
    final /* synthetic */ C0366n f1414a;

    private C0360g(C0366n c0366n) {
        this.f1414a = c0366n;
    }

    public final String m2518a(StringBuilder stringBuilder) {
        stringBuilder.append("Event: ");
        stringBuilder.append(this.f1414a.f1426c.m2520a());
        return stringBuilder.toString();
    }
}
