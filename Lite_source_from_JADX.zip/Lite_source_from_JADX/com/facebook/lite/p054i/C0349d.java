package com.facebook.lite.p054i;

/* renamed from: com.facebook.lite.i.d */
final class C0349d implements Runnable {
    final /* synthetic */ C0351g f1384a;

    C0349d(C0351g c0351g) {
        this.f1384a = c0351g;
    }

    public final void run() {
        if (this.f1384a.f1390e.get()) {
            this.f1384a.f1393h.requestLocationUpdates("network", 5000, 0.0f, this.f1384a.f1387b);
        }
    }
}
