package com.facebook.lite.p049a;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* renamed from: com.facebook.lite.a.c */
public final class C0274c extends ThreadPoolExecutor {
    final /* synthetic */ C0280i f1047a;
    private boolean f1048b;
    private final Object f1049c;

    public C0274c(C0280i c0280i, TimeUnit timeUnit, BlockingQueue blockingQueue, ThreadFactory threadFactory) {
        this.f1047a = c0280i;
        super(1, 1, 2147483647L, timeUnit, blockingQueue, threadFactory);
        this.f1049c = new Object();
    }

    public final void m1865a() {
        this.f1048b = true;
    }

    public final void m1866b() {
        if (this.f1048b) {
            this.f1048b = false;
            synchronized (this.f1049c) {
                this.f1049c.notifyAll();
            }
        }
    }

    protected final void beforeExecute(Thread thread, Runnable runnable) {
        super.beforeExecute(thread, runnable);
        while (this.f1048b) {
            try {
                C0280i.f1070a;
                synchronized (this.f1049c) {
                    this.f1049c.wait();
                }
            } catch (InterruptedException e) {
            }
        }
        if (runnable instanceof C0278g) {
            C0278g c0278g = (C0278g) runnable;
            C0280i.f1070a;
            new StringBuilder("diskcache/taskqueue/perform: save id:").append(c0278g.f1065d);
        } else if (runnable instanceof C0277f) {
            C0277f c0277f = (C0277f) runnable;
            C0280i.f1070a;
            new StringBuilder("diskcache/taskqueue/perform: load id:").append(c0277f.f1057d);
        }
    }
}
