package com.facebook.lite.p053b;

import java.util.Calendar;

/* renamed from: com.facebook.lite.b.i */
public final class C0295i {
    public static boolean m1988a(long j, long j2) {
        return C0295i.m1987a(j).get(6) == C0295i.m1987a(j2).get(6);
    }

    private static Calendar m1987a(long j) {
        Calendar instance = Calendar.getInstance();
        instance.setTimeInMillis(j);
        instance.set(11, 0);
        instance.set(12, 0);
        instance.set(13, 0);
        return instance;
    }
}
