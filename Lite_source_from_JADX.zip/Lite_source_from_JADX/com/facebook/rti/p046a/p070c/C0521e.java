package com.facebook.rti.p046a.p070c;

import android.os.SystemClock;
import com.facebook.rti.p046a.p074f.C0527a;

/* renamed from: com.facebook.rti.a.c.e */
final class C0521e implements Runnable {
    final /* synthetic */ C0522f f2199a;
    private final Runnable f2200b;
    private final long f2201c;
    private volatile long f2202d;
    private volatile long f2203e;

    C0521e(C0522f c0522f, Runnable runnable) {
        this.f2199a = c0522f;
        this.f2200b = runnable;
        this.f2201c = SystemClock.elapsedRealtime();
        this.f2202d = -1;
        this.f2203e = -1;
    }

    public final void run() {
        this.f2202d = SystemClock.elapsedRealtime();
        if (this.f2199a.f2208e != -1 && this.f2202d - this.f2201c > ((long) this.f2199a.f2208e)) {
            C0527a.m3344f("SerialExecutor", "dispatch time exceeded limit: %s", this.f2199a.f2204a);
        }
        long currentThreadTimeMillis = SystemClock.currentThreadTimeMillis();
        this.f2200b.run();
        long currentThreadTimeMillis2 = SystemClock.currentThreadTimeMillis();
        long elapsedRealtime = SystemClock.elapsedRealtime();
        if (this.f2199a.f2206c != -1 && currentThreadTimeMillis2 - currentThreadTimeMillis > ((long) this.f2199a.f2206c)) {
            C0527a.m3344f("SerialExecutor", "compute time exceeded limit: %s", this.f2199a.f2204a);
        }
        if (this.f2199a.f2207d != -1 && elapsedRealtime - this.f2202d > ((long) this.f2199a.f2207d)) {
            C0527a.m3344f("SerialExecutor", "wall clock runtime exceeded limit: %s", this.f2199a.f2204a);
        }
        this.f2199a.m3320a();
    }
}
