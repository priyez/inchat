package com.facebook.p038e.p045d;

import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;

/* renamed from: com.facebook.e.d.h */
public final class C0238h extends C0233c {
    private final C0236f f899a;

    public C0238h(ActivityManager activityManager, C0236f c0236f) {
        super(activityManager);
        this.f899a = c0236f;
    }

    protected final long m1620a(MemoryInfo memoryInfo) {
        this.f899a.m1618b();
        return this.f899a.m1617a();
    }
}
