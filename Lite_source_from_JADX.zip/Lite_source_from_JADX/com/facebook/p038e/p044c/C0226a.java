package com.facebook.p038e.p044c;

/* renamed from: com.facebook.e.c.a */
final /* synthetic */ class C0226a {
    static final /* synthetic */ int[] f852a;

    static {
        f852a = new int[C0227b.m1563a().length];
        try {
            f852a[C0227b.f856d - 1] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            f852a[C0227b.f854b - 1] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            f852a[C0227b.f853a - 1] = 3;
        } catch (NoSuchFieldError e3) {
        }
        try {
            f852a[C0227b.f855c - 1] = 4;
        } catch (NoSuchFieldError e4) {
        }
    }
}
