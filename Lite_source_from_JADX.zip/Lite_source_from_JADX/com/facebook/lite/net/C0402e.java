package com.facebook.lite.net;

/* renamed from: com.facebook.lite.net.e */
public final class C0402e {
    public static String m2844a(String str) {
        return str.replaceAll("localhost", "192.168.56.1");
    }

    public static String m2845b(String str) {
        return str.replaceAll("127.0.0.1", "192.168.56.1");
    }

    public static boolean m2846c(String str) {
        return "192.168.56.1".equals(str);
    }
}
