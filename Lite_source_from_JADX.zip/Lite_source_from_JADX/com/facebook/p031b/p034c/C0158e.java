package com.facebook.p031b.p034c;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.GZIPOutputStream;

/* renamed from: com.facebook.b.c.e */
public final class C0158e {
    private C0155b f630a;

    public C0158e(C0155b c0155b) {
        this.f630a = c0155b;
    }

    public final void m1343a(URL url, C0156c c0156c, C0154a c0154a, String str, String str2) {
        HttpURLConnection a = this.f630a.m1340a(url);
        a.setRequestMethod("POST");
        a.setRequestProperty("User-Agent", str2);
        a.setRequestProperty("Content-Type", str);
        a.setRequestProperty("Content-Encoding", "gzip");
        a.setDoOutput(true);
        try {
            OutputStream gZIPOutputStream = new GZIPOutputStream(a.getOutputStream());
            c0156c.m1341a(gZIPOutputStream);
            gZIPOutputStream.close();
            c0154a.m1339a(a.getResponseCode());
            a.getInputStream().close();
        } finally {
            a.disconnect();
        }
    }
}
