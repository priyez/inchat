package com.facebook.rti.p046a.p077i;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/* renamed from: com.facebook.rti.a.i.a */
public final class C0535a {
    private static final Set f2218a;

    static {
        f2218a = new HashSet(Arrays.asList(new String[]{"ijxLJi1yGs1JpL-X1SExmchvork", "xW-31ZG6ZwTfBH_Zj1NTcv6gAhE", "OKD31QX-GP7GT780Psqq8xDb15k", "Sr9mhPKOEwo6NysnYn803dZ3UiY", "Xo8WBi6jzSxKDVR4drqm84yr9iU"}));
    }

    public static boolean m3356a(String str) {
        return f2218a.contains(str);
    }
}
