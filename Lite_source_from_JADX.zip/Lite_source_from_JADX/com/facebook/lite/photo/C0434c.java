package com.facebook.lite.photo;

import android.graphics.Bitmap;
import android.widget.ImageView;

/* renamed from: com.facebook.lite.photo.c */
final class C0434c implements C0433v {
    final /* synthetic */ AlbumGalleryActivity f1758a;

    C0434c(AlbumGalleryActivity albumGalleryActivity) {
        this.f1758a = albumGalleryActivity;
    }

    private static void m3009a(ImageView imageView, Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            imageView.setImageBitmap(bitmap);
        }
    }
}
