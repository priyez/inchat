package com.facebook.lite.p062j;

import android.graphics.Canvas;

/* renamed from: com.facebook.lite.j.a */
public interface C0353a {
    int m2497a(int i);

    void m2498a(Canvas canvas);
}
