package com.facebook.lite.net;

import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p059m.C0380b;
import com.facebook.lite.p059m.C0381c;
import com.facebook.lite.p059m.C0387i;
import com.facebook.lite.p061h.C0345a;
import com.p008a.p009a.p010a.p012b.C0017i;
import com.p008a.p009a.p010a.p012b.C0018j;
import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p015g.C0023a;
import com.p008a.p009a.p010a.p016h.C0055g;
import com.p008a.p009a.p010a.p022l.C0077f;
import com.p008a.p009a.p010a.p023m.C0115e;
import com.p008a.p009a.p010a.p023m.C0116b;
import com.p008a.p009a.p010a.p023m.p024a.C0095a;
import com.p008a.p009a.p010a.p023m.p024a.C0096b;
import com.p008a.p009a.p010a.p023m.p024a.C0097c;
import com.p008a.p009a.p010a.p023m.p024a.C0098d;
import java.io.DataInputStream;
import java.io.OutputStream;

/* renamed from: com.facebook.lite.net.q */
public class C0400q extends C0397b implements C0017i {
    private static final int[] f1600t;
    private C0409n f1601A;
    private long f1602B;
    private int f1603C;
    private final C0097c f1604D;
    private final C0096b f1605E;
    private volatile boolean f1606F;
    private int f1607G;
    private final C0095a f1608H;
    private int f1609I;
    private int f1610J;
    private boolean f1611K;
    volatile C0410o f1612r;
    volatile C0398p f1613s;
    private final Object f1614u;
    private int f1615v;
    private final Object f1616w;
    private long f1617x;
    private final Object f1618y;
    private int f1619z;

    static {
        f1600t = new int[]{a[1] | a[5], (a[2] | a[0]) | a[5], (a[4] | a[5]) | a[3], a[1], a[1] | a[5], a[6], 0};
    }

    public C0400q(C0023a c0023a, C0022b c0022b, C0018j c0018j, C0077f c0077f, C0403i c0403i, String str, int i, C0345a c0345a, C0055g c0055g, C0387i c0387i) {
        super(c0022b, c0077f, c0023a, c0403i, c0018j, c0345a, c0055g, c0387i);
        this.f1614u = new Object();
        this.f1615v = -1;
        this.f1616w = new Object();
        this.f1617x = 0;
        this.f1618y = new Object();
        this.f1619z = -1;
        this.f1601A = null;
        this.f1602B = Long.MAX_VALUE;
        this.f1607G = 0;
        this.f1611K = true;
        this.f1604D = C0098d.m1047b((Object) str);
        this.f1605E = C0098d.m1046b((long) i);
        this.f1608H = C0098d.m1048d();
        this.f1610J = 2000;
    }

    public final void m2837q() {
        this.e = (byte) 1;
        m2833b(1);
    }

    public final void m2830a(C0411r c0411r) {
        if (!this.f1604D.m1045c().equals(c0411r.m2898a()) || this.f1605E.m1043b() != ((long) c0411r.m2899b())) {
            m2769a();
            m2798a(c0411r.m2898a(), c0411r.m2899b());
            m2837q();
        }
    }

    public final boolean m2834b(C0411r c0411r) {
        if (this.f1604D.m1045c().equals(c0411r.m2898a()) && this.f1605E.m1043b() == ((long) c0411r.m2899b())) {
            return true;
        }
        synchronized (this.k) {
            int j = m2783j();
            if (j == 0 || j == 3 || j == 4) {
                m2798a(c0411r.m2898a(), c0411r.m2899b());
                return true;
            }
            return false;
        }
    }

    public final void m2835d(int i) {
        synchronized (this.f1614u) {
            if (this.f1603C == i) {
                if (m96A()) {
                    this.a_.m243a(45);
                }
                long currentTimeMillis = System.currentTimeMillis();
                if (500 + currentTimeMillis < this.f1617x) {
                    this.f1603C = this.q.m110a(this, this.f1617x - currentTimeMillis);
                    this.f1602B = this.f1617x;
                } else {
                    m2824t();
                    this.f1603C = this.q.m110a(this, (long) this.f1615v);
                    this.f1602B = currentTimeMillis + ((long) this.f1615v);
                    this.f1617x = this.f1602B;
                }
            }
        }
    }

    public final void m2831a(short s) {
        synchronized (this.f1614u) {
            if (s < (short) 0) {
                this.f1603C = -1;
                this.f1617x = Long.MAX_VALUE;
                this.f1615v = -1;
                this.f1602B = Long.MAX_VALUE;
            } else if (s * 1000 != this.f1615v) {
                this.f1615v = s * 1000;
                long currentTimeMillis = System.currentTimeMillis();
                this.f1617x = ((long) this.f1615v) + currentTimeMillis;
                if (this.f1617x < this.f1602B) {
                    this.f1603C = this.q.m110a(this, (long) this.f1615v);
                    this.f1602B = currentTimeMillis + ((long) this.f1615v);
                }
            }
        }
    }

    protected final boolean m2833b(int i) {
        synchronized (this.k) {
            if (i == this.j) {
                return false;
            } else if (i < 0 || i >= a.length) {
                return false;
            } else if ((a[i] & f1600t[this.j]) == 0) {
                return false;
            } else {
                if (i == 1) {
                    if (m96A()) {
                        this.a_.m243a(40);
                    }
                    if (!C0294h.m1974f()) {
                        this.l.m132a(m2827v(), m2781h(), this.e);
                        return false;
                    }
                }
                int i2 = this.j;
                this.j = i;
                if (this.h.am() && i == 1) {
                    C0407l.m2881a().m2886a(this.h, 2);
                }
                if (i2 == 1 && i == 0) {
                    C0407l.m2881a().m2886a(this.h, 4);
                }
                new StringBuilder("conn/state:").append(i2).append("->").append(i);
                switch (i) {
                    case 0:
                    case 3:
                    case 4:
                    case 6:
                        C0380b.m2558a().m2561a(C0381c.CONNECTION_CLOSED);
                        m2836p();
                        if (i2 == 2) {
                            C0407l.m2881a().m2886a(this.h, 5);
                            break;
                        }
                        break;
                    case 1:
                        this.l.m133c();
                        m2820r().start();
                        break;
                    case 2:
                        C0407l.m2881a().m2886a(this.h, 1);
                        m2826u();
                        C0380b.m2558a().m2561a(C0381c.CONNECTION_ESTABLISHED);
                        break;
                    case 5:
                        this.f1601A = null;
                        this.f1612r = null;
                        break;
                    default:
                        return false;
                }
                return true;
            }
        }
    }

    private C0409n m2820r() {
        return new C0409n(this);
    }

    protected final C0410o m2828a(DataInputStream dataInputStream) {
        return new C0410o(this, dataInputStream);
    }

    protected C0398p m2829a(OutputStream outputStream) {
        return new C0398p(this, outputStream);
    }

    protected final int[] m2838x() {
        return new int[]{40, 42, 44, 45, 49, 51, 57, 58, 74, 80, 82, 85};
    }

    protected final boolean m2832a(Thread thread) {
        boolean z;
        synchronized (this.k) {
            z = this.f1613s == thread && (this.j == 2 || this.j == 5);
        }
        return z;
    }

    protected void m2836p() {
        this.f1613s = null;
        this.f1612r = null;
        this.i.m2849a(this.f1619z);
        this.q.m111a(this.f1603C);
        m2831a((short) -1);
        if (this.f1606F) {
            synchronized (this.f1616w) {
                if (this.f1606F) {
                    this.q.m111a(this.f1609I);
                    this.f1606F = false;
                }
            }
        }
        synchronized (this.p) {
            this.p.notifyAll();
        }
    }

    private void m2802b(Thread thread) {
        Object obj = null;
        synchronized (this.k) {
            if (this.f1613s == thread || this.f1612r == thread) {
                m2833b(4);
                obj = 1;
            }
        }
        if (obj != null) {
            m2788o();
            this.l.m132a(m2827v(), m2781h(), this.e);
        }
    }

    private C0345a m2821s() {
        return (C0345a) this.a_;
    }

    private void m2824t() {
        C0115e c0116b = new C0116b(20);
        this.h.m2655a((byte) 66, c0116b);
        c0116b.m1141d(0);
        m2771a(c0116b);
    }

    private void m2826u() {
        try {
            byte[] bArr = new byte[4];
            C0116b.m1145a(this.h.m2649X(), bArr);
            this.f1613s.f1596a.write(bArr);
            if (m96A()) {
                m2821s().m2472c(57);
                this.a_.m243a(58);
                this.a_.m247b(82);
            }
        } catch (Throwable e) {
            this.g.m124a((short) 65, "S: " + e.getMessage(), e);
        }
    }

    private void m2798a(String str, int i) {
        this.f1608H.m1040a(true);
        this.f1604D.m1044a(str);
        this.f1605E.m1042a((long) i);
        this.f1610J = 2000;
    }

    private boolean m2827v() {
        if (this.f1608H.m1041a()) {
            return true;
        }
        return m2786m();
    }
}
