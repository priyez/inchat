package com.facebook.p038e;

import android.content.Context;
import com.facebook.p038e.p045d.C0231a;
import com.facebook.p038e.p045d.C0232b;

/* renamed from: com.facebook.e.b */
public final class C0225b {
    private final C0232b f849a;
    private final Context f850b;
    private final C0212a f851c;

    public C0225b(Context context) {
        this.f849a = new C0232b(context);
        this.f850b = context;
        this.f851c = new C0212a(this);
    }

    private C0251k m1559a(C0251k c0251k, long j) {
        c0251k.m1661a(j);
        C0231a a = this.f849a.m1603a();
        if (a != null) {
            c0251k.m1676a("detailed_battery", a.m1579a());
        }
        return c0251k;
    }

    private static String m1560a() {
        return "ema_battery_status";
    }

    public final void m1562a(long j) {
        this.f851c.execute(new Long[]{Long.valueOf(j)});
    }

    private C0251k m1561b(long j) {
        C0251k c0251k = new C0251k(C0225b.m1560a());
        m1559a(c0251k, j);
        return c0251k;
    }
}
