package com.facebook.lite.p049a.p050a;

import com.facebook.lite.p049a.C0280i;
import com.p008a.p009a.p010a.p018f.C0047a;
import com.p026b.p027a.C0129a;
import com.p026b.p027a.C0135g;

/* renamed from: com.facebook.lite.a.a.a */
public abstract class C0261a {
    private static final String f995a;
    private final byte[] f996b;
    private C0047a f997c;
    private int f998d;
    private final C0135g f999e;
    private int f1000f;
    private int f1001g;

    static {
        f995a = C0261a.class.getSimpleName();
    }

    protected C0261a(C0135g c0135g, C0047a c0047a) {
        if (c0135g == null || c0047a == null) {
            throw new IllegalArgumentException("Null diskLruCache or cacheConfig");
        }
        this.f999e = c0135g;
        this.f997c = c0047a;
        this.f996b = c0047a.m324a();
    }

    public final byte[] m1803a() {
        return this.f996b;
    }

    public final byte m1804b() {
        return this.f997c.m325b();
    }

    public final int m1805c() {
        return this.f998d;
    }

    public final C0135g m1806d() {
        return this.f999e;
    }

    public final int m1807e() {
        return this.f1000f;
    }

    public final int m1808f() {
        return this.f997c.m326c();
    }

    public final int m1809g() {
        return this.f1001g;
    }

    public final void m1800a(int i) {
        this.f998d += i;
    }

    public final void m1810h() {
        this.f1000f++;
    }

    public final void m1811i() {
        this.f1001g++;
    }

    public final void m1812j() {
        this.f998d = 0;
    }

    public final void m1813k() {
        this.f1000f = 0;
    }

    public final void m1814l() {
        this.f1001g = 0;
    }

    public final void m1802a(C0129a c0129a) {
        this.f999e.m1291a(c0129a);
    }

    public final void m1801a(C0047a c0047a) {
        if (this.f997c.equals(c0047a)) {
            new StringBuilder().append(C0280i.m1873a(c0047a.m325b())).append("not updating, already up to date");
            return;
        }
        synchronized (this) {
            this.f997c = c0047a;
            this.f999e.m1290a((long) c0047a.m326c());
            new StringBuilder().append(C0280i.m1873a(c0047a.m325b())).append("updating persisted:").append(c0047a.m328e()).append(" maxSize:").append(c0047a.m326c());
        }
    }
}
