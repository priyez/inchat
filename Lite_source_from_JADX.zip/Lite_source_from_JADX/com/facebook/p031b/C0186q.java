package com.facebook.p031b;

import android.util.Log;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/* renamed from: com.facebook.b.q */
final class C0186q {
    protected static String m1457a(String str) {
        StringBuilder stringBuilder;
        Throwable e;
        int i = 0;
        try {
            ArrayList arrayList = new ArrayList();
            arrayList.add("logcat");
            if (str != null) {
                arrayList.add("-b");
                arrayList.add(str);
            }
            Collection arrayList2 = new ArrayList(Arrays.asList(C0148a.m1327a().m1315b()));
            int indexOf = arrayList2.indexOf("-t");
            if (indexOf >= 0 && indexOf < arrayList2.size() && C0153b.m1337a() < 8) {
                arrayList2.remove(indexOf + 1);
                arrayList2.remove(indexOf);
                arrayList2.add("-d");
            }
            arrayList.addAll(arrayList2);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec((String[]) arrayList.toArray(new String[arrayList.size()])).getInputStream()));
            String str2 = C0148a.f621a;
            List arrayList3 = new ArrayList(100);
            int i2 = 0;
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                arrayList3.add(readLine);
                i2 = (i2 + readLine.length()) + 1;
            }
            stringBuilder = new StringBuilder(i2);
            while (i < arrayList3.size()) {
                try {
                    stringBuilder.append((String) arrayList3.get(i));
                    stringBuilder.append("\n");
                    i++;
                } catch (IOException e2) {
                    e = e2;
                }
            }
        } catch (IOException e3) {
            e = e3;
            stringBuilder = null;
            Log.e(C0148a.f621a, "LogCatCollector.collectLogcat could not retrieve data.", e);
            return stringBuilder != null ? stringBuilder.toString() : null;
        }
        if (stringBuilder != null) {
        }
    }
}
