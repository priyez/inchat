package com.facebook.lite.autoupdate;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Environment;
import android.util.Log;
import com.facebook.lite.an;
import com.facebook.lite.ao;
import com.facebook.lite.notification.C0412a;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p053b.C0301o;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

/* renamed from: com.facebook.lite.autoupdate.a */
public class C0286a extends IntentService {
    private static final String f1161a;

    static {
        f1161a = IntentService.class.getSimpleName();
    }

    public C0286a() {
        super(f1161a);
    }

    protected void onHandleIntent(Intent intent) {
        InputStream bufferedInputStream;
        Throwable e;
        InputStream inputStream = null;
        if (C0294h.m1976g()) {
            File externalStorageDirectory = C0301o.m2173a() ? Environment.getExternalStorageDirectory() : Environment.getDataDirectory();
            File file = new File(externalStorageDirectory, "ema.apk");
            if (file.exists()) {
                file.delete();
            }
            if (C0301o.m2169a(externalStorageDirectory) < 1) {
                m1932a(14400000);
                return;
            }
            FileOutputStream fileOutputStream;
            try {
                URLConnection openConnection = new URL("https://ci-builds.fb.com/job/snaptu/lastSuccessfulBuild/com.moblica$android-client/artifact/com.moblica/android-client/0.1/android-client-0.1.apk").openConnection();
                openConnection.connect();
                bufferedInputStream = new BufferedInputStream(openConnection.getInputStream());
                try {
                    fileOutputStream = new FileOutputStream(file.getPath());
                    try {
                        byte[] bArr = new byte[1024];
                        while (true) {
                            int read = bufferedInputStream.read(bArr);
                            if (read == -1) {
                                break;
                            }
                            fileOutputStream.write(bArr, 0, read);
                        }
                        Intent intent2;
                        if (C0294h.m1984n(getApplicationContext())) {
                            intent2 = new Intent();
                            intent2.setAction("com.facebook.lite.NEW_VERSION_DOWNLOADED");
                            intent2.putExtra("extra_uri", Uri.fromFile(file));
                            sendBroadcast(intent2);
                        } else {
                            intent2 = new Intent("android.intent.action.VIEW");
                            intent2.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
                            intent2.setFlags(268435456);
                            m1933a(intent2);
                        }
                        m1932a(86400000);
                        fileOutputStream.flush();
                        try {
                            bufferedInputStream.close();
                        } catch (Throwable e2) {
                            Log.e(f1161a, "autoupdate/fail to close input stream.", e2);
                        }
                        try {
                            fileOutputStream.close();
                            return;
                        } catch (Throwable e22) {
                            Log.e(f1161a, "autoupdate/fail to close output stream.", e22);
                            return;
                        }
                    } catch (Exception e3) {
                        e22 = e3;
                        inputStream = bufferedInputStream;
                        try {
                            Log.e(f1161a, "autoupdate/fail to connect to server.", e22);
                            m1932a(14400000);
                            if (inputStream != null) {
                                try {
                                    inputStream.close();
                                } catch (Throwable e222) {
                                    Log.e(f1161a, "autoupdate/fail to close input stream.", e222);
                                }
                            }
                            if (fileOutputStream == null) {
                                try {
                                    fileOutputStream.close();
                                    return;
                                } catch (Throwable e2222) {
                                    Log.e(f1161a, "autoupdate/fail to close output stream.", e2222);
                                    return;
                                }
                            }
                            return;
                        } catch (Throwable th) {
                            e2222 = th;
                            bufferedInputStream = inputStream;
                            if (bufferedInputStream != null) {
                                try {
                                    bufferedInputStream.close();
                                } catch (Throwable e4) {
                                    Log.e(f1161a, "autoupdate/fail to close input stream.", e4);
                                }
                            }
                            if (fileOutputStream != null) {
                                try {
                                    fileOutputStream.close();
                                } catch (Throwable e5) {
                                    Log.e(f1161a, "autoupdate/fail to close output stream.", e5);
                                }
                            }
                            throw e2222;
                        }
                    } catch (Throwable th2) {
                        e2222 = th2;
                        if (bufferedInputStream != null) {
                            bufferedInputStream.close();
                        }
                        if (fileOutputStream != null) {
                            fileOutputStream.close();
                        }
                        throw e2222;
                    }
                } catch (Exception e6) {
                    e2222 = e6;
                    fileOutputStream = null;
                    inputStream = bufferedInputStream;
                    Log.e(f1161a, "autoupdate/fail to connect to server.", e2222);
                    m1932a(14400000);
                    if (inputStream != null) {
                        inputStream.close();
                    }
                    if (fileOutputStream == null) {
                        fileOutputStream.close();
                        return;
                    }
                    return;
                } catch (Throwable th3) {
                    e2222 = th3;
                    fileOutputStream = null;
                    if (bufferedInputStream != null) {
                        bufferedInputStream.close();
                    }
                    if (fileOutputStream != null) {
                        fileOutputStream.close();
                    }
                    throw e2222;
                }
            } catch (Exception e7) {
                e2222 = e7;
                fileOutputStream = null;
                Log.e(f1161a, "autoupdate/fail to connect to server.", e2222);
                m1932a(14400000);
                if (inputStream != null) {
                    inputStream.close();
                }
                if (fileOutputStream == null) {
                    fileOutputStream.close();
                    return;
                }
                return;
            } catch (Throwable th4) {
                e2222 = th4;
                fileOutputStream = null;
                bufferedInputStream = null;
                if (bufferedInputStream != null) {
                    bufferedInputStream.close();
                }
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
                throw e2222;
            }
        }
        m1932a(14400000);
    }

    private void m1932a(int i) {
        C0294h.m1956a((Context) this, C0286a.class, i);
        C0300n.m2094a((Context) this, System.currentTimeMillis());
    }

    private void m1933a(Intent intent) {
        Notification b;
        NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
        PendingIntent activity = PendingIntent.getActivity(this, 0, intent, 268435456);
        if (VERSION.SDK_INT >= 11) {
            b = C0412a.m2917b(ao.sysnotif_facebook, getString(an.notification_update), System.currentTimeMillis(), this, getString(an.app_name), getString(an.notification_update), activity);
        } else {
            b = C0412a.m2916a(ao.sysnotif_facebook, getString(an.notification_update), System.currentTimeMillis(), this, getString(an.app_name), getString(an.notification_update), activity);
        }
        b.flags |= 16;
        notificationManager.notify(120099, b);
    }
}
