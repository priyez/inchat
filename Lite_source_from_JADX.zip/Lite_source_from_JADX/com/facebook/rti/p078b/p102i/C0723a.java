package com.facebook.rti.p078b.p102i;

import com.facebook.rti.p078b.p080b.p084d.C0588j;

/* renamed from: com.facebook.rti.b.i.a */
final class C0723a implements C0588j {
    final /* synthetic */ C0724b f3100a;

    C0723a(C0724b c0724b) {
        this.f3100a = c0724b;
    }

    public final void m3920a() {
        C0724b.m3922a(this.f3100a);
    }

    public final void m3921b() {
        C0724b.m3923b(this.f3100a);
    }
}
