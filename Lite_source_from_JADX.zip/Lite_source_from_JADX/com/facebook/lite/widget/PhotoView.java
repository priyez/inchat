package com.facebook.lite.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.GestureDetector.OnDoubleTapListener;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.OrientationEventListener;
import android.view.ScaleGestureDetector;
import android.view.ScaleGestureDetector.OnScaleGestureListener;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import com.facebook.lite.p053b.C0300n;

public class PhotoView extends View implements OnDoubleTapListener, OnGestureListener, OnScaleGestureListener {
    public static Bitmap f1954a;
    private static boolean f1955b;
    private static int f1956c;
    private static Paint f1957d;
    private static Paint f1958e;
    private int f1959A;
    private boolean f1960B;
    private boolean f1961C;
    private int f1962D;
    private int f1963E;
    private int f1964F;
    private Matrix f1965G;
    private float f1966H;
    private float f1967I;
    private float f1968J;
    private OrientationEventListener f1969K;
    private Matrix f1970L;
    private float f1971M;
    private int f1972N;
    private byte f1973O;
    private ai f1974P;
    private float f1975Q;
    private ScaleGestureDetector f1976R;
    private ak f1977S;
    private am f1978T;
    private int f1979U;
    private RectF f1980V;
    private RectF f1981W;
    private boolean aa;
    private RectF ab;
    private an ac;
    private float[] ad;
    private boolean f1982f;
    private boolean f1983g;
    private Rect f1984h;
    private int f1985i;
    private int f1986j;
    private float f1987k;
    private boolean f1988l;
    private boolean f1989m;
    private boolean f1990n;
    private BitmapDrawable f1991o;
    private Matrix f1992p;
    private OnClickListener f1993q;
    private aj f1994r;
    private int f1995s;
    private boolean f1996t;
    private GestureDetector f1997u;
    private boolean f1998v;
    private int f1999w;
    private boolean f2000x;
    private boolean f2001y;
    private float f2002z;

    public PhotoView(Context context) {
        super(context);
        this.f1982f = true;
        this.f1984h = new Rect();
        this.f1986j = -1;
        this.f1989m = false;
        this.f1990n = true;
        this.f1994r = null;
        this.f1995s = -1;
        this.f1959A = al.f2058b;
        this.f1965G = new Matrix();
        this.f1969K = new af(this, getContext());
        this.f1970L = new Matrix();
        this.f1972N = ah.f2038c;
        this.f1979U = -1;
        this.f1980V = new RectF();
        this.f1981W = new RectF();
        this.ab = new RectF();
        this.ad = new float[9];
        m3247g();
    }

    public PhotoView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1982f = true;
        this.f1984h = new Rect();
        this.f1986j = -1;
        this.f1989m = false;
        this.f1990n = true;
        this.f1994r = null;
        this.f1995s = -1;
        this.f1959A = al.f2058b;
        this.f1965G = new Matrix();
        this.f1969K = new af(this, getContext());
        this.f1970L = new Matrix();
        this.f1972N = ah.f2038c;
        this.f1979U = -1;
        this.f1980V = new RectF();
        this.f1981W = new RectF();
        this.ab = new RectF();
        this.ad = new float[9];
        m3247g();
    }

    public PhotoView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1982f = true;
        this.f1984h = new Rect();
        this.f1986j = -1;
        this.f1989m = false;
        this.f1990n = true;
        this.f1994r = null;
        this.f1995s = -1;
        this.f1959A = al.f2058b;
        this.f1965G = new Matrix();
        this.f1969K = new af(this, getContext());
        this.f1970L = new Matrix();
        this.f1972N = ah.f2038c;
        this.f1979U = -1;
        this.f1980V = new RectF();
        this.f1981W = new RectF();
        this.ab = new RectF();
        this.ad = new float[9];
        m3247g();
    }

    private void m3230a(Bitmap bitmap) {
        boolean z;
        if (this.f1991o == null) {
            z = false;
        } else if (bitmap != this.f1991o.getBitmap()) {
            z = (bitmap == null || (this.f1991o.getIntrinsicWidth() == bitmap.getWidth() && this.f1991o.getIntrinsicHeight() == bitmap.getHeight())) ? false : true;
            this.f1967I = 0.0f;
            this.f1991o = null;
        } else {
            return;
        }
        if (this.f1991o == null && bitmap != null) {
            this.f1991o = new BitmapDrawable(getResources(), bitmap);
        }
        if (z) {
            this.f1963E = 0;
            this.f1962D = 0;
        }
        m3237b(z);
        invalidate();
    }

    public final void m3248a() {
        this.f1991o = null;
        if (this.f1977S != null) {
            this.f1977S.m3276a();
        }
        if (this.f1978T != null) {
            this.f1978T.m3278a();
        }
        if (this.f1974P != null) {
            this.f1974P.m3274a();
        }
        if (this.ac != null) {
            this.ac.m3281a();
        }
    }

    public final void m3251a(Bitmap bitmap, int i, int i2, byte b, boolean z) {
        m3242d();
        m3230a(bitmap);
        this.f1979U = i2;
        this.f1986j = i;
        this.f1973O = b;
        setVisibility(0);
        setMaxScale(((float) b) * m3234b(bitmap));
        m3239c();
        if (z) {
            setFullScreen$25decb5(true);
            m3229a(getMidScreenX(), getMidScreenY());
        }
    }

    private void m3239c() {
        this.aa = true;
        if (!this.aa) {
            m3243e();
        }
    }

    private void m3229a(int i, int i2) {
        this.f1977S.m3277a(getScale(), getMaxScale(), (float) i, (float) i2);
    }

    public Bitmap getCroppedPhoto() {
        if (!this.f1983g) {
            return null;
        }
        Bitmap createBitmap = Bitmap.createBitmap(256, 256, Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        float f = 256.0f / ((float) (this.f1984h.right - this.f1984h.left));
        Matrix matrix = new Matrix(this.f1992p);
        matrix.postTranslate((float) (-this.f1984h.left), (float) (-this.f1984h.top));
        matrix.postScale(f, f);
        if (this.f1991o == null) {
            return createBitmap;
        }
        canvas.concat(matrix);
        this.f1991o.draw(canvas);
        return createBitmap;
    }

    public int getCurrImageId() {
        return this.f1986j;
    }

    public float getMaxScale() {
        return this.f1966H;
    }

    public float getMinScale() {
        return this.f1967I;
    }

    public Bitmap getPhoto() {
        if (this.f1991o != null) {
            return this.f1991o.getBitmap();
        }
        return null;
    }

    public int getTargetImageId() {
        return this.f1979U;
    }

    public final void m3253b() {
        this.f1982f = false;
    }

    public final void m3252a(boolean z) {
        if (this.f1982f && z) {
            this.f1969K.enable();
        } else {
            this.f1969K.disable();
        }
    }

    public boolean onDoubleTap(MotionEvent motionEvent) {
        if (this.f1990n && this.aa) {
            if (!this.f1988l) {
                float scale = getScale();
                float min = Math.min(this.f1966H, Math.max(this.f1967I, scale == this.f1967I ? 2.5f : this.f1967I));
                if (min == this.f1967I) {
                    this.f1989m = true;
                    this.f1977S.m3277a(scale, min, (float) (getWidth() / 2), (float) (getHeight() / 2));
                } else {
                    this.f1989m = false;
                    this.f1977S.m3277a(scale, min, motionEvent.getX(), motionEvent.getY());
                }
            }
            this.f1988l = false;
        }
        return true;
    }

    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        return true;
    }

    public boolean onDown(MotionEvent motionEvent) {
        if (this.aa) {
            this.ac.m3281a();
            this.f1978T.m3278a();
        }
        return true;
    }

    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
        if (this.aa) {
            this.ac.m3282a(f, f2);
        }
        return true;
    }

    public void onLongPress(MotionEvent motionEvent) {
    }

    public boolean onScale(ScaleGestureDetector scaleGestureDetector) {
        if (this.aa) {
            this.f1960B = false;
            float scale = getScale() * scaleGestureDetector.getScaleFactor();
            if (this.f1994r != null) {
                this.f1994r.m1927a(scale);
            }
            m3228a(scale, scaleGestureDetector.getFocusX(), scaleGestureDetector.getFocusY(), false);
        }
        return true;
    }

    public boolean onScaleBegin(ScaleGestureDetector scaleGestureDetector) {
        if (this.aa) {
            this.f1977S.m3276a();
            this.f1960B = true;
        }
        return true;
    }

    public void onScaleEnd(ScaleGestureDetector scaleGestureDetector) {
        if (this.aa && this.f1960B) {
            this.f1988l = true;
            m3243e();
        }
    }

    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
        if (this.aa) {
            m3232a(-f, -f2);
        }
        return true;
    }

    public void onShowPress(MotionEvent motionEvent) {
    }

    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        if (!(this.f1993q == null || this.f1960B)) {
            this.f1993q.onClick(this);
        }
        this.f1960B = false;
        return true;
    }

    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return false;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!(this.f1976R == null || this.f1997u == null)) {
            this.f1976R.onTouchEvent(motionEvent);
            this.f1997u.onTouchEvent(motionEvent);
            switch (motionEvent.getAction()) {
                case 1:
                case 3:
                    if (!this.ac.f2069b) {
                        m3240c(false);
                        break;
                    }
                    break;
                default:
                    break;
            }
        }
        return true;
    }

    private void m3242d() {
        this.f1989m = false;
        this.f1990n = true;
        this.f1975Q = 0.0f;
        this.f1964F = 0;
        this.f1972N = ah.f2038c;
        this.f1967I = 0.0f;
        this.f1986j = -1;
        this.f1979U = -1;
        m3247g();
    }

    private void m3243e() {
        this.f1965G.set(this.f1970L);
        this.f1987k = this.f1971M;
        invalidate();
    }

    public final void m3249a(float f, boolean z) {
        if (z) {
            this.f1974P.m3275a(f);
            return;
        }
        this.f1975Q += f;
        this.f1965G.postRotate(f, (float) (getWidth() / 2), (float) (getHeight() / 2));
        invalidate();
    }

    public void setFixedHeight(int i) {
        boolean z = i != this.f1995s;
        this.f1995s = i;
        setMeasuredDimension(getMeasuredWidth(), this.f1995s);
        if (z) {
            m3237b(true);
            requestLayout();
        }
    }

    private void setFullScreen$25decb5(boolean z) {
        if (true != this.f1996t) {
            this.f1996t = true;
            requestLayout();
            invalidate();
        }
    }

    public void setHeightForInitialScaleCalculation(int i) {
        this.f1999w = i;
    }

    public void setIgnoreRescaleOnHeightChange(boolean z) {
        this.f2000x = z;
    }

    public void setIgnoreRescaleOnWidthChange(boolean z) {
        this.f2001y = z;
    }

    public void setInitialFitTolerance(float f) {
        this.f2002z = f;
    }

    public void setInitialScaleType$208dc1b2(int i) {
        this.f1959A = i;
    }

    public void setIsVideo(boolean z) {
        this.f1961C = z;
    }

    public void setMaxScale(float f) {
        this.f1966H = f;
    }

    public void setOnClickListener(OnClickListener onClickListener) {
        this.f1993q = onClickListener;
    }

    public void setScaleListener(aj ajVar) {
        this.f1994r = ajVar;
    }

    public final void m3250a(Bitmap bitmap, int i) {
        if (i != this.f1986j) {
            this.f1986j = i;
            float f = (this.ab.right + this.ab.left) / 2.0f;
            float f2 = (this.ab.bottom + this.ab.top) / 2.0f;
            float intrinsicWidth = (this.f1987k * ((float) this.f1991o.getIntrinsicWidth())) / ((float) bitmap.getWidth());
            m3230a(bitmap);
            m3228a(intrinsicWidth, f, f2, true);
            m3232a(f - ((this.ab.right + this.ab.left) / 2.0f), f2 - ((this.ab.bottom + this.ab.top) / 2.0f));
            setMaxScale(((float) this.f1973O) * m3234b(bitmap));
            invalidate();
        }
    }

    protected float getScale() {
        return this.f1987k;
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f1991o != null) {
            int saveCount = canvas.getSaveCount();
            canvas.save();
            if (this.f1992p != null) {
                canvas.concat(this.f1992p);
            }
            this.f1991o.draw(canvas);
            canvas.restoreToCount(saveCount);
            if (this.f1961C) {
                Bitmap bitmap = f1954a;
                canvas.drawBitmap(bitmap, (float) ((getWidth() - bitmap.getWidth()) / 2), (float) ((getHeight() - bitmap.getHeight()) / 2), null);
            }
            this.ab.set(this.f1991o.getBounds());
            if (Math.abs(this.f1975Q % 180.0f) == 90.0f) {
                float f = this.ab.right;
                this.ab.right = this.ab.bottom;
                this.ab.bottom = f;
            }
            if (this.f1992p != null) {
                this.f1992p.mapRect(this.ab);
            }
            if (this.f1983g) {
                int saveCount2 = canvas.getSaveCount();
                canvas.drawRect(0.0f, 0.0f, (float) getWidth(), (float) getHeight(), f1957d);
                canvas.save();
                canvas.clipRect(this.f1984h);
                if (this.f1992p != null) {
                    canvas.concat(this.f1992p);
                }
                this.f1991o.draw(canvas);
                canvas.restoreToCount(saveCount2);
                canvas.drawRect(this.f1984h, f1958e);
            }
            if (getScale() == this.f1967I && this.f1989m) {
                this.f1994r.m1926a();
            }
        }
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        this.f1998v = true;
        int width = getWidth();
        int height = getHeight();
        if (this.f1983g) {
            this.f1985i = Math.min(f1956c, Math.min(width, height));
            width = (width - this.f1985i) / 2;
            height = (height - this.f1985i) / 2;
            this.f1984h.set(width, height, this.f1985i + width, this.f1985i + height);
        }
        m3237b(z);
    }

    protected void onMeasure(int i, int i2) {
        if (this.f1995s != -1) {
            super.onMeasure(i, MeasureSpec.makeMeasureSpec(this.f1995s, Integer.MIN_VALUE));
            setMeasuredDimension(getMeasuredWidth(), this.f1995s);
            return;
        }
        super.onMeasure(i, i2);
    }

    private void m3237b(boolean z) {
        if (this.f1991o != null && this.f1998v) {
            int intrinsicWidth = this.f1991o.getIntrinsicWidth();
            int intrinsicHeight = this.f1991o.getIntrinsicHeight();
            this.f1991o.setBounds(0, 0, intrinsicWidth, intrinsicHeight);
            if (Math.abs(this.f1975Q % 180.0f) != 90.0f) {
                int i = intrinsicHeight;
                intrinsicHeight = intrinsicWidth;
                intrinsicWidth = i;
            }
            intrinsicWidth = ((intrinsicHeight < 0 || getWidth() == intrinsicHeight) && (intrinsicWidth < 0 || getHeight() == intrinsicWidth)) ? 1 : 0;
            if (z || (this.f1967I == 0.0f && this.f1991o != null && this.f1998v)) {
                m3245f();
            }
            if (intrinsicWidth != 0 || this.f1965G.isIdentity()) {
                this.f1992p = null;
            } else {
                this.f1992p = this.f1965G;
            }
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m3245f() {
        /*
        r13 = this;
        r12 = 1077936128; // 0x40400000 float:3.0 double:5.325712093E-315;
        r11 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r10 = 1127481344; // 0x43340000 float:180.0 double:5.570497984E-315;
        r8 = 1119092736; // 0x42b40000 float:90.0 double:5.529052754E-315;
        r9 = 0;
        r0 = r13.f1991o;
        r3 = r0.getIntrinsicWidth();
        r0 = r13.f1991o;
        r4 = r0.getIntrinsicHeight();
        r0 = r13.f1983g;
        if (r0 == 0) goto L_0x006d;
    L_0x0019:
        r0 = f1956c;
    L_0x001b:
        r1 = r13.f1983g;
        if (r1 == 0) goto L_0x0072;
    L_0x001f:
        r2 = f1956c;
    L_0x0021:
        if (r3 < 0) goto L_0x0025;
    L_0x0023:
        if (r0 != r3) goto L_0x0077;
    L_0x0025:
        if (r4 < 0) goto L_0x0029;
    L_0x0027:
        if (r2 != r4) goto L_0x0077;
    L_0x0029:
        r1 = 1;
    L_0x002a:
        r13.f1968J = r9;
        r5 = r13.f1965G;
        r5.reset();
        if (r1 == 0) goto L_0x0079;
    L_0x0033:
        r1 = r13.f1983g;
        if (r1 != 0) goto L_0x0079;
    L_0x0037:
        r13.f1967I = r11;
        r13.f1987k = r11;
    L_0x003b:
        r0 = r13.f1966H;
        r1 = r13.f1967I;
        r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1));
        if (r0 >= 0) goto L_0x004c;
    L_0x0043:
        r0 = r13.f1967I;
        r0 = r0 * r12;
        r0 = java.lang.Math.max(r0, r12);
        r13.f1966H = r0;
    L_0x004c:
        r0 = r13.f1965G;
        r1 = r13.f1975Q;
        r2 = r13.getWidth();
        r2 = r2 / 2;
        r2 = (float) r2;
        r3 = r13.getHeight();
        r3 = r3 / 2;
        r3 = (float) r3;
        r0.postRotate(r1, r2, r3);
        r0 = r13.f1987k;
        r13.f1971M = r0;
        r0 = r13.f1970L;
        r1 = r13.f1965G;
        r0.set(r1);
        return;
    L_0x006d:
        r0 = r13.getWidth();
        goto L_0x001b;
    L_0x0072:
        r2 = r13.getHeight();
        goto L_0x0021;
    L_0x0077:
        r1 = 0;
        goto L_0x002a;
    L_0x0079:
        r1 = r13.f1981W;
        r5 = (float) r3;
        r6 = (float) r4;
        r1.set(r9, r9, r5, r6);
        r1 = r13.f1983g;
        if (r1 == 0) goto L_0x013f;
    L_0x0084:
        r1 = r13.f1980V;
        r5 = r13.f1984h;
        r1.set(r5);
    L_0x008b:
        r1 = r13.f1965G;
        r5 = r0 / 2;
        r6 = r3 / 2;
        r5 = r5 - r6;
        r5 = (float) r5;
        r6 = r2 / 2;
        r7 = r4 / 2;
        r6 = r6 - r7;
        r6 = (float) r6;
        r1.setTranslate(r5, r6);
        r1 = r13.f1999w;
        if (r1 == 0) goto L_0x01c0;
    L_0x00a0:
        r1 = r13.f1999w;
    L_0x00a2:
        r2 = r13.f1975Q;
        r2 = r2 % r10;
        r2 = java.lang.Math.abs(r2);
        r2 = (r2 > r8 ? 1 : (r2 == r8 ? 0 : -1));
        if (r2 != 0) goto L_0x0148;
    L_0x00ad:
        r2 = (float) r0;
        r5 = (float) r4;
        r2 = r2 / r5;
        r5 = (float) r1;
        r6 = (float) r3;
        r5 = r5 / r6;
        r2 = java.lang.Math.min(r2, r5);
    L_0x00b7:
        r13.f1967I = r2;
        r2 = r13.f1967I;
        r5 = r13.f1966H;
        r2 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1));
        if (r2 <= 0) goto L_0x00c5;
    L_0x00c1:
        r2 = r13.f1966H;
        r13.f1967I = r2;
    L_0x00c5:
        r2 = r13.f1959A;
        r5 = com.facebook.lite.widget.al.f2057a;
        if (r2 != r5) goto L_0x015f;
    L_0x00cb:
        r2 = r13.f1975Q;
        r2 = r2 % r10;
        r2 = java.lang.Math.abs(r2);
        r2 = (r2 > r8 ? 1 : (r2 == r8 ? 0 : -1));
        if (r2 != 0) goto L_0x0154;
    L_0x00d6:
        r2 = (float) r0;
        r5 = (float) r4;
        r2 = r2 / r5;
        r5 = (float) r1;
        r6 = (float) r3;
        r5 = r5 / r6;
        r2 = java.lang.Math.max(r2, r5);
    L_0x00e0:
        r5 = r13.f1975Q;
        r5 = r5 % r10;
        r5 = java.lang.Math.abs(r5);
        r5 = (r5 > r8 ? 1 : (r5 == r8 ? 0 : -1));
        if (r5 != 0) goto L_0x0199;
    L_0x00eb:
        r5 = (float) r0;
        r6 = (float) r4;
        r5 = r5 / r6;
        r6 = (float) r1;
        r7 = (float) r3;
        r6 = r6 / r7;
        r7 = r5 / r6;
        r7 = r7 - r11;
        r7 = java.lang.Math.abs(r7);
        r8 = r13.f2002z;
        r7 = (r7 > r8 ? 1 : (r7 == r8 ? 0 : -1));
        if (r7 >= 0) goto L_0x0106;
    L_0x00fe:
        r2 = java.lang.Math.max(r5, r6);
        r13.f1968J = r2;
        r2 = r13.f1968J;
    L_0x0106:
        r5 = r13.f1987k;
        r5 = (r5 > r9 ? 1 : (r5 == r9 ? 0 : -1));
        if (r5 != 0) goto L_0x0110;
    L_0x010c:
        r5 = r13.f1967I;
        r13.f1987k = r5;
    L_0x0110:
        r5 = r13.f2001y;
        if (r5 == 0) goto L_0x0118;
    L_0x0114:
        r5 = r13.f2000x;
        if (r5 != 0) goto L_0x0122;
    L_0x0118:
        r5 = r13.f2000x;
        if (r5 == 0) goto L_0x01b6;
    L_0x011c:
        r5 = r13.f1963E;
        if (r5 == r0) goto L_0x0122;
    L_0x0120:
        r13.f1987k = r2;
    L_0x0122:
        r13.f1963E = r0;
        r13.f1962D = r1;
        r0 = r13.f1968J;
        r0 = java.lang.Math.min(r0, r12);
        r13.f1968J = r0;
        r0 = r13.f1965G;
        r1 = r13.f1987k;
        r2 = r13.f1987k;
        r3 = r3 / 2;
        r3 = (float) r3;
        r4 = r4 / 2;
        r4 = (float) r4;
        r0.preScale(r1, r2, r3, r4);
        goto L_0x003b;
    L_0x013f:
        r1 = r13.f1980V;
        r5 = (float) r0;
        r6 = (float) r2;
        r1.set(r9, r9, r5, r6);
        goto L_0x008b;
    L_0x0148:
        r2 = (float) r0;
        r5 = (float) r3;
        r2 = r2 / r5;
        r5 = (float) r1;
        r6 = (float) r4;
        r5 = r5 / r6;
        r2 = java.lang.Math.min(r2, r5);
        goto L_0x00b7;
    L_0x0154:
        r2 = (float) r0;
        r5 = (float) r3;
        r2 = r2 / r5;
        r5 = (float) r1;
        r6 = (float) r4;
        r5 = r5 / r6;
        r2 = java.lang.Math.max(r2, r5);
        goto L_0x00e0;
    L_0x015f:
        r2 = r13.f1959A;
        r5 = com.facebook.lite.widget.al.f2060d;
        if (r2 != r5) goto L_0x017a;
    L_0x0165:
        r2 = r13.f1975Q;
        r2 = r2 % r10;
        r2 = java.lang.Math.abs(r2);
        r2 = (r2 > r8 ? 1 : (r2 == r8 ? 0 : -1));
        if (r2 != 0) goto L_0x0175;
    L_0x0170:
        r2 = (float) r0;
        r5 = (float) r4;
        r2 = r2 / r5;
        goto L_0x00e0;
    L_0x0175:
        r2 = (float) r0;
        r5 = (float) r3;
        r2 = r2 / r5;
        goto L_0x00e0;
    L_0x017a:
        r2 = r13.f1959A;
        r5 = com.facebook.lite.widget.al.f2059c;
        if (r2 != r5) goto L_0x0195;
    L_0x0180:
        r2 = r13.f1975Q;
        r2 = r2 % r10;
        r2 = java.lang.Math.abs(r2);
        r2 = (r2 > r8 ? 1 : (r2 == r8 ? 0 : -1));
        if (r2 != 0) goto L_0x0190;
    L_0x018b:
        r2 = (float) r1;
        r5 = (float) r3;
        r2 = r2 / r5;
        goto L_0x00e0;
    L_0x0190:
        r2 = (float) r1;
        r5 = (float) r4;
        r2 = r2 / r5;
        goto L_0x00e0;
    L_0x0195:
        r2 = r13.f1967I;
        goto L_0x00e0;
    L_0x0199:
        r5 = (float) r0;
        r6 = (float) r3;
        r5 = r5 / r6;
        r6 = (float) r1;
        r7 = (float) r4;
        r6 = r6 / r7;
        r7 = r5 / r6;
        r7 = r7 - r11;
        r7 = java.lang.Math.abs(r7);
        r8 = r13.f2002z;
        r7 = (r7 > r8 ? 1 : (r7 == r8 ? 0 : -1));
        if (r7 >= 0) goto L_0x0106;
    L_0x01ac:
        r2 = java.lang.Math.max(r5, r6);
        r13.f1968J = r2;
        r2 = r13.f1968J;
        goto L_0x0106;
    L_0x01b6:
        r5 = r13.f2001y;
        if (r5 == 0) goto L_0x0120;
    L_0x01ba:
        r5 = r13.f1962D;
        if (r5 == r1) goto L_0x0122;
    L_0x01be:
        goto L_0x0120;
    L_0x01c0:
        r1 = r2;
        goto L_0x00a2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.widget.PhotoView.f():void");
    }

    private int getCropSize() {
        return this.f1985i > 0 ? this.f1985i : f1956c;
    }

    private float m3234b(Bitmap bitmap) {
        float screenWidth;
        if (bitmap.getWidth() > bitmap.getHeight()) {
            screenWidth = ((float) getScreenWidth()) / ((float) bitmap.getWidth());
        } else {
            screenWidth = ((float) getScreenHeight()) / ((float) bitmap.getHeight());
        }
        if (screenWidth < 1.0f) {
            return 1.0f;
        }
        return screenWidth;
    }

    private int getMidScreenX() {
        return getScreenWidth() / 2;
    }

    private int getMidScreenY() {
        return getScreenHeight() / 2;
    }

    private int getScreenHeight() {
        return C0300n.m2102b(getContext());
    }

    private int getScreenWidth() {
        return C0300n.m2120d(getContext());
    }

    private void m3247g() {
        Context context = getContext();
        if (!f1955b) {
            f1955b = true;
            Paint paint = new Paint();
            f1957d = paint;
            paint.setAntiAlias(true);
            f1957d.setStyle(Style.FILL);
            paint = new Paint();
            f1958e = paint;
            paint.setAntiAlias(true);
            f1958e.setStyle(Style.STROKE);
        }
        this.f1997u = new GestureDetector(context, this, null);
        this.f1976R = new ScaleGestureDetector(context, this);
        if (VERSION.SDK_INT >= 19) {
            this.f1976R.setQuickScaleEnabled(false);
        }
        this.f1977S = new ak(this);
        this.ac = new an(this);
        this.f1978T = new am(this);
        this.f1974P = new ai(this);
        this.f1969K.disable();
    }

    private void m3228a(float f, float f2, float f3, boolean z) {
        float min = Math.min(Math.max(f, this.f1967I), this.f1966H);
        float scale = min / getScale();
        this.f1965G.postRotate(-this.f1975Q, (float) (getWidth() / 2), (float) (getHeight() / 2));
        this.f1965G.postScale(scale, scale, f2, f3);
        this.f1987k = min;
        this.f1965G.postRotate(this.f1975Q, (float) (getWidth() / 2), (float) (getHeight() / 2));
        m3240c(z);
        invalidate();
    }

    private void m3240c(boolean z) {
        float f = 0.0f;
        this.ab.set(this.f1981W);
        this.f1965G.mapRect(this.ab);
        float f2 = this.f1983g ? (float) this.f1984h.left : 0.0f;
        float width = this.f1983g ? (float) this.f1984h.right : (float) getWidth();
        float f3 = this.ab.left;
        float f4 = this.ab.right;
        f2 = f4 - f3 < width - f2 ? f2 + (((width - f2) - (f3 + f4)) / 2.0f) : f3 > f2 ? f2 - f3 : f4 < width ? width - f4 : 0.0f;
        if (this.f1983g) {
            width = (float) this.f1984h.top;
        } else {
            width = 0.0f;
        }
        f3 = this.f1983g ? (float) this.f1984h.bottom : (float) getHeight();
        f4 = this.ab.top;
        float f5 = this.ab.bottom;
        if (f5 - f4 < f3 - width) {
            f = (((f3 - width) - (f5 + f4)) / 2.0f) + width;
        } else if (f4 > width) {
            f = width - f4;
        } else if (f5 < f3) {
            f = f3 - f5;
        }
        if ((Math.abs(f2) > 20.0f || Math.abs(f) > 20.0f) && !z) {
            this.f1978T.m3279a(f2, f);
            return;
        }
        this.f1965G.postTranslate(f2, f);
        invalidate();
    }

    private boolean m3232a(float f, float f2) {
        float f3;
        float f4 = 0.0f;
        this.ab.set(this.f1981W);
        this.f1965G.mapRect(this.ab);
        float f5 = this.f1983g ? (float) this.f1984h.left : 0.0f;
        if (this.f1983g) {
            f3 = (float) this.f1984h.right;
        } else {
            f3 = (float) getWidth();
        }
        float f6 = this.ab.left;
        float f7 = this.ab.right;
        if (this.f1983g) {
            f5 = Math.max(f5 - this.ab.right, Math.min(f3 - this.ab.left, f));
        } else if (f7 - f6 < f3 - f5) {
            f5 += ((f3 - f5) - (f6 + f7)) / 2.0f;
        } else {
            f5 = Math.max(f3 - f7, Math.min(f5 - f6, f));
        }
        if (this.f1983g) {
            f4 = (float) this.f1984h.top;
        }
        if (this.f1983g) {
            f3 = (float) this.f1984h.bottom;
        } else {
            f3 = (float) getHeight();
        }
        f6 = this.ab.top;
        f7 = this.ab.bottom;
        if (this.f1983g) {
            f4 = Math.max(f4 - this.ab.bottom, Math.min(f3 - this.ab.top, f2));
        } else if (f7 - f6 < f3 - f4) {
            f4 += ((f3 - f4) - (f6 + f7)) / 2.0f;
        } else {
            f4 = Math.max(f3 - f7, Math.min(f4 - f6, f2));
        }
        this.f1965G.postTranslate(f5, f4);
        invalidate();
        if (f5 == f && f4 == f2) {
            return true;
        }
        return false;
    }
}
