package com.facebook.lite.p049a;

import android.util.Log;
import com.p008a.p009a.p010a.p022l.C0088r;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

/* renamed from: com.facebook.lite.a.k */
public final class C0282k {
    private static final String f1086a;
    private final LinkedList f1087b;
    private final int f1088c;
    private final File f1089d;
    private final int f1090e;
    private final Map f1091f;
    private int f1092g;

    static {
        f1086a = C0282k.class.getSimpleName();
    }

    public C0282k(File file, int i, int i2) {
        this.f1087b = new LinkedList();
        this.f1091f = new HashMap();
        this.f1089d = file;
        this.f1090e = i2;
        this.f1088c = i;
        new StringBuilder("fontcache/maxsize:").append(i).append("/filesize:").append(i2);
        m1910b();
    }

    public final void m1913a() {
        Iterator it = this.f1087b.iterator();
        while (it.hasNext()) {
            File file = (File) it.next();
            if (file.delete()) {
                new StringBuilder("fontcache/delete:").append(file.getName());
            } else {
                new StringBuilder("fontcache/delete failed:").append(file.getName());
            }
        }
        this.f1087b.clear();
        this.f1091f.clear();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void m1914a(com.p008a.p009a.p010a.p022l.C0080i r11) {
        /*
        r10 = this;
        r0 = r10.f1087b;
        r4 = r0.iterator();
    L_0x0006:
        r0 = r4.hasNext();
        if (r0 == 0) goto L_0x00d1;
    L_0x000c:
        r0 = r4.next();
        r0 = (java.io.File) r0;
        r3 = 0;
        r1 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x00d4, all -> 0x00c0 }
        r2 = "fontcache/read:";
        r1.<init>(r2);	 Catch:{ IOException -> 0x00d4, all -> 0x00c0 }
        r2 = r0.getName();	 Catch:{ IOException -> 0x00d4, all -> 0x00c0 }
        r1 = r1.append(r2);	 Catch:{ IOException -> 0x00d4, all -> 0x00c0 }
        r2 = " | ";
        r1 = r1.append(r2);	 Catch:{ IOException -> 0x00d4, all -> 0x00c0 }
        r6 = r0.length();	 Catch:{ IOException -> 0x00d4, all -> 0x00c0 }
        r1.append(r6);	 Catch:{ IOException -> 0x00d4, all -> 0x00c0 }
        r2 = new java.io.RandomAccessFile;	 Catch:{ IOException -> 0x00d4, all -> 0x00c0 }
        r1 = "r";
        r2.<init>(r0, r1);	 Catch:{ IOException -> 0x00d4, all -> 0x00c0 }
        r1 = r2.readInt();	 Catch:{ IOException -> 0x0095 }
        r3 = r2.readShort();	 Catch:{ IOException -> 0x0095 }
        r5 = r2.readByte();	 Catch:{ IOException -> 0x0095 }
        r5 = r5 & 255;
        r6 = r2.readByte();	 Catch:{ IOException -> 0x0095 }
        r6 = r6 & 255;
        r7 = com.facebook.lite.p049a.C0282k.m1909a(r3, r5, r6);	 Catch:{ IOException -> 0x0095 }
        if (r7 == 0) goto L_0x006e;
    L_0x0050:
        r1 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x0095 }
        r3 = "fontcache/delete corrupted/:";
        r1.<init>(r3);	 Catch:{ IOException -> 0x0095 }
        r3 = r0.getName();	 Catch:{ IOException -> 0x0095 }
        r1.append(r3);	 Catch:{ IOException -> 0x0095 }
        r0.delete();	 Catch:{ IOException -> 0x0095 }
        r2.close();	 Catch:{ IOException -> 0x0065 }
        goto L_0x0006;
    L_0x0065:
        r0 = move-exception;
        r1 = f1086a;
        r2 = "fontcache/write/faile to close";
        android.util.Log.e(r1, r2, r0);
        goto L_0x0006;
    L_0x006e:
        r1 = r11.m620a(r1, r3, r5, r6);	 Catch:{ IOException -> 0x0095 }
    L_0x0072:
        r6 = r2.getFilePointer();	 Catch:{ IOException -> 0x0095 }
        r8 = r0.length();	 Catch:{ IOException -> 0x0095 }
        r3 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1));
        if (r3 >= 0) goto L_0x00b1;
    L_0x007e:
        r3 = r2.readShort();	 Catch:{ IOException -> 0x0095 }
        if (r3 <= 0) goto L_0x00b1;
    L_0x0084:
        r5 = r2.readChar();	 Catch:{ IOException -> 0x0095 }
        r3 = new byte[r3];	 Catch:{ IOException -> 0x0095 }
        r2.read(r3);	 Catch:{ IOException -> 0x0095 }
        r6 = r1.m752a();	 Catch:{ IOException -> 0x0095 }
        r6.m587a(r5, r3);	 Catch:{ IOException -> 0x0095 }
        goto L_0x0072;
    L_0x0095:
        r1 = move-exception;
    L_0x0096:
        r3 = f1086a;	 Catch:{ all -> 0x00d2 }
        r5 = "fontcache/read failed";
        android.util.Log.e(r3, r5, r1);	 Catch:{ all -> 0x00d2 }
        r0.delete();	 Catch:{ all -> 0x00d2 }
        if (r2 == 0) goto L_0x0006;
    L_0x00a2:
        r2.close();	 Catch:{ IOException -> 0x00a7 }
        goto L_0x0006;
    L_0x00a7:
        r0 = move-exception;
        r1 = f1086a;
        r2 = "fontcache/write/faile to close";
        android.util.Log.e(r1, r2, r0);
        goto L_0x0006;
    L_0x00b1:
        r2.close();	 Catch:{ IOException -> 0x00b6 }
        goto L_0x0006;
    L_0x00b6:
        r0 = move-exception;
        r1 = f1086a;
        r2 = "fontcache/write/faile to close";
        android.util.Log.e(r1, r2, r0);
        goto L_0x0006;
    L_0x00c0:
        r0 = move-exception;
        r2 = r3;
    L_0x00c2:
        if (r2 == 0) goto L_0x00c7;
    L_0x00c4:
        r2.close();	 Catch:{ IOException -> 0x00c8 }
    L_0x00c7:
        throw r0;
    L_0x00c8:
        r1 = move-exception;
        r2 = f1086a;
        r3 = "fontcache/write/faile to close";
        android.util.Log.e(r2, r3, r1);
        goto L_0x00c7;
    L_0x00d1:
        return;
    L_0x00d2:
        r0 = move-exception;
        goto L_0x00c2;
    L_0x00d4:
        r1 = move-exception;
        r2 = r3;
        goto L_0x0096;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.a.k.a(com.a.a.a.l.i):void");
    }

    public final void m1915a(C0088r c0088r, char c, byte[] bArr) {
        RandomAccessFile randomAccessFile;
        Throwable e;
        File a = m1908a(c0088r.f331b);
        try {
            randomAccessFile = new RandomAccessFile(a, "rw");
            try {
                if (a.length() == 0) {
                    randomAccessFile.writeInt(c0088r.f331b);
                    randomAccessFile.writeShort(c0088r.f330a);
                    randomAccessFile.writeByte(c0088r.f332c);
                    randomAccessFile.writeByte(c0088r.f333d);
                }
                randomAccessFile.seek(a.length());
                randomAccessFile.writeShort(bArr.length);
                randomAccessFile.writeChar(c);
                randomAccessFile.write(bArr);
                try {
                    randomAccessFile.close();
                } catch (Throwable e2) {
                    Log.e(f1086a, "fontcache/write/faile to close", e2);
                }
            } catch (IOException e3) {
                e2 = e3;
                try {
                    Log.e(f1086a, "fontcache/write failed", e2);
                    if (randomAccessFile != null) {
                        try {
                            randomAccessFile.close();
                        } catch (Throwable e22) {
                            Log.e(f1086a, "fontcache/write/faile to close", e22);
                        }
                    }
                } catch (Throwable th) {
                    e22 = th;
                    if (randomAccessFile != null) {
                        try {
                            randomAccessFile.close();
                        } catch (Throwable e4) {
                            Log.e(f1086a, "fontcache/write/faile to close", e4);
                        }
                    }
                    throw e22;
                }
            }
        } catch (IOException e5) {
            e22 = e5;
            randomAccessFile = null;
            Log.e(f1086a, "fontcache/write failed", e22);
            if (randomAccessFile != null) {
                randomAccessFile.close();
            }
        } catch (Throwable th2) {
            e22 = th2;
            randomAccessFile = null;
            if (randomAccessFile != null) {
                randomAccessFile.close();
            }
            throw e22;
        }
    }

    private File m1908a(int i) {
        File file = (File) this.f1091f.get(Integer.valueOf(i));
        if (file == null) {
            Iterator it = this.f1087b.iterator();
            while (it.hasNext()) {
                file = (File) it.next();
                if (file.length() <= ((long) this.f1090e) && file.getName().indexOf(Integer.toString(i), file.getName().indexOf(".")) > 0) {
                    new StringBuilder("fontcache/continue write to file:").append(file.getName()).append(" | ").append(file.length());
                    this.f1091f.put(Integer.valueOf(i), file);
                    return file;
                }
            }
            m1911b(i);
            return (File) this.f1091f.get(Integer.valueOf(i));
        } else if (file.length() < ((long) this.f1090e)) {
            return file;
        } else {
            m1911b(i);
            return (File) this.f1091f.get(Integer.valueOf(i));
        }
    }

    private void m1910b() {
        File[] listFiles = this.f1089d.listFiles();
        Arrays.sort(listFiles);
        new StringBuilder("fontcache/file count:").append(listFiles.length);
        Object obj = null;
        for (int length = listFiles.length - 1; length >= 0; length--) {
            this.f1092g = (int) (((long) this.f1092g) + listFiles[length].length());
            if (this.f1092g > this.f1088c) {
                obj = 1;
            }
            if (obj != null) {
                new StringBuilder("fontcache/delete:").append(listFiles[length].getName());
                listFiles[length].delete();
            } else {
                this.f1087b.add(listFiles[length]);
            }
        }
        new StringBuilder("fontcache/cache size:").append(this.f1092g);
    }

    private void m1911b(int i) {
        File file = new File(this.f1089d, C0282k.m1912c(i));
        this.f1091f.put(Integer.valueOf(i), file);
        this.f1087b.addFirst(file);
        new StringBuilder("fontcache/add file:").append(file.getName());
    }

    private static String m1912c(int i) {
        return System.currentTimeMillis() + "." + i;
    }

    private static boolean m1909a(int i, int i2, int i3) {
        return i <= 0 || i3 < 200 || i2 > 50;
    }
}
