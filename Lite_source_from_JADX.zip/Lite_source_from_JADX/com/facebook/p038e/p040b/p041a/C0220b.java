package com.facebook.p038e.p040b.p041a;

import android.content.Context;
import com.facebook.lite.p053b.C0300n;

/* renamed from: com.facebook.e.b.a.b */
public final class C0220b {
    private final Context f834a;
    private final String f835b;

    public C0220b(Context context, String str) {
        this.f834a = context.getApplicationContext();
        this.f835b = str;
    }

    public final String m1548a() {
        return this.f835b;
    }

    public final int m1549b() {
        int a;
        synchronized (this) {
            a = C0300n.m2090a(this.f834a, m1546d());
        }
        return a;
    }

    public final int m1550c() {
        return m1547a(1);
    }

    public final int m1547a(int i) {
        int a;
        synchronized (this) {
            a = C0300n.m2091a(this.f834a, m1546d(), i);
        }
        return a;
    }

    private String m1546d() {
        return "counter_" + this.f835b;
    }
}
