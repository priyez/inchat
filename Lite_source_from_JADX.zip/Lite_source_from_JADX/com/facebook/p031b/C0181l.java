package com.facebook.p031b;

/* renamed from: com.facebook.b.l */
final class C0181l extends Throwable {
    final /* synthetic */ C0184o f664a;

    private C0181l(C0184o c0184o) {
        this.f664a = c0184o;
    }
}
