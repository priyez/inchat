package com.facebook.lite.p053b;

import com.facebook.lite.ClientApplication;
import com.p008a.p009a.p010a.p022l.C0075d;
import com.p008a.p009a.p010a.p022l.C0088r;
import com.p008a.p009a.p010a.p023m.C0122j;
import com.p008a.p009a.p010a.p023m.C0123k;

/* renamed from: com.facebook.lite.b.f */
final class C0292f implements C0075d {
    private final C0123k f1170a;
    private final int f1171b;
    private final StringBuffer f1172c;

    C0292f(int i, C0123k c0123k) {
        this.f1172c = new StringBuffer();
        this.f1171b = i;
        this.f1170a = c0123k;
    }

    public final byte[] m1946a(char c) {
        C0122j c2 = this.f1170a.m1223c(m1942b(c));
        if (c2 == null) {
            return null;
        }
        return (byte[]) c2.m1214j();
    }

    public final String m1943a() {
        return this.f1172c.toString();
    }

    public final void m1944a(char c, byte[] bArr) {
        int b = m1942b(c);
        if (!C0088r.m748b((int) c) && this.f1172c.indexOf(String.valueOf(c)) < 0) {
            this.f1172c.append(c);
        }
        C0122j c2 = this.f1170a.m1223c(b);
        if (c2 == null) {
            this.f1170a.m1217a(b, bArr);
        } else {
            c2.m1212a((Object) bArr);
        }
    }

    public final void m1945a(char c, byte[] bArr, C0088r c0088r) {
        m1944a(c, bArr);
        if (!C0088r.m748b((int) c)) {
            ClientApplication.m1691c().m2409a(c0088r, c, bArr);
        }
    }

    private int m1942b(char c) {
        return (this.f1171b << 16) | c;
    }
}
