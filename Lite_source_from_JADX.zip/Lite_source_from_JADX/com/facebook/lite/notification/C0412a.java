package com.facebook.lite.notification;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.Notification.Builder;
import android.app.PendingIntent;
import android.content.Context;
import p002b.p003a.p004a.p005a.C0002a;

/* renamed from: com.facebook.lite.notification.a */
public final class C0412a {
    @TargetApi(9)
    public static Notification m2916a(int i, String str, long j, Context context, String str2, String str3, PendingIntent pendingIntent) {
        Notification notification = new Notification();
        notification.icon = i;
        notification.tickerText = str;
        notification.when = j;
        C0002a.m40a(notification, context, str2, str3, pendingIntent);
        return notification;
    }

    @TargetApi(11)
    public static Notification m2917b(int i, String str, long j, Context context, String str2, String str3, PendingIntent pendingIntent) {
        return new Builder(context).setSmallIcon(i).setTicker(str).setWhen(j).setContentTitle(str2).setContentText(str3).setContentIntent(pendingIntent).getNotification();
    }
}
