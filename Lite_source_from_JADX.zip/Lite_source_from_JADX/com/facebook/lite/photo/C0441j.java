package com.facebook.lite.photo;

import java.util.concurrent.ThreadFactory;

/* renamed from: com.facebook.lite.photo.j */
final class C0441j implements ThreadFactory {
    final /* synthetic */ C0443l f1767a;

    C0441j(C0443l c0443l) {
        this.f1767a = c0443l;
    }

    public final Thread newThread(Runnable runnable) {
        Thread thread = new Thread(runnable);
        thread.setPriority(5);
        return thread;
    }
}
