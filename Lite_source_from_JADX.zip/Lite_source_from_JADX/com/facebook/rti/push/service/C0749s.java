package com.facebook.rti.push.service;

import org.json.JSONObject;

/* renamed from: com.facebook.rti.push.service.s */
public final class C0749s {
    public String f3195a;
    public String f3196b;
    public String f3197c;
    public Long f3198d;

    public C0749s() {
        this.f3195a = "";
        this.f3196b = "";
        this.f3197c = "";
        this.f3198d = Long.valueOf(0);
    }

    public final String m3977a() {
        JSONObject jSONObject = new JSONObject();
        jSONObject.putOpt("app_id", this.f3195a);
        jSONObject.putOpt("pkg_name", this.f3196b);
        jSONObject.putOpt("token", this.f3197c);
        jSONObject.putOpt("time", this.f3198d);
        return jSONObject.toString();
    }
}
