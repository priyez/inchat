package com.facebook.lite.widget;

public final class al {
    public static final int f2057a;
    public static final int f2058b;
    public static final int f2059c;
    public static final int f2060d;
    private static final /* synthetic */ int[] f2061e;

    static {
        f2057a = 1;
        f2058b = 2;
        f2059c = 3;
        f2060d = 4;
        f2061e = new int[]{f2057a, f2058b, f2059c, f2060d};
    }
}
