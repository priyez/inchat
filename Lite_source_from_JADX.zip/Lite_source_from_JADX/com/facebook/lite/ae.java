package com.facebook.lite;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;

final class ae implements OnClickListener {
    final /* synthetic */ Context f1120a;
    final /* synthetic */ MainActivity f1121b;

    ae(MainActivity mainActivity, Context context) {
        this.f1121b = mainActivity;
        this.f1120a = context;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setDataAndType(this.f1121b.f990v, "application/vnd.android.package-archive");
        intent.setFlags(268435456);
        if (this.f1121b.f971c != null && this.f1121b.f971c.isShowing()) {
            this.f1121b.f971c.dismiss();
        }
        this.f1121b.finish();
        this.f1120a.startActivity(intent);
        this.f1121b.f990v = null;
        this.f1121b.f971c = null;
    }
}
