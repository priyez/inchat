package com.facebook.p037d;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* renamed from: com.facebook.d.f */
public final class C0204f extends BroadcastReceiver {
    private C0205g f791a;
    private C0206h f792b;

    public C0204f(C0205g c0205g, C0206h c0206h) {
        this.f791a = c0205g;
        this.f792b = c0206h;
    }

    public final void onReceive(Context context, Intent intent) {
        if (getResultCode() == -1) {
            m1508a(new C0202d(getResultData(), getResultExtras(true).getLong("timestamp", Long.MAX_VALUE)), intent.getPackage());
        }
    }

    private void m1508a(C0202d c0202d, String str) {
        Object obj = null;
        C0202d a = this.f791a.m1509a();
        if (c0202d.f786a != null && c0202d.f787b < a.f787b) {
            this.f791a.m1510a(c0202d);
            obj = 1;
        }
        if (obj != null) {
            this.f792b.m1511a(a, c0202d, str);
        }
    }
}
