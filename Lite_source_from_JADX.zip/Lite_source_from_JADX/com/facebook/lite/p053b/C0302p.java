package com.facebook.lite.p053b;

import com.p008a.p009a.p010a.p022l.C0088r;
import java.text.Bidi;

/* renamed from: com.facebook.lite.b.p */
public final class C0302p {
    public static String m2174a(String str) {
        return str == null ? "" : str;
    }

    public static boolean m2175a(CharSequence charSequence) {
        if (C0302p.m2177b(charSequence)) {
            return true;
        }
        for (int i = 0; i < charSequence.length(); i++) {
            if (!Character.isWhitespace(charSequence.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public static boolean m2177b(CharSequence charSequence) {
        return charSequence == null || charSequence.length() == 0;
    }

    public static String m2176b(String str) {
        int length = str.length();
        StringBuilder stringBuilder = new StringBuilder(length);
        int i = 0;
        while (i < length) {
            int codePointAt = str.codePointAt(i);
            if (!C0088r.m748b(codePointAt)) {
                stringBuilder.appendCodePoint(codePointAt);
            }
            i += Character.charCount(codePointAt);
        }
        return stringBuilder.toString();
    }

    public static String m2178c(String str) {
        String[] split = str.split("\n");
        StringBuilder stringBuilder = new StringBuilder(str.length());
        for (int i = 0; i < split.length; i++) {
            if (i != 0) {
                stringBuilder.append('\n');
            }
            stringBuilder.append(C0302p.m2179d(split[i]));
        }
        return stringBuilder.toString();
    }

    private static String m2179d(String str) {
        int i = 0;
        Bidi bidi = new Bidi(str, 0);
        if (bidi.isLeftToRight()) {
            return str;
        }
        if (bidi.isRightToLeft()) {
            return new StringBuilder(str).reverse().toString();
        }
        StringBuilder stringBuilder = new StringBuilder(str.length());
        int runCount = bidi.getRunCount();
        while (i < runCount) {
            String substring = str.substring(bidi.getRunStart(i), bidi.getRunLimit(i));
            if (bidi.getRunLevel(i) % 2 == 0) {
                stringBuilder.append(substring);
            } else {
                stringBuilder.append(new StringBuilder(substring).reverse());
            }
            i++;
        }
        return stringBuilder.toString();
    }
}
