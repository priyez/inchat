package com.facebook.rti.push.service.p103a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.facebook.rti.p046a.p074f.C0527a;
import com.facebook.rti.p078b.p093d.C0619c;

/* renamed from: com.facebook.rti.push.service.a.b */
final class C0729b extends BroadcastReceiver {
    final /* synthetic */ C0730c f3122a;

    C0729b(C0730c c0730c) {
        this.f3122a = c0730c;
    }

    public final void onReceive(Context context, Intent intent) {
        if (getResultCode() == -1) {
            Bundle resultExtras = getResultExtras(true);
            C0527a.m3336a(C0730c.f3123a, "New ids from sharing: %s", new C0619c(resultExtras.getString("/settings/mqtt/id/mqtt_device_id"), resultExtras.getString("/settings/mqtt/id/mqtt_device_secret"), resultExtras.getLong("/settings/mqtt/id/timestamp", Long.MAX_VALUE)));
            C0730c.m3952a(this.f3122a, r0);
        }
    }
}
