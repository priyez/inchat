package com.facebook.p038e;

import com.p008a.p009a.p010a.p014e.C0022b;

/* renamed from: com.facebook.e.m */
public interface C0252m extends C0022b {
    boolean m1682a(C0249i c0249i);
}
