package com.facebook.lite.widget;

import android.media.MediaPlayer;
import android.media.MediaPlayer.OnInfoListener;

/* renamed from: com.facebook.lite.widget.k */
final class C0480k implements OnInfoListener {
    final /* synthetic */ C0481l f2096a;

    C0480k(C0481l c0481l) {
        this.f2096a = c0481l;
    }

    public final boolean onInfo(MediaPlayer mediaPlayer, int i, int i2) {
        switch (i) {
            case 3:
            case 702:
                this.f2096a.f2097a.f1899c.setVisibility(8);
                break;
            case 701:
                this.f2096a.f2097a.f1899c.setBackgroundColor(0);
                this.f2096a.f2097a.f1899c.setVisibility(0);
                break;
        }
        return false;
    }
}
