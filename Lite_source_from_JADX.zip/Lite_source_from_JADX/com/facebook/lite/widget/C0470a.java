package com.facebook.lite.widget;

import android.view.Choreographer;
import android.view.Choreographer.FrameCallback;

/* renamed from: com.facebook.lite.widget.a */
final class C0470a implements FrameCallback {
    final /* synthetic */ AbstractGLRendererView f2022a;

    C0470a(AbstractGLRendererView abstractGLRendererView) {
        this.f2022a = abstractGLRendererView;
    }

    public final void doFrame(long j) {
        this.f2022a.f1863d = j / 1000000;
        Choreographer.getInstance().postFrameCallback(this.f2022a.f1864e);
    }
}
