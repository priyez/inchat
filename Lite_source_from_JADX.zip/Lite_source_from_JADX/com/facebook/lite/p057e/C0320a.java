package com.facebook.lite.p057e;

import java.util.List;

/* renamed from: com.facebook.lite.e.a */
public final class C0320a {
    public String f1267a;
    private final int f1268b;
    private final List f1269c;
    private C0328h f1270d;
    private final String f1271e;

    public C0320a(int i, String str, List list) {
        this.f1268b = i;
        this.f1271e = str;
        this.f1269c = list;
    }

    public C0320a(int i, String str, List list, C0328h c0328h) {
        this.f1268b = i;
        this.f1271e = str;
        this.f1269c = list;
        this.f1270d = c0328h;
    }

    public C0320a(int i, String str, List list, String str2) {
        this(i, str, list);
        this.f1267a = str2;
    }

    public final int m2271a() {
        return this.f1268b;
    }

    public final List m2272b() {
        return this.f1269c;
    }

    public final C0328h m2273c() {
        return this.f1270d;
    }

    public final String m2274d() {
        return this.f1271e;
    }
}
