package com.facebook.lite.p059m;

/* renamed from: com.facebook.lite.m.c */
public enum C0381c {
    CONNECTION_ESTABLISHED,
    CONNECTION_CLOSED,
    FONT_READY,
    SCREEN_DATA_RECEIVED
}
