package com.facebook.lite.p062j;

/* renamed from: com.facebook.lite.j.m */
public final class C0365m implements C0358i {
    final /* synthetic */ C0366n f1423a;

    public C0365m(C0366n c0366n) {
        this.f1423a = c0366n;
    }

    public final String m2530a(StringBuilder stringBuilder) {
        stringBuilder.append("Screen TTI: ").append(this.f1423a.f1426c.m2524c()).append(" ms");
        return stringBuilder.toString();
    }
}
