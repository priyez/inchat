package com.facebook.lite;

public final class aw {
    public static final boolean f1162a = false;
    public static final boolean f1163b = false;
}
