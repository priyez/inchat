package com.facebook.lite.net;

import com.facebook.lite.p053b.C0294h;
import com.p008a.p009a.p010a.p012b.C0017i;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;

/* renamed from: com.facebook.lite.net.n */
public final class C0409n extends Thread implements C0017i {
    final /* synthetic */ C0400q f1651a;
    private int f1652b;

    protected C0409n(C0400q c0400q) {
        this.f1651a = c0400q;
    }

    public final void run() {
        int c;
        Exception e;
        String message;
        Object obj;
        synchronized (this.f1651a.f1618y) {
            if (this.f1651a.f1601A == null) {
                String str;
                this.f1651a.f1601A = this;
                Long c2 = this.f1651a.n.m365c(47);
                if (c2 == null) {
                    c2 = Long.valueOf(40000);
                }
                this.f1652b = this.f1651a.q.m110a(this, c2.longValue());
                try {
                    if (this.f1651a.m96A()) {
                        this.f1651a.m2821s().m2472c(42);
                    }
                    long currentTimeMillis = System.currentTimeMillis();
                    c = m2894c();
                    try {
                        if (this.f1651a.m96A()) {
                            this.f1651a.m2821s().m2472c(1);
                            this.f1651a.a_.m244a(74, (int) (System.currentTimeMillis() - currentTimeMillis));
                            this.f1651a.a_.m247b(80);
                            this.f1651a.a_.m243a(85);
                        }
                        this.f1651a.q.m111a(this.f1652b);
                    } catch (Exception e2) {
                        e = e2;
                        new StringBuilder("conn/connecting/run:").append(e.toString());
                        message = e.getMessage();
                        if (message != null || message.indexOf("Connection refused") <= 0) {
                            this.f1651a.e = (byte) 1;
                        } else {
                            this.f1651a.e = (byte) 2;
                        }
                        synchronized (this.f1651a.f1618y) {
                            if (m2893b()) {
                                this.f1651a.i.m2849a(c);
                            } else {
                                if (c == -1) {
                                    this.f1651a.f1619z = c;
                                    m2895d();
                                } else {
                                    synchronized (this.f1651a.k) {
                                        if (m2893b()) {
                                            obj = null;
                                        } else {
                                            this.f1651a.m2833b(0);
                                            obj = (byte) 1;
                                        }
                                    }
                                    if (obj != null) {
                                        this.f1651a.l.m132a(this.f1651a.m2827v(), this.f1651a.m2781h(), this.f1651a.e);
                                    }
                                }
                                this.f1651a.f1601A = null;
                            }
                        }
                        str = (String) this.f1651a.f1604D.m1045c();
                        if (!str.contains("facebook.com")) {
                            try {
                                C0405h.m2873a(str, C0294h.m1976g(), InetAddress.getByName(str).getHostAddress(), this.f1651a.h.m2634I());
                                return;
                            } catch (UnknownHostException e3) {
                                new StringBuilder("conn/dnslookup/").append(e3.toString());
                                return;
                            }
                        }
                        return;
                    }
                } catch (Exception e4) {
                    e = e4;
                    c = -1;
                    new StringBuilder("conn/connecting/run:").append(e.toString());
                    message = e.getMessage();
                    if (message != null) {
                    }
                    this.f1651a.e = (byte) 1;
                    synchronized (this.f1651a.f1618y) {
                        if (m2893b()) {
                            if (c == -1) {
                                synchronized (this.f1651a.k) {
                                    if (m2893b()) {
                                        this.f1651a.m2833b(0);
                                        obj = (byte) 1;
                                    } else {
                                        obj = null;
                                    }
                                }
                                if (obj != null) {
                                    this.f1651a.l.m132a(this.f1651a.m2827v(), this.f1651a.m2781h(), this.f1651a.e);
                                }
                            } else {
                                this.f1651a.f1619z = c;
                                m2895d();
                            }
                            this.f1651a.f1601A = null;
                        } else {
                            this.f1651a.i.m2849a(c);
                        }
                    }
                    str = (String) this.f1651a.f1604D.m1045c();
                    if (!str.contains("facebook.com")) {
                        C0405h.m2873a(str, C0294h.m1976g(), InetAddress.getByName(str).getHostAddress(), this.f1651a.h.m2634I());
                        return;
                    }
                    return;
                }
                synchronized (this.f1651a.f1618y) {
                    if (m2893b()) {
                        if (c == -1) {
                            synchronized (this.f1651a.k) {
                                if (m2893b()) {
                                    this.f1651a.m2833b(0);
                                    obj = (byte) 1;
                                } else {
                                    obj = null;
                                }
                            }
                            if (obj != null) {
                                this.f1651a.l.m132a(this.f1651a.m2827v(), this.f1651a.m2781h(), this.f1651a.e);
                            }
                        } else {
                            this.f1651a.f1619z = c;
                            m2895d();
                        }
                        this.f1651a.f1601A = null;
                    } else {
                        this.f1651a.i.m2849a(c);
                    }
                }
                str = (String) this.f1651a.f1604D.m1045c();
                if (!str.contains("facebook.com")) {
                    C0405h.m2873a(str, C0294h.m1976g(), InetAddress.getByName(str).getHostAddress(), this.f1651a.h.m2634I());
                    return;
                }
                return;
            }
        }
    }

    public final void m2896d(int i) {
        synchronized (this.f1651a.f1618y) {
            if (this.f1651a.f1601A == this && i == this.f1652b) {
                if (this.f1651a.m96A()) {
                    this.f1651a.a_.m243a(44);
                }
                this.f1651a.f1601A = null;
                this.f1651a.m2833b(0);
                this.f1651a.l.m132a(this.f1651a.m2827v(), this.f1651a.m2781h(), this.f1651a.e);
            }
        }
    }

    private int m2892a() {
        int j = this.f1651a.f1610J;
        this.f1651a.f1610J = Math.min(this.f1651a.f1610J * 2, 16000);
        return j;
    }

    private boolean m2893b() {
        return this.f1651a.f1601A == this && this.f1651a.m2783j() == 1;
    }

    private int m2894c() {
        int a;
        SecurityException e;
        try {
            a = this.f1651a.i.m2848a((String) this.f1651a.f1604D.m1045c(), (int) this.f1651a.f1605E.m1043b(), m2892a());
            try {
                this.f1651a.m2780g();
                this.f1651a.f1610J = 2000;
            } catch (SecurityException e2) {
                e = e2;
                this.f1651a.g.m126a((short) 5, (short) 129, e.getMessage());
                new StringBuilder("conn/openSocketConnection:").append(e.toString());
                synchronized (this.f1651a.f1618y) {
                    if (m2893b()) {
                        this.f1651a.f1601A = null;
                        this.f1651a.m2833b(0);
                        this.f1651a.l.m132a(false, this.f1651a.m2781h(), this.f1651a.e);
                    }
                }
                return a;
            }
        } catch (SecurityException e3) {
            SecurityException securityException = e3;
            a = -1;
            e = securityException;
            this.f1651a.g.m126a((short) 5, (short) 129, e.getMessage());
            new StringBuilder("conn/openSocketConnection:").append(e.toString());
            synchronized (this.f1651a.f1618y) {
                if (m2893b()) {
                    this.f1651a.f1601A = null;
                    this.f1651a.m2833b(0);
                    this.f1651a.l.m132a(false, this.f1651a.m2781h(), this.f1651a.e);
                }
            }
            return a;
        }
        return a;
    }

    private void m2895d() {
        Throwable e;
        DataInputStream c;
        try {
            c = this.f1651a.i.m2852c(this.f1651a.f1619z);
            try {
                OutputStream d = this.f1651a.i.m2853d(this.f1651a.f1619z);
                this.f1651a.f1612r = this.f1651a.m2828a(c);
                this.f1651a.f1613s = this.f1651a.m2829a(d);
                this.f1651a.m2833b(2);
                this.f1651a.f1612r.start();
                this.f1651a.f1613s.start();
            } catch (IOException e2) {
                e = e2;
            }
        } catch (IOException e3) {
            e = e3;
            c = null;
            if (c != null) {
                try {
                    c.close();
                } catch (IOException e4) {
                }
            }
            this.f1651a.g.m124a((short) 41, null, e);
            new StringBuilder("conn/startSendAndReceiveThreads:").append(e.toString());
            this.f1651a.m2833b(0);
            this.f1651a.l.m132a(this.f1651a.m2827v(), this.f1651a.m2781h(), this.f1651a.e);
        }
    }
}
