package com.facebook.rti.p046a.p075g;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.SharedPreferences;

/* renamed from: com.facebook.rti.a.g.a */
final class C0529a extends C0528c {
    private C0529a() {
    }

    @TargetApi(11)
    public final SharedPreferences m3348a(Context context, String str, boolean z) {
        int i = 0;
        if (z) {
            i = 4;
        }
        return context.getSharedPreferences(str, i);
    }
}
