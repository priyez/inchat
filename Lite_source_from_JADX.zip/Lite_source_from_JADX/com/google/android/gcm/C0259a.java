package com.google.android.gcm;

import android.app.AlarmManager;
import android.app.IntentService;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.SystemClock;
import android.util.Log;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/* renamed from: com.google.android.gcm.a */
public abstract class C0259a extends IntentService {
    private static WakeLock f954a;
    private static final Object f955b;
    private static int f956d;
    private static final Random f957e;
    private static final int f958f;
    private static final String f959g;
    private final String[] f960c;

    protected abstract void m1714a(Context context);

    protected abstract void m1715a(Context context, Intent intent);

    protected abstract void m1716a(String str);

    protected abstract void m1718b(Context context, String str);

    static {
        f955b = C0259a.class;
        f956d = 0;
        f957e = new Random();
        f958f = (int) TimeUnit.SECONDS.toMillis(3600);
        f959g = Long.toBinaryString(f957e.nextLong());
    }

    protected C0259a() {
        this(C0259a.m1710b("DynamicSenderIds"), null);
    }

    protected C0259a(String... strArr) {
        this(C0259a.m1708a(strArr), strArr);
    }

    private C0259a(String str, String[] strArr) {
        super(str);
        this.f960c = strArr;
    }

    private static String m1710b(String str) {
        StringBuilder append = new StringBuilder("GCMIntentService-").append(str).append("-");
        int i = f956d + 1;
        f956d = i;
        return append.append(i).toString();
    }

    private static String m1708a(String[] strArr) {
        return C0259a.m1710b(C0751b.m3993a(strArr));
    }

    private String[] m1712b() {
        if (this.f960c != null) {
            return this.f960c;
        }
        throw new IllegalStateException("sender id not set on constructor");
    }

    protected void m1713a() {
    }

    protected boolean m1717a(Context context, String str) {
        return true;
    }

    public final void onHandleIntent(Intent intent) {
        String stringExtra;
        try {
            Context applicationContext = getApplicationContext();
            String action = intent.getAction();
            if (action.equals("com.google.android.c2dm.intent.REGISTRATION")) {
                C0751b.m4005f(applicationContext);
                m1711b(applicationContext, intent);
            } else if (action.equals("com.google.android.c2dm.intent.RECEIVE")) {
                action = intent.getStringExtra("message_type");
                if (action == null) {
                    m1715a(applicationContext, intent);
                } else if (action.equals("deleted_messages")) {
                    stringExtra = intent.getStringExtra("total_deleted");
                    if (stringExtra != null) {
                        Integer.parseInt(stringExtra);
                        m1713a();
                    }
                } else {
                    Log.e("GCMBaseIntentService", "Received unknown special message: " + action);
                }
            } else if (action.equals("com.google.android.gcm.intent.RETRY")) {
                action = intent.getStringExtra("token");
                if (!f959g.equals(action)) {
                    Log.e("GCMBaseIntentService", "Received invalid token: " + action);
                    synchronized (f955b) {
                        if (f954a != null) {
                            f954a.release();
                        } else {
                            Log.e("GCMBaseIntentService", "Wakelock reference is null");
                        }
                    }
                    return;
                } else if (C0751b.m4007h(applicationContext)) {
                    C0751b.m4004e(applicationContext);
                } else {
                    C0751b.m4001b(applicationContext, m1712b());
                }
            }
        } catch (NumberFormatException e) {
            Log.e("GCMBaseIntentService", "GCM returned invalid number of deleted messages: " + stringExtra);
        } catch (Throwable th) {
            synchronized (f955b) {
            }
            if (f954a != null) {
                f954a.release();
            } else {
                Log.e("GCMBaseIntentService", "Wakelock reference is null");
            }
        }
        synchronized (f955b) {
            if (f954a != null) {
                f954a.release();
            } else {
                Log.e("GCMBaseIntentService", "Wakelock reference is null");
            }
        }
    }

    static void m1709a(Context context, Intent intent, String str) {
        synchronized (f955b) {
            if (f954a == null) {
                f954a = ((PowerManager) context.getSystemService("power")).newWakeLock(1, "GCM_LIB");
            }
        }
        f954a.acquire();
        intent.setClassName(context, str);
        context.startService(intent);
    }

    private void m1711b(Context context, Intent intent) {
        String stringExtra = intent.getStringExtra("registration_id");
        String stringExtra2 = intent.getStringExtra("error");
        String stringExtra3 = intent.getStringExtra("unregistered");
        new StringBuilder("handleRegistration: registrationId = ").append(stringExtra).append(", error = ").append(stringExtra2).append(", unregistered = ").append(stringExtra3);
        if (stringExtra != null) {
            C0751b.m4010k(context);
            C0751b.m3992a(context, stringExtra);
            m1718b(context, stringExtra);
        } else if (stringExtra3 != null) {
            C0751b.m4010k(context);
            C0751b.m4008i(context);
            m1714a(context);
        } else if (!"SERVICE_NOT_AVAILABLE".equals(stringExtra2)) {
            m1716a(stringExtra2);
        } else if (m1717a(context, stringExtra2)) {
            int l = C0751b.m4011l(context);
            int nextInt = f957e.nextInt(l) + (l / 2);
            new StringBuilder("Scheduling registration retry, backoff = ").append(nextInt).append(" (").append(l).append(")");
            Intent intent2 = new Intent("com.google.android.gcm.intent.RETRY");
            intent2.putExtra("token", f959g);
            ((AlarmManager) context.getSystemService("alarm")).set(3, SystemClock.elapsedRealtime() + ((long) nextInt), PendingIntent.getBroadcast(context, 0, intent2, 0));
            if (l < f958f) {
                C0751b.m3995a(context, l * 2);
            }
        }
    }
}
