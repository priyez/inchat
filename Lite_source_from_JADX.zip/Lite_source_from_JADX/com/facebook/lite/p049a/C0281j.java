package com.facebook.lite.p049a;

import android.content.Context;
import com.facebook.lite.p053b.C0300n;
import com.p008a.p009a.p010a.p016h.C0055g;
import com.p008a.p009a.p010a.p022l.C0080i;
import com.p008a.p009a.p010a.p022l.C0088r;
import java.io.File;

/* renamed from: com.facebook.lite.a.j */
public class C0281j {
    private static final String f1079a;
    private static C0281j f1080b;
    private static boolean f1081c;
    private static int f1082d;
    private static boolean f1083e;
    private final Context f1084f;
    private final C0282k f1085g;

    static {
        f1079a = C0281j.class.getSimpleName();
        f1083e = true;
    }

    private C0281j(String str, Context context) {
        this.f1084f = context;
        File file = new File(str + "/font");
        if (!file.exists()) {
            file.mkdir();
        }
        this.f1085g = new C0282k(file, f1082d, (int) (10240.0f * context.getResources().getDisplayMetrics().density));
    }

    public static C0281j m1900a(String str, Context context) {
        if (f1080b == null && str != null) {
            synchronized (C0281j.class) {
                if (f1080b == null) {
                    f1080b = new C0281j(str, context);
                }
            }
        }
        return f1080b;
    }

    public static void m1903a(boolean z) {
        f1083e = z;
    }

    public static void m1902a(C0055g c0055g) {
        boolean z = true;
        Integer a = c0055g.m356a(56);
        if (a == null || a.intValue() != 1) {
            z = false;
        }
        f1081c = z;
        if (z) {
            Integer a2 = c0055g.m356a(57);
            f1082d = a2 == null ? 524288 : a2.intValue();
        }
    }

    public final void m1906a(C0088r c0088r, char c, byte[] bArr) {
        if (f1081c) {
            this.f1085g.m1915a(c0088r, c, bArr);
        }
    }

    public final void m1904a() {
        this.f1085g.m1913a();
    }

    public final void m1905a(C0080i c0080i) {
        if (f1083e && f1081c) {
            this.f1085g.m1914a(c0080i);
        }
    }

    public final void m1907b(C0055g c0055g) {
        Integer a = c0055g.m356a(58);
        m1901a(a == null ? -1 : a.intValue());
    }

    private void m1901a(int i) {
        int n = C0300n.m2154n(this.f1084f);
        new StringBuilder("fontcache/serverVersion: ").append(i).append(", clientVersion: ").append(n);
        if (i > n) {
            m1904a();
            C0300n.m2114c(this.f1084f, i);
        }
    }
}
