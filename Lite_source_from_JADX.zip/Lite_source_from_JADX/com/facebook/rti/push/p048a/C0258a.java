package com.facebook.rti.push.p048a;

import android.app.IntentService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.facebook.rti.p046a.p047b.C0256e;
import com.facebook.rti.p046a.p074f.C0527a;
import com.facebook.rti.p046a.p075g.C0528c;
import com.facebook.rti.p078b.p080b.p091g.C0614b;

/* renamed from: com.facebook.rti.push.a.a */
public abstract class C0258a extends IntentService {
    private C0614b f951a;
    private SharedPreferences f952b;

    protected abstract void m1699a();

    protected abstract void m1700a(Intent intent);

    protected abstract void m1701a(String str);

    protected abstract void m1702b(String str);

    protected C0258a(String str) {
        super(str);
        this.f951a = new C0614b(this);
    }

    protected C0258a() {
        super("");
        this.f951a = new C0614b(this);
    }

    protected C0258a(String str, C0614b c0614b, SharedPreferences sharedPreferences) {
        super(str);
        this.f951a = c0614b;
        this.f952b = sharedPreferences;
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        this.f952b = C0528c.f2215a.m3346a(this, "token_store");
        return super.onStartCommand(intent, i, i2);
    }

    protected final void onHandleIntent(Intent intent) {
        if (intent != null) {
            try {
                m1698b(intent);
            } finally {
                C0256e.m1697a(intent);
            }
        }
    }

    private void m1698b(Intent intent) {
        if ("com.facebook.rti.fbns.intent.RECEIVE".equals(intent.getAction())) {
            C0527a.m3338b("FbnsCallbackHandlerBase", intent.toString(), new Object[0]);
            if (this.f951a.m3523a(intent)) {
                String stringExtra = intent.getStringExtra("receive_type");
                if ("message".equals(stringExtra)) {
                    stringExtra = intent.getStringExtra("token");
                    Object string = this.f952b.getString("token_key", "");
                    if (TextUtils.isEmpty(string) || string.equals(stringExtra)) {
                        m1700a(intent);
                    } else {
                        C0527a.m3343e("FbnsCallbackHandlerBase", "Dropping unintended message.", new Object[0]);
                    }
                } else if ("registered".equals(stringExtra)) {
                    stringExtra = intent.getStringExtra("data");
                    C0528c.m3345a(this.f952b.edit().putString("token_key", stringExtra));
                    m1701a(stringExtra);
                } else if ("reg_error".equals(stringExtra)) {
                    m1702b(intent.getStringExtra("data"));
                } else if (!"deleted".equals(stringExtra)) {
                    if ("unregistered".equals(stringExtra)) {
                        m1699a();
                    } else {
                        C0527a.m3344f("FbnsCallbackHandlerBase", "Unknown message type", new Object[0]);
                    }
                }
            }
        }
    }
}
