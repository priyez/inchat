package com.facebook.rti.p046a.p070c;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/* renamed from: com.facebook.rti.a.c.a */
final class C0517a implements ThreadFactory {
    private final AtomicInteger f2189a;

    C0517a() {
        this.f2189a = new AtomicInteger(1);
    }

    public final Thread newThread(Runnable runnable) {
        return new C0519c(runnable, "IgExecutor #" + this.f2189a.getAndIncrement());
    }
}
