package com.facebook.lite.p053b;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.util.Log;

/* renamed from: com.facebook.lite.b.b */
final class C0288b implements IInterface {
    private final IBinder f1166a;

    public final boolean m1936b() {
        /* JADX: method processing error */
/*
        Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.ssa.SSATransform.placePhi(SSATransform.java:82)
	at jadx.core.dex.visitors.ssa.SSATransform.process(SSATransform.java:50)
	at jadx.core.dex.visitors.ssa.SSATransform.visit(SSATransform.java:42)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:281)
	at jadx.api.JavaClass.decompile(JavaClass.java:59)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:161)
*/
        /*
        r7 = this;
        r0 = 1;
        r1 = 0;
        r2 = android.os.Parcel.obtain();
        r3 = android.os.Parcel.obtain();
        r4 = "com.google.android.gms.ads.identifier.internal.IAdvertisingIdService";	 Catch:{ RemoteException -> 0x002c, all -> 0x003e }
        r2.writeInterfaceToken(r4);	 Catch:{ RemoteException -> 0x002c, all -> 0x003e }
        r4 = 1;	 Catch:{ RemoteException -> 0x002c, all -> 0x003e }
        r2.writeInt(r4);	 Catch:{ RemoteException -> 0x002c, all -> 0x003e }
        r4 = r7.f1166a;	 Catch:{ RemoteException -> 0x002c, all -> 0x003e }
        r5 = 2;	 Catch:{ RemoteException -> 0x002c, all -> 0x003e }
        r6 = 0;	 Catch:{ RemoteException -> 0x002c, all -> 0x003e }
        r4.transact(r5, r2, r3, r6);	 Catch:{ RemoteException -> 0x002c, all -> 0x003e }
        r3.readException();	 Catch:{ RemoteException -> 0x002c, all -> 0x003e }
        r4 = r3.readInt();	 Catch:{ RemoteException -> 0x002c, all -> 0x003e }
        if (r4 == 0) goto L_0x002a;
    L_0x0023:
        r3.recycle();
        r2.recycle();
    L_0x0029:
        return r0;
    L_0x002a:
        r0 = r1;
        goto L_0x0023;
    L_0x002c:
        r0 = move-exception;
        r4 = com.facebook.lite.p053b.C0290d.f1169a;	 Catch:{ RemoteException -> 0x002c, all -> 0x003e }
        r5 = "googleadinfo/Google opt out ads transaction failed";	 Catch:{ RemoteException -> 0x002c, all -> 0x003e }
        android.util.Log.e(r4, r5, r0);	 Catch:{ RemoteException -> 0x002c, all -> 0x003e }
        r3.recycle();
        r2.recycle();
        r0 = r1;
        goto L_0x0029;
    L_0x003e:
        r0 = move-exception;
        r3.recycle();
        r2.recycle();
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.b.b.b():boolean");
    }

    public C0288b(IBinder iBinder) {
        this.f1166a = iBinder;
    }

    public final IBinder asBinder() {
        return this.f1166a;
    }

    public final String m1935a() {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        String str = null;
        try {
            obtain.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
            this.f1166a.transact(1, obtain, obtain2, 0);
            obtain2.readException();
            str = obtain2.readString();
        } catch (Throwable e) {
            Log.e(C0290d.f1169a, "googleadinfo/Google ad id transaction failed.", e);
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
        return str;
    }
}
