package com.facebook.p038e;

import android.os.AsyncTask;
import com.facebook.lite.p053b.C0300n;

/* renamed from: com.facebook.e.a */
public final class C0212a extends AsyncTask {
    final /* synthetic */ C0225b f796a;

    public C0212a(C0225b c0225b) {
        this.f796a = c0225b;
    }

    protected final /* synthetic */ Object doInBackground(Object[] objArr) {
        return m1518a((Long[]) objArr);
    }

    private Void m1518a(Long... lArr) {
        if (lArr != null && lArr.length == 1) {
            C0251k.m1672a(this.f796a.m1561b(lArr[0].longValue()), this.f796a.f850b);
            C0300n.m2108b(this.f796a.f850b, lArr[0].longValue());
        }
        return null;
    }
}
