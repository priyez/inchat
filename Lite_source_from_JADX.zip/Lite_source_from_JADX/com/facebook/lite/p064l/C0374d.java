package com.facebook.lite.p064l;

import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;

/* renamed from: com.facebook.lite.l.d */
final class C0374d implements OnDismissListener {
    final /* synthetic */ C0377g f1445a;

    C0374d(C0377g c0377g) {
        this.f1445a = c0377g;
    }

    public final void onDismiss(DialogInterface dialogInterface) {
        this.f1445a.f1453d = false;
    }
}
