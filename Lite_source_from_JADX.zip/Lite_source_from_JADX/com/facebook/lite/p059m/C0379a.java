package com.facebook.lite.p059m;

/* renamed from: com.facebook.lite.m.a */
final /* synthetic */ class C0379a {
    static final /* synthetic */ int[] f1460a;

    static {
        f1460a = new int[C0381c.values().length];
        try {
            f1460a[C0381c.CONNECTION_ESTABLISHED.ordinal()] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            f1460a[C0381c.CONNECTION_CLOSED.ordinal()] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            f1460a[C0381c.SCREEN_DATA_RECEIVED.ordinal()] = 3;
        } catch (NoSuchFieldError e3) {
        }
        try {
            f1460a[C0381c.FONT_READY.ordinal()] = 4;
        } catch (NoSuchFieldError e4) {
        }
    }
}
