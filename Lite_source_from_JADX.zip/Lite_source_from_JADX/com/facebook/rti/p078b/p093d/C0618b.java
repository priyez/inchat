package com.facebook.rti.p078b.p093d;

import android.content.Context;
import android.content.SharedPreferences;
import com.facebook.rti.p046a.p075g.C0528c;

/* renamed from: com.facebook.rti.b.d.b */
public final class C0618b {
    public final SharedPreferences f2528a;
    public C0617a f2529b;

    public final synchronized C0617a m3540a() {
        return this.f2529b;
    }

    public static String m3538b() {
        return "device_auth";
    }

    public final synchronized boolean m3541a(C0617a c0617a) {
        boolean z;
        if (this.f2529b.equals(c0617a)) {
            z = false;
        } else {
            C0528c.m3345a(this.f2528a.edit().putString("/settings/mqtt/id/connection_key", c0617a.m3536a()).putString("/settings/mqtt/id/connection_secret", c0617a.m3537b()));
            this.f2529b = c0617a;
            z = true;
        }
        return z;
    }

    public final synchronized void m3542c() {
        m3541a(C0617a.f2527a);
    }

    public static String m3539d() {
        return "";
    }

    public C0618b(Context context) {
        this.f2528a = C0528c.f2215a.m3347a(context, "rti.mqtt.ids", true);
        this.f2529b = C0617a.m3535a(this.f2528a.getString("/settings/mqtt/id/connection_key", ""), this.f2528a.getString("/settings/mqtt/id/connection_secret", ""));
    }
}
