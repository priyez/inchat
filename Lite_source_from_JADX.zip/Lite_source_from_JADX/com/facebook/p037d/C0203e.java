package com.facebook.p037d;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/* renamed from: com.facebook.d.e */
public final class C0203e {
    private final Context f788a;
    private final C0205g f789b;
    private final C0206h f790c;

    public C0203e(Context context, C0205g c0205g, C0206h c0206h) {
        this.f788a = context;
        this.f789b = c0205g;
        this.f790c = c0206h;
    }

    public final void m1507a() {
        m1504b();
        for (String a : m1505c()) {
            this.f788a.sendOrderedBroadcast(C0203e.m1503a(a), null, new C0204f(this.f789b, this.f790c), null, 1, null, m1506d());
        }
    }

    private boolean m1504b() {
        synchronized (this.f789b) {
            if (this.f789b.m1509a() == null) {
                this.f789b.m1510a(new C0202d(UUID.randomUUID().toString(), System.currentTimeMillis()));
                return true;
            }
            return false;
        }
    }

    private List m1505c() {
        List<PackageInfo> installedPackages = this.f788a.getPackageManager().getInstalledPackages(0);
        List arrayList = new ArrayList();
        String packageName = this.f788a.getPackageName();
        for (PackageInfo packageInfo : installedPackages) {
            PackageInfo packageInfo2;
            if (!packageInfo2.packageName.equals(packageName)) {
                try {
                    packageInfo2 = this.f788a.getPackageManager().getPackageInfo(packageInfo2.packageName, 64);
                    if (C0200b.m1500a(packageInfo2)) {
                        arrayList.add(packageInfo2.packageName);
                    }
                } catch (NameNotFoundException e) {
                }
            }
        }
        return arrayList;
    }

    private static Intent m1503a(String str) {
        Intent intent = new Intent();
        intent.setAction("com.facebook.GET_PHONE_ID");
        intent.setPackage(str);
        return intent;
    }

    private Bundle m1506d() {
        Parcelable activity = PendingIntent.getActivity(this.f788a, 0, new Intent(), 134217728);
        Bundle bundle = new Bundle();
        bundle.putParcelable("auth", activity);
        return bundle;
    }
}
