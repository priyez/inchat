package com.facebook.lite;

public final class av {
    public static final int custom_keyboard_layout_default_height = 2131099650;
    public static final int multipicker_bar_height = 2131099652;
    public static final int multipicker_button_text_size = 2131099654;
    public static final int multipicker_grid_spacing = 2131099651;
    public static final int multipicker_progress_bar_height = 2131099655;
    public static final int multipicker_thumbnail_size = 2131099653;
    public static final int soft_input_detection_min_height_dp = 2131099649;
    public static final int toolbar_button_height = 2131099648;
    public static final int video_loading_text_padding = 2131099656;
}
