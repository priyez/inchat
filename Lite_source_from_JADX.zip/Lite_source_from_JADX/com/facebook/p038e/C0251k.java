package com.facebook.p038e;

import android.content.Context;
import com.facebook.p038e.p039a.C0207d;
import com.facebook.p038e.p039a.C0208a;
import com.facebook.p038e.p039a.C0209b;
import java.util.Map;
import org.json.JSONObject;

/* renamed from: com.facebook.e.k */
public final class C0251k extends C0249i {
    public C0251k(String str) {
        super(str, "client_event");
    }

    public C0251k(String str, String str2) {
        super(str, str2);
    }

    public static void m1672a(C0251k c0251k, Context context) {
        C0248h.m1653a().m1657a(c0251k, context);
    }

    public static void m1673a(C0251k c0251k, Context context, C0253n c0253n) {
        C0248h.m1653a().m1658a(c0251k, context, c0253n);
    }

    public final C0249i m1680b(String str, String str2) {
        return super.m1666a(str, str2);
    }

    public final C0249i m1678b(String str, double d) {
        return super.m1663a(str, d);
    }

    public final C0249i m1679b(String str, long j) {
        return super.m1664a(str, j);
    }

    public final C0249i m1681b(String str, boolean z) {
        return super.m1667a(str, z);
    }

    public final C0249i m1675a(String str, C0209b c0209b) {
        return super.m1665a(str, (C0207d) c0209b);
    }

    public final C0249i m1674a(String str, C0208a c0208a) {
        return super.m1665a(str, (C0207d) c0208a);
    }

    public final C0249i m1676a(String str, JSONObject jSONObject) {
        return super.m1666a(str, jSONObject.toString());
    }

    public final void m1677a(Map map) {
        for (String str : map.keySet()) {
            super.m1666a(str, map.get(str).toString());
        }
    }
}
