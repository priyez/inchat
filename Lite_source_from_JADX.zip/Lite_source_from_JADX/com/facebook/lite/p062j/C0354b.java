package com.facebook.lite.p062j;

/* renamed from: com.facebook.lite.j.b */
public final class C0354b {
    public static final int f1398a;
    private static final /* synthetic */ int[] f1399b;

    static {
        f1398a = 1;
        f1399b = new int[]{f1398a};
    }

    public static int m2500a(int i) {
        switch (i) {
            case 1:
            case 2:
                return -65536;
            case 3:
                return -256;
            default:
                return -12303292;
        }
    }

    public static int m2499a() {
        return -16776961;
    }
}
