package com.facebook.lite.widget;

import android.content.Context;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import com.facebook.lite.p053b.C0294h;

/* renamed from: com.facebook.lite.widget.o */
final class C0484o implements OnFocusChangeListener {
    final /* synthetic */ Context f2100a;
    final /* synthetic */ FloatingTextBox f2101b;

    C0484o(FloatingTextBox floatingTextBox, Context context) {
        this.f2101b = floatingTextBox;
        this.f2100a = context;
    }

    public final void onFocusChange(View view, boolean z) {
        if (z) {
            C0294h.m1965b(this.f2100a, this.f2101b.f1909e);
        } else {
            C0294h.m1954a(this.f2100a, this.f2101b.f1909e);
        }
    }
}
