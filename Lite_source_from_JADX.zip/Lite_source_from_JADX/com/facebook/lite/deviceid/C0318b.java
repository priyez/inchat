package com.facebook.lite.deviceid;

import android.content.Context;
import android.util.Log;
import com.facebook.p037d.C0202d;
import com.facebook.p037d.C0206h;
import com.facebook.p038e.C0251k;
import com.facebook.rti.push.p048a.C0727d;

/* renamed from: com.facebook.lite.deviceid.b */
public class C0318b implements C0206h {
    private static final String f1263a;
    private final Context f1264b;

    static {
        f1263a = C0318b.class.getName();
    }

    public C0318b(Context context) {
        this.f1264b = context.getApplicationContext();
    }

    public final void m2264a(C0202d c0202d, C0202d c0202d2, String str) {
        Log.w(f1263a, "Updated Phone Id from " + c0202d.toString() + " to " + c0202d2.toString() + "with source " + str);
        C0727d.m3930a(this.f1264b, "275254692598279");
        C0251k c0251k = new C0251k("phoneid_update");
        c0251k.m1680b("type", "global_sync");
        c0251k.m1680b("new_id", c0202d2.f786a);
        c0251k.m1679b("new_ts", c0202d2.f787b);
        c0251k.m1680b("old_id", c0202d.f786a);
        c0251k.m1679b("old_ts", c0202d.f787b);
        c0251k.m1680b("src_pkg", str);
        C0251k.m1672a(c0251k, this.f1264b);
    }
}
