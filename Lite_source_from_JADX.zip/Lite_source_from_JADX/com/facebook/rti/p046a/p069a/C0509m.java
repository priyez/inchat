package com.facebook.rti.p046a.p069a;

import android.text.TextUtils;
import com.facebook.rti.p046a.p074f.C0527a;

/* renamed from: com.facebook.rti.a.a.m */
final class C0509m implements Runnable {
    final /* synthetic */ C0512p f2155a;
    private C0498b f2156b;

    private C0509m(C0512p c0512p, C0498b c0498b) {
        this.f2155a = c0512p;
        this.f2156b = c0498b;
    }

    public final void run() {
        C0512p c0512p = this.f2155a;
        C0498b c0498b = this.f2156b;
        String string = c0512p.f2169k.getString("user_id", "");
        if (TextUtils.isEmpty(string)) {
            string = "0";
        }
        c0498b.m3285a(string);
        C0527a.m3336a("DefaultAnalyticsLogger", "New event %s.", this.f2156b);
        this.f2155a.f2161c.m3299a(this.f2156b);
        this.f2155a.f2162d.removeMessages(2);
        if (this.f2155a.f2161c.m3301b().size() >= 50) {
            c0512p = this.f2155a;
            if (!c0512p.f2161c.m3301b().isEmpty()) {
                C0527a.m3336a("DefaultAnalyticsLogger", "Storing batch %s", c0512p.f2161c);
                c0512p.f2167i.m3307a(c0512p.f2161c);
                c0512p.f2161c.m3296a();
                return;
            }
            return;
        }
        this.f2155a.f2162d.sendEmptyMessageDelayed(2, 300000);
    }
}
