package com.facebook.rti.push.service;

import org.json.JSONObject;

/* renamed from: com.facebook.rti.push.service.r */
public final class C0748r {
    private String f3193a;
    private String f3194b;

    public final String m3976a() {
        JSONObject jSONObject = new JSONObject();
        jSONObject.putOpt("tk", this.f3193a);
        jSONObject.putOpt("pn", this.f3194b);
        return jSONObject.toString();
    }

    public C0748r(String str, String str2) {
        this.f3193a = str;
        this.f3194b = str2;
    }
}
