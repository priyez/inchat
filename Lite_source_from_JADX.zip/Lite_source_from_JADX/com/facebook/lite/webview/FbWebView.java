package com.facebook.lite.webview;

import android.content.Context;
import android.net.Uri;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p053b.C0302p;
import org.json.JSONArray;
import org.json.JSONObject;

public class FbWebView extends WebView {
    private static final String f1848a;
    private boolean f1849b;
    private boolean f1850c;
    private boolean f1851d;
    private String f1852e;

    static {
        f1848a = FbWebView.class.getSimpleName();
    }

    public FbWebView(Context context) {
        super(context);
        this.f1849b = false;
        this.f1850c = false;
        this.f1851d = false;
        this.f1852e = "";
        m3132c();
    }

    public FbWebView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1849b = false;
        this.f1850c = false;
        this.f1851d = false;
        this.f1852e = "";
        m3132c();
    }

    public FbWebView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1849b = false;
        this.f1850c = false;
        this.f1851d = false;
        this.f1852e = "";
        m3132c();
    }

    public final void m3134a() {
        stopLoading();
        loadUrl("about:blank");
    }

    public final void m3135a(Uri uri, String str) {
        getSettings().setUserAgentString(this.f1852e + " " + m3130b());
        CookieManager instance = CookieManager.getInstance();
        instance.setAcceptCookie(true);
        if (C0302p.m2177b((CharSequence) str)) {
            instance.removeAllCookie();
        } else {
            m3128a(instance, str);
        }
        if (uri != null) {
            loadUrl(String.valueOf(uri));
        }
    }

    public final void setMFacebookWebviewRequestFromServer(boolean z) {
        this.f1849b = z;
    }

    public final void setMFbWebviewRequetsFromServer(boolean z) {
        this.f1850c = z;
    }

    public final void setMGenericWebviewRequestFromServer(boolean z) {
        this.f1851d = z;
    }

    private static void m3128a(CookieManager cookieManager, String str) {
        try {
            JSONArray jSONArray = new JSONArray(str);
            for (int i = 0; i < jSONArray.length(); i++) {
                String substring;
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                String optString = jSONObject.optString("name");
                String optString2 = jSONObject.optString("value");
                String optString3 = jSONObject.optString("domain");
                String optString4 = jSONObject.optString("path");
                String optString5 = jSONObject.optString("expires");
                boolean optBoolean = jSONObject.optBoolean("is_secure");
                StringBuilder stringBuilder = new StringBuilder(optBoolean ? "https://" : "http://");
                if (optString3.charAt(0) == '.') {
                    substring = optString3.substring(1);
                } else {
                    substring = optString3;
                }
                stringBuilder.append(substring).append(optString4);
                StringBuilder stringBuilder2 = new StringBuilder(optString);
                stringBuilder2.append('=').append(optString2).append("; ");
                stringBuilder2.append("Path=").append(optString4).append("; ");
                stringBuilder2.append("Domain=").append(optString3).append("; ");
                stringBuilder2.append("Expires=").append(optString5);
                if (optBoolean) {
                    stringBuilder2.append("; Secure");
                }
                cookieManager.setCookie(stringBuilder.toString(), stringBuilder2.toString());
            }
        } catch (Throwable e) {
            Log.e(f1848a, "Cookie Error", e);
        }
    }

    private String m3130b() {
        StringBuilder append = new StringBuilder("[FBAN/EMA;FBLC/").append(C0302p.m2174a(C0294h.m1977h(getContext()))).append(";");
        append.append("FBAV/").append(C0294h.m1981k(getContext())).append(";");
        try {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            ((WindowManager) getContext().getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
            append.append("FBDM/" + displayMetrics.toString() + ";");
        } catch (Throwable e) {
            Log.e(f1848a, "DisplayMetrics failed", e);
        }
        return append.append("]").toString();
    }

    private void m3132c() {
        WebSettings settings = getSettings();
        settings.setJavaScriptEnabled(true);
        this.f1852e = settings.getUserAgentString();
        setWebViewClient(new C0467b());
        setWebChromeClient(new C0466a());
    }
}
