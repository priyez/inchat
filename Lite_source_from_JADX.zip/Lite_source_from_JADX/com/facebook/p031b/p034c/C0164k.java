package com.facebook.p031b.p034c;

import android.os.Process;
import android.util.Log;
import java.io.File;
import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.Scanner;

/* renamed from: com.facebook.b.c.k */
public class C0164k {
    private static final Class f636a;
    private static final String f637b;

    static {
        f636a = C0164k.class;
        f637b = String.format("/proc/%s/fd", new Object[]{Integer.valueOf(Process.myPid())});
    }

    public static int m1354a() {
        try {
            String[] list = new File(f637b).list();
            return list != null ? list.length : -1;
        } catch (SecurityException e) {
            Log.e(f636a.toString(), e.getMessage());
            return -2;
        }
    }

    public static C0163j m1355b() {
        Scanner scanner;
        Throwable th;
        Scanner scanner2;
        try {
            scanner2 = new Scanner(new File("/proc/self/limits"));
            try {
                if (scanner2.findWithinHorizon("Max open files", 5000) == null) {
                    scanner2.close();
                    return null;
                }
                C0163j c0163j = new C0163j(scanner2.next(), scanner2.next());
                scanner2.close();
                return c0163j;
            } catch (IOException e) {
                scanner = scanner2;
                if (scanner != null) {
                    return null;
                }
                scanner.close();
                return null;
            } catch (NoSuchElementException e2) {
                if (scanner2 != null) {
                    return null;
                }
                scanner2.close();
                return null;
            } catch (Throwable th2) {
                th = th2;
                if (scanner2 != null) {
                    scanner2.close();
                }
                throw th;
            }
        } catch (IOException e3) {
            scanner = null;
            if (scanner != null) {
                return null;
            }
            scanner.close();
            return null;
        } catch (NoSuchElementException e4) {
            scanner2 = null;
            if (scanner2 != null) {
                return null;
            }
            scanner2.close();
            return null;
        } catch (Throwable th3) {
            scanner2 = null;
            th = th3;
            if (scanner2 != null) {
                scanner2.close();
            }
            throw th;
        }
    }
}
