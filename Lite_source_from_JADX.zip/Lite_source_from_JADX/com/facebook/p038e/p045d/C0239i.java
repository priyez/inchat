package com.facebook.p038e.p045d;

import java.io.File;
import java.io.FileFilter;

/* renamed from: com.facebook.e.d.i */
final class C0239i implements FileFilter {
    final /* synthetic */ C0240j f900a;

    C0239i(C0240j c0240j) {
        this.f900a = c0240j;
    }

    public final boolean accept(File file) {
        return file.getName().matches("cpu[0-9]+");
    }
}
