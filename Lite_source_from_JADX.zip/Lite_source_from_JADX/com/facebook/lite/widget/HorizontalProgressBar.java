package com.facebook.lite.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.util.AttributeSet;
import android.view.View;
import com.facebook.lite.ar;

public class HorizontalProgressBar extends View {
    private Paint f1917a;
    private float f1918b;

    public HorizontalProgressBar(Context context) {
        super(context);
        m3195d();
    }

    public HorizontalProgressBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        m3195d();
    }

    public final boolean m3196a() {
        return this.f1918b >= 1.0f;
    }

    public final void m3197b() {
        this.f1918b += 0.1f;
        if (this.f1918b > 1.0f) {
            this.f1918b = 1.0f;
        }
        invalidate();
    }

    public final void m3198c() {
        this.f1918b = 0.0f;
        invalidate();
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f1918b > 0.0f) {
            float width = (((float) getWidth()) * (1.0f - this.f1918b)) / 2.0f;
            canvas.drawRect(width, 0.0f, ((float) getWidth()) - width, (float) getHeight(), this.f1917a);
        }
    }

    private void m3195d() {
        this.f1917a = new Paint();
        this.f1917a.setColor(getResources().getColor(ar.blue));
        this.f1917a.setStyle(Style.FILL);
        this.f1918b = 0.0f;
    }
}
