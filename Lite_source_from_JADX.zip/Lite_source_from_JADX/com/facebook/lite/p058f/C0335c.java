package com.facebook.lite.p058f;

/* renamed from: com.facebook.lite.f.c */
final class C0335c {
    public static final int f1313a;
    public static final int f1314b;
    private static final /* synthetic */ int[] f1315c;

    static {
        f1313a = 1;
        f1314b = 2;
        f1315c = new int[]{f1313a, f1314b};
    }
}
