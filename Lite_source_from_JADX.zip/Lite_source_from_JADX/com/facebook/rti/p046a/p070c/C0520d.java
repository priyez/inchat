package com.facebook.rti.p046a.p070c;

import java.util.concurrent.Executor;

/* renamed from: com.facebook.rti.a.c.d */
public final class C0520d {
    final Executor f2194a;
    String f2195b;
    int f2196c;
    int f2197d;
    int f2198e;

    public C0520d(Executor executor) {
        this.f2194a = executor;
        this.f2196c = -1;
        this.f2197d = -1;
        this.f2198e = -1;
    }

    public final C0520d m3317a(String str) {
        this.f2195b = str;
        return this;
    }

    public final C0522f m3318a() {
        return new C0522f();
    }
}
