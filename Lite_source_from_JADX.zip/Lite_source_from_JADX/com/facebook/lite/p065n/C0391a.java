package com.facebook.lite.p065n;

import android.content.Context;
import android.util.Log;
import com.facebook.lite.ClientApplication;
import java.io.InputStream;
import java.util.Locale;

/* renamed from: com.facebook.lite.n.a */
public final class C0391a {
    private static final String f1554a;
    private static byte[] f1555b;

    static {
        f1554a = C0391a.class.getSimpleName();
    }

    private C0391a() {
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static synchronized java.lang.String m2719a(int r6) {
        /*
        r0 = 0;
        r4 = com.facebook.lite.p065n.C0391a.class;
        monitor-enter(r4);
        r1 = f1555b;	 Catch:{ all -> 0x003e }
        if (r1 != 0) goto L_0x0027;
    L_0x0008:
        r1 = com.facebook.lite.ClientApplication.m1692d();	 Catch:{ all -> 0x003e }
        r1 = com.facebook.lite.p053b.C0294h.m1977h(r1);	 Catch:{ all -> 0x003e }
        r1 = com.facebook.lite.p053b.C0302p.m2174a(r1);	 Catch:{ all -> 0x003e }
        r2 = "_";
        r2 = r1.split(r2);	 Catch:{ all -> 0x003e }
        r3 = r2.length;	 Catch:{ all -> 0x003e }
        r5 = 2;
        if (r3 != r5) goto L_0x0038;
    L_0x001e:
        r1 = 0;
        r1 = r2[r1];	 Catch:{ all -> 0x003e }
        r3 = 1;
        r2 = r2[r3];	 Catch:{ all -> 0x003e }
        com.facebook.lite.p065n.C0391a.m2721a(r1, r2);	 Catch:{ all -> 0x003e }
    L_0x0027:
        r3 = r0;
        r2 = r0;
    L_0x0029:
        if (r3 >= r6) goto L_0x0061;
    L_0x002b:
        r1 = r2;
        r5 = f1555b;	 Catch:{ all -> 0x003e }
        r2 = r1 + 1;
        r1 = r5[r1];	 Catch:{ all -> 0x003e }
        if (r1 != 0) goto L_0x002b;
    L_0x0034:
        r1 = r3 + 1;
        r3 = r1;
        goto L_0x0029;
    L_0x0038:
        r2 = "";
        com.facebook.lite.p065n.C0391a.m2721a(r1, r2);	 Catch:{ all -> 0x003e }
        goto L_0x0027;
    L_0x003e:
        r0 = move-exception;
        monitor-exit(r4);
        throw r0;
    L_0x0041:
        r0 = f1555b;	 Catch:{ all -> 0x003e }
        r3 = r2 + r1;
        r0 = r0[r3];	 Catch:{ all -> 0x003e }
        if (r0 == 0) goto L_0x004d;
    L_0x0049:
        r0 = r1 + 1;
        r1 = r0;
        goto L_0x0041;
    L_0x004d:
        r0 = new java.lang.String;	 Catch:{ UnsupportedEncodingException -> 0x0058 }
        r3 = f1555b;	 Catch:{ UnsupportedEncodingException -> 0x0058 }
        r5 = "utf-8";
        r0.<init>(r3, r2, r1, r5);	 Catch:{ UnsupportedEncodingException -> 0x0058 }
    L_0x0056:
        monitor-exit(r4);
        return r0;
    L_0x0058:
        r0 = move-exception;
        r0 = new java.lang.String;	 Catch:{ all -> 0x003e }
        r3 = f1555b;	 Catch:{ all -> 0x003e }
        r0.<init>(r3, r2, r1);	 Catch:{ all -> 0x003e }
        goto L_0x0056;
    L_0x0061:
        r1 = r0;
        goto L_0x0041;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.n.a.a(int):java.lang.String");
    }

    public static synchronized void m2721a(String str, String str2) {
        synchronized (C0391a.class) {
            Context d = ClientApplication.m1692d();
            if (d != null) {
                int a = C0391a.m2718a(d, "text_" + str.toLowerCase(Locale.ENGLISH) + "_r" + str2.toLowerCase(Locale.ENGLISH));
                if (a == 0) {
                    a = C0391a.m2718a(d, "text_" + str.toLowerCase(Locale.ENGLISH));
                    if (a == 0) {
                        a = C0391a.m2718a(d, "text");
                    }
                }
                C0391a.m2720a(d, a);
            }
        }
    }

    private static int m2718a(Context context, String str) {
        return context.getResources().getIdentifier("raw/" + str, "raw", context.getPackageName());
    }

    private static void m2720a(Context context, int i) {
        try {
            InputStream openRawResource = context.getResources().openRawResource(i);
            byte[] bArr = new byte[openRawResource.available()];
            openRawResource.read(bArr);
            openRawResource.close();
            f1555b = bArr;
        } catch (Throwable e) {
            Log.e(f1554a, "Cannot load text", e);
        }
    }
}
