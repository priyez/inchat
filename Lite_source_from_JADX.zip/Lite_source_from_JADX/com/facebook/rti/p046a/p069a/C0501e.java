package com.facebook.rti.p046a.p069a;

import android.content.SharedPreferences;
import com.facebook.rti.p046a.p075g.C0528c;
import java.util.Random;

/* renamed from: com.facebook.rti.a.a.e */
public final class C0501e {
    final SharedPreferences f2133a;
    final boolean f2134b;
    int f2135c;
    boolean f2136d;

    public final synchronized boolean m3293a() {
        boolean z = true;
        synchronized (this) {
            if (this.f2134b) {
                if (!m3291b()) {
                    if (this.f2135c == 0) {
                        this.f2135c = this.f2133a.getInt("/settings/rti/analytics/sampling/sample_rate", 0);
                        this.f2136d = this.f2133a.getBoolean("/settings/rti/analytics/sampling/is_sampled", false);
                    }
                    z = this.f2136d;
                }
            }
        }
        return z;
    }

    public final synchronized void m3292a(int i) {
        if (i != this.f2135c) {
            this.f2135c = i;
            this.f2136d = new Random().nextInt(10000) < this.f2135c;
            C0528c.m3345a(this.f2133a.edit().putInt("/settings/rti/analytics/sampling/sample_rate", this.f2135c).putBoolean("/settings/rti/analytics/sampling/is_sampled", this.f2136d));
        }
    }

    public C0501e(SharedPreferences sharedPreferences, boolean z) {
        this.f2133a = sharedPreferences;
        this.f2134b = z;
    }

    private boolean m3291b() {
        return this.f2133a.getBoolean("is_employee", false);
    }
}
