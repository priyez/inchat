package com.facebook.rti.p046a.p070c;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Executor;

/* renamed from: com.facebook.rti.a.c.f */
public final class C0522f implements Executor {
    private final String f2204a;
    private final Executor f2205b;
    private final int f2206c;
    private final int f2207d;
    private final int f2208e;
    private final Queue f2209f;
    private C0521e f2210g;

    private C0522f(C0520d c0520d) {
        this.f2204a = c0520d.f2195b;
        this.f2205b = c0520d.f2194a;
        this.f2206c = c0520d.f2196c;
        this.f2207d = c0520d.f2197d;
        this.f2208e = c0520d.f2198e;
        this.f2209f = new LinkedList();
    }

    public final synchronized void execute(Runnable runnable) {
        this.f2209f.add(new C0521e(this, runnable));
        if (this.f2210g == null) {
            m3320a();
        }
    }

    private synchronized void m3320a() {
        this.f2210g = (C0521e) this.f2209f.poll();
        if (this.f2210g != null) {
            this.f2205b.execute(this.f2210g);
        }
    }
}
