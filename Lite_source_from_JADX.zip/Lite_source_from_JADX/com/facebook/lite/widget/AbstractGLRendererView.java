package com.facebook.lite.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.opengl.GLSurfaceView;
import android.opengl.GLSurfaceView.Renderer;
import android.os.Build.VERSION;
import android.os.SystemClock;
import android.view.Choreographer.FrameCallback;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.View;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p059m.C0387i;
import com.facebook.lite.p062j.C0353a;
import com.facebook.lite.p062j.C0362j;
import com.facebook.lite.p062j.C0366n;
import com.facebook.lite.ui.C0460b;
import com.facebook.lite.ui.C0462d;
import com.p008a.p009a.p010a.p012b.C0019m;
import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p023m.C0124l;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import javax.microedition.khronos.opengles.GL10;

public abstract class AbstractGLRendererView extends GLSurfaceView implements Renderer, C0469r {
    private C0460b f1859A;
    private C0387i f1860a;
    private Bitmap f1861b;
    private Canvas f1862c;
    private volatile long f1863d;
    private FrameCallback f1864e;
    private final int f1865f;
    private int f1866g;
    private int f1867h;
    private boolean f1868i;
    private View f1869j;
    private final C0124l f1870k;
    private boolean f1871l;
    private C0022b f1872m;
    private C0362j f1873n;
    private boolean f1874o;
    private int f1875p;
    private int f1876q;
    private IntBuffer f1877r;
    private final Object f1878s;
    private boolean f1879t;
    private C0353a f1880u;
    private int f1881v;
    private C0353a f1882w;
    private int f1883x;
    private C0462d f1884y;
    private C0019m f1885z;

    protected abstract void m3148a(GL10 gl10);

    protected abstract void m3149a(GL10 gl10, Bitmap bitmap);

    protected abstract void m3150a(GL10 gl10, IntBuffer intBuffer);

    @SuppressLint({"NewApi"})
    public AbstractGLRendererView(Context context) {
        super(context);
        this.f1870k = new C0124l();
        this.f1878s = new Object();
        if (VERSION.SDK_INT >= 16) {
            this.f1864e = new C0470a(this);
            this.f1864e.doFrame(0);
        }
        this.f1865f = 1000 / C0294h.m1975g(context);
        m3153b(1);
        setRenderer(this);
        setRenderMode(0);
    }

    public final View m3145a() {
        return this;
    }

    public Bitmap getScreenshot() {
        Bitmap createBitmap;
        synchronized (this.f1878s) {
            int[] iArr = new int[this.f1877r.limit()];
            this.f1877r.get(iArr);
            createBitmap = Bitmap.createBitmap(iArr, getWidth(), getHeight(), Config.ARGB_8888);
        }
        return createBitmap;
    }

    public void onDrawFrame(GL10 gl10) {
        long uptimeMillis = SystemClock.uptimeMillis();
        if (!this.f1874o) {
            synchronized (this.f1878s) {
                m3150a(gl10, this.f1877r);
                if (m3154c()) {
                    m3144e();
                    m3149a(gl10, this.f1861b);
                }
                m3148a(gl10);
                m3143a(uptimeMillis, SystemClock.uptimeMillis());
            }
        }
    }

    public final void m3146a(int i) {
        C0300n.m2136g(getContext(), i);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.f1868i) {
            if (this.f1869j == null) {
                this.f1868i = false;
            } else {
                this.f1869j.dispatchTouchEvent(motionEvent);
                return true;
            }
        }
        if (!this.f1871l) {
            return super.onTouchEvent(motionEvent);
        }
        int x = (int) motionEvent.getX();
        int y = (int) motionEvent.getY();
        switch (motionEvent.getAction() & 255) {
            case 0:
                try {
                    this.f1885z.m114b(x, y);
                    return true;
                } catch (Throwable th) {
                    this.f1872m.m124a((short) 102, null, th);
                    return true;
                }
            case 1:
                try {
                    this.f1885z.m116c(x, y);
                    return true;
                } catch (Throwable th2) {
                    this.f1872m.m124a((short) 102, null, th2);
                    return true;
                }
            case 2:
                try {
                    this.f1885z.m112a(x, y);
                    return true;
                } catch (Throwable th22) {
                    this.f1872m.m124a((short) 102, null, th22);
                    return true;
                }
            case 5:
                try {
                    this.f1885z.m119q();
                    return true;
                } catch (Throwable th222) {
                    this.f1872m.m124a((short) 102, null, th222);
                    return true;
                }
            case 99:
                try {
                    this.f1885z.m117d(x, y);
                    return true;
                } catch (Throwable th2222) {
                    this.f1872m.m124a((short) 102, null, th2222);
                    return true;
                }
            default:
                return true;
        }
    }

    public final void m3151a(int[] iArr) {
        if (this.f1871l && this.f1859A != null && iArr != null && iArr.length >= this.f1867h * this.f1866g) {
            synchronized (this.f1878s) {
                this.f1877r.clear();
                this.f1877r.put(iArr, 0, this.f1867h * this.f1866g);
                this.f1877r.position(0);
                if (this.f1859A.m940E()) {
                    this.f1870k.m1228a(this.f1859A.m3101V());
                }
                requestRender();
            }
        }
    }

    public final void m3147a(View view, boolean z) {
        this.f1868i = z;
        this.f1869j = view;
    }

    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
        this.f1876q = i2;
        this.f1875p = i3;
        super.surfaceChanged(surfaceHolder, i, i2, i3);
        if (this.f1859A != null) {
            m3151a(this.f1859A.m1031q());
        }
    }

    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        this.f1871l = true;
        this.f1867h = C0300n.m2120d(getContext());
        this.f1866g = C0300n.m2102b(getContext());
        if (this.f1877r == null) {
            this.f1877r = ByteBuffer.allocateDirect((this.f1867h * this.f1866g) * 4).order(ByteOrder.nativeOrder()).asIntBuffer();
        }
        this.f1860a = ClientApplication.m1691c().m2387S();
        this.f1885z = this.f1860a.m2651Z();
        this.f1859A = (C0460b) this.f1860a.aa();
        this.f1872m = this.f1860a.m2642Q();
        this.f1880u = this.f1860a.m2645T();
        this.f1882w = this.f1860a.m2646U();
        this.f1873n = ((C0366n) this.f1882w).m2535a();
        this.f1884y = new C0462d(getResources(), this);
        if (!this.f1879t) {
            this.f1879t = true;
            this.f1883x = this.f1882w.m2497a(this.f1867h);
            this.f1881v = this.f1880u.m2497a(this.f1867h);
            int i = this.f1867h;
            int max = Math.max(this.f1881v, this.f1883x);
            if (max > 0) {
                this.f1861b = Bitmap.createBitmap(i, max, Config.ARGB_8888);
                this.f1862c = new Canvas(this.f1861b);
            }
        }
        super.surfaceCreated(surfaceHolder);
    }

    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        super.surfaceDestroyed(surfaceHolder);
        this.f1871l = false;
    }

    protected final void m3152b() {
        this.f1874o = true;
        C0300n.m2131f(getContext(), 1);
        this.f1860a.m2647V().m358a(65, 1);
        post(new C0471b(this));
    }

    protected int getFixedHeight() {
        return this.f1866g;
    }

    protected int getFixedWidth() {
        return this.f1867h;
    }

    protected C0022b getLogger() {
        return this.f1872m;
    }

    protected int getRealHeight() {
        return this.f1875p;
    }

    protected int getRealWidth() {
        return this.f1876q;
    }

    protected void m3153b(int i) {
        setEGLContextClientVersion(i);
        setEGLConfigChooser(false);
        if (VERSION.SDK_INT >= 11) {
            setPreserveEGLContextOnPause(true);
        }
    }

    protected final boolean m3154c() {
        return this.f1861b != null;
    }

    protected final boolean m3155d() {
        return C0300n.m2164v(getContext());
    }

    protected void onMeasure(int i, int i2) {
        if (this.f1884y != null) {
            this.f1884y.m3126a(this, i2);
        }
        super.onMeasure(i, i2);
    }

    private void m3144e() {
        this.f1861b.eraseColor(0);
        if (this.f1883x > 0) {
            this.f1882w.m2498a(this.f1862c);
        }
        if (this.f1881v > 0) {
            this.f1880u.m2498a(this.f1862c);
        }
    }

    private void m3143a(long j, long j2) {
        this.f1873n.m2523b((int) (j2 - j));
        long j3 = ((long) this.f1865f) + this.f1863d;
        for (int i = 0; i < this.f1870k.m1229b(); i++) {
            this.f1873n.m2525c((int) (j3 - this.f1870k.m1226a(i)));
        }
        this.f1870k.m1227a();
    }
}
