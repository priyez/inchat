package com.facebook.rti.p046a.p069a;

import com.facebook.rti.p046a.p074f.C0527a;

/* renamed from: com.facebook.rti.a.a.n */
final class C0510n implements Runnable {
    final /* synthetic */ C0512p f2157a;

    private C0510n(C0512p c0512p) {
        this.f2157a = c0512p;
    }

    public final void run() {
        C0512p c0512p = this.f2157a;
        if (!c0512p.f2161c.m3301b().isEmpty()) {
            C0527a.m3336a("DefaultAnalyticsLogger", "Storing batch %s", c0512p.f2161c);
            c0512p.f2167i.m3307a(c0512p.f2161c);
            c0512p.f2161c.m3296a();
        }
    }
}
