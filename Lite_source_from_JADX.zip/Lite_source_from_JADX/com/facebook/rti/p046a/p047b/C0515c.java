package com.facebook.rti.p046a.p047b;

import android.content.BroadcastReceiver;
import android.content.IntentFilter;

/* renamed from: com.facebook.rti.a.b.c */
final class C0515c {
    final IntentFilter f2179a;
    final BroadcastReceiver f2180b;
    boolean f2181c;

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder(128);
        stringBuilder.append("Receiver{");
        stringBuilder.append(this.f2180b);
        stringBuilder.append(" filter=");
        stringBuilder.append(this.f2179a);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}
