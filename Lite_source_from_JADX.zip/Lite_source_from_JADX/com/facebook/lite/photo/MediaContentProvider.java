package com.facebook.lite.photo;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import java.io.File;
import java.io.FileNotFoundException;

public class MediaContentProvider extends ContentProvider {
    private UriMatcher f1749a;

    public int delete(Uri uri, String str, String[] strArr) {
        return 0;
    }

    public String getType(Uri uri) {
        String path = uri.getPath();
        if (path.endsWith(".jpg") || path.endsWith(".jpeg")) {
            return "image/jpeg";
        }
        return null;
    }

    public Uri insert(Uri uri, ContentValues contentValues) {
        return null;
    }

    public boolean onCreate() {
        this.f1749a = new UriMatcher(-1);
        this.f1749a.addURI("com.facebook.lite.media", "*", 1);
        return true;
    }

    public ParcelFileDescriptor openFile(Uri uri, String str) {
        new StringBuilder("photo/called with uri: ").append(uri);
        if (this.f1749a.match(uri) == 1) {
            File file = new File(getContext().getFilesDir(), uri.getLastPathSegment());
            if (!file.exists()) {
                try {
                    file.createNewFile();
                } catch (Throwable e) {
                    Log.e("MediaContentProvider", "photo/create new file failed", e);
                }
            }
            return ParcelFileDescriptor.open(file, 805306368);
        }
        new StringBuilder("photo/unsupported uri: ").append(uri);
        throw new FileNotFoundException("Unsupported uri: " + uri.toString());
    }

    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        return null;
    }

    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        return 0;
    }
}
