package com.facebook.lite;

import android.text.ClipboardManager;

/* renamed from: com.facebook.lite.l */
final class C0378l implements Runnable {
    final /* synthetic */ String f1458a;
    final /* synthetic */ MainActivity f1459b;

    C0378l(MainActivity mainActivity, String str) {
        this.f1459b = mainActivity;
        this.f1458a = str;
    }

    public final void run() {
        ((ClipboardManager) this.f1459b.getSystemService("clipboard")).setText(this.f1458a);
    }
}
