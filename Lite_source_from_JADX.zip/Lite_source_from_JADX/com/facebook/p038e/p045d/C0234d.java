package com.facebook.p038e.p045d;

import android.os.Build;
import java.util.ArrayList;
import java.util.Collections;

/* renamed from: com.facebook.e.d.d */
public final class C0234d {
    private final C0233c f890a;
    private final C0240j f891b;
    private Integer f892c;

    public C0234d(C0240j c0240j, C0233c c0233c) {
        this.f891b = c0240j;
        this.f890a = c0233c;
    }

    public final int m1613a() {
        if (this.f892c == null) {
            this.f892c = Integer.valueOf(m1608b());
        }
        return this.f892c.intValue();
    }

    private int m1608b() {
        ArrayList arrayList = new ArrayList();
        C0234d.m1607a(arrayList, m1610d());
        C0234d.m1607a(arrayList, m1609c());
        C0234d.m1607a(arrayList, m1611e());
        if (arrayList.isEmpty()) {
            return 2008;
        }
        Collections.sort(arrayList);
        if ((arrayList.size() & 1) == 1) {
            return ((Integer) arrayList.get(arrayList.size() / 2)).intValue();
        }
        int size = (arrayList.size() / 2) - 1;
        return ((((Integer) arrayList.get(size + 1)).intValue() - ((Integer) arrayList.get(size)).intValue()) / 2) + ((Integer) arrayList.get(size)).intValue();
    }

    private static void m1607a(ArrayList arrayList, int i) {
        if (i != 0) {
            arrayList.add(Integer.valueOf(i));
        }
    }

    private int m1609c() {
        int intValue = this.f891b.m1625b().intValue();
        if (intValue == -1) {
            return 0;
        }
        if (intValue <= 528000) {
            return 2008;
        }
        if (intValue <= 620000) {
            return 2009;
        }
        if (intValue <= 1020000) {
            return 2010;
        }
        if (intValue <= 1220000) {
            return 2011;
        }
        if (intValue <= 1520000) {
            return 2012;
        }
        if (intValue <= 2020000) {
            return 2013;
        }
        return 2014;
    }

    private int m1610d() {
        int a = this.f891b.m1624a();
        if (a == 0) {
            return 0;
        }
        if (a == 1) {
            if (C0234d.m1612f()) {
                return 0;
            }
            return 2008;
        } else if (a <= 3) {
            return 2011;
        } else {
            return 2012;
        }
    }

    private int m1611e() {
        long a = this.f890a.m1605a();
        if (a == 0) {
            return 0;
        }
        if (a <= 201326592) {
            return 2008;
        }
        if (a <= 304087040) {
            return 2009;
        }
        if (a <= 536870912) {
            return 2010;
        }
        if (a <= 1073741824) {
            return 2011;
        }
        if (a <= 1610612736) {
            return 2012;
        }
        if (a <= 2147483648L) {
            return 2013;
        }
        return 2014;
    }

    private static boolean m1612f() {
        return Build.FINGERPRINT.contains("generic");
    }
}
