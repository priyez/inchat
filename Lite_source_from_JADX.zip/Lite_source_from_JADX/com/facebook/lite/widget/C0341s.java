package com.facebook.lite.widget;

/* renamed from: com.facebook.lite.widget.s */
public interface C0341s {
    void m2348g(String str);
}
