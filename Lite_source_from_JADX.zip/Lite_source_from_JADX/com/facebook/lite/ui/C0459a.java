package com.facebook.lite.ui;

import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p022l.C0089s;

/* renamed from: com.facebook.lite.ui.a */
public final class C0459a extends C0089s {
    public C0459a(int i, int i2, int[][] iArr, C0022b c0022b) {
        super(i, i2, iArr, c0022b);
    }

    public C0459a(int i, int i2, int[][] iArr, C0022b c0022b, C0089s c0089s) {
        super(i, i2, iArr, c0022b, c0089s);
    }

    private static void m3088a(int i, int i2, float f, int[] iArr) {
        iArr[0] = C0459a.m3087a((i >> 24) & 255, (i2 >> 24) & 255, f);
        if (C0459a.m3091e(i)) {
            C0459a.m3089c(iArr, i2);
        } else if (C0459a.m3091e(i2)) {
            C0459a.m3089c(iArr, i);
        } else {
            int i3 = (i >> 8) & 255;
            int i4 = i & 255;
            int i5 = (i2 >> 8) & 255;
            int i6 = i2 & 255;
            int a = C0459a.m3087a((i >> 16) & 255, (i2 >> 16) & 255, f);
            i3 = C0459a.m3087a(i3, i5, f);
            iArr[1] = (a << 16) + C0459a.m3087a(i4, i6, f);
            iArr[2] = i3 << 8;
        }
    }

    protected final void m3092a(int i, int i2, int i3, int i4, int[] iArr, int[] iArr2) {
        int min = Math.min(i + i3, m781d());
        int max = Math.max(i, m779c());
        int min2 = Math.min(i2 + i4, m774b());
        int max2 = Math.max(i2, m783e());
        int i5 = min - max;
        int i6 = min2 - max2;
        min = Math.min(i3, i4) / 2;
        int i7 = i + (i3 / 2);
        int i8 = i2 + (i4 / 2);
        float f = ((float) min) / 25.0f;
        int[] f2 = m786f();
        int[] n = m794n();
        min2 = (m789i() * max2) + max;
        int i9 = iArr[iArr2[1]];
        int i10 = iArr[iArr2[2]];
        float f3 = (((float) min) - f) * (((float) min) - f);
        float f4 = ((float) (min * min)) - f3;
        for (int i11 = 0; i11 < i6; i11++) {
            for (min = 0; min < i5; min++) {
                int i12 = (min + max) - i7;
                int i13 = (i11 + max2) - i8;
                float f5 = (((float) ((i12 * i12) + (i13 * i13))) - f3) / f4;
                if (f5 > 1.0f) {
                    if (!C0459a.m3091e(i9)) {
                        if (C0459a.m3090d(i9)) {
                            f2[min2] = i9;
                        } else {
                            C0089s.m757a(n, i9);
                            f2[min2] = C0089s.m758b(n[0], n[1], n[2], f2[min2]);
                        }
                    }
                } else if (f5 > 0.0f) {
                    C0459a.m3088a(i9, i10, f5, n);
                    f2[min2] = C0089s.m758b(n[0], n[1], n[2], f2[min2]);
                } else if (!C0459a.m3091e(i10)) {
                    if (C0459a.m3090d(i10)) {
                        f2[min2] = i10;
                    } else {
                        C0089s.m757a(n, i10);
                        f2[min2] = C0089s.m758b(n[0], n[1], n[2], f2[min2]);
                    }
                }
                min2++;
            }
            min2 += m789i() - i5;
        }
    }

    private static int m3087a(int i, int i2, float f) {
        return (int) ((((float) i) * f) + (((float) i2) * (1.0f - f)));
    }

    private static boolean m3090d(int i) {
        return (i & -16777216) == -16777216;
    }

    private static boolean m3091e(int i) {
        return (-16777216 & i) == 0;
    }

    private static void m3089c(int[] iArr, int i) {
        iArr[1] = 16711935 & i;
        iArr[2] = 65280 & i;
    }
}
