package com.facebook.lite;

import java.util.Arrays;

/* renamed from: com.facebook.lite.j */
public final class C0367j {
    public static final int[] f1431a;

    static {
        int[] iArr = new int[]{1, 2, 4, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 28, 66, 82};
        f1431a = iArr;
        Arrays.sort(iArr);
    }
}
