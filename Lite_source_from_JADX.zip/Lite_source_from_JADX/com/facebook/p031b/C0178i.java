package com.facebook.p031b;

import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.Debug;
import java.util.Locale;

/* renamed from: com.facebook.b.i */
final class C0178i {
    protected static String m1386a(Context context) {
        StringBuilder stringBuilder = new StringBuilder();
        ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
        MemoryInfo memoryInfo = new MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);
        Debug.MemoryInfo memoryInfo2 = new Debug.MemoryInfo();
        Debug.getMemoryInfo(memoryInfo2);
        int memoryClass = activityManager.getMemoryClass();
        int i = (int) (100.0f * (((float) (memoryInfo2.nativePrivateDirty + memoryInfo2.dalvikPrivateDirty)) / (((float) memoryClass) * 1024.0f)));
        int i2 = (int) (((float) (memoryInfo2.nativePrivateDirty * 100)) / (((float) memoryClass) * 1024.0f));
        int i3 = (int) (((float) (((memoryInfo2.nativePrivateDirty + memoryInfo2.dalvikPrivateDirty) + memoryInfo2.otherPrivateDirty) * 100)) / (((float) memoryClass) * 1024.0f));
        int i4 = (int) (((float) (memoryInfo2.otherPrivateDirty * 100)) / (((float) memoryClass) * 1024.0f));
        stringBuilder.append(String.format(Locale.US, "percent dalvik+native / native / d+n+other / other %d / %d / %d / %d", new Object[]{Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3), Integer.valueOf(i4)}));
        stringBuilder.append("avail/thresh/low? " + memoryInfo.availMem + "/" + memoryInfo.threshold + "/" + memoryInfo.lowMemory + "/(" + ((int) (((float) (100 * memoryInfo.threshold)) / ((float) memoryInfo.availMem))) + "%) memclass=" + memoryClass);
        stringBuilder.append("DebugMemInfo(kB): Private / Proportional / Shared");
        stringBuilder.append(String.format(Locale.US, "          dalvik: %7d / %7d / %7d", new Object[]{Integer.valueOf(memoryInfo2.dalvikPrivateDirty), Integer.valueOf(memoryInfo2.dalvikPss), Integer.valueOf(memoryInfo2.dalvikSharedDirty)}));
        stringBuilder.append(String.format(Locale.US, "          native: %7d / %7d / %7d", new Object[]{Integer.valueOf(memoryInfo2.nativePrivateDirty), Integer.valueOf(memoryInfo2.nativePss), Integer.valueOf(memoryInfo2.nativeSharedDirty)}));
        stringBuilder.append(String.format(Locale.US, "           other: %7d / %7d / %7d", new Object[]{Integer.valueOf(memoryInfo2.otherPrivateDirty), Integer.valueOf(memoryInfo2.otherPss), Integer.valueOf(memoryInfo2.otherSharedDirty)}));
        stringBuilder.append(String.format(Locale.US, "GC: %d GCs, %d freed, %d free count", new Object[]{Integer.valueOf(Debug.getGlobalGcInvocationCount()), Integer.valueOf(Debug.getGlobalFreedSize()), Integer.valueOf(Debug.getGlobalFreedCount())}));
        stringBuilder.append(String.format(Locale.US, "Native Heap: size/allocated/free %7d / %7d / %7d", new Object[]{Long.valueOf(Debug.getNativeHeapSize()), Long.valueOf(Debug.getNativeHeapAllocatedSize()), Long.valueOf(Debug.getNativeHeapFreeSize())}));
        stringBuilder.append(String.format(Locale.US, "Threads: alloc count/alloc size/ext ac/ext as %7d / %7d / %7d / %7d", new Object[]{Integer.valueOf(Debug.getThreadAllocCount()), Integer.valueOf(Debug.getThreadAllocSize()), Integer.valueOf(Debug.getThreadExternalAllocCount()), Integer.valueOf(Debug.getThreadExternalAllocSize())}));
        Runtime runtime = Runtime.getRuntime();
        stringBuilder.append(String.format(Locale.US, "Java Heap: size/allocated/free %7d / %7d / %7d", new Object[]{Long.valueOf(runtime.maxMemory()), Long.valueOf(runtime.totalMemory() - runtime.freeMemory()), Long.valueOf(runtime.freeMemory())}));
        return stringBuilder.toString();
    }

    protected static String m1387b(Context context) {
        if (VERSION.SDK_INT < 11) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Large heap size =" + ((ActivityManager) context.getSystemService("activity")).getLargeMemoryClass());
        return stringBuilder.toString();
    }
}
