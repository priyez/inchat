package com.facebook.lite.net;

import com.facebook.lite.p059m.C0387i;
import com.facebook.lite.p067o.C0423a;
import com.facebook.lite.p067o.C0425c;
import com.p008a.p009a.p010a.p023m.C0115e;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.Deflater;

/* renamed from: com.facebook.lite.net.d */
public class C0401d extends C0400q {
    private static final String f1620t;
    private final C0387i f1621u;
    private C0423a f1622v;
    private C0425c f1623w;
    private volatile boolean f1624x;
    private boolean f1625y;

    static {
        f1620t = C0401d.class.getSimpleName();
    }

    public C0401d(C0387i c0387i, String str, int i) {
        super(c0387i.m2639N(), c0387i.m2642Q(), c0387i.m2639N(), c0387i, c0387i.m2633H(), str, i, c0387i.m2628C(), c0387i.m2647V(), c0387i);
        this.f1621u = c0387i;
    }

    protected final C0398p m2842a(OutputStream outputStream) {
        return new C0399c(this, outputStream);
    }

    protected final void m2843p() {
        super.m2836p();
        this.f1624x = true;
    }

    private boolean m2841d(C0115e c0115e) {
        int i;
        Throwable th;
        boolean z;
        int o;
        long currentTimeMillis = System.currentTimeMillis();
        int n = c0115e.m1128n();
        int o2 = c0115e.m1129o();
        int i2 = n + 2;
        byte c = C0397b.m2757c(c0115e);
        c0115e.m1115c(n + 2);
        if (!this.f1625y && C0397b.m2752a((int) c) && (c == (byte) 1 || this.f1621u.af())) {
            if (this.f1622v == null) {
                Deflater deflater = new Deflater(9);
                this.f1622v = new C0423a();
                this.f1623w = new C0425c(this.f1622v, deflater);
            }
            try {
                if (this.f1624x || c == (byte) 1) {
                    i = i2 + 2;
                    try {
                        this.f1623w.m2943a();
                        i2 = i;
                        i = true;
                    } catch (Throwable e) {
                        th = e;
                        i2 = i;
                        boolean z2 = true;
                        this.f1625y = true;
                        this.g.m124a((short) 165, null, th);
                        try {
                            this.f1623w.close();
                        } catch (IOException e2) {
                        }
                        this.f1622v = null;
                        this.f1623w = null;
                        z = false;
                        c0115e.m1115c(n);
                        if (z) {
                            o = c0115e.m1129o() - (i2 - n);
                            c0115e.m1135a((short) ((i == 0 ? o : 0) | 32768));
                            if (i != 0) {
                                c0115e.m1135a((short) o);
                            }
                        }
                        c0115e.m1115c(n);
                        i2 = Math.round(100.0f * (1.0f - (((float) c0115e.m1129o()) / ((float) o2))));
                        String.format("Code: %d. %d -> %d (%d%%). Compressed: %b. Time: %dms.", new Object[]{Byte.valueOf(c), Integer.valueOf(o2), Integer.valueOf(c0115e.m1129o()), Integer.valueOf(i2), Boolean.valueOf(z), Long.valueOf(System.currentTimeMillis() - currentTimeMillis)});
                        return z;
                    }
                }
                i = 0;
                if (c == (byte) 1) {
                    try {
                        this.f1624x = true;
                        z = false;
                    } catch (IOException e3) {
                        th = e3;
                        this.f1625y = true;
                        this.g.m124a((short) 165, null, th);
                        this.f1623w.close();
                        this.f1622v = null;
                        this.f1623w = null;
                        z = false;
                        c0115e.m1115c(n);
                        if (z) {
                            o = c0115e.m1129o() - (i2 - n);
                            if (i == 0) {
                            }
                            c0115e.m1135a((short) ((i == 0 ? o : 0) | 32768));
                            if (i != 0) {
                                c0115e.m1135a((short) o);
                            }
                        }
                        c0115e.m1115c(n);
                        i2 = Math.round(100.0f * (1.0f - (((float) c0115e.m1129o()) / ((float) o2))));
                        String.format("Code: %d. %d -> %d (%d%%). Compressed: %b. Time: %dms.", new Object[]{Byte.valueOf(c), Integer.valueOf(o2), Integer.valueOf(c0115e.m1129o()), Integer.valueOf(i2), Boolean.valueOf(z), Long.valueOf(System.currentTimeMillis() - currentTimeMillis)});
                        return z;
                    }
                }
                this.f1622v.reset();
                this.f1623w.write(c0115e.m1137a(), c0115e.m1128n(), c0115e.m1129o());
                this.f1623w.m2944b();
                c0115e.m1140c();
                c0115e.m1115c(i2);
                c0115e.m1139b(this.f1622v.m2939a(), 0, this.f1622v.size() - 4);
                c0115e.m1118e();
                z = true;
            } catch (Throwable e4) {
                th = e4;
                i = 0;
                this.f1625y = true;
                this.g.m124a((short) 165, null, th);
                this.f1623w.close();
                this.f1622v = null;
                this.f1623w = null;
                z = false;
                c0115e.m1115c(n);
                if (z) {
                    o = c0115e.m1129o() - (i2 - n);
                    if (i == 0) {
                    }
                    c0115e.m1135a((short) ((i == 0 ? o : 0) | 32768));
                    if (i != 0) {
                        c0115e.m1135a((short) o);
                    }
                }
                c0115e.m1115c(n);
                i2 = Math.round(100.0f * (1.0f - (((float) c0115e.m1129o()) / ((float) o2))));
                String.format("Code: %d. %d -> %d (%d%%). Compressed: %b. Time: %dms.", new Object[]{Byte.valueOf(c), Integer.valueOf(o2), Integer.valueOf(c0115e.m1129o()), Integer.valueOf(i2), Boolean.valueOf(z), Long.valueOf(System.currentTimeMillis() - currentTimeMillis)});
                return z;
            }
        }
        i = 0;
        z = false;
        c0115e.m1115c(n);
        if (z) {
            o = c0115e.m1129o() - (i2 - n);
            if (i == 0) {
            }
            c0115e.m1135a((short) ((i == 0 ? o : 0) | 32768));
            if (i != 0) {
                c0115e.m1135a((short) o);
            }
        }
        c0115e.m1115c(n);
        i2 = Math.round(100.0f * (1.0f - (((float) c0115e.m1129o()) / ((float) o2))));
        String.format("Code: %d. %d -> %d (%d%%). Compressed: %b. Time: %dms.", new Object[]{Byte.valueOf(c), Integer.valueOf(o2), Integer.valueOf(c0115e.m1129o()), Integer.valueOf(i2), Boolean.valueOf(z), Long.valueOf(System.currentTimeMillis() - currentTimeMillis)});
        return z;
    }
}
