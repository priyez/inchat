package com.facebook.rti.p046a.p069a;

/* renamed from: com.facebook.rti.a.a.l */
final class C0508l implements Runnable {
    final /* synthetic */ C0512p f2154a;

    private C0508l(C0512p c0512p) {
        this.f2154a = c0512p;
    }

    public final void run() {
        this.f2154a.f2165g.set(false);
        while (!this.f2154a.f2163e.isEmpty()) {
            ((Runnable) this.f2154a.f2163e.remove()).run();
        }
    }
}
