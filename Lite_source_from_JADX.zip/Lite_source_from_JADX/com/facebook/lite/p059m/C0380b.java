package com.facebook.lite.p059m;

import com.p008a.p009a.p010a.p012b.C0025b;
import java.util.concurrent.TimeUnit;

/* renamed from: com.facebook.lite.m.b */
public class C0380b {
    private static final String f1461a;
    private static final C0380b f1462b;
    private static final long f1463c;
    private static volatile long f1464d;
    private C0025b f1465e;
    private boolean f1466f;
    private boolean f1467g;
    private final Object f1468h;

    static {
        f1461a = C0380b.class.getSimpleName();
        f1462b = new C0380b();
        long currentTimeMillis = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(31536000);
        f1463c = currentTimeMillis;
        f1464d = currentTimeMillis;
    }

    private C0380b() {
        this.f1468h = new Object();
    }

    public static C0380b m2558a() {
        return f1462b;
    }

    public final boolean m2562b() {
        return System.currentTimeMillis() - f1464d > 20000 && this.f1466f;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void m2561a(com.facebook.lite.p059m.C0381c r7) {
        /*
        r6 = this;
        r0 = new java.lang.StringBuilder;
        r1 = "appevent/fired/";
        r0.<init>(r1);
        r1 = r7.toString();
        r0.append(r1);
        r0 = r6.f1465e;
        if (r0 != 0) goto L_0x001a;
    L_0x0012:
        r0 = f1461a;
        r1 = "appevent/not handle event/event manager not set.";
        android.util.Log.e(r0, r1);
    L_0x0019:
        return;
    L_0x001a:
        r1 = r6.f1468h;
        monitor-enter(r1);
        r0 = com.facebook.lite.p059m.C0379a.f1460a;	 Catch:{ all -> 0x003e }
        r2 = r7.ordinal();	 Catch:{ all -> 0x003e }
        r0 = r0[r2];	 Catch:{ all -> 0x003e }
        switch(r0) {
            case 1: goto L_0x0041;
            case 2: goto L_0x004e;
            case 3: goto L_0x0056;
            case 4: goto L_0x0065;
            default: goto L_0x0028;
        };	 Catch:{ all -> 0x003e }
    L_0x0028:
        r0 = f1461a;	 Catch:{ all -> 0x003e }
        r2 = new java.lang.StringBuilder;	 Catch:{ all -> 0x003e }
        r3 = "appevent/not handle event:";
        r2.<init>(r3);	 Catch:{ all -> 0x003e }
        r2 = r2.append(r7);	 Catch:{ all -> 0x003e }
        r2 = r2.toString();	 Catch:{ all -> 0x003e }
        android.util.Log.e(r0, r2);	 Catch:{ all -> 0x003e }
    L_0x003c:
        monitor-exit(r1);	 Catch:{ all -> 0x003e }
        goto L_0x0019;
    L_0x003e:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x003e }
        throw r0;
    L_0x0041:
        r0 = 1;
        r6.f1466f = r0;	 Catch:{ all -> 0x003e }
        r0 = r6.f1467g;	 Catch:{ all -> 0x003e }
        if (r0 == 0) goto L_0x003c;
    L_0x0048:
        r0 = r6.f1465e;	 Catch:{ all -> 0x003e }
        r0.m201e();	 Catch:{ all -> 0x003e }
        goto L_0x003c;
    L_0x004e:
        r0 = 0;
        r6.f1466f = r0;	 Catch:{ all -> 0x003e }
        r2 = f1463c;	 Catch:{ all -> 0x003e }
        f1464d = r2;	 Catch:{ all -> 0x003e }
        goto L_0x003c;
    L_0x0056:
        r2 = f1464d;	 Catch:{ all -> 0x003e }
        r4 = f1463c;	 Catch:{ all -> 0x003e }
        r0 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1));
        if (r0 != 0) goto L_0x003c;
    L_0x005e:
        r2 = java.lang.System.currentTimeMillis();	 Catch:{ all -> 0x003e }
        f1464d = r2;	 Catch:{ all -> 0x003e }
        goto L_0x003c;
    L_0x0065:
        r0 = 1;
        r6.f1467g = r0;	 Catch:{ all -> 0x003e }
        r0 = r6.f1466f;	 Catch:{ all -> 0x003e }
        if (r0 == 0) goto L_0x003c;
    L_0x006c:
        r0 = r6.f1465e;	 Catch:{ all -> 0x003e }
        r0.m201e();	 Catch:{ all -> 0x003e }
        goto L_0x003c;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.m.b.a(com.facebook.lite.m.c):void");
    }

    public final void m2563c() {
        this.f1466f = false;
        this.f1467g = false;
        C0380b.m2559d();
    }

    public static void m2559d() {
        f1464d = f1463c;
    }

    public final void m2560a(C0025b c0025b) {
        this.f1465e = c0025b;
        m2563c();
    }
}
