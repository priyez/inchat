package com.facebook.p038e.p040b;

import com.facebook.p038e.C0251k;
import com.facebook.p038e.C0253n;

/* renamed from: com.facebook.e.b.a */
public interface C0214a {
    C0253n m1520a();

    C0251k m1521b();
}
