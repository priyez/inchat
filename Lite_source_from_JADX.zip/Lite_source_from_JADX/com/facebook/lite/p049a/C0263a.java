package com.facebook.lite.p049a;

/* renamed from: com.facebook.lite.a.a */
public abstract class C0263a implements Comparable, Runnable {
    private final long f1002a;

    public C0263a(long j) {
        this.f1002a = j;
    }

    public int compareTo(Object obj) {
        if (obj == null) {
            return 1;
        }
        if (C0263a.m1818a(this, obj)) {
            return m1820a(obj);
        }
        return m1819b(obj);
    }

    protected int m1820a(Object obj) {
        return this.f1002a > ((C0263a) obj).f1002a ? -1 : 1;
    }

    private int m1819b(Object obj) {
        return C0280i.m1871a((Object) this) - C0280i.m1871a(obj);
    }

    protected final long m1821a() {
        return this.f1002a;
    }

    private static boolean m1818a(Object obj, Object obj2) {
        return obj.getClass().equals(obj2.getClass());
    }
}
