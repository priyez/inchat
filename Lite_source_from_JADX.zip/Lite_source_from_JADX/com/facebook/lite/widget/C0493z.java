package com.facebook.lite.widget;

/* renamed from: com.facebook.lite.widget.z */
final class C0493z implements CharSequence {
    final /* synthetic */ aa f2114a;
    private final CharSequence f2115b;

    public C0493z(aa aaVar, CharSequence charSequence) {
        this.f2114a = aaVar;
        this.f2115b = charSequence;
    }

    public final char charAt(int i) {
        return '*';
    }

    public final int length() {
        return this.f2115b.length();
    }

    public final CharSequence subSequence(int i, int i2) {
        return this.f2115b.subSequence(i, i2);
    }
}
