package com.facebook.lite.p062j;

import android.graphics.Canvas;
import android.text.TextPaint;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.p053b.C0300n;
import com.facebook.p038e.C0249i;
import java.util.LinkedList;
import java.util.List;

/* renamed from: com.facebook.lite.j.e */
public final class C0357e implements C0353a {
    static final /* synthetic */ boolean f1407a;
    private final LinkedList f1408b;
    private boolean f1409c;
    private final TextPaint f1410d;
    private int f1411e;
    private int f1412f;

    static {
        f1407a = !C0357e.class.desiredAssertionStatus();
    }

    public C0357e() {
        this((byte) 0);
    }

    private C0357e(byte b) {
        this.f1408b = new LinkedList();
        this.f1410d = new TextPaint();
        this.f1412f = 2;
        this.f1411e = 20;
    }

    public final void m2512a(C0249i c0249i, C0356d c0356d) {
        if (this.f1409c) {
            String str = c0356d.m2507b() + ": " + c0249i.toString();
            C0356d.m2503a();
            m2508a(new C0355c(str, C0354b.m2499a()));
        }
    }

    public final void m2513a(short s, short s2, String str, C0356d c0356d) {
        if (this.f1409c) {
            String stringBuilder = new StringBuilder(c0356d.m2505a(s)).append(": ").append(s2).append(" ").append(str).toString();
            C0356d.m2503a();
            m2508a(new C0355c(stringBuilder, C0354b.m2500a(s)));
        }
    }

    private void m2508a(C0355c c0355c) {
        if (this.f1409c) {
            synchronized (this) {
                this.f1408b.addLast(c0355c);
                if (this.f1408b.size() > this.f1412f + this.f1411e) {
                    this.f1408b.remove(this.f1412f);
                }
            }
        }
    }

    public final void m2511a(Canvas canvas) {
        int i = 10;
        for (C0355c c0355c : m2509b()) {
            this.f1410d.setFakeBoldText(true);
            this.f1410d.setColor(c0355c.m2501a());
            canvas.drawText(c0355c.m2502b(), 10.0f, (float) i, this.f1410d);
            i = (int) (((float) i) + (this.f1410d.descent() - this.f1410d.ascent()));
        }
    }

    private List m2509b() {
        if (this.f1409c) {
            return this.f1408b;
        }
        return new LinkedList();
    }

    public final int m2510a(int i) {
        if (!this.f1409c) {
            return 0;
        }
        for (int i2 = 0; i2 < this.f1412f; i2++) {
            this.f1408b.add(new C0355c("", 0));
        }
        return C0300n.m2102b(ClientApplication.m1691c().m2377I());
    }

    public final boolean m2515a() {
        return this.f1409c;
    }

    public final void m2514a(boolean z) {
        this.f1409c = z;
    }
}
