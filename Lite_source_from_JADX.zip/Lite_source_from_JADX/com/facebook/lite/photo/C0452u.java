package com.facebook.lite.photo;

import android.graphics.Bitmap;

/* renamed from: com.facebook.lite.photo.u */
final class C0452u implements Runnable {
    final /* synthetic */ Object f1795a;
    final /* synthetic */ Integer f1796b;
    final /* synthetic */ Bitmap f1797c;
    final /* synthetic */ C0453w f1798d;

    C0452u(C0453w c0453w, Object obj, Integer num, Bitmap bitmap) {
        this.f1798d = c0453w;
        this.f1795a = obj;
        this.f1796b = num;
        this.f1797c = bitmap;
    }

    public final void run() {
        if (this.f1798d.f1805e.get(this.f1795a) == this.f1796b) {
            this.f1798d.f1805e.remove(this.f1795a);
            this.f1798d.f1803c.m3008a(this.f1795a, this.f1797c);
        }
    }
}
