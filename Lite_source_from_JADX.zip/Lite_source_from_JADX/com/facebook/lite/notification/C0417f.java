package com.facebook.lite.notification;

import java.util.ArrayList;

/* renamed from: com.facebook.lite.notification.f */
final class C0417f extends ArrayList {
    C0417f() {
        add("com.google.android.googlequicksearchbox");
        add("com.android.launcher");
    }
}
