package com.facebook.lite.widget;

import android.content.Context;
import android.view.KeyEvent;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

/* renamed from: com.facebook.lite.widget.p */
final class C0485p implements OnEditorActionListener {
    final /* synthetic */ Context f2102a;
    final /* synthetic */ FloatingTextBox f2103b;

    C0485p(FloatingTextBox floatingTextBox, Context context) {
        this.f2103b = floatingTextBox;
        this.f2102a = context;
    }

    public final boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
        if (i != 2 && i != 3 && i != 4 && i != 5 && i != 6) {
            return false;
        }
        this.f2103b.m3183e();
        return true;
    }
}
