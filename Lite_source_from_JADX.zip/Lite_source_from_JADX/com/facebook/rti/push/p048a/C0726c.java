package com.facebook.rti.push.p048a;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.facebook.rti.p046a.p074f.C0527a;

/* renamed from: com.facebook.rti.push.a.c */
final class C0726c implements ServiceConnection {
    C0726c() {
    }

    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        C0527a.m3338b(C0727d.f3109a, "onServiceConnected %s", componentName);
    }

    public final void onServiceDisconnected(ComponentName componentName) {
        C0527a.m3338b(C0727d.f3109a, "onServiceDisconnected %s", componentName);
    }
}
