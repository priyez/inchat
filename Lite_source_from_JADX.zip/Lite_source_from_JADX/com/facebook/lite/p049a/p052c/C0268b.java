package com.facebook.lite.p049a.p052c;

/* renamed from: com.facebook.lite.a.c.b */
public final class C0268b {
    private C0269c f1029a;
    private int f1030b;
    private int f1031c;
    private C0267a f1032d;
    private int f1033e;

    private C0268b(C0269c c0269c, C0267a c0267a) {
        this.f1029a = c0269c;
        this.f1032d = c0267a;
        this.f1033e = 0;
        this.f1031c = 0;
        this.f1030b = 0;
    }

    C0268b(C0269c c0269c, C0267a c0267a, byte b) {
        this(c0269c, c0267a);
    }

    public final int m1837a() {
        int i = this.f1030b;
        this.f1030b = 0;
        return i;
    }

    public final int m1838b() {
        int i = this.f1031c;
        this.f1031c = 0;
        return i;
    }

    public final int m1839c() {
        int i = this.f1033e;
        this.f1033e = 0;
        return i;
    }

    public final void m1840d() {
        this.f1030b++;
    }

    public final void m1841e() {
        this.f1031c++;
    }

    public final void m1842f() {
        this.f1033e++;
    }
}
