package com.facebook.rti.p046a.p076h;

/* renamed from: com.facebook.rti.a.h.d */
public final class C0534d implements C0531a {
    private static final C0534d f2217a;

    static {
        f2217a = new C0534d();
    }

    private C0534d() {
    }

    public static C0534d m3354b() {
        return f2217a;
    }

    public final long m3355a() {
        return System.currentTimeMillis();
    }
}
