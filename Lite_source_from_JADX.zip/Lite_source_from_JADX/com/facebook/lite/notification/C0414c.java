package com.facebook.lite.notification;

import android.content.Context;
import com.facebook.lite.deviceid.C0317a;
import com.google.android.gcm.C0751b;

/* renamed from: com.facebook.lite.notification.c */
final class C0414c implements Runnable {
    final /* synthetic */ Context f1691a;
    final /* synthetic */ String f1692b;

    C0414c(Context context, String str) {
        this.f1691a = context;
        this.f1692b = str;
    }

    public final void run() {
        if (!C0415d.m2923a(this.f1691a, this.f1692b, C0317a.m2260a(this.f1691a).m2262a().f786a, "GCM")) {
            C0751b.m4002c(this.f1691a);
        }
    }
}
