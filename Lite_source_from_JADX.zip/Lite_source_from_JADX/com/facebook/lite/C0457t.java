package com.facebook.lite;

import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;

/* renamed from: com.facebook.lite.t */
final class C0457t implements OnCancelListener {
    final /* synthetic */ C0458u f1818a;

    C0457t(C0458u c0458u) {
        this.f1818a = c0458u;
    }

    public final void onCancel(DialogInterface dialogInterface) {
        if (this.f1818a.f1820b) {
            this.f1818a.f1822d.m1747b(this.f1818a.f1822d.f988t);
        } else {
            this.f1818a.f1822d.m1737a(this.f1818a.f1822d.f988t);
        }
    }
}
