package com.facebook.lite;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.facebook.lite.deviceid.C0317a;
import com.facebook.lite.notification.C0415d;
import com.facebook.lite.notification.C0422k;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p053b.C0302p;
import com.facebook.rti.push.p048a.C0257b;
import com.facebook.rti.push.p048a.C0258a;

public class FbnsIntentService extends C0258a {
    private static final String f953a;

    public class CallbackReceiver extends C0257b {
        public CallbackReceiver() {
            super(FbnsIntentService.class);
        }
    }

    static {
        f953a = FbnsIntentService.class.getSimpleName();
    }

    public FbnsIntentService() {
        super(f953a);
    }

    protected final void m1705a(Intent intent) {
        Log.i(f953a, "push/received message.");
        C0300n.m2141h((Context) this, System.currentTimeMillis());
        C0422k.m2934a((Context) this, intent.getStringExtra("data"));
    }

    protected final void m1706a(String str) {
        Log.i(f953a, "push/device registered: token = " + str);
        C0415d.m2923a(this, str, C0317a.m2260a((Context) this).m2262a().f786a, "FBNS");
        m1703b();
    }

    protected final void m1707b(String str) {
        Log.i(f953a, "push/received error: " + str);
        C0415d.m2918a().m104a(0, 0, "FBNS:" + C0302p.m2174a(str));
        m1703b();
    }

    protected final void m1704a() {
        C0415d.m2924b(this);
        Log.i(f953a, "push/device unregistered.");
    }

    private void m1703b() {
        sendBroadcast(new Intent("com.facebook.lite.FBNS_REGISTRATION_COMPLETED"));
    }
}
