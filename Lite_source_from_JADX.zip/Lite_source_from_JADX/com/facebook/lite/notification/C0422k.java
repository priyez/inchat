package com.facebook.lite.notification;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import com.facebook.lite.MainActivity;
import com.facebook.lite.an;
import com.facebook.lite.ao;
import com.facebook.lite.notification.SystemTrayNotification.NotificationType;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p053b.C0302p;
import com.facebook.lite.p056d.C0315h;
import com.facebook.p038e.C0251k;
import com.facebook.p038e.p040b.p041a.C0221c;
import java.util.List;

/* renamed from: com.facebook.lite.notification.k */
public class C0422k {
    private static final String f1705a;

    static {
        f1705a = C0422k.class.getSimpleName();
    }

    public static void m2935a(Context context, List list) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
        for (Integer num : list) {
            if (num != null) {
                notificationManager.cancel(num.intValue());
            }
        }
    }

    public static void m2934a(Context context, String str) {
        C0221c.f836a.m1544d();
        C0251k c0251k = new C0251k("ema_push_notification_received");
        if (C0300n.m2083K(context)) {
            c0251k.m1681b("push_disabled", false);
            if (C0302p.m2177b((CharSequence) str)) {
                c0251k.m1681b("missing_payload", true);
                C0422k.m2936a(c0251k, context);
                return;
            }
            c0251k.m1681b("missing_payload", false);
            SystemTrayNotification a = SystemTrayNotification.m2904a(str);
            c0251k.m1679b("notification_id", (long) str.hashCode());
            c0251k.m1680b("notification_type", a.m2913h());
            c0251k.m1679b("time_received", C0422k.m2932a(a));
            long i = C0300n.m2143i(context);
            c0251k.m1679b("current_user_id", i);
            long f = a.m2911f();
            c0251k.m1679b("target_user_id", f);
            boolean i2 = a.m2914i();
            c0251k.m1681b("logged_out_push", i2);
            C0422k.m2936a(c0251k, context);
            if (i == 0 && !i2) {
                return;
            }
            if (!a.m2915j() || f == i) {
                C0315h b = C0315h.m2235b(context);
                if (C0422k.m2938a(a.m2907b(), b)) {
                    C0422k.m2937a(context, a, b);
                    return;
                }
                return;
            }
            return;
        }
        c0251k.m1681b("push_disabled", true);
        C0422k.m2936a(c0251k, context);
    }

    private static long m2932a(SystemTrayNotification systemTrayNotification) {
        long e = systemTrayNotification.m2910e();
        if (e <= 1072944000 || e >= 1577865600) {
            return System.currentTimeMillis();
        }
        return e * 1000;
    }

    private static boolean m2938a(NotificationType notificationType, C0315h c0315h) {
        if (c0315h.m2238c()) {
            return false;
        }
        if (c0315h.m2239d() && NotificationType.BIRTHDAY_REMINDER.equals(notificationType)) {
            return false;
        }
        if (c0315h.m2240e() && NotificationType.COMMENT.equals(notificationType)) {
            return false;
        }
        if (c0315h.m2241f() && NotificationType.EVENT.equals(notificationType)) {
            return false;
        }
        if (c0315h.m2242g() && NotificationType.FRIEND_CONFIRMATION.equals(notificationType)) {
            return false;
        }
        if (c0315h.m2243h() && NotificationType.FRIEND_REQUEST.equals(notificationType)) {
            return false;
        }
        if (c0315h.m2244i() && NotificationType.GROUP.equals(notificationType)) {
            return false;
        }
        if (c0315h.m2247l() && NotificationType.TAG.equals(notificationType)) {
            return false;
        }
        if (c0315h.m2250o() && NotificationType.WALL.equals(notificationType)) {
            return false;
        }
        if (c0315h.m2246k() && NotificationType.MSG.equals(notificationType)) {
            return false;
        }
        return true;
    }

    private static void m2936a(C0251k c0251k, Context context) {
        C0251k.m1672a(c0251k, context);
    }

    private static boolean m2937a(Context context, SystemTrayNotification systemTrayNotification, C0315h c0315h) {
        NotificationType b = systemTrayNotification.m2907b();
        int i = ao.sysnotif_facebook;
        String str = null;
        int i2 = 0;
        switch (C0421j.f1704a[b.ordinal()]) {
            case 1:
                i = ao.sysnotif_message;
                str = systemTrayNotification.m2912g();
                i2 = systemTrayNotification.m2909d().hashCode();
                break;
            case 2:
                i = ao.sysnotif_friend_request;
                break;
            case 3:
                i = ao.sysnotif_invite;
                break;
        }
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(603979776);
        C0422k.m2933a(context, systemTrayNotification, c0315h, intent, b.m2903a(), i, str, i2);
        return true;
    }

    private static void m2933a(Context context, SystemTrayNotification systemTrayNotification, C0315h c0315h, Intent intent, int i, int i2, String str, int i3) {
        Notification b;
        long a = C0422k.m2932a(systemTrayNotification);
        intent.putExtra("fb-push-json", systemTrayNotification.m2908c());
        intent.putExtra("fb-push-time", a);
        intent.setAction(systemTrayNotification.m2913h());
        NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
        String string = context.getString(an.app_full_name);
        PendingIntent activity = PendingIntent.getActivity(context, i3, intent, 268435456);
        if (VERSION.SDK_INT >= 11) {
            b = C0412a.m2917b(i2, systemTrayNotification.m2906a(), a, context, string, systemTrayNotification.m2906a(), activity);
        } else {
            b = C0412a.m2916a(i2, systemTrayNotification.m2906a(), a, context, string, systemTrayNotification.m2906a(), activity);
        }
        b.flags |= 16;
        if (!c0315h.m2248m()) {
            b.defaults |= 1;
        }
        if (!c0315h.m2249n()) {
            b.defaults |= 2;
        }
        if (!c0315h.m2245j()) {
            b.ledARGB = -16776961;
            b.ledOnMS = 500;
            b.ledOffMS = 500;
            b.flags |= 1;
        }
        C0221c.f836a.m1545e();
        if (str == null) {
            notificationManager.notify(i, b);
        } else {
            notificationManager.notify(str, i, b);
        }
    }
}
