package com.facebook.p038e.p040b.p041a.p042a.p043a;

/* renamed from: com.facebook.e.b.a.a.a.a */
public final class C0213a {
    public int f797a;
    public int f798b;
    public int f799c;
    public int f800d;
    public boolean f801e;
    public int f802f;
    public int f803g;
    public int f804h;
    public int f805i;
    public int f806j;
    public long f807k;
    public C0217c f808l;
    public int f809m;
    public int f810n;

    private C0213a(long j, C0217c c0217c, int i, int i2) {
        this.f797a = -1;
        this.f803g = -1;
        this.f804h = -1;
        this.f807k = j;
        this.f808l = c0217c;
        this.f799c = i;
        this.f806j = i2;
    }

    public static C0213a m1519a(int i, long j, int i2) {
        return new C0213a(j, C0217c.REQUEST_SEND_OUT, i, i2);
    }
}
