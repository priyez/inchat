package com.facebook.lite;

import android.content.Context;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.MediaScannerConnectionClient;
import android.net.Uri;

/* renamed from: com.facebook.lite.e */
final class C0332e implements MediaScannerConnectionClient {
    final /* synthetic */ C0342f f1299a;
    private final MediaScannerConnection f1300b;
    private Uri f1301c;

    public C0332e(C0342f c0342f, Context context) {
        this.f1299a = c0342f;
        this.f1300b = new MediaScannerConnection(context, this);
    }

    public final void m2313a(Uri uri) {
        this.f1301c = uri;
        this.f1300b.connect();
    }

    public final void onMediaScannerConnected() {
        this.f1300b.scanFile(this.f1301c.getPath(), null);
    }

    public final void onScanCompleted(String str, Uri uri) {
        this.f1300b.disconnect();
    }
}
