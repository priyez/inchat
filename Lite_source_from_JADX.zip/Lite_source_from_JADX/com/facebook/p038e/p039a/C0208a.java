package com.facebook.p038e.p039a;

/* renamed from: com.facebook.e.a.a */
public final class C0208a implements C0207d {
    public final StringBuilder f793a;

    public C0208a() {
        this.f793a = new StringBuilder("[");
    }

    public final void m1512a(C0207d c0207d) {
        if (this.f793a.length() != 1) {
            this.f793a.append(",");
        }
        this.f793a.append(c0207d);
    }

    public final String toString() {
        return this.f793a.toString() + "]";
    }
}
