package com.facebook.lite.deviceid;

import android.content.Context;
import com.facebook.p037d.C0199a;
import com.facebook.p037d.C0202d;

public class FbLitePhoneIdRequestReceiver extends C0199a {
    private static final String f1254a;

    static {
        f1254a = FbLitePhoneIdRequestReceiver.class.getName();
    }

    protected final C0202d m2253a(Context context) {
        C0202d a = C0317a.m2260a(context).m2262a();
        new StringBuilder("Respond Phone Id: ").append(a);
        return a;
    }
}
