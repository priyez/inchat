package com.facebook.lite;

import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Vibrator;
import android.provider.MediaStore.Images.Media;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.util.SparseArray;
import com.facebook.lite.autoupdate.C0286a;
import com.facebook.lite.deviceid.C0317a;
import com.facebook.lite.deviceid.FbLitePhoneIdUpdater;
import com.facebook.lite.diode.C0319a;
import com.facebook.lite.net.C0403i;
import com.facebook.lite.net.C0404f;
import com.facebook.lite.net.C0406k;
import com.facebook.lite.net.C0407l;
import com.facebook.lite.notification.C0415d;
import com.facebook.lite.notification.C0418g;
import com.facebook.lite.p049a.C0280i;
import com.facebook.lite.p049a.C0281j;
import com.facebook.lite.p049a.p052c.C0270d;
import com.facebook.lite.p049a.p052c.C0273g;
import com.facebook.lite.p053b.C0289c;
import com.facebook.lite.p053b.C0291e;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p053b.C0295i;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p053b.C0301o;
import com.facebook.lite.p053b.C0302p;
import com.facebook.lite.p054i.C0351g;
import com.facebook.lite.p055c.C0305a;
import com.facebook.lite.p057e.C0323d;
import com.facebook.lite.p057e.C0329i;
import com.facebook.lite.p059m.C0340j;
import com.facebook.lite.p059m.C0380b;
import com.facebook.lite.p059m.C0381c;
import com.facebook.lite.p059m.C0387i;
import com.facebook.lite.p063k.C0368a;
import com.facebook.lite.p063k.C0369b;
import com.facebook.lite.photo.AlbumGalleryActivity;
import com.facebook.lite.photo.C0443l;
import com.facebook.lite.photo.C0444m;
import com.facebook.lite.photo.GalleryItem;
import com.facebook.lite.ui.C0460b;
import com.facebook.lite.widget.C0341s;
import com.facebook.lite.widget.C0469r;
import com.facebook.p031b.C0184o;
import com.facebook.p038e.C0225b;
import com.facebook.p038e.C0244e;
import com.facebook.p038e.C0248h;
import com.facebook.p038e.C0251k;
import com.facebook.p038e.C0253n;
import com.facebook.p038e.p040b.C0222b;
import com.facebook.p038e.p040b.C0224d;
import com.facebook.p038e.p040b.p041a.C0221c;
import com.facebook.p038e.p040b.p041a.p042a.p043a.C0213a;
import com.facebook.p038e.p040b.p041a.p042a.p043a.C0216b;
import com.facebook.rti.p046a.p076h.C0534d;
import com.facebook.rti.push.p048a.C0727d;
import com.p008a.p009a.p010a.C0010a;
import com.p008a.p009a.p010a.C0044d;
import com.p008a.p009a.p010a.p011a.C0004a;
import com.p008a.p009a.p010a.p011a.C0006c;
import com.p008a.p009a.p010a.p012b.C0011a;
import com.p008a.p009a.p010a.p012b.C0019m;
import com.p008a.p009a.p010a.p012b.C0020n;
import com.p008a.p009a.p010a.p012b.C0026e;
import com.p008a.p009a.p010a.p013c.C0032d;
import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p016h.C0051c;
import com.p008a.p009a.p010a.p019i.C0057a;
import com.p008a.p009a.p010a.p019i.C0058b;
import com.p008a.p009a.p010a.p019i.C0059c;
import com.p008a.p009a.p010a.p019i.C0060d;
import com.p008a.p009a.p010a.p019i.C0061e;
import com.p008a.p009a.p010a.p019i.C0062f;
import com.p008a.p009a.p010a.p019i.C0063g;
import com.p008a.p009a.p010a.p019i.C0064h;
import com.p008a.p009a.p010a.p022l.C0076e;
import com.p008a.p009a.p010a.p022l.C0078g;
import com.p008a.p009a.p010a.p022l.C0080i;
import com.p008a.p009a.p010a.p022l.C0082k;
import com.p008a.p009a.p010a.p022l.C0088r;
import com.p008a.p009a.p010a.p022l.C0094y;
import com.p008a.p009a.p010a.p023m.C0099a;
import com.p008a.p009a.p010a.p023m.C0119g;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;

/* renamed from: com.facebook.lite.f */
public class C0342f implements C0004a, C0026e, C0020n, C0051c, C0057a, C0058b, C0059c, C0060d, C0062f, C0063g, C0064h, C0078g, C0082k, C0340j, C0341s {
    static SparseArray f1330a;
    private static final String f1331b;
    private static C0460b f1332c;
    private static C0011a f1333d;
    private static C0011a f1334e;
    private static C0011a f1335f;
    private static C0011a f1336g;
    private static C0011a f1337h;
    private static C0011a f1338i;
    private static C0011a f1339j;
    private static C0011a f1340k;
    private static C0011a f1341l;
    private static C0011a f1342m;
    private static C0011a f1343n;
    private static Uri f1344o;
    private static boolean f1345p;
    private int f1346A;
    private int f1347B;
    private String f1348C;
    private C0351g f1349D;
    private C0281j f1350E;
    private WeakReference f1351F;
    private int f1352G;
    private int[] f1353H;
    private Location f1354I;
    private C0011a f1355J;
    private C0406k f1356K;
    private C0332e f1357L;
    private C0418g f1358M;
    private int f1359N;
    private int f1360O;
    private String f1361P;
    private C0099a f1362Q;
    private C0011a f1363R;
    private C0011a f1364S;
    private C0222b f1365T;
    private C0019m f1366U;
    private Map f1367q;
    private long f1368r;
    private C0387i f1369s;
    private String f1370t;
    private Context f1371u;
    private C0329i f1372v;
    private boolean f1373w;
    private C0443l f1374x;
    private C0022b f1375y;
    private WeakReference f1376z;

    public C0342f() {
        this.f1346A = -1;
        this.f1347B = -1;
        this.f1361P = "";
        this.f1362Q = new C0099a();
    }

    static {
        f1331b = C0342f.class.getSimpleName();
        f1330a = new SparseArray();
    }

    public final void m2374F() {
        if (f1343n != null) {
            this.f1369s.m2639N().m168a(f1343n);
        }
    }

    public final void m2396a(byte b) {
        if (b == null) {
            m2381M().finish();
        }
    }

    public final void m2409a(C0088r c0088r, char c, byte[] bArr) {
        String a = C0301o.m2171a(this.f1371u);
        if (a != null) {
            C0281j.m1900a(a, this.f1371u).m1906a(c0088r, c, bArr);
        }
    }

    public final void m2435c() {
        this.f1350E.m1904a();
    }

    public final void m2437c(String str) {
        m2381M().m1780a(C0302p.m2178c(C0302p.m2176b(str)));
    }

    public final boolean m2427a(byte[] bArr, int i, int i2, int i3, int i4, int i5, int[] iArr, int i6) {
        WeakReference weakReference = (WeakReference) f1330a.get(i6);
        if (weakReference == null || weakReference.get() == null) {
            try {
                return m2361b(bArr, i, i2, i3, i4, i5, iArr, i6);
            } catch (Throwable e) {
                StringBuffer stringBuffer = new StringBuffer(150);
                stringBuffer.append("imageBuffer:").append(bArr == null ? "NULL" : Integer.valueOf(bArr.length)).append(" Length:").append(i).append(" imageWidth:").append(i2).append(" fromX:").append(i3).append(" fromY:").append(i4).append(" imageHeight:").append(i5).append(" resourceId:").append(i6);
                this.f1375y.m124a((short) 58, stringBuffer.toString(), e);
                C0216b.m1527a(i6);
                return false;
            }
        }
        ((Bitmap) weakReference.get()).getPixels(iArr, 0, i2, i3, i4, i2, i5);
        C0213a c = C0216b.m1531c(i6);
        if (c != null) {
            ClientApplication.m1691c().m2387S().m2684b(i6, c.f800d, c.f797a, c.f802f, c.f807k, c.f804h, c.f803g, c.f801e, c.f806j, c.f805i);
        }
        return true;
    }

    public final boolean m2428a(byte[] bArr, int i, int i2, int i3, int i4, int i5, int[] iArr, int i6, C0119g c0119g) {
        Bitmap a = this.f1374x.m3031a(c0119g);
        if (a != null) {
            try {
                a.getPixels(iArr, 0, i2, i3, i4, i2, i5);
                C0213a c = C0216b.m1531c(i6);
                if (c != null) {
                    ClientApplication.m1691c().m2387S().m2684b(i6, c.f800d, c.f797a, c.f802f, c.f807k, c.f804h, c.f803g, c.f801e, c.f806j, c.f805i);
                }
                return true;
            } catch (Throwable e) {
                this.f1375y.m124a((short) 284, c0119g.toString(), e);
                new StringBuilder("photo/decode getPixels image failed exception:").append(e.toString());
                C0216b.m1527a(i6);
            }
        }
        if (c0119g.m1189e() > 0) {
            this.f1374x.m3033a(bArr, i, i6, c0119g);
            return false;
        }
        try {
            return m2362b(bArr, i, i2, i3, i4, i5, iArr, i6, c0119g);
        } catch (Throwable e2) {
            StringBuffer stringBuffer = new StringBuffer(150);
            stringBuffer.append("imageBuffer:").append(bArr == null ? "NULL" : Integer.valueOf(bArr.length)).append(" Length:").append(i).append(" imageWidth:").append(i2).append(" fromX:").append(i3).append(" fromY:").append(i4).append(" imageHeight:").append(i5).append(" resourceId:").append(i6);
            this.f1375y.m124a((short) 281, stringBuffer.toString(), e2);
            new StringBuilder("photo/decode decode image failed exception:").append(e2.toString());
            C0216b.m1527a(i6);
            return false;
        } catch (Throwable e3) {
            this.f1375y.m124a((short) 280, "decode normal image find OOM!", e3);
            new StringBuilder("photo/decode decoded image failed OOM!:").append(e3.toString());
            C0216b.m1527a(i6);
            return false;
        }
    }

    public final boolean m2425a(String str) {
        return this.f1371u.deleteFile(str);
    }

    public final void m2397a(int i, byte b) {
        C0280i a = C0280i.m1872a(this.f1371u, this.f1375y);
        if (a != null) {
            a.m1890a(i, b);
        }
    }

    public final void m2408a(C0076e c0076e, int i, byte b, boolean z, boolean z2, boolean z3) {
        m2381M().m1779a(c0076e, i, b, z, z2, z3);
    }

    public final void m2401a(int i, String str, C0011a c0011a, String str2, C0011a c0011a2, boolean z, int i2, int i3, int i4, int i5, int i6, String str3, String str4, boolean z2, int i7, short s, String str5, C0099a c0099a, C0099a c0099a2, C0099a c0099a3, String str6) {
        int min = i > 0 ? Math.min(2500, i) : 200;
        String A = m2369A();
        if (A.length() > min) {
            A = A.substring(0, min);
        }
        this.f1363R = c0011a2;
        this.f1364S = c0011a;
        int i8 = 251658240 & i6;
        long P = this.f1369s.m2641P();
        C0323d L = this.f1369s.m2637L();
        if (i8 == 0 || i8 == 16777216) {
            m2381M().m1774a(i6, A, str, str2, min, z, i2, i3, i4, i5, str3, str4, this.f1372v, z2, i7, s, str5, c0099a, c0099a2, c0099a3, str6, Long.valueOf(P), L);
        } else {
            m2381M().m1773a(i6, A, str, str2, min);
        }
    }

    private boolean m2361b(byte[] bArr, int i, int i2, int i3, int i4, int i5, int[] iArr, int i6) {
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(bArr, 0, i);
        f1330a.put(i6, new WeakReference(decodeByteArray));
        if (decodeByteArray == null) {
            decodeByteArray = C0444m.m3040a(this.f1371u, bArr, bArr.length, C0300n.m2120d(this.f1371u), C0300n.m2102b(this.f1371u));
        }
        if (decodeByteArray == null) {
            this.f1375y.m125a((short) 2, (short) 58);
            return false;
        }
        decodeByteArray.getPixels(iArr, 0, i2, i3, i4, i2, i5);
        C0213a c = C0216b.m1531c(i6);
        if (c != null) {
            ClientApplication.m1691c().m2387S().m2684b(i6, c.f800d, c.f797a, c.f802f, c.f807k, c.f804h, c.f803g, c.f801e, c.f806j, c.f805i);
        }
        return true;
    }

    private boolean m2362b(byte[] bArr, int i, int i2, int i3, int i4, int i5, int[] iArr, int i6, C0119g c0119g) {
        long currentTimeMillis = System.currentTimeMillis();
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(bArr, 0, i);
        if (decodeByteArray == null) {
            decodeByteArray = C0444m.m3040a(this.f1371u, bArr, bArr.length, C0300n.m2120d(this.f1371u), C0300n.m2102b(this.f1371u));
        }
        if (decodeByteArray == null) {
            this.f1375y.m126a((short) 2, (short) 58, "decode image from bytes error appController");
            return false;
        }
        Bitmap a = C0443l.m3022a(decodeByteArray, c0119g.m1188d(), c0119g.m1187c(), c0119g.m1191g(), c0119g.m1192h(), c0119g.m1190f(), c0119g.m1185a(), this.f1375y);
        if (a != decodeByteArray) {
            decodeByteArray.recycle();
        }
        a.getPixels(iArr, 0, i2, i3, i4, i2, i5);
        C0213a c = C0216b.m1531c(i6);
        if (c != null) {
            ClientApplication.m1691c().m2387S().m2684b(i6, c.f800d, c.f797a, c.f802f, c.f807k, c.f804h, c.f803g, c.f801e, c.f806j, c.f805i);
        }
        C0443l.m3026a(c0119g, a);
        new StringBuilder("photo/decode decode image successfully time cost:").append(System.currentTimeMillis() - currentTimeMillis);
        return true;
    }

    public final String m2441d(String str) {
        String str2 = (String) this.f1367q.get(str);
        if (str2 != null) {
            return str2;
        }
        str2 = C0319a.m2269a(this.f1371u, str);
        if (str2 == null) {
            return System.getProperty(str);
        }
        return str2;
    }

    public final AlbumGalleryActivity m2375G() {
        return (AlbumGalleryActivity) this.f1351F.get();
    }

    public final long m2376H() {
        return this.f1368r;
    }

    public final long m2440d() {
        C0280i a = C0280i.m1872a(this.f1371u, this.f1375y);
        if (a != null) {
            return a.m1889a();
        }
        return 0;
    }

    public final String m2443e() {
        return this.f1370t;
    }

    public final C0403i m2394a(C0032d c0032d) {
        return new C0404f(this.f1375y, this.f1371u, c0032d);
    }

    public final void m2418a(short s, byte b, short s2) {
        Collection<C0369b> a = new C0368a(this.f1371u).m2539a();
        C0251k c0251k = new C0251k("ema_upload_contacts");
        c0251k.m1679b("size_of_contacts", (long) a.size());
        C0251k.m1672a(c0251k, this.f1371u);
        C0010a c0010a = new C0010a();
        c0010a.m68a("Phonebook");
        for (C0369b a2 : a) {
            a2.m2540a(c0010a);
        }
        c0010a.m66a(a.size());
        this.f1369s.a_().m423a(s, c0010a.m65a(), b, s2);
    }

    public final Context m2377I() {
        return this.f1371u;
    }

    public final String m2446f() {
        Resources resources = this.f1371u.getResources();
        if (resources == null || resources.getConfiguration() == null || resources.getConfiguration().locale == null) {
            return "";
        }
        return resources.getConfiguration().locale.getCountry();
    }

    public final C0006c m2378J() {
        return this.f1369s.m2629D() == null ? C0006c.f16f : this.f1369s.m2629D().m53a();
    }

    public final C0329i m2379K() {
        return this.f1372v;
    }

    public final int m2466x() {
        return this.f1371u.getResources().getDisplayMetrics().densityDpi;
    }

    public final int[] m2449g() {
        if (this.f1354I == null) {
            return null;
        }
        float latitude = (float) this.f1354I.getLatitude();
        int floatToIntBits = Float.floatToIntBits((float) this.f1354I.getLongitude());
        int floatToIntBits2 = Float.floatToIntBits(latitude);
        return new int[]{floatToIntBits, floatToIntBits2};
    }

    public final void m2430b() {
        if (aw.f1162a) {
            m2381M().startActivityForResult(new Intent(m2381M(), AlbumGalleryActivity.class), 2);
        }
    }

    public final int m2467y() {
        if (m2381M() == null) {
            return 0;
        }
        return C0300n.m2102b(m2381M());
    }

    public final C0443l m2380L() {
        return this.f1374x;
    }

    public final String m2450h() {
        Resources resources = this.f1371u.getResources();
        if (resources == null || resources.getConfiguration() == null || resources.getConfiguration().locale == null) {
            return "";
        }
        return resources.getConfiguration().locale.toString();
    }

    public final InputStream m2429b(int i) {
        if (i == 101 || i == 102) {
            return this.f1371u.getResources().openRawResource(at.logo);
        }
        return null;
    }

    public final MainActivity m2381M() {
        return (MainActivity) this.f1376z.get();
    }

    public final int m2451i() {
        long j = 2147483647L;
        long j2 = C0294h.m1980j(this.f1371u) / 6;
        if (j2 <= 2147483647L) {
            j = j2;
        }
        return (int) j;
    }

    public final C0099a m2468z() {
        return this.f1362Q;
    }

    public final String m2369A() {
        return this.f1361P;
    }

    public final InputStream m2452j() {
        return this.f1371u.getResources().openRawResource(at.f1159p);
    }

    public final String m2457o() {
        return C0294h.m1968c();
    }

    public final int m2370B() {
        if (this.f1346A == -1) {
            this.f1346A = C0300n.m2081I(this.f1371u);
        }
        return this.f1346A;
    }

    public final int m2371C() {
        if (this.f1347B == -1) {
            this.f1347B = C0300n.m2082J(this.f1371u);
        }
        return this.f1347B;
    }

    public final int m2372D() {
        if (m2381M() == null) {
            return 0;
        }
        return C0300n.m2120d(m2381M());
    }

    public final void m2398a(int i, int i2, Intent intent) {
        int i3 = 0;
        if (i2 == -1) {
            switch (i) {
                case 0:
                    ae();
                case 1:
                    m2365d(intent);
                case 2:
                    m2431b(intent);
                default:
            }
        } else if (i2 == 0 && this.f1369s != null) {
            C0251k c0251k;
            C0251k c0251k2;
            switch (i) {
                case 0:
                    this.f1369s.m2639N().m168a(f1336g);
                    C0444m.m3059b(this.f1371u, f1344o);
                    c0251k2 = new C0251k("ema_cancel_launched_camera");
                    c0251k2.m1679b("image_id", (long) this.f1352G);
                    C0251k.m1672a(c0251k2, this.f1371u);
                    this.f1373w = false;
                    return;
                case 1:
                    this.f1369s.m2639N().m168a(f1340k);
                    c0251k = new C0251k("ema_cancel_launched_photo_picker");
                    c0251k.m1679b("upload_id", (long) this.f1360O);
                    break;
                case 2:
                    this.f1369s.m2639N().m168a(f1334e);
                    c0251k2 = new C0251k("ema_cancel_launched_multi_photo_picker");
                    if (this.f1353H != null) {
                        while (i3 < this.f1353H.length) {
                            c0251k2.m1679b("image_ids_" + i3, (long) this.f1353H[i3]);
                            i3++;
                        }
                        c0251k = c0251k2;
                        break;
                    }
                    c0251k2.m1681b("invalid_imageIds", true);
                    return;
                default:
                    return;
            }
            C0251k.m1672a(c0251k, this.f1371u);
        }
    }

    public final boolean m2424a(Intent intent) {
        if (intent == null) {
            return false;
        }
        String action = intent.getAction();
        String type = intent.getType();
        if ("android.intent.action.SEND".equals(action) && type != null) {
            C0251k c0251k = new C0251k("ema_handle_external_request");
            if ("text/plain".equals(type)) {
                type = intent.getStringExtra("android.intent.extra.TEXT");
                this.f1369s.m2639N().m180a(new String[]{"t", type});
                c0251k.m1680b("type", "text");
                C0251k.m1673a(c0251k, this.f1371u, C0253n.MUST_HAVE);
                return true;
            } else if (!type.startsWith("image/")) {
                return false;
            } else {
                this.f1369s.m2639N().m180a(m2357a((Uri) intent.getParcelableExtra("android.intent.extra.STREAM"), this.f1369s));
                c0251k.m1680b("type", "image");
                C0251k.m1673a(c0251k, this.f1371u, C0253n.MUST_HAVE);
                return true;
            }
        } else if ("android.intent.action.VIEW".equals(action)) {
            if (intent.getData() == null) {
                return false;
            }
            this.f1369s.m2639N().m180a(new String[]{"d", intent.getData().toString()});
            C0251k c0251k2 = new C0251k("ema_handle_external_request");
            c0251k2.m1680b("type", "deep_linking");
            C0251k.m1673a(c0251k2, this.f1371u, C0253n.MUST_HAVE);
            return true;
        } else if (intent.hasExtra("fb-push-json")) {
            Bundle extras = intent.getExtras();
            this.f1369s.m2639N().m173a(extras.getString("fb-push-json"), extras.getLong("fb-push-time"));
            return true;
        } else if (!"com.facebook.lite.CAMERA".equals(action)) {
            return false;
        } else {
            m2354a(f1344o);
            return true;
        }
    }

    public final void m2431b(Intent intent) {
        if (intent.getBooleanExtra("camera_result", false)) {
            ae();
        } else if (!intent.getBooleanExtra("result_handled", false)) {
            C0251k c0251k = new C0251k("ema_handle_multi_photo_picker_result");
            if (!m2356a(c0251k, intent)) {
                return;
            }
            if (this.f1355J == null && f1335f == null) {
                c0251k.m1681b("invalid_event", true);
                return;
            }
            c0251k.m1681b("invalid_event", false);
            List parcelableArrayListExtra = intent.getParcelableArrayListExtra("selected_items");
            int intExtra = intent.getIntExtra("selected_num", 0);
            String[] strArr = new String[parcelableArrayListExtra.size()];
            int[] iArr = new int[parcelableArrayListExtra.size()];
            for (int i = 0; i < parcelableArrayListExtra.size(); i++) {
                GalleryItem galleryItem = (GalleryItem) parcelableArrayListExtra.get(i);
                strArr[i] = C0444m.m3048a(this.f1371u, Uri.withAppendedPath(Media.EXTERNAL_CONTENT_URI, Integer.toString(galleryItem.m2991b())));
                iArr[i] = galleryItem.m2995d();
            }
            this.f1369s.a_().m427b((short) intExtra);
            if (parcelableArrayListExtra.isEmpty()) {
                this.f1369s.a_().m428c((short) 0);
                this.f1369s.m2639N().m168a(this.f1355J);
                this.f1369s.aa().m945J();
                return;
            }
            new C0285a(this, parcelableArrayListExtra, strArr, c0251k, iArr).execute(new Void[0]);
        }
    }

    public final void m2382N() {
        if (C0301o.m2171a(this.f1371u) != null) {
            C0280i a = C0280i.m1872a(this.f1371u, this.f1375y);
            if (a != null) {
                a.m1895b();
            }
            C0281j.m1903a(true);
        }
    }

    public final void m2383O() {
        C0280i a = C0280i.m1872a(this.f1371u, this.f1375y);
        if (a != null) {
            a.m1897c();
        }
        C0281j.m1903a(false);
    }

    public final void m2453k() {
        if (m2381M() != null) {
            m2381M().m1795m();
        }
    }

    public final void m2406a(C0022b c0022b, C0019m c0019m) {
        this.f1375y = c0022b;
        this.f1366U = c0019m;
    }

    public final void m2436c(Intent intent) {
        String g;
        C0251k c0251k = new C0251k("ema_init_client_session");
        if (this.f1369s == null) {
            this.f1369s = new C0387i(this.f1371u, this, this, this, this, this, this, this, this, new C0291e(), this, this, this, this, this, C0300n.m2139h(this.f1371u));
            g = C0300n.m2135g(this.f1371u);
            if (g != null) {
                f1344o = Uri.parse(g);
            }
            C0300n.m2087O(this.f1371u);
            C0300n.m2086N(this.f1371u);
            if (m2424a(intent)) {
                m2381M().setIntent(null);
            }
            this.f1369s.aq();
            af();
            C0280i.m1872a(this.f1371u, this.f1375y);
            this.f1357L = new C0332e(this, this.f1371u);
            this.f1374x = new C0443l(this.f1371u, this.f1375y);
            if (this.f1369s.ab()) {
                this.f1358M = new C0418g(this.f1371u, MainActivity.class.getName());
            }
            C0407l.m2881a().m2887a(this.f1369s.m2643R());
            C0300n.m2129e(this.f1371u, this.f1369s.al());
            C0300n.m2124d(this.f1371u, this.f1369s.ak());
            C0415d.m2920a(this.f1369s.m2639N());
            c0251k.m1681b("already_initialized", true);
        } else {
            if (m2424a(intent)) {
                m2381M().setIntent(null);
            }
            m2373E();
            c0251k.m1681b("already_initialized", false);
        }
        g = C0300n.m2162t(this.f1371u);
        if (g == null) {
            g = C0294h.m1971e(this.f1371u);
            C0300n.m2149k(this.f1371u, g);
        }
        c0251k.m1680b("installation_source", g);
        c0251k.m1681b("is_on_wifi", C0294h.m1976g());
        C0251k.m1672a(c0251k, this.f1371u);
        g = C0300n.m2168z(this.f1371u);
        if (g != null) {
            this.f1369s.m2691c(g);
            C0300n.m2085M(this.f1371u);
        }
        if (this.f1356K == null) {
            this.f1356K = new C0406k(this.f1371u);
            ((TelephonyManager) this.f1371u.getSystemService("phone")).listen(this.f1356K, 256);
        }
        if (this.f1349D == null) {
            this.f1349D = new C0351g(Executors.newScheduledThreadPool(1), (LocationManager) m2381M().getSystemService("location"));
        }
        if (this.f1372v == null) {
            this.f1372v = new C0329i(m2377I(), this.f1375y, "fblite_database.db");
        }
    }

    public final boolean m2458p() {
        return f1345p;
    }

    public final boolean m2384P() {
        return this.f1369s.m2641P() != 0;
    }

    public final boolean m2433b(int i, byte b) {
        C0280i a = C0280i.m1872a(this.f1371u, this.f1375y);
        if (a != null) {
            return a.m1896b(i, b);
        }
        return false;
    }

    public final boolean m2459q() {
        return C0294h.m1976g();
    }

    public final void m2385Q() {
        this.f1373w = true;
        m2400a(this.f1353H[0], this.f1355J, f1334e, f1333d, f1335f);
    }

    public final void m2400a(int i, C0011a c0011a, C0011a c0011a2, C0011a c0011a3, C0011a c0011a4) {
        C0251k c0251k = new C0251k("ema_launch_camera");
        c0251k.m1679b("image_id", (long) i);
        if (!this.f1369s.ad()) {
            c0251k.m1680b("camera_hardware_availability", "check_disabled");
        } else if (C0444m.m3063c(this.f1371u)) {
            c0251k.m1681b("camera_hardware_availability", true);
        } else {
            this.f1369s.m2639N().m168a(c0011a4);
            c0251k.m1681b("camera_hardware_availability", false);
            C0251k.m1672a(c0251k, this.f1371u);
            return;
        }
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        if (C0294h.m1958a(this.f1371u, intent)) {
            boolean z;
            c0251k.m1681b("camera_intent_availability", true);
            boolean a = C0444m.m3054a();
            c0251k.m1680b("camera_storage", a ? "external" : "internal");
            this.f1352G = i;
            f1337h = c0011a;
            f1336g = c0011a2;
            f1339j = c0011a3;
            f1338i = c0011a4;
            if (this.f1369s.aj()) {
                if (a && C0444m.m3055a(this.f1371u)) {
                    z = true;
                } else if (C0444m.m3060b(this.f1371u)) {
                    z = false;
                } else {
                    this.f1369s.m2639N().m168a(f1339j);
                    c0251k.m1681b("camera_available_space", false);
                    C0251k.m1672a(c0251k, this.f1371u);
                    return;
                }
                c0251k.m1681b("camera_available_space", true);
            } else {
                c0251k.m1680b("camera_available_space", "check_disabled");
                z = a;
            }
            try {
                ContentValues contentValues = new ContentValues();
                this.f1348C = C0444m.m3048a(this.f1371u, C0444m.m3046a(z));
                contentValues.put("title", this.f1348C);
                f1344o = this.f1371u.getContentResolver().insert(Media.EXTERNAL_CONTENT_URI, contentValues);
                c0251k.m1681b("request_exif", true);
            } catch (Exception e) {
                f1344o = C0444m.m3046a(z);
                c0251k.m1681b("request_exif", false);
            }
            intent.putExtra("output", f1344o);
            C0251k.m1672a(c0251k, this.f1371u);
            C0300n.m2095a(this.f1371u, this.f1369s.m2631F());
            C0300n.m2128e(this.f1371u, f1344o.toString());
            if (this.f1373w) {
                m2375G().startActivityForResult(intent, 0);
                return;
            } else {
                m2381M().startActivityForResult(intent, 0);
                return;
            }
        }
        this.f1369s.m2639N().m168a(c0011a4);
        c0251k.m1681b("camera_intent_availability", false);
        C0251k.m1672a(c0251k, this.f1371u);
    }

    public final void m2420a(int[] iArr, C0011a c0011a, C0011a c0011a2, C0011a c0011a3, C0011a c0011a4, String str, String str2, boolean z, String str3, String str4, String str5, boolean z2, short s, C0011a c0011a5, int i) {
        C0251k c0251k = new C0251k("ema_launch_multi_photo_picker");
        this.f1355J = c0011a;
        f1334e = c0011a2;
        f1335f = c0011a3;
        f1333d = c0011a4;
        f1343n = c0011a5;
        this.f1353H = iArr;
        this.f1359N = iArr[0];
        Intent intent = new Intent(m2381M(), AlbumGalleryActivity.class);
        C0305a F = this.f1369s.m2631F();
        if (z2) {
            intent.putParcelableArrayListExtra("selected_items", F.m2199e());
            if (!F.m2204i()) {
                F.m2192a(iArr);
            }
        } else {
            F.m2190a(this.f1369s.m2714w());
            F.m2192a(iArr);
        }
        intent.putExtra("android.intent.extra.LOCAL_ONLY", true);
        intent.putExtra("title_text", str);
        intent.putExtra("button_text", str2);
        intent.putExtra("camera_enabled", z);
        intent.putExtra("multi_picker_max_selected", s);
        intent.putExtra("preview_select", str3);
        intent.putExtra("preview_rotate", str4);
        intent.putExtra("button_color", str5);
        intent.putExtra("composer_screen_id", i);
        if (C0294h.m1958a(this.f1371u, intent)) {
            c0251k.m1681b("photo_picker_intent_availability", true);
            C0251k.m1672a(c0251k, this.f1371u);
            m2381M().startActivityForResult(intent, 2);
            return;
        }
        this.f1369s.m2639N().m168a(c0011a3);
        c0251k.m1681b("photo_picker_intent_availability", false);
        C0251k.m1672a(c0251k, this.f1371u);
    }

    public final void m2399a(int i, C0011a c0011a, C0011a c0011a2, C0011a c0011a3) {
        C0251k c0251k = new C0251k("ema_launch_photo_picker");
        c0251k.m1679b("upload_id", (long) i);
        f1342m = c0011a;
        f1340k = c0011a2;
        f1341l = c0011a3;
        this.f1360O = i;
        this.f1359N = this.f1360O;
        Intent intent = new Intent("android.intent.action.PICK");
        intent.putExtra("android.intent.extra.LOCAL_ONLY", true);
        intent.setDataAndType(Media.EXTERNAL_CONTENT_URI, "image/*");
        if (C0294h.m1958a(this.f1371u, intent)) {
            c0251k.m1681b("photo_picker_intent_availability", true);
            C0251k.m1672a(c0251k, this.f1371u);
            m2381M().startActivityForResult(intent, 1);
            return;
        }
        this.f1369s.m2639N().m168a(c0011a3);
        c0251k.m1681b("photo_picker_intent_availability", false);
        C0251k.m1672a(c0251k, this.f1371u);
    }

    public final void m2405a(C0044d c0044d) {
        if (this.f1369s.ai() && c0044d != null) {
            C0444m.m3051a(c0044d, this.f1369s, this.f1369s.m2629D(), this.f1371u);
        }
    }

    public final void m2416a(String str, C0061e c0061e) {
        this.f1371u.startActivity(new Intent("android.intent.action.CALL", Uri.parse("tel:" + str)).addFlags(268435456));
        C0251k.m1672a(new C0251k("ema_phone_call"), this.f1371u);
        c0061e.m398l();
    }

    public final C0082k m2463u() {
        return this;
    }

    public final void m2407a(C0076e c0076e) {
        MainActivity M = m2381M();
        if (M != null) {
            M.m1778a(c0076e);
            M.m1783b(this.f1369s.ah());
        }
    }

    public final C0342f m2393a(Context context) {
        this.f1371u = context.getApplicationContext();
        this.f1365T = new C0224d(context, C0248h.m1653a(), C0534d.m3354b());
        m2360b(this.f1371u);
        C0221c.m1551a(this.f1365T, context);
        return this;
    }

    public final void m2404a(C0006c c0006c, int i) {
        C0251k c0251k = new C0251k("ema_connection_quality_changed");
        c0251k.m1680b("connection_quality", c0006c.toString());
        c0251k.m1679b("download_bits_per_second", (long) i);
        C0251k.m1673a(c0251k, this.f1371u, C0253n.MUST_HAVE);
        C0407l.m2881a().m2885a(i, c0006c);
        new StringBuilder("conn/bandwidth/change/").append(c0006c.toString()).append(" (").append(i).append(")");
    }

    public final void m2461s() {
        this.f1365T.m1552a();
    }

    public final void m2395a() {
        MainActivity M = m2381M();
        if (M != null) {
            M.m1783b(this.f1369s.ah());
        }
    }

    public final void m2447f(String str) {
        if (str != null) {
            C0300n.m2153m(this.f1371u, str);
        }
    }

    public final void m2386R() {
        C0251k c0251k = new C0251k("ema_switch_user");
        long P = this.f1369s.m2641P();
        long i = C0300n.m2143i(this.f1371u);
        C0300n.m2122d(this.f1371u, P);
        C0184o.m1401a().m1455a(P == 0 ? null : Long.toString(P));
        if (P > 0) {
            if (this.f1369s.al()) {
                FbLitePhoneIdUpdater.m2254a(this.f1371u).m2259a();
            }
            c0251k.m1680b("action", "login");
            ag();
            if (C0300n.m2167y(this.f1371u) < System.currentTimeMillis() - this.f1369s.m2650Y()) {
                C0244e c0244e = new C0244e(this.f1371u);
                System.currentTimeMillis();
                C0251k.m1672a(c0244e.m1651a(Long.toString(P)), this.f1371u);
                C0300n.m2137g(this.f1371u, System.currentTimeMillis());
            }
            C0251k.m1672a(c0251k, this.f1371u);
            return;
        }
        c0251k.m1680b("action", "logout");
        C0251k.m1672a(c0251k, this.f1371u);
        ((NotificationManager) this.f1371u.getSystemService("notification")).cancelAll();
        C0251k c0251k2 = new C0251k("ema_update_badge");
        if (this.f1358M == null) {
            c0251k2.m1680b("badge_count", "update_disabled");
        } else {
            this.f1358M.m2929a(0);
            c0251k2.m1680b("badge_count", "cleared");
        }
        C0251k.m1672a(c0251k2, this.f1371u);
        if (i != 0 && m2458p()) {
            C0342f.m2355a(false);
        }
    }

    public final void m2417a(String str, boolean z, C0061e c0061e) {
        C0251k c0251k = new C0251k("ema_open_url");
        if (C0302p.m2177b((CharSequence) str)) {
            c0251k.m1680b("url", "no_url");
            C0251k.m1672a(c0251k, this.f1371u);
            return;
        }
        this.f1371u.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)).addFlags(268435456));
        c0251k.m1680b("url", str);
        C0251k.m1672a(c0251k, this.f1371u);
        c0061e.m397a(z);
    }

    public final void m2454l() {
        ((AudioManager) m2381M().getSystemService("audio")).playSoundEffect(0);
    }

    public final C0387i m2387S() {
        return this.f1369s;
    }

    public final C0022b m2388T() {
        return this.f1375y;
    }

    public final byte[] m2434b(String str) {
        try {
            FileInputStream openFileInput = this.f1371u.openFileInput(str);
            byte[] bArr = new byte[openFileInput.available()];
            openFileInput.read(bArr);
            return bArr;
        } catch (IOException e) {
            return null;
        }
    }

    public final void m2464v() {
        C0727d.m3930a(this.f1371u, "275254692598279");
    }

    public final void m2373E() {
        MainActivity M = m2381M();
        if (M != null) {
            C0469r h = M.m1790h();
            if (h != null) {
                h.m3140a(f1332c.m1031q());
            }
        }
    }

    public final void m2389U() {
        if (this.f1369s != null && this.f1369s.ac()) {
            long currentTimeMillis = System.currentTimeMillis();
            if (C0300n.m2166x(this.f1371u) < currentTimeMillis - this.f1369s.m2630E()) {
                new C0225b(m2377I()).m1562a(currentTimeMillis);
            }
        }
    }

    public final boolean m2439c(int i, byte b) {
        return m2423a(i, 0, false, b);
    }

    public final boolean m2423a(int i, int i2, boolean z, byte b) {
        C0280i a = C0280i.m1872a(this.f1371u, this.f1375y);
        if (a != null) {
            return a.m1894a(i, i2, z, b);
        }
        return false;
    }

    public final void m2419a(boolean z, boolean z2) {
        if (z && this.f1349D.m2495a() && m2381M() != null) {
            m2381M().m1785c();
            return;
        }
        if (z2 && m2381M() != null) {
            m2381M().m1798p();
        }
        this.f1349D.m2494a(new C0304b(this, z2));
    }

    private void ad() {
        this.f1364S = null;
        this.f1363R = null;
    }

    public final boolean m2421a(int i) {
        FileOutputStream fileOutputStream;
        Throwable th;
        C0251k c0251k = new C0251k("ema_save_image_file");
        c0251k.m1679b("image_id", (long) i);
        C0080i w = this.f1369s.m2714w();
        if (w == null) {
            Log.e(f1331b, "saveimagefile/unable to get provider.");
            c0251k.m1681b("invalid_provider", true);
            C0251k.m1672a(c0251k, this.f1371u);
            return false;
        }
        c0251k.m1681b("invalid_provider", false);
        C0076e e = w.m632e(i);
        if (e == null) {
            Log.e(f1331b, "saveimagefile/unable to get image from id.");
            c0251k.m1681b("invalid_image_id", true);
            C0251k.m1672a(c0251k, this.f1371u);
            return false;
        }
        boolean z;
        c0251k.m1681b("invalid_image_id", false);
        boolean a = C0444m.m3054a();
        c0251k.m1680b("save_image_storage", a ? "external" : "internal");
        if (this.f1369s.aj()) {
            if (a && C0444m.m3055a(this.f1371u)) {
                z = true;
            } else if (C0444m.m3060b(this.f1371u)) {
                z = false;
            } else {
                c0251k.m1681b("save_image_available_space", false);
                C0251k.m1672a(c0251k, this.f1371u);
                return false;
            }
            c0251k.m1681b("save_image_available_space", true);
        } else {
            c0251k.m1680b("save_image_available_space", "check_disabled");
            z = a;
        }
        String a2 = C0444m.m3048a(this.f1371u, C0444m.m3046a(z));
        if (a2 == null) {
            Log.e(f1331b, "saveimagefile/unable to get save image path.");
            c0251k.m1681b("invalid_save_image_path", true);
            C0251k.m1672a(c0251k, this.f1371u);
            return false;
        }
        c0251k.m1681b("invalid_save_image_path", false);
        Bitmap a3 = C0444m.m3040a(this.f1371u, e.m592c(), e.m590a(), C0300n.m2120d(this.f1371u), C0300n.m2102b(this.f1371u));
        if (a3 == null) {
            c0251k.m1681b("decoding_succeeded", false);
            C0251k.m1672a(c0251k, this.f1371u);
            return false;
        }
        c0251k.m1681b("decoding_succeeded", true);
        FileOutputStream fileOutputStream2 = null;
        try {
            fileOutputStream = new FileOutputStream(a2);
            try {
                a3.compress(CompressFormat.JPEG, 100, fileOutputStream);
                fileOutputStream.flush();
                a3.recycle();
                try {
                    fileOutputStream.close();
                } catch (IOException e2) {
                    Log.e(f1331b, "saveimagefile/unable to close output stream");
                }
                ContentValues contentValues = new ContentValues();
                contentValues.put("mime_type", "image/jpeg");
                contentValues.put("_data", a2);
                contentValues.put("date_added", Long.valueOf(System.currentTimeMillis()));
                this.f1371u.getContentResolver().insert(Media.EXTERNAL_CONTENT_URI, contentValues);
                c0251k.m1681b("handling_succeeded", true);
                C0251k.m1672a(c0251k, this.f1371u);
                return true;
            } catch (Exception e3) {
                try {
                    Log.e(f1331b, "saveimagefile/unable to save to output stream");
                    c0251k.m1681b("handling_succeeded", false);
                    C0251k.m1672a(c0251k, this.f1371u);
                    if (fileOutputStream != null) {
                        return false;
                    }
                    try {
                        fileOutputStream.close();
                        return false;
                    } catch (IOException e4) {
                        Log.e(f1331b, "saveimagefile/unable to close output stream");
                        return false;
                    }
                } catch (Throwable th2) {
                    fileOutputStream2 = fileOutputStream;
                    th = th2;
                    if (fileOutputStream2 != null) {
                        try {
                            fileOutputStream2.close();
                        } catch (IOException e5) {
                            Log.e(f1331b, "saveimagefile/unable to close output stream");
                        }
                    }
                    throw th;
                }
            }
        } catch (Exception e6) {
            fileOutputStream = null;
            Log.e(f1331b, "saveimagefile/unable to save to output stream");
            c0251k.m1681b("handling_succeeded", false);
            C0251k.m1672a(c0251k, this.f1371u);
            if (fileOutputStream != null) {
                return false;
            }
            fileOutputStream.close();
            return false;
        } catch (Throwable th3) {
            th = th3;
            if (fileOutputStream2 != null) {
                fileOutputStream2.close();
            }
            throw th;
        }
    }

    public final void m2390V() {
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - C0300n.m2125e(this.f1371u) > 86400000) {
            C0294h.m1966b(this.f1371u, C0286a.class, 86400000);
            C0300n.m2094a(this.f1371u, currentTimeMillis);
        }
    }

    public final int m2455m() {
        throw new UnsupportedOperationException();
    }

    public final void m2413a(AlbumGalleryActivity albumGalleryActivity) {
        if (this.f1351F != null) {
            this.f1351F.clear();
        }
        this.f1351F = new WeakReference(albumGalleryActivity);
    }

    public final void m2403a(long j) {
        if (this.f1368r == 0) {
            this.f1368r = j;
        }
    }

    public static void m2355a(boolean z) {
        f1345p = z;
    }

    public final void m2402a(int i, byte[] bArr, byte b) {
        C0280i a = C0280i.m1872a(this.f1371u, this.f1375y);
        if (a != null) {
            a.m1891a(i, bArr, b);
        }
    }

    public final void m2412a(MainActivity mainActivity) {
        if (this.f1376z != null) {
            this.f1376z.clear();
        }
        this.f1376z = new WeakReference(mainActivity);
    }

    public final void m2411a(C0099a c0099a) {
        this.f1362Q = c0099a;
    }

    public final void m2445e(String str) {
        this.f1361P = str;
    }

    public final void m2444e(int i) {
        this.f1359N = i;
    }

    public final void m2414a(Integer num) {
        C0300n.m2096a(this.f1371u, num);
        this.f1346A = -1;
    }

    public final void m2432b(Integer num) {
        C0300n.m2109b(this.f1371u, num);
        this.f1347B = -1;
    }

    public final void m2410a(C0094y c0094y) {
        if (c0094y != null) {
            f1332c = (C0460b) c0094y;
        }
    }

    public final boolean m2460r() {
        return this.f1369s.ae();
    }

    public final boolean m2462t() {
        return this.f1369s.ai();
    }

    public final boolean m2391W() {
        return this.f1369s != null && this.f1369s.an();
    }

    public final void m2415a(String str, long j, int i, int i2, int i3, int i4, int i5, int i6, int i7, boolean z, String str2) {
        if (m2381M() != null) {
            m2381M().m1771a(i, i2, i3, i4, str, j, i5, i6, i7, z, str2);
        }
    }

    public final void m2456n() {
        m2381M().finish();
        this.f1369s = null;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean m2426a(java.lang.String r6, com.p008a.p009a.p010a.p023m.C0115e r7) {
        /*
        r5 = this;
        r4 = 0;
        r3 = 117; // 0x75 float:1.64E-43 double:5.8E-322;
        r0 = 0;
        r1 = r5.f1371u;	 Catch:{ FileNotFoundException -> 0x0036 }
        r2 = 0;
        r1 = r1.openFileOutput(r6, r2);	 Catch:{ FileNotFoundException -> 0x0036 }
        r2 = r7.m1130p();	 Catch:{ IOException -> 0x001e, all -> 0x002a }
        r1.write(r2);	 Catch:{ IOException -> 0x001e, all -> 0x002a }
        r1.close();	 Catch:{ IOException -> 0x0017 }
    L_0x0015:
        r0 = 1;
    L_0x0016:
        return r0;
    L_0x0017:
        r0 = move-exception;
        r1 = r5.f1375y;
        r1.m124a(r3, r4, r0);
        goto L_0x0015;
    L_0x001e:
        r2 = move-exception;
        r1.close();	 Catch:{ IOException -> 0x0023 }
        goto L_0x0016;
    L_0x0023:
        r1 = move-exception;
        r2 = r5.f1375y;
        r2.m124a(r3, r4, r1);
        goto L_0x0016;
    L_0x002a:
        r0 = move-exception;
        r1.close();	 Catch:{ IOException -> 0x002f }
    L_0x002e:
        throw r0;
    L_0x002f:
        r1 = move-exception;
        r2 = r5.f1375y;
        r2.m124a(r3, r4, r1);
        goto L_0x002e;
    L_0x0036:
        r1 = move-exception;
        goto L_0x0016;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.f.a(java.lang.String, com.a.a.a.m.e):boolean");
    }

    public final boolean m2422a(int i, byte b, byte b2) {
        C0280i a = C0280i.m1872a(this.f1371u, this.f1375y);
        if (a != null) {
            return a.m1893a(i, b, b2);
        }
        return false;
    }

    public final void m2442d(int i) {
        C0251k c0251k = new C0251k("ema_update_badge");
        if (this.f1358M == null) {
            c0251k.m1680b("badge_count", "update_disabled");
        } else {
            this.f1358M.m2929a(i);
            c0251k.m1679b("badge_count", (long) i);
        }
        C0251k.m1672a(c0251k, this.f1371u);
    }

    public final void m2465w() {
        C0280i a = C0280i.m1872a(this.f1371u, this.f1375y);
        if (a != null) {
            a.m1899w();
        }
    }

    public final void m2392X() {
        C0280i a = C0280i.m1872a(this.f1371u, this.f1375y);
        if (a != null) {
            a.m1892a(this.f1371u);
            C0270d.m1843a();
            if (!C0295i.m1988a(C0300n.m2130f(this.f1371u), System.currentTimeMillis())) {
                C0273g.m1863a(this.f1371u, this.f1375y);
                C0300n.m2115c(this.f1371u, System.currentTimeMillis());
            }
        }
    }

    public final void m2448g(String str) {
        f1332c.m946K();
        m2445e(str);
        this.f1366U.m115b(this.f1364S);
        ad();
    }

    public final boolean m2438c(int i) {
        Vibrator vibrator = (Vibrator) this.f1371u.getSystemService("vibrator");
        if (vibrator == null) {
            return false;
        }
        vibrator.vibrate((long) i);
        return true;
    }

    private boolean m2356a(C0251k c0251k, Intent intent) {
        if (f1332c == null) {
            c0251k.m1681b("missing_window_manager", true);
            C0251k.m1672a(c0251k, this.f1371u);
            return false;
        }
        c0251k.m1681b("missing_window_manager", false);
        f1332c.m946K();
        c0251k.m1679b("upload_id", (long) this.f1360O);
        if (this.f1369s == null) {
            c0251k.m1681b("invalid_session", true);
            C0251k.m1672a(c0251k, this.f1371u);
            return false;
        }
        c0251k.m1681b("invalid_session", false);
        if (intent == null) {
            Log.e(f1331b, "gallery/unable to get photo intent.");
            this.f1369s.m2639N().m168a(f1341l);
            c0251k.m1681b("valid_return_intent", false);
            C0251k.m1672a(c0251k, this.f1371u);
            return false;
        }
        c0251k.m1681b("valid_return_intent", true);
        return true;
    }

    private String[] m2357a(Uri uri, C0387i c0387i) {
        String[] strArr;
        Throwable e;
        C0251k c0251k = new C0251k("ema_handle_photo_share_result");
        if (uri == null) {
            Log.e(f1331b, "photosharing/unable to get photo uri.");
            c0251k.m1681b("invalid_uri", true);
            C0251k.m1673a(c0251k, this.f1371u, C0253n.MUST_HAVE);
            return null;
        }
        c0251k.m1681b("invalid_uri", false);
        String a = C0444m.m3048a(this.f1371u, uri);
        if (a == null) {
            Log.e(f1331b, "photosharing/unable to get photo path.");
            c0251k.m1681b("invalid_path", true);
            C0251k.m1673a(c0251k, this.f1371u, C0253n.MUST_HAVE);
            return null;
        }
        c0251k.m1681b("invalid_path", false);
        Bitmap a2 = C0444m.m3039a(this.f1371u, a, C0300n.m2120d(this.f1371u), C0300n.m2102b(this.f1371u));
        if (a2 == null) {
            Log.e(f1331b, "photosharing/unable to read photo.");
            c0251k.m1681b("decoding_success", false);
            C0251k.m1673a(c0251k, this.f1371u, C0253n.MUST_HAVE);
            return null;
        }
        c0251k.m1681b("decoding_success", true);
        a2 = C0444m.m3043a(a, a2, c0251k, 0);
        int W = c0387i.m2648W();
        OutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        a2.compress(CompressFormat.JPEG, W, byteArrayOutputStream);
        a2.recycle();
        byte[] toByteArray = byteArrayOutputStream.toByteArray();
        try {
            byteArrayOutputStream.close();
        } catch (Throwable e2) {
            Log.e(f1331b, "photosharing/unable to close photo byte stream.", e2);
        }
        if (toByteArray == null) {
            Log.e(f1331b, "photosharing/unable to read photo.");
            c0251k.m1681b("read_success", false);
            C0251k.m1673a(c0251k, this.f1371u, C0253n.MUST_HAVE);
            return null;
        }
        c0251k.m1681b("read_success", true);
        try {
            int hashCode;
            if (this.f1359N == 0) {
                hashCode = a.hashCode();
            } else {
                hashCode = this.f1359N;
            }
            int[] a3 = c0387i.m2682a(toByteArray);
            c0387i.m2714w().m619a(hashCode, toByteArray, a3[0], a3[1]);
            C0305a F = this.f1369s.m2631F();
            GalleryItem galleryItem = new GalleryItem(Integer.valueOf(uri.getLastPathSegment()).intValue());
            galleryItem.m2990a(1);
            F.m2190a(this.f1369s.m2714w());
            F.m2189a(hashCode, galleryItem);
            this.f1369s.a_().m427b((short) 1);
            this.f1369s.a_().m428c((short) 1);
            this.f1369s.a_().m425b();
            strArr = new String[]{"i", Integer.toString(hashCode)};
            try {
                c0251k.m1681b("build_params_success", true);
            } catch (Exception e3) {
                e = e3;
                c0251k.m1681b("build_params_success", false);
                Log.e(f1331b, "photosharing/unable to build params.", e);
                C0251k.m1673a(c0251k, this.f1371u, C0253n.MUST_HAVE);
                return strArr;
            }
        } catch (Throwable e4) {
            Throwable th = e4;
            strArr = null;
            e = th;
            c0251k.m1681b("build_params_success", false);
            Log.e(f1331b, "photosharing/unable to build params.", e);
            C0251k.m1673a(c0251k, this.f1371u, C0253n.MUST_HAVE);
            return strArr;
        }
        C0251k.m1673a(c0251k, this.f1371u, C0253n.MUST_HAVE);
        return strArr;
    }

    private void ae() {
        C0251k c0251k = new C0251k("ema_handle_camera_result");
        if (f1332c == null) {
            c0251k.m1681b("missing_window_manager", true);
            C0251k.m1672a(c0251k, this.f1371u);
            return;
        }
        c0251k.m1681b("missing_window_manager", false);
        f1332c.m946K();
        if (this.f1369s == null) {
            c0251k.m1681b("invalid_session", true);
            C0251k.m1672a(c0251k, this.f1371u);
            return;
        }
        c0251k.m1681b("invalid_session", false);
        if (f1337h == null && f1338i == null) {
            c0251k.m1681b("invalid_event", true);
            return;
        }
        c0251k.m1681b("invalid_event", false);
        new C0316d(this, c0251k, f1344o, false, this.f1369s, this.f1371u, this.f1357L).execute(new Void[0]);
    }

    private void m2354a(Uri uri) {
        C0251k c0251k = new C0251k("ema_handle_camera_result_cold_start");
        if (uri == null) {
            Log.e(f1331b, "camera/unable to get camera photo uri.");
            c0251k.m1681b("invalid_uri", true);
            C0251k.m1673a(c0251k, this.f1371u, C0253n.MUST_HAVE);
            return;
        }
        c0251k.m1681b("invalid_uri", false);
        new C0316d(this, c0251k, uri, true, this.f1369s, this.f1371u, this.f1357L).execute(new Void[0]);
    }

    private void m2365d(Intent intent) {
        C0251k c0251k = new C0251k("ema_handle_photo_picker_result");
        if (!m2356a(c0251k, intent)) {
            return;
        }
        if (f1342m == null && f1341l == null) {
            c0251k.m1681b("invalid_event", true);
            return;
        }
        c0251k.m1681b("invalid_event", false);
        String a = C0444m.m3048a(this.f1371u, intent.getData());
        if (a == null) {
            Log.e(f1331b, "gallery/unable to get photo path.");
            this.f1369s.m2639N().m168a(f1341l);
            c0251k.m1681b("valid_photo_path", false);
            C0251k.m1672a(c0251k, this.f1371u);
            return;
        }
        c0251k.m1681b("valid_photo_path", true);
        new C0307c(this, a, c0251k).execute(new Void[0]);
    }

    private void af() {
        C0281j.m1902a(this.f1369s.m2647V());
        this.f1350E = C0281j.m1900a(C0301o.m2171a(this.f1371u), this.f1371u);
        if (this.f1350E != null) {
            C0088r.m747a(this.f1369s.m2644S());
            this.f1350E.m1907b(this.f1369s.m2647V());
            this.f1350E.m1905a(this.f1369s.m2714w());
        }
        C0380b.m2558a().m2561a(C0381c.FONT_READY);
    }

    private static int m2358b(C0305a c0305a, Uri uri, C0387i c0387i) {
        int c = c0305a.m2195c();
        GalleryItem galleryItem = new GalleryItem(Integer.valueOf(uri.getLastPathSegment()).intValue());
        int g = c0305a.m2202g();
        galleryItem.m2990a(g + 1);
        c0305a.m2189a(c, galleryItem);
        c0387i.a_().m427b((short) (g + 1));
        c0387i.a_().m428c((short) 1);
        return c;
    }

    private void ag() {
        boolean z = false;
        C0251k c0251k = new C0251k("log_in");
        C0289c d = C0294h.m1969d(this.f1371u);
        String a = d == null ? null : d.m1937a();
        boolean b = d == null ? false : d.m1938b();
        c0251k.m1680b("advertising_id", a);
        String str = "tracking_enabled";
        if (!b) {
            z = true;
        }
        c0251k.m1680b(str, String.valueOf(z));
        C0251k.m1673a(c0251k, this.f1371u, C0253n.MUST_HAVE);
        if (d != null) {
            C0300n.m2147j(this.f1371u, a);
            C0300n.m2111b(this.f1371u, b);
        }
    }

    private void m2360b(Context context) {
        String str;
        try {
            str = context.getPackageManager().getPackageInfo(getClass().getPackage().getName(), 0).versionName;
        } catch (Throwable e) {
            this.f1375y.m124a((short) 8, "Can't get version name", e);
            str = "n/a";
        }
        if (aw.f1162a) {
            str = "DEV";
        }
        this.f1370t = str;
        this.f1367q = new HashMap();
        this.f1367q.put("microedition.platform", Build.MODEL + "/Android " + VERSION.RELEASE);
        this.f1367q.put("MIDlet-Version", this.f1370t);
        this.f1367q.put("com.android.imei", C0317a.m2260a(context).m2262a().f786a);
        this.f1367q.put("android.useragent", C0294h.m1970d());
    }
}
