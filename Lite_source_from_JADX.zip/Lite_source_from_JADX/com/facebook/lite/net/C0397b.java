package com.facebook.lite.net;

import com.facebook.lite.p059m.C0387i;
import com.facebook.lite.p061h.C0345a;
import com.p008a.p009a.p010a.p012b.C0018j;
import com.p008a.p009a.p010a.p013c.C0013a;
import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p015g.C0023a;
import com.p008a.p009a.p010a.p016h.C0055g;
import com.p008a.p009a.p010a.p020j.C0065a;
import com.p008a.p009a.p010a.p022l.C0077f;
import com.p008a.p009a.p010a.p023m.C0114f;
import com.p008a.p009a.p010a.p023m.C0115e;
import com.p008a.p009a.p010a.p023m.C0116b;
import com.p008a.p009a.p010a.p023m.C0117c;
import com.p008a.p009a.p010a.p023m.p025b.C0101b;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedList;
import java.util.List;

/* renamed from: com.facebook.lite.net.b */
public abstract class C0397b extends C0013a implements C0396j {
    static final int[] f1566a;
    private final List f1567A;
    private final List f1568B;
    private int f1569C;
    private boolean f1570D;
    private long f1571E;
    private int f1572F;
    protected InputStream f1573d;
    protected byte f1574e;
    protected long f1575f;
    protected final C0022b f1576g;
    final C0387i f1577h;
    final C0403i f1578i;
    int f1579j;
    final Object f1580k;
    C0023a f1581l;
    final C0077f f1582m;
    final C0055g f1583n;
    final Object f1584o;
    final Object f1585p;
    final C0018j f1586q;
    private final C0117c f1587r;
    private boolean f1588s;
    private final Object f1589t;
    private final C0114f[] f1590u;
    private final int[] f1591v;
    private final Object f1592w;
    private int f1593x;
    private boolean f1594y;
    private int f1595z;

    protected abstract boolean m2773a(Thread thread);

    protected abstract boolean m2775b(int i);

    static {
        f1566a = new int[]{1, 2, 4, 8, 16, 32, 64};
    }

    protected C0397b(C0022b c0022b, C0077f c0077f, C0023a c0023a, C0403i c0403i, C0018j c0018j, C0345a c0345a, C0055g c0055g, C0387i c0387i) {
        this.f1574e = (byte) 1;
        this.f1579j = 0;
        this.f1580k = new Object();
        this.f1584o = new Object();
        this.f1585p = new Object();
        this.f1589t = new Object();
        this.f1590u = new C0114f[20];
        this.f1591v = new int[20];
        this.f1592w = new Object();
        this.f1593x = 0;
        this.f1595z = 1;
        this.f1567A = new LinkedList();
        this.f1568B = new LinkedList();
        this.f1571E = 0;
        this.f1576g = c0022b;
        this.f1582m = c0077f;
        this.f1578i = c0403i;
        this.f1581l = c0023a;
        this.f1586q = c0018j;
        this.f1583n = c0055g;
        this.f1577h = c0387i;
        m97a(c0345a);
        this.f1587r = new C0117c();
    }

    private static C0114f m2756b(C0114f c0114f) {
        short j = c0114f.m1124j();
        C0114f b = c0114f.m1114b(j);
        c0114f.m1115c(j + c0114f.m1128n());
        return b;
    }

    public static boolean m2752a(int i) {
        return (i == 39 || i == 32) ? false : true;
    }

    public final void m2769a() {
        m2767t();
        m2775b(3);
    }

    public final void m2774b() {
        if (m2766s()) {
            m2767t();
        }
        m2775b(6);
    }

    public final void m2771a(C0115e c0115e) {
        if (m2783j() != 6) {
            c0115e.m1118e();
            m2762e(new C0116b(c0115e.m1130p()));
        }
    }

    public final int m2782i() {
        return 6;
    }

    public static int m2755b(C0115e c0115e) {
        int n = c0115e.m1128n();
        C0397b.m2759c((C0114f) c0115e);
        int h = c0115e.m1122h();
        c0115e.m1115c(n);
        return 65535 & h;
    }

    public final boolean m2776c() {
        return m2783j() == 2;
    }

    public final void m2777d() {
        this.f1581l = new C0395a();
        m2775b(5);
        m2775b(6);
    }

    public final void m2770a(long j) {
        synchronized (this.f1585p) {
            this.f1571E = j;
            if (this.f1571E != 0) {
                for (C0114f c0114f : this.f1568B) {
                    C0397b.m2757c((C0115e) c0114f);
                    C0397b.m2761d(c0114f);
                    c0114f.m1132a(j);
                    c0114f.m1115c(0);
                    m2762e(c0114f);
                }
                this.f1568B.clear();
            }
            this.f1585p.notifyAll();
        }
    }

    public final void m2778e() {
        synchronized (this.f1585p) {
            this.f1570D = false;
            this.f1571E = 0;
            this.f1567A.clear();
            this.f1568B.clear();
            this.f1569C = 0;
            synchronized (this.f1592w) {
                for (int i = 0; i < 20; i++) {
                    this.f1590u[i] = null;
                }
                this.f1572F = 0;
                this.f1595z = 1;
                this.f1593x = 0;
            }
        }
    }

    public final void m2779f() {
        boolean c = m2776c();
        m2775b(5);
        if (!c || this.f1571E == 0) {
            m2775b(6);
            return;
        }
        C0115e c0116b = new C0116b(40);
        this.f1577h.m2655a((byte) 10, c0116b);
        c0116b.m1118e();
        m2762e(c0116b);
    }

    protected static byte m2757c(C0115e c0115e) {
        int n = c0115e.m1128n();
        c0115e.m1119e(2);
        byte g = c0115e.m1121g();
        c0115e.m1115c(n);
        return g;
    }

    private static long m2760d(C0115e c0115e) {
        C0397b.m2761d((C0114f) c0115e);
        long i = c0115e.m1123i();
        c0115e.m1115c(0);
        return i;
    }

    protected final void m2780g() {
        synchronized (this.f1589t) {
            this.f1588s = true;
        }
        this.f1575f = System.currentTimeMillis();
    }

    protected final synchronized C0114f m2768a(C0114f c0114f) {
        byte[] b;
        if (this.f1573d == null) {
            int i;
            if (this.f1582m.m601q() == null) {
                this.f1576g.m125a((short) 3, (short) 154);
                i = 16384;
            } else {
                i = this.f1582m.m601q().intValue();
            }
            try {
                this.f1573d = new C0101b(this.f1587r, i, this.f1582m);
            } catch (Exception e) {
                this.f1576g.m125a((short) 2, (short) 155);
                throw new IOException("LZMA2 decoder allocation failed. Probably not enough memory. Free Memory=" + this.f1582m.m600o());
            }
        }
        this.f1587r.m1181a(c0114f);
        b = this.f1582m.m599b(this.f1573d.available());
        this.f1573d.read(b);
        return new C0116b(b);
    }

    protected final boolean m2781h() {
        boolean z;
        synchronized (this.f1589t) {
            z = this.f1588s;
        }
        return z;
    }

    protected final int m2783j() {
        int i;
        synchronized (this.f1580k) {
            i = this.f1579j;
        }
        return i;
    }

    protected final C0115e m2784k() {
        synchronized (this.f1585p) {
            C0115e p;
            if (this.f1570D) {
                this.f1570D = false;
                this.f1569C = 0;
                p = m2764p();
                return p;
            } else if (m2786m()) {
                return null;
            } else if (m2787n()) {
                new StringBuilder("conn/ackwait/low:").append(C0397b.m2755b((C0115e) this.f1567A.get(0))).append("/high:").append(C0397b.m2755b((C0115e) this.f1567A.get(this.f1569C)));
                return null;
            } else {
                p = (C0115e) this.f1567A.get(this.f1569C);
                this.f1569C++;
                return p;
            }
        }
    }

    protected final boolean m2785l() {
        boolean z;
        synchronized (this.f1585p) {
            z = m2786m() && !this.f1570D;
        }
        return z;
    }

    protected final boolean m2786m() {
        boolean z;
        synchronized (this.f1585p) {
            z = this.f1569C >= this.f1567A.size();
        }
        return z;
    }

    protected final boolean m2787n() {
        synchronized (this.f1585p) {
            if (!m2765r() || m2786m()) {
                return false;
            }
            boolean z;
            if (C0065a.m409a(C0397b.m2755b((C0115e) this.f1567A.get(this.f1569C)), C0397b.m2755b((C0115e) this.f1567A.get(0))) < 0) {
                z = true;
            } else {
                z = false;
            }
            return z;
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected final boolean m2772a(com.p008a.p009a.p010a.p023m.C0114f r9, com.p008a.p009a.p010a.p022l.C0077f r10) {
        /*
        r8 = this;
        r7 = 62000; // 0xf230 float:8.688E-41 double:3.0632E-319;
        r0 = 0;
        r1 = r9.m1121g();
        r2 = 88;
        if (r1 != r2) goto L_0x001c;
    L_0x000c:
        r1 = r9.m1129o();
        if (r1 <= 0) goto L_0x0057;
    L_0x0012:
        r1 = com.facebook.lite.net.C0397b.m2756b(r9);
        r1 = r8.m2772a(r1, r10);
        r0 = r0 | r1;
        goto L_0x000c;
    L_0x001c:
        r2 = new java.lang.StringBuilder;
        r3 = 30;
        r2.<init>(r3);
        r3 = "conn/msgrecv:";
        r2 = r2.append(r3);
        r2 = r2.append(r1);
        r3 = " len:";
        r2 = r2.append(r3);
        r3 = r9.m1129o();
        r2.append(r3);
        r2 = r9.m1122h();
        r2 = r8.m2753a(r1, r2, r9);
        r3 = 53;
        if (r1 != r3) goto L_0x0051;
    L_0x0046:
        r3 = r9.m1122h();
        r3 = java.lang.Integer.valueOf(r3);
        r10.m598a(r3);
    L_0x0051:
        if (r2 == 0) goto L_0x0058;
    L_0x0053:
        r0 = r8.m2754a(r9, r1);
    L_0x0057:
        return r0;
    L_0x0058:
        r3 = r8.f1592w;
        monitor-enter(r3);
        r2 = r0;
    L_0x005c:
        r1 = r8.f1590u;	 Catch:{ all -> 0x00b6 }
        r1 = r1.length;	 Catch:{ all -> 0x00b6 }
        if (r2 >= r1) goto L_0x007d;
    L_0x0061:
        r1 = r8.f1590u;	 Catch:{ all -> 0x00b6 }
        r1 = r1[r2];	 Catch:{ all -> 0x00b6 }
        if (r1 == 0) goto L_0x007d;
    L_0x0067:
        r4 = r8.f1572F;	 Catch:{ all -> 0x00b6 }
        r5 = r1.m1113b();	 Catch:{ all -> 0x00b6 }
        r4 = r4 - r5;
        r8.f1572F = r4;	 Catch:{ all -> 0x00b6 }
        r4 = r8.f1591v;	 Catch:{ all -> 0x00b6 }
        r4 = r4[r2];	 Catch:{ all -> 0x00b6 }
        r1 = r8.m2754a(r1, r4);	 Catch:{ all -> 0x00b6 }
        r0 = r0 | r1;
        r1 = r2 + 1;
        r2 = r1;
        goto L_0x005c;
    L_0x007d:
        if (r2 == 0) goto L_0x00ab;
    L_0x007f:
        r1 = r8.f1590u;	 Catch:{ all -> 0x00b6 }
        r4 = r8.f1590u;	 Catch:{ all -> 0x00b6 }
        r5 = 0;
        r6 = r8.f1590u;	 Catch:{ all -> 0x00b6 }
        r6 = r6.length;	 Catch:{ all -> 0x00b6 }
        r6 = r6 - r2;
        java.lang.System.arraycopy(r1, r2, r4, r5, r6);	 Catch:{ all -> 0x00b6 }
        r1 = r8.f1591v;	 Catch:{ all -> 0x00b6 }
        r4 = r8.f1591v;	 Catch:{ all -> 0x00b6 }
        r5 = 0;
        r6 = r8.f1591v;	 Catch:{ all -> 0x00b6 }
        r6 = r6.length;	 Catch:{ all -> 0x00b6 }
        r6 = r6 - r2;
        java.lang.System.arraycopy(r1, r2, r4, r5, r6);	 Catch:{ all -> 0x00b6 }
        r1 = r8.f1590u;	 Catch:{ all -> 0x00b6 }
        r4 = r1.length;	 Catch:{ all -> 0x00b6 }
        r1 = r4 - r2;
    L_0x009c:
        if (r1 >= r4) goto L_0x00a6;
    L_0x009e:
        r5 = r8.f1590u;	 Catch:{ all -> 0x00b6 }
        r6 = 0;
        r5[r1] = r6;	 Catch:{ all -> 0x00b6 }
        r1 = r1 + 1;
        goto L_0x009c;
    L_0x00a6:
        r1 = r8.f1593x;	 Catch:{ all -> 0x00b6 }
        r1 = r1 + r2;
        r8.f1593x = r1;	 Catch:{ all -> 0x00b6 }
    L_0x00ab:
        r1 = r8.f1593x;	 Catch:{ all -> 0x00b6 }
        if (r1 < r7) goto L_0x00b4;
    L_0x00af:
        r1 = r8.f1593x;	 Catch:{ all -> 0x00b6 }
        r1 = r1 - r7;
        r8.f1593x = r1;	 Catch:{ all -> 0x00b6 }
    L_0x00b4:
        monitor-exit(r3);	 Catch:{ all -> 0x00b6 }
        goto L_0x0057;
    L_0x00b6:
        r0 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x00b6 }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.net.b.a(com.a.a.a.m.f, com.a.a.a.l.f):boolean");
    }

    private C0115e m2764p() {
        C0115e c0116b = new C0116b(40);
        this.f1577h.m2655a((byte) 39, c0116b);
        c0116b.m1118e();
        m2763f(c0116b);
        return c0116b;
    }

    protected final void m2788o() {
        synchronized (this.f1585p) {
            if (this.f1571E != 0) {
                this.f1570D = true;
            }
            this.f1585p.notifyAll();
        }
    }

    private static void m2759c(C0114f c0114f) {
        C0397b.m2761d(c0114f);
        c0114f.m1123i();
    }

    private static void m2761d(C0114f c0114f) {
        c0114f.m1124j();
        if (c0114f.m1121g() == 1) {
            c0114f.m1122h();
            c0114f.m1123i();
            c0114f.m1123i();
            c0114f.m1123i();
            c0114f.m1124j();
        }
    }

    private void m2758c(int i) {
        synchronized (this.f1585p) {
            boolean n = m2787n();
            while (!this.f1567A.isEmpty() && C0065a.m411c(i, C0397b.m2755b((C0115e) this.f1567A.get(0)))) {
                C0115e c0115e = (C0115e) this.f1567A.remove(0);
                if (this.f1569C > 0) {
                    this.f1569C--;
                }
                new StringBuilder("conn/acked:").append(i).append("/remove:").append(C0397b.m2755b(c0115e)).append("/qsize:").append(this.f1567A.size());
            }
            if (n) {
                this.f1585p.notifyAll();
            }
        }
    }

    private void m2762e(C0115e c0115e) {
        synchronized (this.f1585p) {
            byte c = C0397b.m2757c(c0115e);
            long d = C0397b.m2760d(c0115e);
            if (this.f1594y) {
                new StringBuilder("conn/add/ignore/logout in queue/msgCode: ").append(c).append(" sessionId: ").append(d);
                return;
            }
            if (c == 10) {
                this.f1594y = true;
            }
            if (this.f1571E != d) {
                new StringBuilder("conn/add/ignore/invalid session id/msgCode: ").append(c).append(" sessionId: ").append(d);
                this.f1576g.m126a((short) 3, (short) 286, "msgCode=" + c + ", sessionId=" + d);
            } else if (this.f1571E != 0 || c == 1) {
                m2763f(c0115e);
                this.f1567A.add(c0115e);
                this.f1585p.notifyAll();
            } else {
                new StringBuilder("conn/add/no session/msgCode: ").append(c).append(" sessionId: ").append(d);
                this.f1568B.add(c0115e);
            }
        }
    }

    private boolean m2754a(C0114f c0114f, int i) {
        if (!this.f1577h.m2696e(i)) {
            return false;
        }
        this.f1581l.m130a(i, c0114f);
        return true;
    }

    private boolean m2765r() {
        boolean z;
        synchronized (this.f1585p) {
            z = this.f1569C > 0;
        }
        return z;
    }

    private boolean m2766s() {
        boolean z;
        synchronized (this.f1580k) {
            z = this.f1579j == 5;
        }
        return z;
    }

    private int m2751a(boolean z) {
        int i;
        synchronized (this.f1592w) {
            if (z) {
                if (this.f1595z >= 62000) {
                    this.f1595z = 1;
                }
                i = this.f1595z;
                this.f1595z = i + 1;
            } else {
                i = 0;
            }
            i |= (this.f1593x << 16) & -65536;
        }
        return i;
    }

    private void m2763f(C0115e c0115e) {
        int n = c0115e.m1128n();
        c0115e.m1135a((short) (c0115e.m1129o() - 2));
        boolean a = C0397b.m2752a(c0115e.m1121g());
        c0115e.m1115c(n);
        C0397b.m2759c((C0114f) c0115e);
        c0115e.m1141d(m2751a(a));
        c0115e.m1115c(n);
    }

    private boolean m2753a(int i, int i2, C0114f c0114f) {
        int i3 = i2 & 65535;
        m2758c((i2 >> 16) & 65535);
        synchronized (this.f1592w) {
            int i4 = this.f1593x == 62000 ? 1 : this.f1593x + 1;
            if (i3 == 0) {
                return true;
            } else if (i4 == i3) {
                this.f1590u[0] = c0114f;
                this.f1591v[0] = i;
                this.f1572F += c0114f.m1113b();
                return false;
            } else if (C0065a.m410b(i4, i3)) {
                return false;
            } else {
                int a = C0065a.m409a(i4, i3);
                if (a >= 20 || this.f1572F + c0114f.m1113b() > 70000) {
                    m2788o();
                } else if (a >= 0 && this.f1590u[a] == null) {
                    this.f1590u[a] = c0114f;
                    this.f1591v[a] = i;
                    this.f1572F += c0114f.m1113b();
                }
                return false;
            }
        }
    }

    private void m2767t() {
        synchronized (this.f1584o) {
            synchronized (this.f1585p) {
                boolean isEmpty = this.f1567A.isEmpty();
            }
            if (!isEmpty) {
                try {
                    this.f1584o.wait(1000);
                } catch (InterruptedException e) {
                }
            }
        }
    }
}
