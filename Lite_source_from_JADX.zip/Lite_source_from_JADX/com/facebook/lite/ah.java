package com.facebook.lite;

import android.graphics.Bitmap;
import com.p008a.p009a.p010a.p022l.C0076e;

final class ah implements Runnable {
    final /* synthetic */ Bitmap f1147a;
    final /* synthetic */ C0076e f1148b;
    final /* synthetic */ int f1149c;
    final /* synthetic */ byte f1150d;
    final /* synthetic */ boolean f1151e;
    final /* synthetic */ boolean f1152f;
    final /* synthetic */ MainActivity f1153g;

    ah(MainActivity mainActivity, Bitmap bitmap, C0076e c0076e, int i, byte b, boolean z, boolean z2) {
        this.f1153g = mainActivity;
        this.f1147a = bitmap;
        this.f1148b = c0076e;
        this.f1149c = i;
        this.f1150d = b;
        this.f1151e = z;
        this.f1152f = z2;
    }

    public final void run() {
        this.f1153g.f985q.m3251a(this.f1147a, this.f1148b.m593d(), this.f1149c, this.f1150d, this.f1151e);
        if (!this.f1152f) {
            this.f1153g.f985q.m3253b();
        }
        this.f1153g.f985q.m3252a(true);
        this.f1153g.m1777a(this.f1153g.f985q, true);
        this.f1153g.f985q.setScaleListener(new ag(this));
    }
}
