package com.facebook.lite.widget;

final class ai implements Runnable {
    private float f2040a;
    private long f2041b;
    private boolean f2042c;
    private boolean f2043d;
    private float f2044e;
    private float f2045f;
    private final PhotoView f2046g;

    public ai(PhotoView photoView) {
        this.f2046g = photoView;
    }

    public final void run() {
        if (!this.f2043d) {
            if (this.f2040a != this.f2044e) {
                long currentTimeMillis = System.currentTimeMillis();
                float f = ((float) (this.f2041b != -1 ? currentTimeMillis - this.f2041b : 0)) * this.f2045f;
                if ((this.f2040a < this.f2044e && this.f2040a + f > this.f2044e) || (this.f2040a > this.f2044e && this.f2040a + f < this.f2044e)) {
                    f = this.f2044e - this.f2040a;
                }
                this.f2046g.m3249a(f, false);
                this.f2040a = f + this.f2040a;
                if (this.f2040a == this.f2044e) {
                    m3274a();
                }
                this.f2041b = currentTimeMillis;
            }
            if (!this.f2043d) {
                this.f2046g.post(this);
            }
        }
    }

    public final void m3275a(float f) {
        if (this.f2042c) {
            this.f2044e += f;
        } else {
            this.f2044e = f;
            this.f2040a = 0.0f;
            this.f2041b = -1;
            this.f2046g.post(this);
        }
        this.f2045f = this.f2044e / 300.0f;
        this.f2043d = false;
        this.f2042c = true;
    }

    public final void m3274a() {
        this.f2042c = false;
        this.f2043d = true;
        this.f2046g.f1975Q = (float) Math.round(this.f2046g.f1975Q);
        this.f2046g.m3237b(true);
        this.f2046g.requestLayout();
        this.f2046g.invalidate();
    }
}
