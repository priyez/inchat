package com.facebook.lite.p062j;

/* renamed from: com.facebook.lite.j.h */
final class C0361h implements C0358i {
    final /* synthetic */ C0366n f1415a;

    private C0361h(C0366n c0366n) {
        this.f1415a = c0366n;
    }

    public final String m2519a(StringBuilder stringBuilder) {
        stringBuilder.append("FPS: ");
        stringBuilder.append(Math.round(1000.0d / ((double) this.f1415a.f1426c.m2526d())));
        return stringBuilder.toString();
    }
}
