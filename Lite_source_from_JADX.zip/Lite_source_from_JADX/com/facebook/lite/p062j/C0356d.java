package com.facebook.lite.p062j;

/* renamed from: com.facebook.lite.j.d */
public enum C0356d {
    DISCARDED("-"),
    NORMAL(""),
    OFFLINE("*");
    
    private final String f1406d;

    private C0356d(String str) {
        this.f1406d = str;
    }

    public static int m2503a() {
        return C0354b.f1398a;
    }

    public final String m2507b() {
        return "M" + m2506c();
    }

    private String m2506c() {
        return this.f1406d;
    }

    private String m2505a(short s) {
        switch (s) {
            case (short) 1:
                return "EX" + m2506c();
            case (short) 2:
                return "E" + m2506c();
            case (short) 3:
                return "W" + m2506c();
            case (short) 4:
                return "I" + m2506c();
            case (short) 5:
                return "D" + m2506c();
            default:
                return "X" + m2506c();
        }
    }
}
