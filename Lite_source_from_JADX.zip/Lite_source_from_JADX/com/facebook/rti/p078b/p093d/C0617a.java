package com.facebook.rti.p078b.p093d;

import android.text.TextUtils;
import android.util.Pair;

/* renamed from: com.facebook.rti.b.d.a */
public final class C0617a extends Pair {
    public static final C0617a f2527a;

    static {
        f2527a = new C0617a("", "");
    }

    private C0617a(String str, String str2) {
        super(str, str2);
    }

    public final String m3536a() {
        return (String) this.first;
    }

    public final String m3537b() {
        return (String) this.second;
    }

    public static C0617a m3535a(String str, String str2) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2)) {
            return f2527a;
        }
        return new C0617a(str, str2);
    }
}
