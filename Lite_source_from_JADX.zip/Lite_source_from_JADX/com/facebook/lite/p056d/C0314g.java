package com.facebook.lite.p056d;

/* renamed from: com.facebook.lite.d.g */
final class C0314g {
    private static final C0315h f1233a;

    static {
        f1233a = new C0315h();
    }
}
