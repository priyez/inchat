package com.facebook.lite.widget;

final class ah {
    public static final int f2036a;
    public static final int f2037b;
    public static final int f2038c;
    private static final /* synthetic */ int[] f2039d;

    static {
        f2036a = 1;
        f2037b = 2;
        f2038c = 3;
        f2039d = new int[]{f2036a, f2037b, f2038c};
    }

    public static int[] m3273a() {
        return (int[]) f2039d.clone();
    }
}
