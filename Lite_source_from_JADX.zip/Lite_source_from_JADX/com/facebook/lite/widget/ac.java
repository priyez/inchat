package com.facebook.lite.widget;

import android.text.method.PasswordTransformationMethod;
import android.view.View;

final class ac extends PasswordTransformationMethod {
    private ac() {
    }

    public final CharSequence getTransformation(CharSequence charSequence, View view) {
        return new ab(this, charSequence);
    }
}
