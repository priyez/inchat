package com.facebook.lite.p053b;

/* renamed from: com.facebook.lite.b.c */
public final class C0289c {
    private final String f1167a;
    private final boolean f1168b;

    public C0289c(String str, boolean z) {
        this.f1167a = str;
        this.f1168b = z;
    }

    public final String m1937a() {
        return this.f1167a;
    }

    public final boolean m1938b() {
        return this.f1168b;
    }
}
