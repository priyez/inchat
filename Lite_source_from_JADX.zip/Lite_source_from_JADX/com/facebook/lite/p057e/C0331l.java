package com.facebook.lite.p057e;

/* renamed from: com.facebook.lite.e.l */
public final class C0331l extends IllegalArgumentException {
    public C0331l(String str) {
        super(str);
    }
}
