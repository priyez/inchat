package com.facebook.lite.widget;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import com.facebook.lite.ap;
import com.facebook.lite.as;

public final class ae extends Dialog {
    private Button f2028a;
    private final Context f2029b;
    private Button f2030c;
    private TextView f2031d;
    private Button f2032e;
    private TextView f2033f;

    public ae(Context context, int i) {
        super(context, i);
        this.f2029b = context;
        m3267a();
    }

    public final void m3269a(String str, OnClickListener onClickListener) {
        this.f2030c.setVisibility(8);
        this.f2032e.setVisibility(8);
        this.f2028a.setVisibility(0);
        this.f2028a.setText(str);
        this.f2028a.setOnClickListener(onClickListener);
    }

    public final void m3271b(String str, OnClickListener onClickListener) {
        this.f2030c.setText(str);
        this.f2030c.setOnClickListener(onClickListener);
    }

    public final void m3268a(String str) {
        this.f2031d.setText(str);
    }

    public final void m3272c(String str, OnClickListener onClickListener) {
        this.f2032e.setText(str);
        this.f2032e.setOnClickListener(onClickListener);
    }

    public final void m3270b(String str) {
        this.f2033f.setText(str);
    }

    private void m3267a() {
        View inflate = View.inflate(this.f2029b, ap.custom_dialog, null);
        this.f2033f = (TextView) inflate.findViewById(as.dialog_title);
        this.f2031d = (TextView) inflate.findViewById(as.dialog_message);
        this.f2030c = (Button) inflate.findViewById(as.dialog_left_button);
        this.f2032e = (Button) inflate.findViewById(as.dialog_right_button);
        this.f2028a = (Button) inflate.findViewById(as.dialog_central_button);
        setContentView(inflate);
    }
}
