package com.facebook.lite.autoupdate;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.facebook.lite.ClientApplication;

public class PersistentUpdatingBroadcastReceiver extends BroadcastReceiver {
    private static final String f1160a;

    static {
        f1160a = PersistentUpdatingBroadcastReceiver.class.getSimpleName();
    }

    public void onReceive(Context context, Intent intent) {
        if (context == null) {
            Log.e(f1160a, "autoupdate/fail to re-schedule updating service. context null.");
        } else if (intent == null) {
            Log.e(f1160a, "autoupdate/fail to re-schedule updating service. intent null.");
        } else {
            Context applicationContext = context.getApplicationContext();
            if ("android.intent.action.BOOT_COMPLETED".equals(intent.getAction()) || ("android.intent.action.PACKAGE_REPLACED".equals(intent.getAction()) && intent.getDataString().contains(applicationContext.getPackageName()))) {
                Log.i(f1160a, "autoupdate/re-schedule updating service.");
                ClientApplication.m1691c().m2390V();
            }
        }
    }
}
