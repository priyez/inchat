package com.facebook.lite.photo;

import android.widget.ImageView;

/* renamed from: com.facebook.lite.photo.g */
final class C0438g {
    ImageView f1764a;
    ImageView f1765b;

    private C0438g() {
    }
}
