package com.facebook.lite.widget;

final class ak implements Runnable {
    private float f2047a;
    private float f2048b;
    private final PhotoView f2049c;
    private boolean f2050d;
    private float f2051e;
    private long f2052f;
    private boolean f2053g;
    private float f2054h;
    private float f2055i;
    private boolean f2056j;

    public ak(PhotoView photoView) {
        this.f2049c = photoView;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void run() {
        /*
        r4 = this;
        r0 = r4.f2053g;
        if (r0 == 0) goto L_0x0005;
    L_0x0004:
        return;
    L_0x0005:
        r0 = java.lang.System.currentTimeMillis();
        r2 = r4.f2052f;
        r0 = r0 - r2;
        r2 = r4.f2051e;
        r3 = r4.f2055i;
        r0 = (float) r0;
        r0 = r0 * r3;
        r0 = r0 + r2;
        r1 = r4.f2049c;
        r2 = r4.f2047a;
        r3 = r4.f2048b;
        r1.m3228a(r0, r2, r3, true);
        r1 = r4.f2054h;
        r1 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1));
        if (r1 == 0) goto L_0x002d;
    L_0x0022:
        r1 = r4.f2056j;
        r2 = r4.f2054h;
        r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
        if (r0 <= 0) goto L_0x0045;
    L_0x002a:
        r0 = 1;
    L_0x002b:
        if (r1 != r0) goto L_0x003b;
    L_0x002d:
        r0 = r4.f2049c;
        r1 = r4.f2054h;
        r2 = r4.f2047a;
        r3 = r4.f2048b;
        r0.m3228a(r1, r2, r3, true);
        r4.m3276a();
    L_0x003b:
        r0 = r4.f2053g;
        if (r0 != 0) goto L_0x0004;
    L_0x003f:
        r0 = r4.f2049c;
        r0.post(r4);
        goto L_0x0004;
    L_0x0045:
        r0 = 0;
        goto L_0x002b;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.widget.ak.run():void");
    }

    public final boolean m3277a(float f, float f2, float f3, float f4) {
        if (this.f2050d) {
            return false;
        }
        this.f2047a = f3;
        this.f2048b = f4;
        this.f2054h = f2;
        this.f2052f = System.currentTimeMillis();
        this.f2051e = f;
        this.f2056j = this.f2054h > this.f2051e;
        this.f2055i = (this.f2054h - this.f2051e) / 200.0f;
        this.f2050d = true;
        this.f2053g = false;
        this.f2049c.post(this);
        return true;
    }

    public final void m3276a() {
        this.f2050d = false;
        this.f2053g = true;
    }
}
