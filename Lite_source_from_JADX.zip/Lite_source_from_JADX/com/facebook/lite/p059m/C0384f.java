package com.facebook.lite.p059m;

import android.widget.Toast;
import com.facebook.lite.ClientApplication;

/* renamed from: com.facebook.lite.m.f */
final class C0384f implements Runnable {
    final /* synthetic */ String f1478a;
    final /* synthetic */ boolean f1479b;
    final /* synthetic */ C0387i f1480c;

    C0384f(C0387i c0387i, String str, boolean z) {
        this.f1480c = c0387i;
        this.f1478a = str;
        this.f1479b = z;
    }

    public final void run() {
        Toast.makeText(ClientApplication.m1692d(), this.f1478a, this.f1479b ? 1 : 0).show();
    }
}
