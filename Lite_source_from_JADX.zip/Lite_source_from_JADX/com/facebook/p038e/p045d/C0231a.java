package com.facebook.p038e.p045d;

import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;

/* renamed from: com.facebook.e.d.a */
public class C0231a {
    private static final String f872a;
    private double f873b;
    private final JSONObject f874c;

    static {
        f872a = C0231a.class.getSimpleName();
    }

    public C0231a() {
        this.f874c = new JSONObject();
        this.f873b = 0.0d;
    }

    public final void m1581a(String str) {
        try {
            if (!this.f874c.has("errors")) {
                this.f874c.put("errors", new JSONArray());
            }
            this.f874c.getJSONArray("errors").put(str);
        } catch (Throwable e) {
            Log.e(f872a, "batteryusageinfo/fail to parse json for error info ", e);
        }
    }

    public final JSONObject m1579a() {
        return this.f874c;
    }

    public final void m1583a(String str, JSONObject jSONObject) {
        try {
            this.f874c.put(str, jSONObject);
        } catch (Throwable e) {
            Log.e(f872a, "batteryusageinfo/fail to put json object to battery usage info", e);
        }
    }

    public final void m1582a(String str, double d) {
        try {
            this.f874c.put(str, d);
        } catch (Throwable e) {
            Log.e(f872a, "batteryusageinfo/fail to put double value to battery usage info", e);
        }
    }

    public final void m1580a(double d) {
        this.f873b = d;
        m1582a("lite_percent", d);
    }
}
