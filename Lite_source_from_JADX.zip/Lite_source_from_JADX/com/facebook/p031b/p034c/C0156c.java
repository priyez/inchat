package com.facebook.p031b.p034c;

import java.io.OutputStream;

/* renamed from: com.facebook.b.c.c */
public interface C0156c {
    void m1341a(OutputStream outputStream);
}
