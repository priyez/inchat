package com.facebook.lite.p056d;

import android.content.Context;

/* renamed from: com.facebook.lite.d.d */
public interface C0308d {
    C0308d m2211a(Context context, String str);

    String m2212a();
}
