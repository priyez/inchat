package com.facebook.lite;

/* renamed from: com.facebook.lite.k */
public final class C0370k {
    private final String f1436a;
    private final String f1437b;

    public C0370k(String str, String str2) {
        this.f1436a = str;
        this.f1437b = str2;
    }

    public final String m2543a() {
        return this.f1436a;
    }

    public final String m2544b() {
        return this.f1437b;
    }
}
