package com.facebook.lite.p064l;

import android.app.AlertDialog;
import android.view.View;
import android.view.View.OnFocusChangeListener;

/* renamed from: com.facebook.lite.l.e */
final class C0375e implements OnFocusChangeListener {
    final /* synthetic */ AlertDialog f1446a;
    final /* synthetic */ C0377g f1447b;

    C0375e(C0377g c0377g, AlertDialog alertDialog) {
        this.f1447b = c0377g;
        this.f1446a = alertDialog;
    }

    public final void onFocusChange(View view, boolean z) {
        if (z) {
            this.f1446a.getWindow().setSoftInputMode(5);
        } else {
            this.f1446a.getWindow().setSoftInputMode(2);
        }
    }
}
