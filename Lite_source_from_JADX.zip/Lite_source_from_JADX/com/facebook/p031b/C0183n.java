package com.facebook.p031b;

import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import com.facebook.p031b.p034c.C0162i;

/* renamed from: com.facebook.b.n */
final class C0183n extends Thread {
    final /* synthetic */ C0184o f673a;
    private Throwable f674b;
    private C0173d f675c;
    private final C0182m[] f676d;

    public C0183n(C0184o c0184o, C0173d c0173d) {
        this(c0184o, new C0182m[0]);
        this.f675c = c0173d;
    }

    public C0183n(C0184o c0184o, C0182m... c0182mArr) {
        this.f673a = c0184o;
        this.f674b = null;
        this.f676d = c0182mArr;
    }

    public final void run() {
        WakeLock wakeLock = null;
        try {
            wakeLock = m1393b();
            if (this.f675c != null) {
                this.f673a.m1452a(this.f673a.f698o, this.f675c);
            } else {
                this.f673a.m1453a(this.f673a.f698o, this.f676d);
            }
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
        } catch (Throwable th) {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
        }
    }

    public final Throwable m1394a() {
        return this.f674b;
    }

    private WakeLock m1393b() {
        if (!new C0162i(this.f673a.f698o).m1352a("android.permission.WAKE_LOCK")) {
            return null;
        }
        WakeLock newWakeLock = ((PowerManager) this.f673a.f698o.getSystemService("power")).newWakeLock(1, "ACRA wakelock");
        newWakeLock.setReferenceCounted(false);
        newWakeLock.acquire();
        return newWakeLock;
    }
}
