package com.facebook.lite.notification;

import android.content.Context;
import android.os.Build.VERSION;
import android.util.Log;
import com.facebook.lite.aw;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p053b.C0302p;
import com.facebook.p038e.C0251k;
import com.google.android.gcm.C0751b;
import com.p008a.p009a.p010a.p012b.C0016g;

/* renamed from: com.facebook.lite.notification.d */
public final class C0415d {
    private static final String f1693a;
    private static C0016g f1694b;

    static {
        f1693a = C0415d.class.getSimpleName();
    }

    private C0415d() {
    }

    public static C0016g m2918a() {
        return f1694b;
    }

    public static void m2919a(Context context) {
        if (!aw.f1163b) {
            C0251k c0251k = new C0251k("ema_register_push");
            if (C0300n.m2084L(context)) {
                c0251k.m1681b("push_disabled", false);
                c0251k.m1681b("forced_to_register", false);
                if (VERSION.SDK_INT < 8) {
                    c0251k.m1679b("unsupported_android_version", (long) VERSION.SDK_INT);
                    C0415d.m2921a(c0251k, context);
                    Log.e(f1693a, "push/device api level must be 8 or greater to support push notifications.");
                    return;
                }
                c0251k.m1680b("unsupported_android_version", "n/a");
                try {
                    C0751b.m3994a(context);
                    C0751b.m4000b(context);
                    c0251k.m1681b("missing_play_services", false);
                    String g = C0751b.m4006g(context);
                    if (C0415d.m2922a(context, g)) {
                        new Thread(new C0414c(context, g)).start();
                        return;
                    }
                    C0751b.m3998a(context, "15057814354");
                    return;
                } catch (UnsupportedOperationException e) {
                    c0251k.m1681b("missing_play_services", true);
                    C0415d.m2921a(c0251k, context);
                    throw e;
                }
            }
            c0251k.m1681b("push_disabled", true);
            C0415d.m2921a(c0251k, context);
        }
    }

    public static boolean m2923a(Context context, String str, String str2, String str3) {
        if (f1694b != null) {
            Log.i(f1693a, "push/registering device (token = " + str + ", device id = " + str2 + ", push channel = " + str3 + ") on server");
            f1694b.m107a(str, str2, str3);
            String a = C0294h.m1953a(context);
            if (a != null) {
                C0300n.m2123d(context, a);
            }
            int c = C0294h.m1967c(context);
            if (c > 0) {
                C0300n.m2093a(context, c);
            }
            C0300n.m2144i(context, System.currentTimeMillis());
            C0751b.m3997a(context, true);
            return true;
        }
        Log.i(f1693a, "push/registering device on server failed");
        C0751b.m3997a(context, false);
        return false;
    }

    public static void m2920a(C0016g c0016g) {
        f1694b = c0016g;
    }

    public static void m2924b(Context context) {
        Log.i(f1693a, "push/unregistering device");
        if (f1694b != null) {
            f1694b.m108b(null);
        }
        C0751b.m3997a(context, false);
    }

    private static boolean m2922a(Context context, String str) {
        if (C0302p.m2177b((CharSequence) str) || C0294h.m1983m(context) || C0294h.m1982l(context)) {
            return false;
        }
        long currentTimeMillis = System.currentTimeMillis();
        long B = C0300n.m2074B(context);
        long A = C0300n.m2073A(context);
        if (currentTimeMillis - B <= 172800000 || currentTimeMillis - A <= 43200000) {
            return true;
        }
        String.format("push/more than %ds since last registration %d, and %ds since last push received %d.", new Object[]{Long.valueOf((currentTimeMillis / 1000) - 172800), Long.valueOf(B), Long.valueOf((currentTimeMillis / 1000) - 43200), Long.valueOf(A)});
        return false;
    }

    private static void m2921a(C0251k c0251k, Context context) {
        C0251k.m1672a(c0251k, context);
    }
}
