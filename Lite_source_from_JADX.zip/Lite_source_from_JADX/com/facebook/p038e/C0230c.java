package com.facebook.p038e;

/* renamed from: com.facebook.e.c */
enum C0230c {
    SERVICE_DISABLED,
    SERVICE_ENABLED,
    SERVICE_INVALID,
    SERVICE_MISSING
}
