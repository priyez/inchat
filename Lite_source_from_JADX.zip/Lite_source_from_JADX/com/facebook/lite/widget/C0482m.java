package com.facebook.lite.widget;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

/* renamed from: com.facebook.lite.widget.m */
final class C0482m implements OnTouchListener {
    final /* synthetic */ FbVideoView f2098a;

    C0482m(FbVideoView fbVideoView) {
        this.f2098a = fbVideoView;
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        this.f2098a.f1897a.onTouchEvent(motionEvent);
        return false;
    }
}
