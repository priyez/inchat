package com.facebook.lite.widget;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

/* renamed from: com.facebook.lite.widget.u */
final class C0488u implements OnTouchListener {
    final /* synthetic */ InlineTextBox f2107a;

    C0488u(InlineTextBox inlineTextBox) {
        this.f2107a = inlineTextBox;
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        return true;
    }
}
