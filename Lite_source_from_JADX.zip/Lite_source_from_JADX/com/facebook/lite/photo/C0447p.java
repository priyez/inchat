package com.facebook.lite.photo;

import android.view.View;
import android.view.View.OnClickListener;

/* renamed from: com.facebook.lite.photo.p */
final class C0447p implements OnClickListener {
    final /* synthetic */ PreviewActivity f1790a;

    C0447p(PreviewActivity previewActivity) {
        this.f1790a = previewActivity;
    }

    public final void onClick(View view) {
        this.f1790a.f1754e = (this.f1790a.f1754e - 90) % 360;
        new C0449r(this.f1790a).execute(new Void[0]);
    }
}
