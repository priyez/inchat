package com.facebook.lite;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore.Images.Media;
import android.util.Log;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p055c.C0305a;
import com.facebook.lite.p059m.C0387i;
import com.facebook.lite.photo.C0444m;
import com.facebook.lite.photo.GalleryItem;
import com.facebook.p038e.C0251k;
import com.facebook.p038e.C0253n;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.List;

/* renamed from: com.facebook.lite.d */
public final class C0316d extends AsyncTask {
    final boolean f1247a;
    Uri f1248b;
    final /* synthetic */ C0342f f1249c;
    private final C0251k f1250d;
    private final C0387i f1251e;
    private final Context f1252f;
    private final C0332e f1253g;

    protected final /* synthetic */ Object doInBackground(Object[] objArr) {
        return m2252a();
    }

    protected final /* synthetic */ void onPostExecute(Object obj) {
        m2251a((byte[]) obj);
    }

    public C0316d(C0342f c0342f, C0251k c0251k, Uri uri, boolean z, C0387i c0387i, Context context, C0332e c0332e) {
        this.f1249c = c0342f;
        this.f1250d = c0251k;
        this.f1248b = uri;
        this.f1247a = z;
        this.f1251e = c0387i;
        this.f1252f = context;
        this.f1253g = c0332e;
    }

    private byte[] m2252a() {
        if (this.f1247a) {
            int size;
            int i;
            C0305a F = this.f1251e.m2631F();
            List e = F.m2199e();
            size = e.size() < 3 ? e.size() : 3;
            String[] strArr = new String[size];
            int[] iArr = new int[size];
            for (i = 0; i < size; i++) {
                GalleryItem galleryItem = (GalleryItem) e.get(i);
                strArr[i] = C0444m.m3048a(this.f1252f, Uri.withAppendedPath(Media.EXTERNAL_CONTENT_URI, Integer.toString(galleryItem.m2991b())));
                iArr[i] = galleryItem.m2995d();
            }
            List f = F.m2201f();
            for (i = 0; i < size; i++) {
                byte[] a = C0444m.m3057a(this.f1252f, this.f1251e.m2648W(), strArr[i], this.f1250d, iArr[i]);
                try {
                    int[] a2 = this.f1251e.m2682a(a);
                    this.f1251e.m2714w().m619a(((Integer) f.get(i)).intValue(), a, a2[0], a2[1]);
                } catch (Throwable e2) {
                    Log.e(C0342f.f1331b, "camera/unable to get image size.", e2);
                }
            }
        }
        this.f1248b = C0444m.m3062c(this.f1252f, this.f1248b);
        Bitmap a3 = C0444m.m3038a(this.f1252f, this.f1252f.getContentResolver(), this.f1248b, C0300n.m2120d(this.f1252f), C0300n.m2102b(this.f1252f));
        if (a3 == null) {
            Log.e(C0342f.f1331b, "camera/unable to read photo.");
            this.f1250d.m1681b("decoding_success", false);
            return null;
        }
        this.f1250d.m1681b("decoding_success", true);
        a3 = C0444m.m3043a(C0444m.m3048a(this.f1252f, this.f1248b), a3, this.f1250d, 0);
        size = this.f1251e.m2648W();
        this.f1250d.m1679b("photo_quality", (long) size);
        OutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        a3.compress(CompressFormat.JPEG, size, byteArrayOutputStream);
        byte[] toByteArray = byteArrayOutputStream.toByteArray();
        try {
            byteArrayOutputStream.close();
            return toByteArray;
        } catch (Throwable e3) {
            Log.e(C0342f.f1331b, "camera/unable to close photo byte stream.", e3);
            return toByteArray;
        }
    }

    private void m2251a(byte[] bArr) {
        if (bArr == null) {
            Log.e(C0342f.f1331b, "camera/unable to read photo.");
            this.f1250d.m1681b("read_success", false);
            C0251k.m1673a(this.f1250d, this.f1252f, C0253n.MUST_HAVE);
            return;
        }
        this.f1250d.m1681b("read_success", true);
        this.f1253g.m2313a(this.f1248b);
        try {
            C0305a F = this.f1251e.m2631F();
            int e = this.f1249c.f1352G;
            if (this.f1249c.f1373w || this.f1247a) {
                e = C0342f.m2358b(F, this.f1248b, this.f1251e);
                if (this.f1247a) {
                    this.f1251e.a_().m425b();
                }
            }
            int[] a = this.f1251e.m2682a(bArr);
            this.f1251e.m2714w().m619a(e, bArr, a[0], a[1]);
            this.f1249c.f1373w = false;
            if (this.f1247a) {
                String[] strArr = new String[]{"c", Integer.toString(e)};
                this.f1250d.m1681b("build_params_success", true);
                this.f1251e.m2639N().m180a(strArr);
            } else {
                this.f1251e.m2639N().m168a(C0342f.f1337h);
                this.f1249c.f1373w = false;
                this.f1250d.m1681b("handling_succeeded", true);
                C0251k.m1672a(this.f1250d, this.f1252f);
            }
        } catch (Throwable e2) {
            this.f1250d.m1681b("build_params_success", false);
            Log.e(C0342f.f1331b, "camera/unable to build params.", e2);
        }
        C0251k.m1673a(this.f1250d, this.f1252f, C0253n.MUST_HAVE);
    }
}
