package com.facebook.rti.p078b.p102i;

import com.facebook.rti.p046a.p047b.C0516d;
import com.facebook.rti.p046a.p076h.C0532b;
import com.facebook.rti.p078b.p080b.p084d.C0589k;
import p006c.p007a.C0003a;

/* renamed from: com.facebook.rti.b.i.c */
public final class C0725c implements C0003a {
    private final C0724b f3108a;

    public final /* synthetic */ Object m3926b() {
        return m3925a();
    }

    public C0725c(C0516d c0516d, C0589k c0589k, C0532b c0532b) {
        this.f3108a = new C0724b(c0516d, c0589k, c0532b);
    }

    private Boolean m3925a() {
        return Boolean.valueOf(this.f3108a.m3924a());
    }
}
