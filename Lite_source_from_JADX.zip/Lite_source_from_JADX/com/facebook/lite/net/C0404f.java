package com.facebook.lite.net;

import android.content.Context;
import android.net.SSLCertificateSocketFactory;
import android.net.SSLSessionCache;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p053b.C0302p;
import com.p008a.p009a.p010a.p013c.C0012c;
import com.p008a.p009a.p010a.p013c.C0013a;
import com.p008a.p009a.p010a.p013c.C0032d;
import com.p008a.p009a.p010a.p014e.C0022b;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import javax.net.SocketFactory;
import javax.net.ssl.SSLSocket;
import org.apache.http.conn.ssl.BrowserCompatHostnameVerifier;

/* renamed from: com.facebook.lite.net.f */
public class C0404f extends C0013a implements C0403i {
    private static final String f1628d;
    private final Socket[] f1629e;
    private final Object f1630f;
    private final boolean[] f1631g;
    private final Context f1632h;
    private C0022b f1633i;
    private SSLSessionCache f1634j;
    private final HttpURLConnection[] f1635k;

    static {
        f1628d = C0404f.class.getSimpleName();
    }

    public C0404f(C0022b c0022b, Context context, C0032d c0032d) {
        this.f1629e = new Socket[5];
        this.f1630f = new Object();
        this.f1631g = new boolean[5];
        this.f1635k = new HttpURLConnection[5];
        this.f1633i = c0022b;
        try {
            this.f1634j = new SSLSessionCache(context);
        } catch (Exception e) {
            this.f1634j = null;
        }
        this.f1632h = context;
        c0032d.m246a((C0012c) this);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void m2862a(int r2) {
        /*
        r1 = this;
        r0 = r1.m2859h(r2);
        if (r0 == 0) goto L_0x001c;
    L_0x0006:
        r0 = r1.f1629e;	 Catch:{ IOException -> 0x0025, all -> 0x002a }
        r0 = r0[r2];	 Catch:{ IOException -> 0x0025, all -> 0x002a }
        if (r0 != 0) goto L_0x001d;
    L_0x000c:
        r0 = r1.f1635k;	 Catch:{ IOException -> 0x0025, all -> 0x002a }
        r0 = r0[r2];	 Catch:{ IOException -> 0x0025, all -> 0x002a }
        if (r0 == 0) goto L_0x0019;
    L_0x0012:
        r0 = r1.f1635k;	 Catch:{ IOException -> 0x0025, all -> 0x002a }
        r0 = r0[r2];	 Catch:{ IOException -> 0x0025, all -> 0x002a }
        r0.disconnect();	 Catch:{ IOException -> 0x0025, all -> 0x002a }
    L_0x0019:
        r1.m2858g(r2);
    L_0x001c:
        return;
    L_0x001d:
        r0 = r1.f1629e;	 Catch:{ IOException -> 0x0025, all -> 0x002a }
        r0 = r0[r2];	 Catch:{ IOException -> 0x0025, all -> 0x002a }
        r0.close();	 Catch:{ IOException -> 0x0025, all -> 0x002a }
        goto L_0x0019;
    L_0x0025:
        r0 = move-exception;
        r1.m2858g(r2);
        goto L_0x001c;
    L_0x002a:
        r0 = move-exception;
        r1.m2858g(r2);
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.net.f.a(int):void");
    }

    public final int m2864b(int i) {
        return m2857f(i).getResponseCode();
    }

    public final int m2868i() {
        return 5;
    }

    public final DataInputStream m2865c(int i) {
        if (m2859h(i)) {
            InputStream inputStream = null;
            if (this.f1629e[i] != null) {
                inputStream = this.f1629e[i].getInputStream();
            } else if (this.f1635k[i] != null) {
                inputStream = this.f1635k[i].getInputStream();
            }
            if (inputStream != null) {
                return new DataInputStream(inputStream);
            }
            throw new IOException("CONN_MAN");
        }
        throw new IOException("CONN_MAN");
    }

    public final int m2860a(String str) {
        int a = m2855a();
        if (a < 0) {
            throw new IOException("CONN_MAN");
        }
        try {
            URLConnection openConnection = new URL(C0402e.m2844a(str)).openConnection();
            openConnection.setDoOutput(true);
            if (openConnection instanceof HttpURLConnection) {
                this.f1635k[a] = (HttpURLConnection) openConnection;
                return a;
            }
            m2858g(a);
            throw new IOException("CONN_MAN");
        } catch (IOException e) {
            m2858g(a);
            throw e;
        }
    }

    public final OutputStream m2866d(int i) {
        if (!m2859h(i)) {
            throw new IOException("CONN_MAN");
        } else if (this.f1629e[i] != null) {
            return this.f1629e[i].getOutputStream();
        } else {
            if (this.f1635k[i] != null) {
                return this.f1635k[i].getOutputStream();
            }
            throw new IOException("CONN_MAN");
        }
    }

    public final int m2861a(String str, int i, int i2) {
        int a = m2855a();
        if (a < 0) {
            throw new IOException("CONN_MAN");
        }
        try {
            Socket socket;
            this.f1633i.m126a((short) 5, (short) 64, "Openning connection to " + str + ":" + i);
            String b = C0402e.m2845b(str);
            if (C0402e.m2846c(b)) {
                new StringBuilder("conn/socket connecting:").append(System.currentTimeMillis());
                socket = new Socket(b, i);
                new StringBuilder("conn/socket connected:").append(System.currentTimeMillis());
            } else {
                SocketFactory socketFactory;
                if (this.f1634j == null) {
                    socketFactory = SSLCertificateSocketFactory.getDefault();
                } else {
                    socketFactory = SSLCertificateSocketFactory.getDefault(0, this.f1634j);
                }
                new StringBuilder("conn/ssl create socket:").append(System.currentTimeMillis());
                socket = socketFactory.createSocket();
                new StringBuilder("conn/ssl socket created:").append(System.currentTimeMillis());
                C0408m.m2890a().m2891a(socket, "*.facebook.com");
                if (str.contains("facebook.com")) {
                    CharSequence a2 = C0405h.m2872a(str, C0294h.m1976g(), this.f1632h);
                    if (!C0302p.m2177b(a2)) {
                        C0405h.m2873a(str, C0294h.m1976g(), "", this.f1632h);
                        str = a2;
                    }
                }
                InetAddress byName = InetAddress.getByName(str);
                C0404f.m2856a(byName, "*.facebook.com");
                new StringBuilder("conn/tcpconnect ").append(byName).append(":443");
                new StringBuilder("conn/ssl start connect:").append(System.currentTimeMillis());
                socket.connect(new InetSocketAddress(byName, 443), i2);
                new StringBuilder("conn/ssl connected:").append(System.currentTimeMillis());
                new BrowserCompatHostnameVerifier().verify("*.facebook.com", (SSLSocket) socket);
            }
            if (C0300n.m2080H(this.f1632h)) {
                try {
                    socket.setTcpNoDelay(true);
                } catch (Throwable e) {
                    this.f1633i.m124a((short) 292, null, e);
                }
            }
            this.f1629e[a] = socket;
            return a;
        } catch (IllegalArgumentException e2) {
            m2858g(a);
            this.f1633i.m126a((short) 5, (short) 127, e2.getMessage());
            throw e2;
        } catch (InterruptedIOException e3) {
            m2858g(a);
            this.f1633i.m126a((short) 5, (short) 128, e3.getMessage());
            throw e3;
        } catch (IOException e4) {
            m2858g(a);
            this.f1633i.m126a((short) 5, (short) 40, e4.getMessage());
            throw e4;
        }
    }

    public final void m2867e(int i) {
        m2857f(i).setRequestMethod("POST");
    }

    public final void m2863a(int i, String str, String str2) {
        m2857f(i).setRequestProperty(str, str2);
    }

    protected final int[] m2869x() {
        return new int[]{64};
    }

    private HttpURLConnection m2857f(int i) {
        if (m2859h(i) && this.f1635k[i] != null) {
            return this.f1635k[i];
        }
        throw new IOException("CONN_MAN");
    }

    private void m2858g(int i) {
        synchronized (this.f1630f) {
            this.f1629e[i] = null;
            this.f1635k[i] = null;
            this.f1631g[i] = false;
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private int m2855a() {
        /*
        r4 = this;
        r2 = r4.f1630f;
        monitor-enter(r2);
        r0 = -1;
        r1 = 0;
    L_0x0005:
        r3 = r4.f1631g;	 Catch:{ all -> 0x001d }
        r3 = r3.length;	 Catch:{ all -> 0x001d }
        if (r1 >= r3) goto L_0x001b;
    L_0x000a:
        if (r0 >= 0) goto L_0x001b;
    L_0x000c:
        r3 = r4.f1631g;	 Catch:{ all -> 0x001d }
        r3 = r3[r1];	 Catch:{ all -> 0x001d }
        if (r3 != 0) goto L_0x0018;
    L_0x0012:
        r0 = r4.f1631g;	 Catch:{ all -> 0x001d }
        r3 = 1;
        r0[r1] = r3;	 Catch:{ all -> 0x001d }
        r0 = r1;
    L_0x0018:
        r1 = r1 + 1;
        goto L_0x0005;
    L_0x001b:
        monitor-exit(r2);	 Catch:{ all -> 0x001d }
        return r0;
    L_0x001d:
        r0 = move-exception;
        monitor-exit(r2);	 Catch:{ all -> 0x001d }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.net.f.a():int");
    }

    private static void m2856a(InetAddress inetAddress, String str) {
        try {
            Field declaredField = InetAddress.class.getDeclaredField("hostName");
            declaredField.setAccessible(true);
            declaredField.set(inetAddress, str);
        } catch (Exception e) {
        }
    }

    private boolean m2859h(int i) {
        return i >= 0 && i < this.f1629e.length && this.f1631g[i];
    }
}
