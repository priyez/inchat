package com.facebook.lite.deviceid;

import android.content.Context;
import android.util.Log;
import com.facebook.lite.p053b.C0300n;
import com.facebook.lite.p053b.C0302p;
import com.facebook.p037d.C0202d;
import com.facebook.p037d.C0205g;
import java.util.UUID;

/* renamed from: com.facebook.lite.deviceid.a */
public class C0317a implements C0205g {
    private static final String f1259a;
    private static volatile C0317a f1260b;
    private final Context f1261c;
    private C0202d f1262d;

    static {
        f1259a = C0317a.class.getName();
    }

    private C0317a(Context context) {
        this.f1261c = context;
    }

    public static C0317a m2260a(Context context) {
        if (f1260b == null) {
            synchronized (C0317a.class) {
                if (f1260b == null) {
                    f1260b = new C0317a(context.getApplicationContext());
                }
            }
        }
        return f1260b;
    }

    public final synchronized C0202d m2262a() {
        if (this.f1262d == null) {
            m2261b();
        }
        return this.f1262d;
    }

    public final synchronized void m2263a(C0202d c0202d) {
        Log.w(f1259a, "set Phone ID to " + c0202d);
        this.f1262d = c0202d;
        C0300n.m2133f(this.f1261c, c0202d.f786a);
        C0300n.m2127e(this.f1261c, c0202d.f787b);
    }

    private void m2261b() {
        String j = C0300n.m2146j(this.f1261c);
        long k = C0300n.m2148k(this.f1261c);
        if (C0302p.m2177b((CharSequence) j) || k == Long.MAX_VALUE) {
            j = UUID.randomUUID().toString();
            k = System.currentTimeMillis();
            C0300n.m2133f(this.f1261c, j);
            C0300n.m2127e(this.f1261c, k);
            Log.w(f1259a, "created a new Phone ID");
        }
        this.f1262d = new C0202d(j, k);
    }
}
