package com.facebook.rti.p046a.p075g;

import android.content.Context;
import android.content.SharedPreferences;

/* renamed from: com.facebook.rti.a.g.b */
final class C0530b extends C0528c {
    private C0530b() {
    }

    public final SharedPreferences m3349a(Context context, String str, boolean z) {
        return context.getSharedPreferences(str, 0);
    }
}
