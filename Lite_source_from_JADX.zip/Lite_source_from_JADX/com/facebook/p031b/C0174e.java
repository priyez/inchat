package com.facebook.p031b;

/* renamed from: com.facebook.b.e */
public interface C0174e {
    String m1382a();
}
