package com.facebook.p031b.p034c;

/* renamed from: com.facebook.b.c.j */
public final class C0163j {
    public final String f634a;
    public final String f635b;

    public C0163j(String str, String str2) {
        this.f634a = str;
        this.f635b = str2;
    }
}
