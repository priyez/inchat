package com.facebook.lite;

/* renamed from: com.facebook.lite.n */
final class C0392n implements Runnable {
    final /* synthetic */ MainActivity f1556a;

    C0392n(MainActivity mainActivity) {
        this.f1556a = mainActivity;
    }

    public final void run() {
        this.f1556a.f981m.setVisibility(0);
    }
}
