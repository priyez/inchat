package com.facebook.lite.p049a.p052c;

/* renamed from: com.facebook.lite.a.c.a */
public enum C0267a {
    LARGE,
    MEDIUM,
    NONE,
    SMALL
}
