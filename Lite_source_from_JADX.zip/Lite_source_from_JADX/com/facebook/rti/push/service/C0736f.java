package com.facebook.rti.push.service;

/* renamed from: com.facebook.rti.push.service.f */
public final class C0736f {
    public String f3161a;
    public String f3162b;
    public String f3163c;
    public String f3164d;
    public String f3165e;
    public String f3166f;
    public String f3167g;

    public C0736f() {
        this.f3161a = "";
        this.f3162b = "";
        this.f3163c = "";
        this.f3164d = "";
        this.f3165e = "";
        this.f3166f = "";
        this.f3167g = "";
    }

    public final String toString() {
        return "FbnsNotificationMessage{mToken'=" + this.f3161a + '\'' + ", mConnectionKey='" + this.f3162b + '\'' + ", mPackageName='" + this.f3163c + '\'' + ", mCollapseKey='" + this.f3164d + '\'' + ", mPayload='" + this.f3165e + '\'' + ", mNotifId='" + this.f3166f + '\'' + ", mIsBuffered='" + this.f3167g + '\'' + '}';
    }
}
