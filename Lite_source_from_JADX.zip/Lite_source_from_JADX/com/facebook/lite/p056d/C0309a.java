package com.facebook.lite.p056d;

import android.content.Context;
import com.facebook.lite.p053b.C0300n;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: com.facebook.lite.d.a */
public abstract class C0309a implements C0308d {
    protected volatile boolean f1224a;

    protected abstract void m2218a(JSONObject jSONObject);

    public final /* synthetic */ C0308d m2217a(Context context, String str) {
        return m2214b(context, str);
    }

    protected C0309a() {
    }

    private C0309a m2214b(Context context, String str) {
        try {
            C0309a.m2213a(context, m2212a(), str);
            synchronized (this) {
                m2218a(new JSONObject(str));
            }
        } catch (JSONException e) {
        }
        return this;
    }

    protected final C0309a m2216a(Context context) {
        if (!this.f1224a) {
            synchronized (this) {
                if (!this.f1224a) {
                    m2218a(C0309a.m2215c(context, m2212a()));
                    this.f1224a = true;
                }
            }
        }
        return this;
    }

    private static JSONObject m2215c(Context context, String str) {
        String b = C0300n.m2105b(context, "config_" + str);
        if (b == null) {
            return null;
        }
        try {
            return new JSONObject(b);
        } catch (JSONException e) {
            return null;
        }
    }

    private static void m2213a(Context context, String str, String str2) {
        C0300n.m2098a(context, "config_" + str, str2);
    }
}
