package com.facebook.p031b;

import android.content.Context;
import android.util.Log;
import com.facebook.p031b.p032a.C0146b;
import com.facebook.p031b.p033b.C0150a;
import com.facebook.p031b.p033b.C0151b;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/* renamed from: com.facebook.b.a */
public class C0148a {
    public static final String f621a;
    public static final C0191v[] f622b;
    public static final C0191v[] f623c;
    private static C0146b f624d;
    private static C0150a f625e;

    static {
        f621a = C0148a.class.getSimpleName();
        f622b = new C0191v[]{C0191v.ACRA_REPORT_TYPE, C0191v.REPORT_ID, C0191v.APP_VERSION_CODE, C0191v.APP_VERSION_NAME, C0191v.APP_INSTALL_TIME, C0191v.APP_UPGRADE_TIME, C0191v.PACKAGE_NAME, C0191v.FILE_PATH, C0191v.PHONE_MODEL, C0191v.BRAND, C0191v.PRODUCT, C0191v.ANDROID_VERSION, C0191v.OS_VERSION, C0191v.BUILD, C0191v.BUILD_HOST, C0191v.TOTAL_MEM_SIZE, C0191v.AVAILABLE_MEM_SIZE, C0191v.CUSTOM_DATA, C0191v.STACK_TRACE, C0191v.DEVICE, C0191v.CRASH_CONFIGURATION, C0191v.DISPLAY, C0191v.USER_APP_START_DATE, C0191v.USER_CRASH_DATE, C0191v.DUMPSYS_MEMINFO, C0191v.DROPBOX, C0191v.LOGCAT, C0191v.EVENTSLOG, C0191v.RADIOLOG, C0191v.DEVICE_ID, C0191v.INSTALLATION_ID, C0191v.DEVICE_FEATURES, C0191v.ENVIRONMENT, C0191v.SETTINGS_SYSTEM, C0191v.SETTINGS_SECURE, C0191v.PROCESS_NAME, C0191v.PROCESS_NAME_BY_AMS, C0191v.ACTIVITY_LOG, C0191v.JAIL_BROKEN, C0191v.PROCESS_UPTIME, C0191v.DEVICE_UPTIME, C0191v.ACRA_REPORT_FILENAME, C0191v.EXCEPTION_CAUSE, C0191v.REPORT_LOAD_THROW, C0191v.MINIDUMP, C0191v.ANDROID_ID, C0191v.UID, C0191v.UPLOADED_BY_PROCESS, C0191v.OPEN_FD_COUNT, C0191v.OPEN_FD_SOFT_LIMIT, C0191v.OPEN_FD_HARD_LIMIT, C0191v.IS_LOW_RAM_DEVICE, C0191v.SIGQUIT, C0191v.LARGE_MEM_HEAP, C0191v.ANDROID_RUNTIME, C0191v.MINIDUMP_EXCLUDE_REASON, C0191v.ATTACHMENT_ORIGINAL_SIZE, C0191v.LAST_URL_VISITED, C0191v.LAST_URL_VISITED_TIME, C0191v.TIME_OF_CRASH, C0191v.WEBVIEW_VERSION, C0191v.LAST_ACTIVITY_LOGGED, C0191v.LAST_ACTIVITY_LOGGED_TIME, C0191v.IAB_OPEN_TIMES, C0191v.RUNTIME_PERMISSIONS};
        f623c = new C0191v[]{C0191v.ACRA_REPORT_TYPE, C0191v.REPORT_ID, C0191v.APP_VERSION_CODE, C0191v.APP_VERSION_NAME, C0191v.APP_INSTALL_TIME, C0191v.APP_UPGRADE_TIME, C0191v.PACKAGE_NAME, C0191v.FILE_PATH, C0191v.PHONE_MODEL, C0191v.BRAND, C0191v.PRODUCT, C0191v.ANDROID_VERSION, C0191v.OS_VERSION, C0191v.BUILD, C0191v.BUILD_HOST, C0191v.TOTAL_MEM_SIZE, C0191v.AVAILABLE_MEM_SIZE, C0191v.CUSTOM_DATA, C0191v.STACK_TRACE, C0191v.DEVICE, C0191v.CRASH_CONFIGURATION, C0191v.DISPLAY, C0191v.USER_APP_START_DATE, C0191v.USER_CRASH_DATE, C0191v.DUMPSYS_MEMINFO, C0191v.DROPBOX, C0191v.DEVICE_ID, C0191v.INSTALLATION_ID, C0191v.DEVICE_FEATURES, C0191v.ENVIRONMENT, C0191v.SETTINGS_SYSTEM, C0191v.SETTINGS_SECURE, C0191v.PROCESS_NAME, C0191v.PROCESS_NAME_BY_AMS, C0191v.ACTIVITY_LOG, C0191v.JAIL_BROKEN, C0191v.PROCESS_UPTIME, C0191v.DEVICE_UPTIME, C0191v.ACRA_REPORT_FILENAME, C0191v.EXCEPTION_CAUSE, C0191v.REPORT_LOAD_THROW, C0191v.MINIDUMP, C0191v.ANDROID_ID, C0191v.UID, C0191v.UPLOADED_BY_PROCESS, C0191v.IS_LOW_RAM_DEVICE, C0191v.LARGE_MEM_HEAP, C0191v.ANDROID_RUNTIME, C0191v.ATTACHMENT_ORIGINAL_SIZE, C0191v.WEBVIEW_VERSION, C0191v.RUNTIME_PERMISSIONS};
    }

    public static C0184o m1328a(C0146b c0146b, String str) {
        C0184o a = C0184o.m1401a();
        if (f624d == null) {
            f624d = c0146b;
            Context e = c0146b.m1318e();
            new StringBuilder("ACRA is enabled for ").append(e.getPackageName()).append(", intializing...");
            a.m1451a(e);
            Thread.setDefaultUncaughtExceptionHandler(a);
            if (str != null) {
                C0148a.m1330a(e, a, str);
            }
            C0148a.m1329a(e);
            a.m1456b();
        }
        return a;
    }

    public static C0146b m1327a() {
        return f624d;
    }

    private static void m1330a(Context context, C0184o c0184o, String str) {
        Closeable bufferedReader;
        Throwable e;
        f625e = new C0151b(str);
        c0184o.m1454a(f625e);
        try {
            File fileStreamPath = context.getFileStreamPath("report_host.txt");
            if (fileStreamPath.canRead()) {
                bufferedReader = new BufferedReader(new FileReader(fileStreamPath));
                try {
                    String trim = bufferedReader.readLine().trim();
                    if (!(trim == null || trim.isEmpty())) {
                        Log.i("ACRA", "setting crash reporting host to " + trim);
                        f625e.m1333a(trim);
                    }
                    C0148a.m1331a(bufferedReader);
                    return;
                } catch (IOException e2) {
                    e = e2;
                    try {
                        Log.i("ACRA", "could not read host file: ", e);
                        C0148a.m1331a(bufferedReader);
                    } catch (Throwable th) {
                        e = th;
                        C0148a.m1331a(bufferedReader);
                        throw e;
                    }
                }
            }
            C0148a.m1331a(null);
        } catch (IOException e3) {
            e = e3;
            bufferedReader = null;
            Log.i("ACRA", "could not read host file: ", e);
            C0148a.m1331a(bufferedReader);
        } catch (Throwable th2) {
            e = th2;
            bufferedReader = null;
            C0148a.m1331a(bufferedReader);
            throw e;
        }
    }

    private static void m1329a(Context context) {
        Closeable bufferedReader;
        Throwable th;
        Throwable th2;
        Closeable closeable = null;
        boolean z = true;
        try {
            File fileStreamPath = context.getFileStreamPath("cert_checks.txt");
            if (fileStreamPath.canRead()) {
                bufferedReader = new BufferedReader(new FileReader(fileStreamPath));
                try {
                    String trim = bufferedReader.readLine().trim();
                    if (!(trim == null || trim.isEmpty())) {
                        z = Boolean.parseBoolean(trim);
                    }
                } catch (Throwable e) {
                    Throwable th3 = e;
                    closeable = bufferedReader;
                    th = th3;
                    try {
                        Log.i("ACRA", "could not read disable ssl cert checks file: ", th);
                        C0148a.m1331a(closeable);
                        f624d.m1313a(z);
                    } catch (Throwable th4) {
                        th2 = th4;
                        C0148a.m1331a(closeable);
                        throw th2;
                    }
                } catch (Throwable th5) {
                    th2 = th5;
                    closeable = bufferedReader;
                    C0148a.m1331a(closeable);
                    throw th2;
                }
            }
            bufferedReader = null;
            C0148a.m1331a(bufferedReader);
        } catch (IOException e2) {
            th = e2;
            Log.i("ACRA", "could not read disable ssl cert checks file: ", th);
            C0148a.m1331a(closeable);
            f624d.m1313a(z);
        }
        f624d.m1313a(z);
    }

    private static void m1331a(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (Throwable e) {
                Log.e("ACRA", "Error while closing stream: ", e);
            }
        }
    }
}
