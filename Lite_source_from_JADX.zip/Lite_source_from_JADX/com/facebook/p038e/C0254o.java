package com.facebook.p038e;

import android.os.Debug;
import android.util.Log;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.aw;
import com.facebook.lite.p053b.C0301o;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;

/* renamed from: com.facebook.e.o */
public class C0254o {
    private C0254o() {
    }

    public static void m1684a() {
        if (aw.f1162a) {
            try {
                String a = C0301o.m2171a(ClientApplication.m1690b().getApplicationContext());
                if (a != null) {
                    String str = a + '/' + "memdump.hprof";
                    a = a + '/' + "memdump.zip";
                    Debug.dumpHprofData(str);
                    File file = new File(str);
                    C0254o.m1685a(file, new File(a));
                    file.delete();
                }
            } catch (IOException e) {
                Log.e(C0254o.class.getSimpleName(), e.toString());
            } catch (OutOfMemoryError e2) {
                Log.e(C0254o.class.getSimpleName(), e2.toString());
            }
        }
    }

    private static void m1685a(File file, File file2) {
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            OutputStream fileOutputStream = new FileOutputStream(file2);
            GZIPOutputStream gZIPOutputStream;
            try {
                gZIPOutputStream = new GZIPOutputStream(fileOutputStream);
                byte[] bArr = new byte[1024];
                while (true) {
                    int read = fileInputStream.read(bArr);
                    if (read == -1) {
                        break;
                    }
                    gZIPOutputStream.write(bArr, 0, read);
                }
                gZIPOutputStream.flush();
                gZIPOutputStream.close();
                fileOutputStream.close();
            } catch (Throwable th) {
                fileOutputStream.close();
            }
        } finally {
            fileInputStream.close();
        }
    }
}
