package com.facebook.lite.net;

import java.lang.reflect.Method;
import java.net.Socket;

/* renamed from: com.facebook.lite.net.m */
public final class C0408m {
    private static C0408m f1646a;
    private Class f1647b;
    private boolean f1648c;
    private Method f1649d;
    private Method f1650e;

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0408m() {
        /*
        r5 = this;
        r5.<init>();
        r0 = "com.android.org.conscrypt.OpenSSLSocketImpl";
        r0 = java.lang.Class.forName(r0);	 Catch:{ ClassNotFoundException -> 0x0033, NoSuchMethodException -> 0x003f }
        r5.f1647b = r0;	 Catch:{ ClassNotFoundException -> 0x0033, NoSuchMethodException -> 0x003f }
    L_0x000b:
        r0 = r5.f1647b;	 Catch:{ ClassNotFoundException -> 0x003d, NoSuchMethodException -> 0x003f }
        r1 = "setUseSessionTickets";
        r2 = 1;
        r2 = new java.lang.Class[r2];	 Catch:{ ClassNotFoundException -> 0x003d, NoSuchMethodException -> 0x003f }
        r3 = 0;
        r4 = java.lang.Boolean.TYPE;	 Catch:{ ClassNotFoundException -> 0x003d, NoSuchMethodException -> 0x003f }
        r2[r3] = r4;	 Catch:{ ClassNotFoundException -> 0x003d, NoSuchMethodException -> 0x003f }
        r0 = r0.getMethod(r1, r2);	 Catch:{ ClassNotFoundException -> 0x003d, NoSuchMethodException -> 0x003f }
        r5.f1650e = r0;	 Catch:{ ClassNotFoundException -> 0x003d, NoSuchMethodException -> 0x003f }
        r0 = r5.f1647b;	 Catch:{ ClassNotFoundException -> 0x003d, NoSuchMethodException -> 0x003f }
        r1 = "setHostname";
        r2 = 1;
        r2 = new java.lang.Class[r2];	 Catch:{ ClassNotFoundException -> 0x003d, NoSuchMethodException -> 0x003f }
        r3 = 0;
        r4 = java.lang.String.class;
        r2[r3] = r4;	 Catch:{ ClassNotFoundException -> 0x003d, NoSuchMethodException -> 0x003f }
        r0 = r0.getMethod(r1, r2);	 Catch:{ ClassNotFoundException -> 0x003d, NoSuchMethodException -> 0x003f }
        r5.f1649d = r0;	 Catch:{ ClassNotFoundException -> 0x003d, NoSuchMethodException -> 0x003f }
        r0 = 1;
        r5.f1648c = r0;	 Catch:{ ClassNotFoundException -> 0x003d, NoSuchMethodException -> 0x003f }
    L_0x0032:
        return;
    L_0x0033:
        r0 = move-exception;
        r0 = "org.apache.harmony.xnet.provider.jsse.OpenSSLSocketImpl";
        r0 = java.lang.Class.forName(r0);	 Catch:{ ClassNotFoundException -> 0x003d, NoSuchMethodException -> 0x003f }
        r5.f1647b = r0;	 Catch:{ ClassNotFoundException -> 0x003d, NoSuchMethodException -> 0x003f }
        goto L_0x000b;
    L_0x003d:
        r0 = move-exception;
        goto L_0x0032;
    L_0x003f:
        r0 = move-exception;
        goto L_0x0032;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.net.m.<init>():void");
    }

    public static synchronized C0408m m2890a() {
        C0408m c0408m;
        synchronized (C0408m.class) {
            if (f1646a == null) {
                f1646a = new C0408m();
            }
            c0408m = f1646a;
        }
        return c0408m;
    }

    public final void m2891a(Socket socket, String str) {
        if (this.f1648c && this.f1647b.isInstance(socket)) {
            try {
                this.f1650e.invoke(socket, new Object[]{Boolean.valueOf(true)});
                this.f1649d.invoke(socket, new Object[]{str});
            } catch (Throwable e) {
                throw new RuntimeException(e);
            } catch (IllegalAccessException e2) {
                throw new AssertionError(e2);
            }
        }
    }
}
