package com.facebook.p038e.p045d;

import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;

/* renamed from: com.facebook.e.d.c */
public abstract class C0233c {
    private final ActivityManager f889a;

    protected abstract long m1606a(MemoryInfo memoryInfo);

    public C0233c(ActivityManager activityManager) {
        this.f889a = activityManager;
    }

    private C0237g m1604b() {
        MemoryInfo memoryInfo = new MemoryInfo();
        this.f889a.getMemoryInfo(memoryInfo);
        return new C0237g(memoryInfo, m1606a(memoryInfo));
    }

    public final long m1605a() {
        long a = m1606a(null);
        return a >= 0 ? a : m1604b().m1619a();
    }
}
