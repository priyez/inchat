package com.facebook.lite.p059m;

import android.content.Context;
import com.facebook.lite.net.C0388g;
import com.facebook.lite.p053b.C0294h;

/* renamed from: com.facebook.lite.m.k */
public class C0389k implements C0388g {
    private static final String f1543a;
    private final C0387i f1544b;

    static {
        f1543a = C0389k.class.getSimpleName();
    }

    public C0389k(C0387i c0387i) {
        this.f1544b = c0387i;
    }

    public final void m2717a(Context context) {
        if (C0294h.m1974f()) {
            new StringBuilder("conn/network connected/").append(System.currentTimeMillis());
            this.f1544b.m2639N().m196c(this.f1544b.m2653a(true, false));
            return;
        }
        this.f1544b.m2639N().m213p();
    }
}
