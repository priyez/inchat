package com.facebook.rti.p046a.p069a;

/* renamed from: com.facebook.rti.a.a.d */
public interface C0500d {
    void m3289a();

    void m3290a(C0498b c0498b);
}
