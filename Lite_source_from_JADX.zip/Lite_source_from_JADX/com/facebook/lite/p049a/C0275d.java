package com.facebook.lite.p049a;

import android.util.Log;
import com.facebook.lite.p049a.p050a.C0261a;

/* renamed from: com.facebook.lite.a.d */
final class C0275d extends C0263a {
    final /* synthetic */ C0280i f1050a;
    private final C0261a f1051b;
    private final int f1052c;

    public C0275d(C0280i c0280i, int i, long j, C0261a c0261a) {
        this.f1050a = c0280i;
        super(j);
        this.f1052c = i;
        this.f1051b = c0261a;
    }

    public final void run() {
        try {
            this.f1051b.m1806d().m1294c(Integer.toString(this.f1052c));
            C0280i.f1070a;
            new StringBuilder().append(C0280i.m1873a(this.f1051b.m1804b())).append("deleted image:").append(this.f1052c);
        } catch (Throwable e) {
            Log.e(C0280i.f1070a, C0280i.m1873a(this.f1051b.m1804b()) + "can't delete image " + this.f1052c, e);
        }
    }
}
