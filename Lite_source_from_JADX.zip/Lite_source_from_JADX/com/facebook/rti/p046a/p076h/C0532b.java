package com.facebook.rti.p046a.p076h;

/* renamed from: com.facebook.rti.a.h.b */
public interface C0532b {
    long m3351a();
}
