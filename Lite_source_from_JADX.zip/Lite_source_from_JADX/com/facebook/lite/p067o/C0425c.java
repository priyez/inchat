package com.facebook.lite.p067o;

import android.annotation.SuppressLint;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;

/* renamed from: com.facebook.lite.o.c */
public final class C0425c extends DeflaterOutputStream {
    public C0425c(OutputStream outputStream, Deflater deflater) {
        super(outputStream, deflater, 1024);
    }

    public final void m2943a() {
        this.def.reset();
    }

    @SuppressLint({"NewApi"})
    public final void m2944b() {
        while (true) {
            try {
                int deflate = this.def.deflate(this.buf, 0, this.buf.length, 2);
                if (deflate > 0) {
                    this.out.write(this.buf, 0, deflate);
                } else {
                    this.out.flush();
                    return;
                }
            } catch (IOException e) {
                throw e;
            } catch (Throwable th) {
                IOException iOException = new IOException("Sync flush failed. This shouldn't happen. ", th);
            }
        }
    }
}
