package com.facebook.p037d;

/* renamed from: com.facebook.d.d */
public final class C0202d {
    public final String f786a;
    public final long f787b;

    public C0202d(String str, long j) {
        this.f786a = str;
        this.f787b = j;
    }

    public final String toString() {
        return this.f786a + " : " + this.f787b;
    }
}
