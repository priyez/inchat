package com.facebook.lite.p067o;

import com.p008a.p009a.p010a.p023m.C0125m;

/* renamed from: com.facebook.lite.o.b */
public final class C0424b implements C0125m {
    private long f1706a;
    private int[] f1707b;
    private int f1708c;
    private int f1709d;

    public C0424b(int i) {
        this.f1707b = new int[i];
    }

    public final void m2941a(int i) {
        this.f1706a = (this.f1706a - ((long) this.f1707b[this.f1708c])) + ((long) i);
        this.f1707b[this.f1708c] = i;
        this.f1708c = (this.f1708c + 1) % this.f1707b.length;
        this.f1709d = Math.min(this.f1709d + 1, this.f1707b.length);
    }

    public final int m2940a() {
        if (this.f1709d == 0) {
            return 0;
        }
        return (int) (this.f1706a / ((long) this.f1709d));
    }

    public final void m2942b() {
        this.f1707b = new int[this.f1707b.length];
        this.f1708c = 0;
        this.f1709d = 0;
        this.f1706a = 0;
    }
}
