package com.facebook.lite.ui;

import android.content.res.Resources;
import android.graphics.Rect;
import android.view.View;
import android.view.View.MeasureSpec;
import com.facebook.lite.av;

/* renamed from: com.facebook.lite.ui.d */
public final class C0462d {
    private static final Rect f1827a;
    private boolean f1828b;
    private boolean f1829c;
    private int f1830d;
    private int f1831e;
    private final int f1832f;
    private int f1833g;
    private final C0461c f1834h;

    static {
        f1827a = new Rect();
    }

    public C0462d(Resources resources, C0461c c0461c) {
        this.f1834h = c0461c;
        this.f1831e = resources.getConfiguration().orientation;
        this.f1832f = resources.getDimensionPixelSize(av.soft_input_detection_min_height_dp);
        m3125a(resources);
    }

    public final void m3126a(View view, int i) {
        boolean z = true;
        Resources resources = view.getResources();
        int i2 = resources.getConfiguration().orientation;
        if (i2 != this.f1831e) {
            this.f1831e = i2;
            m3125a(resources);
        }
        i2 = MeasureSpec.getSize(i);
        if (i2 != this.f1830d || this.f1829c) {
            view.getWindowVisibleDisplayFrame(f1827a);
            if (f1827a.bottom > 0) {
                this.f1830d = i2;
                this.f1829c = i2 > f1827a.height();
                i2 = resources.getDisplayMetrics().heightPixels - f1827a.bottom;
                if (this.f1828b || i2 <= this.f1832f) {
                    if (i2 <= this.f1832f) {
                        z = false;
                    }
                    this.f1828b = z;
                    if (this.f1828b) {
                        this.f1833g = i2;
                        return;
                    }
                    return;
                }
                this.f1828b = true;
                this.f1833g = i2;
                this.f1834h.m3124a(this.f1833g);
                return;
            }
            this.f1828b = false;
        }
    }

    private void m3125a(Resources resources) {
        this.f1833g = resources.getDimensionPixelSize(av.custom_keyboard_layout_default_height);
    }
}
