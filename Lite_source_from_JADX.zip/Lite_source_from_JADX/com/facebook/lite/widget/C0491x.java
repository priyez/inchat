package com.facebook.lite.widget;

import android.text.Editable;
import android.text.TextWatcher;
import java.util.List;

/* renamed from: com.facebook.lite.widget.x */
final class C0491x implements TextWatcher {
    final /* synthetic */ InlineTextBox f2112a;

    C0491x(InlineTextBox inlineTextBox) {
        this.f2112a = inlineTextBox;
    }

    public final void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        this.f2112a.f1932e = i;
        this.f2112a.f1931d = i2;
        this.f2112a.f1930c = i3;
        this.f2112a.f1926F = this.f2112a.f1946s.getText().toString();
    }

    public final void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }

    public final void afterTextChanged(Editable editable) {
        if (this.f2112a.f1933f) {
            String str;
            int intValue;
            String obj = editable.toString();
            int selectionStart = this.f2112a.f1946s.getSelectionStart();
            List a = this.f2112a.m3202a(this.f2112a.f1932e, this.f2112a.f1931d, this.f2112a.f1930c);
            if (((Integer) a.get(0)).intValue() < this.f2112a.f1932e || ((Integer) a.get(1)).intValue() > this.f2112a.f1932e + this.f2112a.f1931d) {
                str = this.f2112a.f1926F.substring(0, ((Integer) a.get(0)).intValue()) + this.f2112a.f1926F.substring(((Integer) a.get(1)).intValue());
                intValue = ((Integer) a.get(0)).intValue();
            } else {
                intValue = selectionStart;
                str = obj;
            }
            this.f2112a.m3211c();
            if (this.f2112a.f1929I) {
                this.f2112a.m3207a(str, intValue);
            }
        }
        this.f2112a.f1933f = true;
    }
}
