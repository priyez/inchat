package com.facebook.lite.widget;

final /* synthetic */ class ag {
    static final /* synthetic */ int[] f2035a;

    static {
        f2035a = new int[ah.m3273a().length];
        try {
            f2035a[ah.f2038c - 1] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            f2035a[ah.f2037b - 1] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            f2035a[ah.f2036a - 1] = 3;
        } catch (NoSuchFieldError e3) {
        }
    }
}
