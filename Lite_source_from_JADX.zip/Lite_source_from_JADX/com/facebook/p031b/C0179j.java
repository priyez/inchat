package com.facebook.p031b;

import java.io.File;
import java.io.FilenameFilter;

/* renamed from: com.facebook.b.j */
final class C0179j implements FilenameFilter {
    final /* synthetic */ String[] f661a;
    final /* synthetic */ C0184o f662b;

    C0179j(C0184o c0184o, String[] strArr) {
        this.f662b = c0184o;
        this.f661a = strArr;
    }

    public final boolean accept(File file, String str) {
        for (String endsWith : this.f661a) {
            if (str.endsWith(endsWith)) {
                return true;
            }
        }
        return false;
    }
}
