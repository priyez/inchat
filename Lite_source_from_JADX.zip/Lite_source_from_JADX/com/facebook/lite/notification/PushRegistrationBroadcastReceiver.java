package com.facebook.lite.notification;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;

public class PushRegistrationBroadcastReceiver extends BroadcastReceiver {
    private static final String f1657a;

    static {
        f1657a = PushRegistrationBroadcastReceiver.class.getSimpleName();
    }

    public void onReceive(Context context, Intent intent) {
        if (context == null) {
            Log.e(f1657a, "push/fail to register GCM push token. context null.");
        } else {
            new Handler().postDelayed(new C0413b(this, context), 5000);
        }
    }
}
