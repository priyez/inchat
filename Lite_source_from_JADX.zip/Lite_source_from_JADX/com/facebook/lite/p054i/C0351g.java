package com.facebook.lite.p054i;

import android.location.Location;
import android.location.LocationManager;
import android.os.Handler;
import android.os.Looper;
import com.facebook.lite.p053b.C0294h;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/* renamed from: com.facebook.lite.i.g */
public final class C0351g {
    private static final Long f1386a;
    private C0350f f1387b;
    private C0303e f1388c;
    private final Handler f1389d;
    private final AtomicBoolean f1390e;
    private final ScheduledExecutorService f1391f;
    private Location f1392g;
    private final LocationManager f1393h;
    private boolean f1394i;
    private ScheduledFuture f1395j;

    static {
        f1386a = Long.valueOf(10000);
    }

    public C0351g(ScheduledExecutorService scheduledExecutorService, LocationManager locationManager) {
        this.f1390e = new AtomicBoolean();
        this.f1391f = scheduledExecutorService;
        this.f1389d = new Handler(Looper.getMainLooper());
        this.f1393h = locationManager;
    }

    public final boolean m2495a() {
        try {
            return !this.f1393h.isProviderEnabled("network");
        } catch (Exception e) {
            return true;
        }
    }

    public final void m2494a(C0303e c0303e) {
        this.f1394i = true;
        m2496b();
        if (this.f1390e.getAndSet(true)) {
            throw new IllegalStateException("previous location request did not terminate");
        }
        this.f1388c = c0303e;
        m2490f();
        m2491g();
    }

    public final void m2496b() {
        if (this.f1390e.getAndSet(false)) {
            m2480c();
            m2493h();
            m2488e();
        }
    }

    private void m2480c() {
        if (this.f1395j != null) {
            this.f1395j.cancel(false);
            this.f1395j = null;
        }
    }

    private static Location m2477b(Location location) {
        if (location == null) {
            return null;
        }
        if (location.getLatitude() == 0.0d && location.getLongitude() == 0.0d) {
            return null;
        }
        if (location.getTime() == 0) {
            return null;
        }
        if (location.hasAccuracy()) {
            return location;
        }
        location.setAccuracy(3333.0f);
        return location;
    }

    private static boolean m2476a(Location location, Location location2) {
        if (location == null || C0351g.m2483c(location, location2)) {
            return true;
        }
        if (C0351g.m2479b(location, location2) && !C0351g.m2483c(location2, location)) {
            return true;
        }
        if (C0294h.m1962b(location, location2) <= 5000 || C0294h.m1950a(location, location2) <= 50.0f) {
            return false;
        }
        return true;
    }

    private static boolean m2479b(Location location, Location location2) {
        if (location.getAccuracy() >= location2.getAccuracy() && location.getAccuracy() * 0.6666667f >= location2.getAccuracy()) {
            return true;
        }
        return false;
    }

    private static boolean m2483c(Location location, Location location2) {
        if (location.getTime() <= location2.getTime() && location2.getTime() - location.getTime() >= 120000) {
            return true;
        }
        return false;
    }

    private void m2481c(Location location) {
        if (this.f1390e.get() && C0351g.m2476a(this.f1392g, location)) {
            m2480c();
            this.f1392g = location;
            m2485d(location);
        }
    }

    private void m2484d() {
        m2493h();
        this.f1389d.post(new C0346a(this));
    }

    private void m2488e() {
        this.f1387b = null;
        this.f1392g = null;
    }

    private void m2485d(Location location) {
        this.f1389d.post(new C0347b(this, location));
    }

    private void m2490f() {
        if (f1386a != null) {
            this.f1395j = this.f1391f.schedule(new C0348c(this), f1386a.longValue(), TimeUnit.MILLISECONDS);
        }
    }

    private void m2491g() {
        this.f1387b = new C0350f();
        for (String lastKnownLocation : this.f1393h.getProviders(true)) {
            Location b = C0351g.m2477b(this.f1393h.getLastKnownLocation(lastKnownLocation));
            if (b != null) {
                m2481c(b);
            }
        }
        this.f1391f.execute(new C0349d(this));
    }

    private void m2493h() {
        this.f1393h.removeUpdates(this.f1387b);
        this.f1387b = null;
    }
}
