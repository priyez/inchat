package com.facebook.lite.notification;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.util.Log;
import java.util.List;

/* renamed from: com.facebook.lite.notification.g */
public class C0418g {
    private static final String f1695a;
    private static final ComponentName f1696b;
    private static final ComponentName f1697c;
    private static final List f1698d;
    private static final List f1699e;
    private final String f1700f;
    private final Context f1701g;
    private Boolean f1702h;
    private final String f1703i;

    static {
        f1695a = C0418g.class.getSimpleName();
        f1696b = new ComponentName("com.android.launcher", "com.android.launcher2.Launcher");
        f1697c = new ComponentName("", "");
        f1698d = new C0416e();
        f1699e = new C0417f();
    }

    public C0418g(Context context, String str) {
        this.f1701g = context;
        this.f1700f = str;
        this.f1703i = context.getPackageName();
        this.f1702h = Boolean.valueOf(m2928d());
    }

    public final boolean m2929a(int i) {
        if (!this.f1702h.booleanValue()) {
            return false;
        }
        try {
            ContentResolver contentResolver = this.f1701g.getContentResolver();
            Uri parse = Uri.parse("content://com.sec.badge/apps");
            ContentValues contentValues = new ContentValues();
            contentValues.put("package", this.f1703i);
            contentValues.put("class", this.f1700f);
            contentValues.put("badgecount", Integer.valueOf(i));
            if (contentResolver.update(parse, contentValues, String.format("%s=? AND %s=?", new Object[]{"package", "class"}), new String[]{this.f1703i, this.f1700f}) != 0) {
                return true;
            }
            contentResolver.insert(parse, contentValues);
            return true;
        } catch (IllegalArgumentException e) {
            this.f1702h = Boolean.valueOf(false);
            return false;
        } catch (Throwable e2) {
            Log.e(f1695a, "badging/unexpected exception while displaying badge.", e2);
            this.f1702h = Boolean.valueOf(false);
            return false;
        }
    }

    private ComponentName m2925a() {
        PackageManager packageManager = this.f1701g.getPackageManager();
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.HOME");
        try {
            List<ResolveInfo> queryIntentActivities = packageManager.queryIntentActivities(intent, 65536);
            ComponentName componentName = f1696b;
            ComponentName componentName2 = componentName;
            int i = 0;
            for (ResolveInfo resolveInfo : queryIntentActivities) {
                if (!resolveInfo.activityInfo.packageName.startsWith("com.facebook.")) {
                    ComponentName componentName3 = new ComponentName(resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.name);
                    if (i < 3 && f1698d.contains(componentName3.getPackageName())) {
                        i = 3;
                        componentName2 = componentName3;
                    } else if (i >= 2 || !f1699e.contains(componentName3.getPackageName())) {
                        int i2;
                        if (i <= 0) {
                            i2 = 1;
                            componentName = componentName3;
                        } else {
                            i2 = i;
                            componentName = componentName2;
                        }
                        componentName2 = componentName;
                        i = i2;
                    } else {
                        i = 2;
                        componentName2 = componentName3;
                    }
                }
            }
            new StringBuilder("badging/chosen launcher ").append(componentName2.getPackageName()).append(" of priority ").append(i);
            return componentName2;
        } catch (Exception e) {
            return f1697c;
        }
    }

    private boolean m2926b() {
        return m2925a().getPackageName().equals("com.sec.android.app.twlauncher");
    }

    private boolean m2927c() {
        return m2925a().getPackageName().equals("com.sec.android.app.launcher");
    }

    private boolean m2928d() {
        return m2926b() || m2927c();
    }
}
