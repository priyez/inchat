package com.facebook.rti.p046a.p069a;

import com.facebook.rti.p046a.p074f.C0527a;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.json.JSONObject;

/* renamed from: com.facebook.rti.a.a.b */
public class C0498b {
    private static final String f2124a;
    private final String f2125b;
    private final long f2126c;
    private final String f2127d;
    private final Map f2128e;

    static {
        f2124a = C0498b.class.getSimpleName();
    }

    public C0498b(String str, String str2) {
        this.f2128e = new HashMap();
        this.f2126c = System.currentTimeMillis();
        this.f2125b = str;
        this.f2127d = str2;
    }

    public final C0498b m3286a(String str, String str2) {
        this.f2128e.put(str, str2);
        return this;
    }

    public final C0498b m3285a(String str) {
        return m3286a("pk", str);
    }

    public final JSONObject m3287a() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("name", this.f2125b);
            jSONObject.put("time", String.format(null, "%.3f", new Object[]{Double.valueOf(((double) this.f2126c) / 1000.0d)}));
            jSONObject.putOpt("module", this.f2127d);
            if (!this.f2128e.isEmpty()) {
                JSONObject jSONObject2 = new JSONObject();
                for (Entry entry : this.f2128e.entrySet()) {
                    jSONObject2.put((String) entry.getKey(), entry.getValue());
                }
                jSONObject.put("extra", jSONObject2);
            }
        } catch (Throwable e) {
            C0527a.m3337a(f2124a, e, "Failed to serialize", new Object[0]);
        }
        return jSONObject;
    }

    public String toString() {
        return m3287a().toString();
    }
}
