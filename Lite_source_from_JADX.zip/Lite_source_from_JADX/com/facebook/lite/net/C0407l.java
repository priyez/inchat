package com.facebook.lite.net;

import com.facebook.lite.p059m.C0387i;
import com.p008a.p009a.p010a.p011a.C0006c;
import com.p008a.p009a.p010a.p015g.C0049b;

/* renamed from: com.facebook.lite.net.l */
public final class C0407l {
    private static final C0407l f1638a;
    private int f1639b;
    private C0006c f1640c;
    private boolean f1641d;
    private int f1642e;
    private int f1643f;
    private boolean f1644g;
    private int f1645h;

    public C0407l() {
        this.f1639b = 0;
        this.f1640c = C0006c.f16f;
        this.f1642e = -1;
        this.f1643f = -1;
        this.f1645h = 0;
    }

    static {
        f1638a = new C0407l();
    }

    public static C0407l m2881a() {
        return f1638a;
    }

    public final void m2886a(C0387i c0387i, int i) {
        if (this.f1641d) {
            C0049b b = C0407l.m2881a().m2882b(i);
            String a = b.m333a();
            if (a.length() > 0) {
                c0387i.m2674a((short) 4, (short) 258, a);
                new StringBuilder("conn/logging snapshot ").append(b.toString());
            }
        }
    }

    public final void m2888b() {
        this.f1639b = 0;
        this.f1640c = C0006c.f16f;
        this.f1645h = 0;
    }

    public final void m2884a(int i, int i2) {
        this.f1643f = i;
        this.f1642e = i2;
    }

    public final void m2885a(int i, C0006c c0006c) {
        this.f1639b = i;
        this.f1640c = c0006c;
    }

    public final void m2887a(boolean z) {
        this.f1641d = z;
    }

    public final void m2889c() {
        this.f1644g = true;
    }

    public final void m2883a(int i) {
        if (i != 0) {
            this.f1645h = Math.abs(i);
        }
    }

    private C0049b m2882b(int i) {
        if (i == 2 && this.f1644g) {
            i = 3;
            this.f1644g = false;
        }
        return new C0049b((byte) i, (byte) this.f1643f, (byte) this.f1642e, (short) this.f1645h, this.f1639b, this.f1640c);
    }
}
