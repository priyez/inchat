package com.facebook.lite.widget;

import android.view.Choreographer;
import android.view.Choreographer.FrameCallback;

final class ao implements FrameCallback {
    final /* synthetic */ SoftwareRendererView f2074a;

    ao(SoftwareRendererView softwareRendererView) {
        this.f2074a = softwareRendererView;
    }

    public final void doFrame(long j) {
        this.f2074a.f2009g = j / 1000000;
        Choreographer.getInstance().postFrameCallback(this.f2074a.f2015m);
    }
}
