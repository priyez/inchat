package com.facebook.p038e.p040b;

/* renamed from: com.facebook.e.b.c */
public enum C0223c {
    DAILY(86400000),
    HOURLY(3600000),
    ASAP(0);
    
    private long f843d;

    private C0223c(long j) {
        this.f843d = j;
    }

    public final long m1554a() {
        return this.f843d;
    }
}
