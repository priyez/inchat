package com.facebook.lite.widget;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.ui.C0459a;
import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p022l.C0089s;
import com.p008a.p009a.p010a.p022l.C0093w;

public class BannerView extends View {
    protected C0093w f1886a;
    private int[][] f1887b;
    private int[] f1888c;

    public BannerView(Context context) {
        super(context);
    }

    public BannerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public BannerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.f1886a == null) {
            m3156a(new NullPointerException("touch on null screen"));
            return false;
        }
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        switch (motionEvent.getAction()) {
            case 0:
                try {
                    this.f1886a.m898k((int) x, (int) y);
                    break;
                } catch (Throwable th) {
                    m3156a(th);
                    break;
                }
            case 1:
            case 99:
                try {
                    this.f1886a.m881a((int) x, (int) y, false);
                    break;
                } catch (Throwable th2) {
                    m3156a(th2);
                    break;
                }
        }
        return true;
    }

    public void m3158a(C0093w c0093w, int[] iArr, int[][] iArr2) {
        this.f1886a = c0093w;
        this.f1888c = iArr;
        this.f1887b = iArr2;
    }

    public final void m3157a(Activity activity, C0093w c0093w, int[] iArr, int[][] iArr2) {
        if (this.f1886a != null) {
            this.f1886a.m876V();
        }
        m3158a(c0093w, iArr, iArr2);
        this.f1886a.m877W();
        activity.runOnUiThread(new C0472c(this));
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        if (this.f1886a != null && this.f1888c != null && this.f1887b != null) {
            C0089s c0459a = new C0459a(width, height, this.f1887b, ClientApplication.m1691c().m2388T());
            this.f1886a.m882a(c0459a, this.f1888c);
            int[] f = c0459a.m786f();
            if (f != null && f.length >= width * height) {
                canvas.drawBitmap(f, 0, width, 0, 0, width, height, false, null);
            }
        }
    }

    private static void m3156a(Throwable th) {
        C0022b T = ClientApplication.m1691c().m2388T();
        if (T != null) {
            T.m124a((short) 256, null, th);
        }
    }
}
