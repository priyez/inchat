package com.facebook.lite.p055c;

import android.util.Log;
import com.facebook.lite.photo.GalleryItem;
import com.p008a.p009a.p010a.p022l.C0080i;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: com.facebook.lite.c.a */
public class C0305a {
    private static final String f1213a;
    private final List f1214b;
    private final List f1215c;
    private final Map f1216d;
    private final List f1217e;
    private final List f1218f;
    private final Map f1219g;

    public C0305a() {
        this.f1214b = new LinkedList();
        this.f1215c = new LinkedList();
        this.f1216d = new HashMap();
        this.f1217e = new LinkedList();
        this.f1218f = new LinkedList();
        this.f1219g = new HashMap();
    }

    static {
        f1213a = C0305a.class.getSimpleName();
    }

    public static C0305a m2185a(String str) {
        int i = 0;
        C0305a c0305a = new C0305a();
        try {
            int i2;
            JSONObject jSONObject = new JSONObject(str);
            JSONArray jSONArray = jSONObject.getJSONArray("unusedImageId");
            JSONArray jSONArray2 = jSONObject.getJSONArray("itemId");
            JSONArray jSONArray3 = jSONObject.getJSONArray("uploadedImageId");
            for (i2 = 0; i2 < jSONArray.length(); i2++) {
                c0305a.f1217e.add(Integer.valueOf(jSONArray.getInt(i2)));
            }
            while (i < jSONArray3.length()) {
                i2 = jSONArray3.getInt(i);
                GalleryItem a = GalleryItem.m2988a(jSONArray2.getString(i));
                c0305a.f1218f.add(Integer.valueOf(i2));
                c0305a.f1219g.put(Integer.valueOf(i2), a);
                c0305a.f1216d.put(Integer.valueOf(a.m2991b()), Integer.valueOf(i2));
                i++;
            }
        } catch (JSONException e) {
            Log.e(f1213a, "clientComposerState/jsonException when create clientComposerState from json string " + e);
        }
        return c0305a;
    }

    public final void m2187a(int i) {
        int indexOf = this.f1218f.indexOf(Integer.valueOf(i));
        int i2 = 0;
        while (i2 < this.f1214b.size()) {
            if (indexOf < ((Integer) this.f1214b.get(i2)).intValue()) {
                this.f1214b.add(i2, Integer.valueOf(indexOf));
                this.f1215c.add(i2, Integer.valueOf(i));
                break;
            }
            i2++;
        }
        if (i2 == this.f1214b.size()) {
            this.f1214b.add(i2, Integer.valueOf(indexOf));
            this.f1215c.add(i2, Integer.valueOf(i));
        }
        this.f1216d.remove(Integer.valueOf(((GalleryItem) this.f1219g.remove(Integer.valueOf(i))).m2991b()));
    }

    public final void m2192a(int[] iArr) {
        for (int i : iArr) {
            if (!this.f1218f.contains(Integer.valueOf(i))) {
                this.f1217e.add(Integer.valueOf(i));
            }
        }
    }

    public final void m2194b(int i) {
        this.f1217e.add(Integer.valueOf(i));
        this.f1218f.remove(Integer.valueOf(i));
        GalleryItem galleryItem = (GalleryItem) this.f1219g.remove(Integer.valueOf(i));
        if (galleryItem != null) {
            this.f1216d.remove(Integer.valueOf(galleryItem.m2991b()));
        }
    }

    public final void m2196c(int i) {
        this.f1218f.add(Integer.valueOf(i));
    }

    public final void m2186a() {
        for (int i = 0; i < this.f1215c.size(); i++) {
            this.f1217e.add(this.f1215c.remove(0));
        }
        this.f1214b.clear();
        this.f1215c.clear();
    }

    public final void m2190a(C0080i c0080i) {
        if (this.f1217e.size() + this.f1218f.size() > 1) {
            for (Integer intValue : this.f1218f) {
                c0080i.m634g(intValue.intValue());
            }
        }
        this.f1218f.clear();
        this.f1217e.clear();
        this.f1219g.clear();
        this.f1214b.clear();
        this.f1215c.clear();
        this.f1216d.clear();
    }

    public final int m2193b() {
        return ((Integer) this.f1214b.remove(0)).intValue();
    }

    public final int m2197d(int i) {
        return ((Integer) this.f1216d.get(Integer.valueOf(i))).intValue();
    }

    public final int m2195c() {
        if (this.f1215c.isEmpty()) {
            return ((Integer) this.f1217e.remove(0)).intValue();
        }
        return ((Integer) this.f1215c.remove(0)).intValue();
    }

    public final Set m2198d() {
        return this.f1216d.keySet();
    }

    public final ArrayList m2199e() {
        return new ArrayList(this.f1219g.values());
    }

    public final List m2201f() {
        return this.f1218f;
    }

    public final int m2202g() {
        return this.f1218f.size();
    }

    public final boolean m2203h() {
        return !this.f1214b.isEmpty();
    }

    public final boolean m2204i() {
        return !this.f1217e.isEmpty();
    }

    public final boolean m2200e(int i) {
        return !this.f1218f.contains(Integer.valueOf(i));
    }

    public final void m2189a(int i, GalleryItem galleryItem) {
        this.f1219g.put(Integer.valueOf(i), galleryItem);
        this.f1216d.put(Integer.valueOf(galleryItem.m2991b()), Integer.valueOf(i));
    }

    public final void m2205j() {
        for (int i = 0; i < this.f1215c.size(); i++) {
            this.f1218f.remove(((Integer) this.f1214b.get(i)).intValue() - i);
        }
    }

    public final String m2206k() {
        JSONArray jSONArray = new JSONArray();
        for (Integer intValue : this.f1217e) {
            jSONArray.put(intValue.intValue());
        }
        JSONArray jSONArray2 = new JSONArray();
        JSONArray jSONArray3 = new JSONArray();
        for (Entry entry : this.f1219g.entrySet()) {
            jSONArray2.put(entry.getKey());
            jSONArray3.put(((GalleryItem) entry.getValue()).m2997f());
        }
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("unusedImageId", jSONArray);
            jSONObject.put("uploadedImageId", jSONArray2);
            jSONObject.put("itemId", jSONArray3);
        } catch (JSONException e) {
            Log.e(f1213a, "clientComposerState/jsonException when write clientComposerState to json string " + e);
        }
        return jSONObject.toString();
    }

    public final void m2188a(int i, int i2) {
        GalleryItem galleryItem = (GalleryItem) this.f1219g.remove(Integer.valueOf(i));
        if (galleryItem != null) {
            m2189a(i2, galleryItem);
        }
    }

    public final void m2191a(GalleryItem galleryItem) {
        if (galleryItem != null) {
            this.f1219g.put(Integer.valueOf(((Integer) this.f1216d.get(Integer.valueOf(galleryItem.m2991b()))).intValue()), galleryItem);
        }
    }
}
