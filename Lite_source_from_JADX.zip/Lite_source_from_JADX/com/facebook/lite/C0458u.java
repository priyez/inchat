package com.facebook.lite;

import com.facebook.lite.net.C0403i;
import com.facebook.lite.p065n.C0391a;

/* renamed from: com.facebook.lite.u */
final class C0458u implements Runnable {
    final /* synthetic */ boolean f1819a;
    final /* synthetic */ boolean f1820b;
    final /* synthetic */ int f1821c;
    final /* synthetic */ MainActivity f1822d;

    C0458u(MainActivity mainActivity, boolean z, boolean z2, int i) {
        this.f1822d = mainActivity;
        this.f1819a = z;
        this.f1820b = z2;
        this.f1821c = i;
    }

    public final void run() {
        if (this.f1819a) {
            this.f1822d.f977i = this.f1820b;
            String a = C0391a.m2719a(12);
            String a2 = C0391a.m2719a(13);
            String a3 = C0391a.m2719a(3);
            if (this.f1821c == C0403i.f1627b) {
                a2 = C0391a.m2719a(13);
            }
            this.f1822d.f988t = this.f1822d.m1732a(a, a2);
            a = "right";
            a2 = C0391a.m2719a(0);
            if (this.f1821c < C0403i.f1627b) {
                this.f1822d.f988t.m3271b(a3, new C0456s(this));
                a2 = C0391a.m2719a(4);
                this.f1822d.f994z = false;
            } else {
                a = "central";
                this.f1822d.f994z = true;
            }
            if (this.f1820b) {
                this.f1822d.m1739a(this.f1822d.f988t, a2, true, a);
            } else {
                this.f1822d.m1738a(this.f1822d.f988t, "central");
            }
            this.f1822d.f988t.setOnCancelListener(new C0457t(this));
        }
        if (!this.f1822d.isFinishing() && !this.f1822d.f988t.isShowing()) {
            if (this.f1822d.f984p != null && this.f1822d.f984p.isShowing()) {
                this.f1822d.f984p.dismiss();
            }
            this.f1822d.m1781a(this.f1820b);
        }
    }
}
