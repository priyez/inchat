package com.facebook.lite.p059m;

/* renamed from: com.facebook.lite.m.d */
final class C0382d implements Runnable {
    final /* synthetic */ C0387i f1474a;

    C0382d(C0387i c0387i) {
        this.f1474a = c0387i;
    }

    public final void run() {
        if (this.f1474a.f1512R != 0) {
            this.f1474a.m2599c(this.f1474a.f1515U, this.f1474a.f1513S, "(" + this.f1474a.f1512R + " times)" + this.f1474a.f1516V);
            this.f1474a.f1512R = 0;
        }
        this.f1474a.m2687b(true);
    }
}
