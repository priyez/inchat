package com.facebook.lite;

import android.net.Uri;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;

/* renamed from: com.facebook.lite.v */
final class C0464v implements Runnable {
    final /* synthetic */ int f1836a;
    final /* synthetic */ int f1837b;
    final /* synthetic */ int f1838c;
    final /* synthetic */ int f1839d;
    final /* synthetic */ boolean f1840e;
    final /* synthetic */ boolean f1841f;
    final /* synthetic */ boolean f1842g;
    final /* synthetic */ Uri f1843h;
    final /* synthetic */ String f1844i;
    final /* synthetic */ MainActivity f1845j;

    C0464v(MainActivity mainActivity, int i, int i2, int i3, int i4, boolean z, boolean z2, boolean z3, Uri uri, String str) {
        this.f1845j = mainActivity;
        this.f1836a = i;
        this.f1837b = i2;
        this.f1838c = i3;
        this.f1839d = i4;
        this.f1840e = z;
        this.f1841f = z2;
        this.f1842g = z3;
        this.f1843h = uri;
        this.f1844i = str;
    }

    public final void run() {
        LayoutParams layoutParams = new FrameLayout.LayoutParams(this.f1836a, this.f1837b);
        layoutParams.setMargins(this.f1838c, this.f1839d, 0, 0);
        layoutParams.gravity = 48;
        this.f1845j.f993y.setMFbWebviewRequetsFromServer(this.f1840e);
        this.f1845j.f993y.setMFacebookWebviewRequestFromServer(this.f1841f);
        this.f1845j.f993y.setMGenericWebviewRequestFromServer(this.f1842g);
        this.f1845j.f993y.setLayoutParams(layoutParams);
        this.f1845j.f993y.m3135a(this.f1843h, this.f1844i);
        this.f1845j.f993y.setVisibility(0);
    }
}
