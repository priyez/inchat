package com.facebook.rti.push.service;

import com.facebook.rti.p078b.p096g.p098b.C0677w;
import java.util.ArrayList;

/* renamed from: com.facebook.rti.push.service.m */
final class C0743m extends ArrayList {
    final /* synthetic */ FbnsService f3183a;

    C0743m(FbnsService fbnsService) {
        this.f3183a = fbnsService;
        add(new C0677w("/fbns_reg_resp", 1));
        add(new C0677w("/fbns_msg", 1));
    }
}
