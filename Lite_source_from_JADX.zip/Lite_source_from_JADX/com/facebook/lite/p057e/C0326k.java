package com.facebook.lite.p057e;

/* renamed from: com.facebook.lite.e.k */
public interface C0326k {
    void m2281a(C0320a c0320a);
}
