package com.facebook.lite.widget;

import android.content.Context;
import android.view.OrientationEventListener;

final class af extends OrientationEventListener {
    final /* synthetic */ PhotoView f2034a;

    af(PhotoView photoView, Context context) {
        this.f2034a = photoView;
        super(context);
    }

    public final void onOrientationChanged(int i) {
        int a = this.f2034a.f1972N;
        if ((i >= 340 && i <= 360) || (i >= 0 && i <= 20)) {
            a = ah.f2038c;
        } else if (i >= 70 && i <= 110) {
            a = ah.f2036a;
        } else if (i >= 250 && i <= 290) {
            a = ah.f2037b;
        }
        if (a != this.f2034a.f1972N) {
            this.f2034a.f1972N = a;
            if (this.f2034a.getVisibility() == 0) {
                switch (ag.f2035a[this.f2034a.f1972N - 1]) {
                    case 1:
                        this.f2034a.m3249a((float) (-this.f2034a.f1964F), true);
                        this.f2034a.f1964F = 0;
                        if (this.f2034a.f1994r != null) {
                            this.f2034a.f1994r.m1928b();
                        }
                    case 2:
                        this.f2034a.m3249a((float) (90 - this.f2034a.f1964F), true);
                        this.f2034a.f1964F = 90;
                    case 3:
                        this.f2034a.m3249a((float) (-90 - this.f2034a.f1964F), true);
                        this.f2034a.f1964F = -90;
                    default:
                        throw new IllegalStateException("Invalid Phone Orientation");
                }
            }
        }
    }
}
