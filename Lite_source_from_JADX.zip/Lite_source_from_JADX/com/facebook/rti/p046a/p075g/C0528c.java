package com.facebook.rti.p046a.p075g;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Build.VERSION;

/* renamed from: com.facebook.rti.a.g.c */
public abstract class C0528c {
    public static final C0528c f2215a;

    public abstract SharedPreferences m3347a(Context context, String str, boolean z);

    static {
        if (VERSION.SDK_INT >= 11) {
            f2215a = new C0529a();
        } else {
            f2215a = new C0530b();
        }
    }

    public final SharedPreferences m3346a(Context context, String str) {
        return m3347a(context, str, false);
    }

    public static void m3345a(Editor editor) {
        editor.apply();
    }
}
