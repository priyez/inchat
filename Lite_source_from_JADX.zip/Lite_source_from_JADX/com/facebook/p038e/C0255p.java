package com.facebook.p038e;

import android.content.Context;
import android.util.Log;
import com.facebook.lite.p056d.C0313f;
import java.io.DataOutputStream;
import java.io.OutputStream;
import java.util.concurrent.atomic.AtomicBoolean;

/* renamed from: com.facebook.e.p */
public final class C0255p {
    private static final String f940a;
    private static final C0255p f941b;
    private final AtomicBoolean f942c;
    private final String f943d;

    static {
        f940a = C0255p.class.getSimpleName();
        f941b = new C0255p();
    }

    private C0255p() {
        this.f942c = new AtomicBoolean(false);
        this.f943d = "logfile";
    }

    public static C0255p m1686a() {
        return f941b;
    }

    public final boolean m1687a(Context context, C0249i c0249i) {
        DataOutputStream dataOutputStream;
        boolean z = false;
        try {
            String c0209b = C0250j.m1671a(c0249i).toString();
            int e = C0313f.m2224b(context).m2230e();
            this.f942c.set(false);
            synchronized (this) {
                try {
                    OutputStream openFileOutput = context.openFileOutput(this.f943d, 32768);
                    if (openFileOutput.getChannel().size() > ((long) e)) {
                        openFileOutput.close();
                        openFileOutput = context.openFileOutput(this.f943d, 0);
                    }
                    dataOutputStream = new DataOutputStream(openFileOutput);
                    dataOutputStream.writeUTF(c0209b);
                    dataOutputStream.close();
                    z = true;
                } catch (Throwable e2) {
                    Log.e(f940a, "Exception when writing offline log ", e2);
                } catch (Throwable th) {
                    dataOutputStream.close();
                }
            }
        } catch (Throwable e22) {
            Log.e(f940a, "Exception when serializing event", e22);
        }
        return z;
    }
}
