package com.facebook.lite.net;

import com.p008a.p009a.p010a.p015g.C0023a;
import com.p008a.p009a.p010a.p023m.C0114f;

/* renamed from: com.facebook.lite.net.a */
final class C0395a implements C0023a {
    private C0395a() {
    }

    public final void m2732c() {
    }

    public final void m2733d() {
    }

    public final void m2734e() {
    }

    public final void m2735f() {
    }

    public final void m2731a(boolean z, boolean z2, byte b) {
    }

    public final void m2736g() {
    }

    public final void m2729a(int i, C0114f c0114f) {
    }

    public final void m2737p() {
    }

    public final void m2738t() {
    }

    public final void m2730a(int i, boolean z, String str, int i2, byte[] bArr) {
    }
}
