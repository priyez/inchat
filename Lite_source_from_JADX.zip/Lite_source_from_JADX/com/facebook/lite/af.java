package com.facebook.lite;

import com.facebook.lite.p057e.C0323d;
import com.facebook.lite.p057e.C0329i;
import com.p008a.p009a.p010a.p023m.C0099a;

final class af implements Runnable {
    final /* synthetic */ int f1122a;
    final /* synthetic */ String f1123b;
    final /* synthetic */ String f1124c;
    final /* synthetic */ String f1125d;
    final /* synthetic */ int f1126e;
    final /* synthetic */ boolean f1127f;
    final /* synthetic */ int f1128g;
    final /* synthetic */ int f1129h;
    final /* synthetic */ int f1130i;
    final /* synthetic */ int f1131j;
    final /* synthetic */ String f1132k;
    final /* synthetic */ String f1133l;
    final /* synthetic */ C0329i f1134m;
    final /* synthetic */ boolean f1135n;
    final /* synthetic */ int f1136o;
    final /* synthetic */ short f1137p;
    final /* synthetic */ String f1138q;
    final /* synthetic */ C0099a f1139r;
    final /* synthetic */ C0099a f1140s;
    final /* synthetic */ C0099a f1141t;
    final /* synthetic */ String f1142u;
    final /* synthetic */ Long f1143v;
    final /* synthetic */ C0323d f1144w;
    final /* synthetic */ MainActivity f1145x;

    af(MainActivity mainActivity, int i, String str, String str2, String str3, int i2, boolean z, int i3, int i4, int i5, int i6, String str4, String str5, C0329i c0329i, boolean z2, int i7, short s, String str6, C0099a c0099a, C0099a c0099a2, C0099a c0099a3, String str7, Long l, C0323d c0323d) {
        this.f1145x = mainActivity;
        this.f1122a = i;
        this.f1123b = str;
        this.f1124c = str2;
        this.f1125d = str3;
        this.f1126e = i2;
        this.f1127f = z;
        this.f1128g = i3;
        this.f1129h = i4;
        this.f1130i = i5;
        this.f1131j = i6;
        this.f1132k = str4;
        this.f1133l = str5;
        this.f1134m = c0329i;
        this.f1135n = z2;
        this.f1136o = i7;
        this.f1137p = s;
        this.f1138q = str6;
        this.f1139r = c0099a;
        this.f1140s = c0099a2;
        this.f1141t = c0099a3;
        this.f1142u = str7;
        this.f1143v = l;
        this.f1144w = c0323d;
    }

    public final void run() {
        this.f1145x.f978j.m3222a(this.f1122a, this.f1123b, this.f1124c, this.f1126e, this.f1127f, this.f1128g, this.f1129h, this.f1130i, this.f1131j, this.f1132k, this.f1133l, this.f1134m, this.f1135n, this.f1136o, this.f1137p, this.f1138q, this.f1139r, this.f1140s, this.f1141t, this.f1142u, this.f1143v.longValue(), this.f1144w);
    }
}
