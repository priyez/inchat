package com.facebook.rti.p046a.p072e.p073a;

/* renamed from: com.facebook.rti.a.e.a.a */
final class C0525a extends C0524b {
    static final C0525a f2211a;

    static {
        f2211a = new C0525a();
    }

    private C0525a() {
    }

    public final boolean m3330a() {
        return false;
    }

    public final Object m3331b() {
        throw new IllegalStateException("Optional.get() cannot be called on an absent value");
    }

    public final boolean equals(Object obj) {
        return obj == this;
    }

    public final int hashCode() {
        return 1502476572;
    }

    public final String toString() {
        return "Optional.absent()";
    }
}
