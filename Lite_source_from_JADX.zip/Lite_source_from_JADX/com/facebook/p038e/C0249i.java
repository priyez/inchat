package com.facebook.p038e;

import com.facebook.p038e.p039a.C0207d;
import com.facebook.p038e.p039a.C0209b;
import com.facebook.p038e.p039a.C0210c;

/* renamed from: com.facebook.e.i */
public class C0249i {
    protected final C0209b f931a;
    protected String f932b;
    protected final String f933c;
    protected long f934d;

    private C0249i(String str) {
        this.f931a = new C0209b();
        this.f934d = System.currentTimeMillis();
        this.f933c = str;
    }

    public C0249i(String str, String str2) {
        this(str);
        this.f932b = str2;
    }

    public final C0249i m1666a(String str, String str2) {
        this.f931a.m1513a(new C0210c(str), new C0210c(str2));
        return this;
    }

    public final C0249i m1663a(String str, double d) {
        this.f931a.m1513a(new C0210c(str), new C0210c(d));
        return this;
    }

    public final C0249i m1664a(String str, long j) {
        this.f931a.m1513a(new C0210c(str), new C0210c(j));
        return this;
    }

    public final C0249i m1667a(String str, boolean z) {
        this.f931a.m1513a(new C0210c(str), new C0210c(z));
        return this;
    }

    public final C0249i m1665a(String str, C0207d c0207d) {
        this.f931a.m1513a(new C0210c(str), c0207d);
        return this;
    }

    public final C0209b m1660a() {
        return this.f931a;
    }

    public final String m1668b() {
        return this.f932b;
    }

    public final String m1669c() {
        return this.f933c;
    }

    public final long m1670d() {
        return this.f934d;
    }

    public final C0249i m1661a(long j) {
        this.f934d = j;
        return this;
    }

    public final C0249i m1662a(String str) {
        return m1666a("pk", str);
    }

    public String toString() {
        return this.f933c + this.f931a;
    }
}
