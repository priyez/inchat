package com.facebook.p031b.p034c;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

/* renamed from: com.facebook.b.c.p */
final class C0169p implements HostnameVerifier {
    final /* synthetic */ C0170q f644a;

    C0169p(C0170q c0170q) {
        this.f644a = c0170q;
    }

    public final boolean verify(String str, SSLSession sSLSession) {
        return true;
    }
}
