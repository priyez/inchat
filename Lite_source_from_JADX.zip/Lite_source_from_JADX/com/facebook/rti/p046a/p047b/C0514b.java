package com.facebook.rti.p046a.p047b;

import android.content.Intent;
import java.util.ArrayList;

/* renamed from: com.facebook.rti.a.b.b */
final class C0514b {
    final Intent f2177a;
    final ArrayList f2178b;

    C0514b(Intent intent, ArrayList arrayList) {
        this.f2177a = intent;
        this.f2178b = arrayList;
    }
}
