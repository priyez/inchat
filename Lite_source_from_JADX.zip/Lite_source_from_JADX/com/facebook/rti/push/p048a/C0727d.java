package com.facebook.rti.push.p048a;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.text.TextUtils;
import com.facebook.rti.p046a.p074f.C0527a;
import com.facebook.rti.p078b.p080b.p091g.C0614b;
import com.facebook.rti.push.service.FbnsService;

/* renamed from: com.facebook.rti.push.a.d */
public final class C0727d {
    private static final String f3109a;
    private static final ServiceConnection f3110b;

    static {
        f3109a = C0727d.class.getSimpleName();
        f3110b = new C0726c();
    }

    private static void m3931a(Context context, String str, Class cls, C0614b c0614b) {
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("Missing appId");
        }
        String packageName = context.getPackageName();
        context.getPackageManager().setComponentEnabledSetting(new ComponentName(context, cls), 1, 1);
        C0527a.m3338b(f3109a, "%s is enabled: %b", r1.getShortClassName(), Boolean.valueOf(true));
        Intent intent = new Intent("com.facebook.rti.fbns.intent.REGISTER");
        ComponentName componentName = new ComponentName(packageName, FbnsService.class.getName());
        intent.setComponent(componentName);
        intent.putExtra("pkg_name", context.getPackageName());
        intent.putExtra("appid", str);
        if (c0614b.m3522a(intent, componentName) == null) {
            C0527a.m3344f(f3109a, "Missing %s", cls.getCanonicalName());
        }
    }

    public static void m3930a(Context context, String str) {
        C0727d.m3931a(context, str, FbnsService.class, new C0614b(context));
    }

    private static void m3929a(Context context, Class cls, String str, boolean z, String str2) {
        if (z) {
            context.getPackageManager().setComponentEnabledSetting(new ComponentName(context, cls), 1, 1);
            C0527a.m3338b(f3109a, "%s is enabled: %b", r0.getShortClassName(), Boolean.valueOf(true));
        }
        ComponentName componentName = new ComponentName(context.getPackageName(), FbnsService.class.getName());
        Intent intent = new Intent(str2);
        intent.setComponent(componentName);
        if (str != null) {
            intent.putExtra("caller", str);
        }
        if (new C0614b(context).m3522a(intent, componentName) == null) {
            C0527a.m3343e(f3109a, "Missing %s", cls.getCanonicalName());
        }
    }

    public static void m3928a(Context context) {
        C0727d.m3929a(context, FbnsService.class, null, true, "Orca.START");
    }

    public static void m3932b(Context context, String str) {
        C0727d.m3929a(context, FbnsService.class, str, false, "Orca.START");
    }
}
