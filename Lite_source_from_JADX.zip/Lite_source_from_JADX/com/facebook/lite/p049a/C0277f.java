package com.facebook.lite.p049a;

import android.util.Log;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.p049a.p050a.C0261a;
import com.p008a.p009a.p010a.p012b.C0011a;
import com.p026b.p027a.C0132d;
import com.p026b.p027a.C0134f;

/* renamed from: com.facebook.lite.a.f */
final class C0277f extends C0263a {
    final /* synthetic */ C0280i f1054a;
    private final boolean f1055b;
    private final C0261a f1056c;
    private final int f1057d;
    private final int f1058e;
    private final C0134f f1059f;
    private final byte f1060g;
    private final boolean f1061h;

    public C0277f(C0280i c0280i, int i, long j, C0134f c0134f, C0261a c0261a, int i2, boolean z, boolean z2, byte b) {
        this.f1054a = c0280i;
        super(j);
        this.f1057d = i;
        this.f1059f = c0134f;
        this.f1058e = i2;
        this.f1061h = z;
        this.f1056c = c0261a;
        this.f1060g = b;
        this.f1055b = z2;
    }

    public final int m1868a(Object obj) {
        return m1821a() > ((C0277f) obj).m1821a() ? 1 : -1;
    }

    public final void run() {
        byte[] a = this.f1059f.m1264a();
        if (a == null || a.length == 0) {
            Log.e(C0280i.f1070a, C0280i.m1873a(this.f1056c.m1804b()) + "loadimage/failed:" + this.f1057d);
            this.f1059f.m1265b();
            ClientApplication.m1691c().m2387S().m2639N().m168a(new C0011a(92, this.f1057d));
            return;
        }
        ClientApplication.m1691c().m2387S().m2639N().m168a(C0011a.m74a(this.f1057d, a, this.f1058e, this.f1061h));
        this.f1056c.m1810h();
        this.f1056c.m1800a(a.length);
        C0280i.f1070a;
        new StringBuilder().append(C0280i.m1873a(this.f1056c.m1804b())).append("stats/hit:").append(this.f1056c.m1807e()).append(" , byte saved:").append(this.f1056c.m1805c());
        C0261a c0261a = (C0261a) this.f1054a.f1075f.get(Byte.valueOf(this.f1060g));
        if (this.f1055b && this.f1054a.f1074e && c0261a != null && this.f1056c.m1804b() != this.f1060g) {
            try {
                C0132d a2 = c0261a.m1806d().m1289a(Integer.toString(this.f1057d));
                if (a2 != null) {
                    a2.m1248a(a);
                    a2.m1249b();
                    try {
                        this.f1056c.m1806d().m1294c(Integer.toString(this.f1057d));
                        C0280i.f1070a;
                        new StringBuilder().append(C0280i.m1873a(c0261a.m1804b())).append("transferfiletask success from: ").append(this.f1056c.m1804b()).append(" fileId: ").append(this.f1057d);
                    } catch (Throwable e) {
                        Log.e(C0280i.f1070a, C0280i.m1873a(c0261a.m1804b()) + "transferfiletask/could not remove " + this.f1057d, e);
                    }
                }
            } catch (Throwable e2) {
                Log.e(C0280i.f1070a, C0280i.m1873a(c0261a.m1804b()) + "transferfiletask/could not write " + this.f1057d, e2);
            }
        }
    }
}
