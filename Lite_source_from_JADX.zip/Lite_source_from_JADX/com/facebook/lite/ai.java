package com.facebook.lite;

final class ai implements Runnable {
    final /* synthetic */ MainActivity f1154a;

    ai(MainActivity mainActivity) {
        this.f1154a = mainActivity;
    }

    public final void run() {
        this.f1154a.f973e.clearAnimation();
        this.f1154a.f973e.setVisibility(8);
    }
}
