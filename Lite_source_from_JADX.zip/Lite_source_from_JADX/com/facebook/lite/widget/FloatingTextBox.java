package com.facebook.lite.widget;

import android.content.Context;
import android.text.InputFilter;
import android.text.InputFilter.LengthFilter;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.ap;
import com.facebook.lite.as;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p053b.C0302p;

public class FloatingTextBox extends RelativeLayout {
    private static final InputFilter[] f1905a;
    private final LayoutParams f1906b;
    private final StringBuilder f1907c;
    private final RelativeLayout f1908d;
    private final EditText f1909e;
    private final TextView f1910f;
    private final RelativeLayout f1911g;
    private final RelativeLayout f1912h;
    private boolean f1913i;
    private final LayoutParams f1914j;

    static {
        f1905a = new InputFilter[0];
    }

    public FloatingTextBox(Context context) {
        this(context, null);
    }

    public FloatingTextBox(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1906b = new LayoutParams(-1, -1);
        this.f1914j = new LayoutParams(-1, -2);
        ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(ap.floating_textbox, this, true);
        this.f1908d = (RelativeLayout) findViewById(as.floating_textbox_container);
        this.f1912h = (RelativeLayout) findViewById(as.floating_textbox_wrapper);
        this.f1911g = (RelativeLayout) findViewById(as.floating_textbox_tool_bar);
        this.f1909e = (EditText) findViewById(as.floating_textbox_edit_text);
        this.f1910f = (TextView) findViewById(as.floating_textbox_right_button);
        this.f1909e.setOnFocusChangeListener(new C0484o(this, context));
        this.f1909e.setOnEditorActionListener(new C0485p(this, context));
        this.f1909e.setMinLines(1);
        this.f1910f.setOnClickListener(new C0486q(this, context));
        this.f1907c = new StringBuilder();
    }

    public FloatingTextBox(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet);
    }

    public final void m3184a() {
        this.f1907c.setLength(0);
    }

    public boolean dispatchKeyEventPreIme(KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() != 4) {
            return super.dispatchKeyEventPreIme(keyEvent);
        }
        if (getKeyDispatcherState() == null || keyEvent.getAction() != 0 || keyEvent.getRepeatCount() != 0) {
            return super.dispatchKeyEventPreIme(keyEvent);
        }
        this.f1907c.append(this.f1909e.getText().toString());
        return true;
    }

    public final void m3187b() {
        C0294h.m1954a(getContext(), this.f1909e);
        setVisibility(8);
    }

    public final boolean m3186a(MotionEvent motionEvent) {
        if (!C0294h.m1959a(motionEvent, this.f1912h) || C0294h.m1959a(motionEvent, this.f1909e)) {
            return true;
        }
        return false;
    }

    private boolean m3182d() {
        if (m3189c() && C0294h.m1949a((float) (this.f1908d.getRootView().getHeight() - this.f1908d.getHeight()), getContext()) > 100.0f) {
            return true;
        }
        return false;
    }

    public final boolean m3188b(MotionEvent motionEvent) {
        return this.f1913i && m3182d() && !C0294h.m1959a(motionEvent, this.f1909e) && !C0294h.m1959a(motionEvent, this.f1910f) && motionEvent.getAction() == 1;
    }

    public final boolean m3189c() {
        return getVisibility() == 0;
    }

    public final void m3185a(int i, String str, String str2, int i2) {
        boolean z = true;
        int i3 = 0;
        this.f1909e.requestFocus();
        if (!m3189c()) {
            boolean z2;
            boolean z3;
            setVisibility(0);
            if (i2 > 0) {
                this.f1909e.setFilters(new InputFilter[]{new LengthFilter(i2)});
            } else {
                this.f1909e.setFilters(f1905a);
            }
            this.f1910f.setText(str2);
            int i4 = ((15728640 & i) >>> 20) | (i & 240);
            if ((i & 1024) > 0) {
                i4 |= 16384;
            }
            switch (i & 768) {
                case 0:
                    i4 |= 32768;
                    break;
                case 512:
                    i4 |= 32768;
                    break;
                case 768:
                    break;
            }
            i4 |= 524288;
            this.f1909e.setInputType(i4);
            this.f1909e.setImeOptions(i & 15);
            int i5 = i & 251658240;
            this.f1913i = (983040 & i) == 65536;
            if (i5 == 33554432) {
                z2 = true;
            } else {
                z2 = false;
            }
            if (i5 == 67108864) {
                z3 = true;
            } else {
                z3 = false;
            }
            this.f1909e.setSingleLine(z2);
            EditText editText = this.f1909e;
            i5 = z3 ? Integer.MAX_VALUE : z2 ? 1 : 4;
            editText.setMaxLines(i5);
            if (C0302p.m2177b(this.f1907c)) {
                this.f1909e.setText(str);
            } else {
                this.f1909e.setText(this.f1907c);
                m3184a();
            }
            this.f1909e.setLayoutParams(z3 ? this.f1906b : this.f1914j);
            this.f1909e.setGravity(z2 ? 16 : 48);
            EditText editText2 = this.f1909e;
            if (z2) {
                z = false;
            }
            editText2.setVerticalScrollBarEnabled(z);
            if (this.f1909e.getText() != null) {
                this.f1909e.setSelection(this.f1909e.getText().length());
            }
            RelativeLayout relativeLayout = this.f1911g;
            if ((61440 & i) == 0) {
                i3 = 8;
            }
            relativeLayout.setVisibility(i3);
        }
    }

    private void m3183e() {
        ClientApplication.m1691c().m2448g(this.f1909e.getText().toString());
        setVisibility(8);
        this.f1909e.clearComposingText();
    }
}
