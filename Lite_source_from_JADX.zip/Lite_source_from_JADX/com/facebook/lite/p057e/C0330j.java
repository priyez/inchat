package com.facebook.lite.p057e;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import com.p008a.p009a.p010a.p014e.C0022b;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/* renamed from: com.facebook.lite.e.j */
public final class C0330j extends SQLiteOpenHelper {
    private final C0022b f1298a;

    public final java.util.List m2311b(java.lang.String r9, java.util.List r10, java.lang.String r11) {
        /* JADX: method processing error */
/*
        Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find block by offset: 0x0096 in list []
	at jadx.core.utils.BlockUtils.getBlockByOffset(BlockUtils.java:42)
	at jadx.core.dex.instructions.IfNode.initBlocks(IfNode.java:58)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.initBlocksInIfNodes(BlockFinish.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.visit(BlockFinish.java:33)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:281)
	at jadx.api.JavaClass.decompile(JavaClass.java:59)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:161)
*/
        /*
        r8 = this;
        r4 = 285; // 0x11d float:4.0E-43 double:1.41E-321;
        r3 = 1;
        r2 = 0;
        r0 = 0;
        r8.m2301b(r9, r10, r0);	 Catch:{ IllegalArgumentException -> 0x0017 }
        r1 = r8.m2300b(r9);
        r0 = r1.size();
        if (r3 < r0) goto L_0x0022;
    L_0x0012:
        r0 = java.util.Collections.emptyList();
    L_0x0016:
        return r0;
    L_0x0017:
        r0 = move-exception;
        r1 = r8.f1298a;
        r1.m124a(r4, r2, r0);
        r0 = java.util.Collections.emptyList();
        goto L_0x0016;
    L_0x0022:
        r0 = r8.getReadableDatabase();
        r2 = r1.size();
        r2 = new java.lang.String[r2];
        r2 = r1.toArray(r2);
        r2 = (java.lang.String[]) r2;
        r1 = r1.get(r3);
        r1 = (java.lang.String) r1;
        r3 = new java.lang.StringBuilder;	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r3.<init>();	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r1 = r3.append(r1);	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r3 = " LIKE ?";	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r1 = r1.append(r3);	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r3 = r1.toString();	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r1 = 1;	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r4 = new java.lang.String[r1];	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r1 = 0;	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r5 = new java.lang.StringBuilder;	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r5.<init>();	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r5 = r5.append(r11);	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r6 = "%";	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r5 = r5.append(r6);	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r5 = r5.toString();	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r4[r1] = r5;	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r5 = 0;	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r6 = 0;	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r7 = 0;	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r1 = r9;	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r1 = r0.query(r1, r2, r3, r4, r5, r6, r7);	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        if (r1 != 0) goto L_0x0073;
    L_0x006e:
        if (r0 == 0) goto L_0x0073;
    L_0x0070:
        r0.close();
    L_0x0073:
        r2 = com.facebook.lite.p057e.C0330j.m2299a(r1, r10);
        r1.close();
        if (r0 == 0) goto L_0x007f;
    L_0x007c:
        r0.close();
    L_0x007f:
        r0 = java.util.Collections.unmodifiableList(r2);
        goto L_0x0016;
    L_0x0084:
        r1 = move-exception;
        r2 = r8.f1298a;	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r3 = 285; // 0x11d float:4.0E-43 double:1.41E-321;	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r4 = 0;	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r2.m124a(r3, r4, r1);	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        r1 = java.util.Collections.emptyList();	 Catch:{ SQLiteException -> 0x0084, all -> 0x0099 }
        if (r0 == 0) goto L_0x0096;
    L_0x0093:
        r0.close();
    L_0x0096:
        r0 = r1;
        goto L_0x0016;
    L_0x0099:
        r1 = move-exception;
        if (r0 == 0) goto L_0x009f;
    L_0x009c:
        r0.close();
    L_0x009f:
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.e.j.b(java.lang.String, java.util.List, java.lang.String):java.util.List");
    }

    public C0330j(Context context, C0022b c0022b, String str) {
        super(context, str, null, 1);
        this.f1298a = c0022b;
    }

    public final void m2309a(String str, List list, List list2, List list3) {
        Throwable e;
        try {
            m2301b(str, list, list2);
            if (list.size() <= 0) {
                this.f1298a.m126a((short) 2, (short) 285, "Delete search field number is not valid, the number is 0, but should be less than " + list.size());
            } else if (list3.size() != list2.size()) {
                this.f1298a.m126a((short) 2, (short) 285, "Option size is not valid, the number is " + list3.size() + ", but should be " + list3.size());
            } else {
                List b = m2300b(str);
                SQLiteDatabase writableDatabase = getWritableDatabase();
                try {
                    writableDatabase.beginTransaction();
                    for (int i = 0; i < list2.size(); i++) {
                        List list4 = (List) list2.get(i);
                        if (((Boolean) list3.get(i)).booleanValue()) {
                            writableDatabase.insertWithOnConflict(str, null, C0330j.m2297a(b, list, list4), 5);
                        } else {
                            writableDatabase.delete(str, ((String) b.get(0)) + " = ?", new String[]{list4.get(0).toString()});
                        }
                    }
                    writableDatabase.setTransactionSuccessful();
                    writableDatabase.endTransaction();
                } catch (SQLiteException e2) {
                    e = e2;
                    try {
                        this.f1298a.m124a((short) 285, null, e);
                        if (writableDatabase == null) {
                            writableDatabase.close();
                        }
                    } finally {
                        writableDatabase.endTransaction();
                    }
                } catch (ClassCastException e3) {
                    e = e3;
                    this.f1298a.m124a((short) 285, null, e);
                    if (writableDatabase == null) {
                        writableDatabase.close();
                    }
                }
                if (writableDatabase == null) {
                    writableDatabase.close();
                }
            }
        } catch (Throwable e4) {
            this.f1298a.m124a((short) 285, null, e4);
        }
    }

    public final void m2308a(String str) {
        if (m2304d(str)) {
            SQLiteDatabase writableDatabase = getWritableDatabase();
            try {
                writableDatabase.delete(str, null, null);
            } catch (Throwable e) {
                this.f1298a.m124a((short) 285, null, e);
            } finally {
                writableDatabase.close();
            }
        }
    }

    private static ContentValues m2297a(List list, List list2, List list3) {
        ContentValues contentValues = new ContentValues();
        for (int i = 0; i < list2.size(); i++) {
            switch (((Byte) list2.get(i)).byteValue()) {
                case (byte) 2:
                    contentValues.put((String) list.get(i), Integer.valueOf(((Integer) list3.get(i)).intValue()));
                    break;
                case (byte) 3:
                    contentValues.put((String) list.get(i), Long.valueOf(((Long) list3.get(i)).longValue()));
                    break;
                case (byte) 4:
                    contentValues.put((String) list.get(i), Float.valueOf(((Float) list3.get(i)).floatValue()));
                    break;
                case (byte) 5:
                    contentValues.put((String) list.get(i), Double.valueOf(((Double) list3.get(i)).doubleValue()));
                    break;
                case (byte) 6:
                    contentValues.put((String) list.get(i), (String) list3.get(i));
                    break;
                default:
                    break;
            }
        }
        return contentValues;
    }

    public final boolean m2310a(String str, List list, List list2) {
        return m2312b(str, list, list2, Arrays.asList(new Integer[]{Integer.valueOf(0)}));
    }

    public final boolean m2312b(String str, List list, List list2, List list3) {
        Throwable e;
        SQLiteDatabase writableDatabase = getWritableDatabase();
        boolean z = true;
        try {
            writableDatabase.execSQL(C0330j.m2302c(str, list, list2, list3));
            if (writableDatabase != null) {
                writableDatabase.close();
            }
        } catch (IllegalArgumentException e2) {
            e = e2;
            try {
                this.f1298a.m124a((short) 285, null, e);
                z = false;
                if (writableDatabase != null) {
                    writableDatabase.close();
                }
                return z;
            } catch (Throwable th) {
                if (writableDatabase != null) {
                    writableDatabase.close();
                }
            }
        } catch (SQLiteException e3) {
            e = e3;
            this.f1298a.m124a((short) 285, null, e);
            z = false;
            if (writableDatabase != null) {
                writableDatabase.close();
            }
            return z;
        }
        return z;
    }

    public final List m2306a(String str, List list) {
        try {
            m2301b(str, list, null);
            String str2 = "SELECT  * FROM '" + str + "'";
            SQLiteDatabase writableDatabase = getWritableDatabase();
            Cursor rawQuery = writableDatabase.rawQuery(str2, null);
            List a = C0330j.m2299a(rawQuery, list);
            rawQuery.close();
            if (writableDatabase != null) {
                writableDatabase.close();
            }
            return Collections.unmodifiableList(a);
        } catch (C0331l e) {
            return Collections.emptyList();
        } catch (Throwable e2) {
            this.f1298a.m124a((short) 285, null, e2);
            return Collections.emptyList();
        }
    }

    public final List m2307a(String str, List list, String str2) {
        try {
            m2301b(str, list, null);
            List b = m2300b(str);
            if (b.size() <= 0) {
                return Collections.emptyList();
            }
            SQLiteDatabase readableDatabase = getReadableDatabase();
            try {
                Cursor rawQuery = readableDatabase.rawQuery("SELECT  * FROM '" + str + "' WHERE " + ((String) b.get(0)) + " =?", new String[]{str2});
                if (rawQuery == null) {
                    b = Collections.emptyList();
                } else {
                    b = C0330j.m2299a(rawQuery, list);
                    rawQuery.close();
                }
                if (readableDatabase != null) {
                    readableDatabase.close();
                }
                return Collections.unmodifiableList(b);
            } catch (Throwable e) {
                this.f1298a.m124a((short) 285, null, e);
                b = Collections.emptyList();
                Collections.emptyList();
                if (readableDatabase == null) {
                    return b;
                }
                readableDatabase.close();
                return b;
            } catch (Throwable th) {
                Collections.emptyList();
                if (readableDatabase != null) {
                    readableDatabase.close();
                }
            }
        } catch (Throwable e2) {
            this.f1298a.m124a((short) 285, null, e2);
            return Collections.emptyList();
        }
    }

    private List m2300b(String str) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor rawQuery = readableDatabase.rawQuery("PRAGMA table_info('" + str + "')", null);
        List arrayList = new ArrayList();
        if (rawQuery.moveToFirst()) {
            do {
                arrayList.add(rawQuery.getString(rawQuery.getColumnIndex("name")));
            } while (rawQuery.moveToNext());
        }
        if (rawQuery != null) {
            rawQuery.close();
        }
        if (readableDatabase != null) {
            readableDatabase.close();
        }
        return arrayList;
    }

    private List m2303c(String str) {
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor rawQuery = readableDatabase.rawQuery("PRAGMA table_info('" + str + "')", null);
        List arrayList = new ArrayList();
        if (rawQuery.moveToFirst()) {
            do {
                arrayList.add(rawQuery.getString(rawQuery.getColumnIndex("type")));
            } while (rawQuery.moveToNext());
        }
        if (rawQuery != null) {
            rawQuery.close();
        }
        if (readableDatabase != null) {
            readableDatabase.close();
        }
        return arrayList;
    }

    private boolean m2304d(String str) {
        boolean z = false;
        SQLiteDatabase readableDatabase = getReadableDatabase();
        try {
            Cursor rawQuery = readableDatabase.rawQuery(C0330j.m2305e(str), null);
            if (rawQuery == null && readableDatabase != null) {
                readableDatabase.close();
            }
            if (rawQuery != null && rawQuery.getCount() > 0) {
                z = true;
                rawQuery.close();
            }
            if (readableDatabase != null) {
                readableDatabase.close();
            }
        } catch (Throwable e) {
            this.f1298a.m124a((short) 285, null, e);
            if (readableDatabase != null) {
                readableDatabase.close();
            }
        } catch (Throwable th) {
            if (readableDatabase != null) {
                readableDatabase.close();
            }
        }
        return z;
    }

    public final void onCreate(SQLiteDatabase sQLiteDatabase) {
    }

    public final void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
    }

    private static String m2298a(byte b) {
        switch (b) {
            case (byte) 2:
                return "INTEGER";
            case (byte) 3:
                return "INTEGER";
            case (byte) 4:
                return "REAL";
            case (byte) 5:
                return "REAL";
            case (byte) 6:
                return "TEXT";
            default:
                throw new IllegalArgumentException("Field Type must be correct");
        }
    }

    private void m2301b(String str, List list, List list2) {
        if (m2304d(str)) {
            if (list != null) {
                List c = m2303c(str);
                if (list.size() != c.size()) {
                    throw new IllegalArgumentException("FieldType size not valid, actual size is " + c.size() + ", but have " + list.size());
                }
                int i = 0;
                while (i < list.size()) {
                    if (C0330j.m2298a(((Byte) list.get(i)).byteValue()).equals(c.get(i))) {
                        i++;
                    } else {
                        throw new IllegalArgumentException("Entry type not valid, the actual type should be " + ((String) c.get(i)) + ", but have " + list.get(i));
                    }
                }
            }
            List b = m2300b(str);
            if (list2 != null) {
                for (List list3 : list2) {
                    if (list3 != null && b.size() != list3.size()) {
                        throw new IllegalArgumentException("Entry size not valid, actural size is " + b.size() + " but have " + list3.size());
                    }
                }
                return;
            }
            return;
        }
        throw new C0331l("Table " + str + " doesn't exist");
    }

    private static String m2305e(String str) {
        return new StringBuilder("SELECT DISTINCT tbl_name from sqlite_master where tbl_name = '" + str + '\'').toString();
    }

    private static String m2302c(String str, List list, List list2, List list3) {
        StringBuilder stringBuilder = new StringBuilder("CREATE TABLE IF NOT EXISTS '" + str + "'(");
        for (int i = 0; i < list.size(); i++) {
            String a = C0330j.m2298a(((Byte) list2.get(i)).byteValue());
            stringBuilder.append((String) list.get(i));
            stringBuilder.append(' ');
            stringBuilder.append(a);
            stringBuilder.append(',');
        }
        if (list3.isEmpty()) {
            stringBuilder.setCharAt(stringBuilder.length() - 1, ')');
        } else {
            stringBuilder.append("PRIMARY KEY (");
            for (Integer intValue : list3) {
                int intValue2 = intValue.intValue();
                if (intValue2 < list.size()) {
                    stringBuilder.append((String) list.get(intValue2));
                    stringBuilder.append(',');
                } else {
                    throw new IllegalArgumentException("Invalid Primary Key, index of primary key should be less than " + list.size() + " but have " + intValue2);
                }
            }
            stringBuilder.setCharAt(stringBuilder.length() - 1, ')');
            stringBuilder.append(')');
        }
        return stringBuilder.toString();
    }

    private static List m2299a(Cursor cursor, List list) {
        List arrayList = new ArrayList();
        if (cursor.moveToFirst()) {
            do {
                List arrayList2 = new ArrayList();
                for (int i = 0; i < list.size(); i++) {
                    switch (((Byte) list.get(i)).byteValue()) {
                        case (byte) 2:
                            arrayList2.add(Integer.valueOf(cursor.getInt(i)));
                            break;
                        case (byte) 3:
                            arrayList2.add(Long.valueOf(cursor.getLong(i)));
                            break;
                        case (byte) 4:
                            arrayList2.add(Float.valueOf(cursor.getFloat(i)));
                            break;
                        case (byte) 5:
                            arrayList2.add(Double.valueOf(cursor.getDouble(i)));
                            break;
                        case (byte) 6:
                            arrayList2.add(cursor.getString(i));
                            break;
                        default:
                            break;
                    }
                }
                arrayList.add(arrayList2);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return arrayList;
    }
}
