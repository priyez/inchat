package com.facebook.lite;

import android.view.View;
import android.view.View.OnClickListener;
import com.facebook.lite.widget.ae;

/* renamed from: com.facebook.lite.z */
final class C0496z implements OnClickListener {
    final /* synthetic */ ae f2121a;
    final /* synthetic */ MainActivity f2122b;

    C0496z(MainActivity mainActivity, ae aeVar) {
        this.f2122b = mainActivity;
        this.f2121a = aeVar;
    }

    public final void onClick(View view) {
        this.f2122b.m1737a(this.f2121a);
    }
}
