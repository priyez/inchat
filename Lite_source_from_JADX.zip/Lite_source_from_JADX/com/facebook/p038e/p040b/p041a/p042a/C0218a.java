package com.facebook.p038e.p040b.p041a.p042a;

import android.content.Context;
import com.facebook.lite.p049a.p052c.C0267a;
import com.facebook.lite.p049a.p052c.C0269c;
import com.facebook.p038e.C0251k;
import com.facebook.p038e.C0253n;
import com.facebook.p038e.p040b.p041a.C0215a;
import com.facebook.p038e.p040b.p041a.C0220b;
import java.util.EnumMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/* renamed from: com.facebook.e.b.a.a.a */
public final class C0218a extends C0215a {
    private final Map f829a;
    private final Map f830b;
    private final Map f831c;

    public C0218a(Context context) {
        super("cache_stats", C0253n.MUST_HAVE);
        this.f829a = new EnumMap(C0269c.class);
        this.f830b = new EnumMap(C0269c.class);
        this.f831c = new EnumMap(C0269c.class);
        this.f830b.put(C0269c.DISK, new EnumMap(C0267a.class));
        ((EnumMap) this.f830b.get(C0269c.DISK)).put(C0267a.NONE, new C0220b(context, "disk_cache_hit"));
        ((EnumMap) this.f830b.get(C0269c.DISK)).put(C0267a.SMALL, new C0220b(context, "disk_cache_hit_s"));
        ((EnumMap) this.f830b.get(C0269c.DISK)).put(C0267a.MEDIUM, new C0220b(context, "disk_cache_hit_m"));
        ((EnumMap) this.f830b.get(C0269c.DISK)).put(C0267a.LARGE, new C0220b(context, "disk_cache_hit_l"));
        this.f830b.put(C0269c.MEM, new EnumMap(C0267a.class));
        ((EnumMap) this.f830b.get(C0269c.MEM)).put(C0267a.NONE, new C0220b(context, "mem_cache_hit"));
        ((EnumMap) this.f830b.get(C0269c.MEM)).put(C0267a.SMALL, new C0220b(context, "mem_cache_hit_s"));
        ((EnumMap) this.f830b.get(C0269c.MEM)).put(C0267a.MEDIUM, new C0220b(context, "mem_cache_hit_m"));
        ((EnumMap) this.f830b.get(C0269c.MEM)).put(C0267a.LARGE, new C0220b(context, "mem_cache_hit_l"));
        this.f831c.put(C0269c.DISK, new EnumMap(C0267a.class));
        ((EnumMap) this.f831c.get(C0269c.DISK)).put(C0267a.NONE, new C0220b(context, "disk_cache_miss"));
        ((EnumMap) this.f831c.get(C0269c.DISK)).put(C0267a.SMALL, new C0220b(context, "disk_cache_miss_s"));
        ((EnumMap) this.f831c.get(C0269c.DISK)).put(C0267a.MEDIUM, new C0220b(context, "disk_cache_miss_m"));
        ((EnumMap) this.f831c.get(C0269c.DISK)).put(C0267a.LARGE, new C0220b(context, "disk_cache_miss_l"));
        this.f831c.put(C0269c.MEM, new EnumMap(C0267a.class));
        ((EnumMap) this.f831c.get(C0269c.MEM)).put(C0267a.NONE, new C0220b(context, "mem_cache_miss"));
        ((EnumMap) this.f831c.get(C0269c.MEM)).put(C0267a.SMALL, new C0220b(context, "mem_cache_miss_s"));
        ((EnumMap) this.f831c.get(C0269c.MEM)).put(C0267a.MEDIUM, new C0220b(context, "mem_cache_miss_m"));
        ((EnumMap) this.f831c.get(C0269c.MEM)).put(C0267a.LARGE, new C0220b(context, "mem_cache_miss_l"));
        this.f829a.put(C0269c.DISK, new EnumMap(C0267a.class));
        ((EnumMap) this.f829a.get(C0269c.DISK)).put(C0267a.NONE, new C0220b(context, "disk_cache_evicted"));
        ((EnumMap) this.f829a.get(C0269c.DISK)).put(C0267a.SMALL, new C0220b(context, "disk_cache_evicted_s"));
        ((EnumMap) this.f829a.get(C0269c.DISK)).put(C0267a.MEDIUM, new C0220b(context, "disk_cache_evicted_m"));
        ((EnumMap) this.f829a.get(C0269c.DISK)).put(C0267a.LARGE, new C0220b(context, "disk_cache_evicted_l"));
        this.f829a.put(C0269c.MEM, new EnumMap(C0267a.class));
        ((EnumMap) this.f829a.get(C0269c.MEM)).put(C0267a.NONE, new C0220b(context, "mem_cache_evicted"));
        ((EnumMap) this.f829a.get(C0269c.MEM)).put(C0267a.SMALL, new C0220b(context, "mem_cache_evicted_s"));
        ((EnumMap) this.f829a.get(C0269c.MEM)).put(C0267a.MEDIUM, new C0220b(context, "mem_cache_evicted_m"));
        ((EnumMap) this.f829a.get(C0269c.MEM)).put(C0267a.LARGE, new C0220b(context, "mem_cache_evicted_l"));
    }

    public final C0220b[] m1541c() {
        List linkedList = new LinkedList();
        for (Object obj : C0269c.values()) {
            linkedList.addAll(((EnumMap) this.f831c.get(obj)).values());
            linkedList.addAll(((EnumMap) this.f830b.get(obj)).values());
            linkedList.addAll(((EnumMap) this.f829a.get(obj)).values());
        }
        return (C0220b[]) linkedList.toArray(new C0220b[linkedList.size()]);
    }

    public final void m1538a(C0269c c0269c, C0267a c0267a, int i) {
        ((C0220b) ((EnumMap) this.f829a.get(c0269c)).get(c0267a)).m1547a(i);
    }

    public final void m1539b(C0269c c0269c, C0267a c0267a, int i) {
        ((C0220b) ((EnumMap) this.f830b.get(c0269c)).get(c0267a)).m1547a(i);
    }

    public final void m1540c(C0269c c0269c, C0267a c0267a, int i) {
        ((C0220b) ((EnumMap) this.f831c.get(c0269c)).get(c0267a)).m1547a(i);
    }

    protected final void m1537a(C0251k c0251k) {
    }
}
