package com.facebook.lite.p057e;

import com.facebook.lite.ClientApplication;
import com.facebook.lite.p059m.C0387i;
import com.p008a.p009a.p010a.p014e.C0022b;
import java.util.ArrayList;
import java.util.List;

/* renamed from: com.facebook.lite.e.d */
public final class C0323d implements Runnable {
    private final C0326k f1277a;
    private final List f1278b;
    private C0387i f1279c;
    private C0022b f1280d;
    private volatile boolean f1281e;

    public C0323d(C0387i c0387i, C0022b c0022b) {
        this.f1278b = new ArrayList();
        this.f1279c = c0387i;
        this.f1280d = c0022b;
        this.f1277a = new C0327g();
    }

    public final void m2279a(C0320a c0320a) {
        synchronized (this.f1278b) {
            for (C0320a c0320a2 : this.f1278b) {
                if (c0320a2.m2271a() == c0320a.m2271a()) {
                    this.f1278b.remove(c0320a2);
                }
            }
            this.f1278b.add(c0320a);
            this.f1278b.notifyAll();
        }
    }

    public final void m2280b(C0320a c0320a) {
        synchronized (this.f1278b) {
            this.f1278b.add(c0320a);
            this.f1278b.notifyAll();
        }
    }

    private void m2277c(C0320a c0320a) {
        if (c0320a != null) {
            m2278d(c0320a);
        }
    }

    private void m2278d(C0320a c0320a) {
        switch (C0321b.f1272a[c0320a.m2271a() - 1]) {
            case 1:
                this.f1279c.m2666a(c0320a);
            case 2:
                ClientApplication.m1691c().m2379K().m2296a(c0320a);
            case 3:
                this.f1277a.m2281a(c0320a);
            default:
        }
    }

    public final void run() {
        this.f1281e = true;
        while (this.f1281e) {
            C0320a a;
            synchronized (this.f1278b) {
                do {
                    a = m2276a();
                    if (a != null) {
                        break;
                    }
                    try {
                        this.f1278b.wait();
                    } catch (InterruptedException e) {
                    }
                } while (this.f1278b.isEmpty());
            }
            m2277c(a);
        }
    }

    private C0320a m2276a() {
        if (this.f1278b.isEmpty()) {
            return null;
        }
        return (C0320a) this.f1278b.remove(0);
    }
}
