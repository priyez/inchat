package com.facebook.p038e.p039a;

/* renamed from: com.facebook.e.a.e */
public final class C0211e {
    public static boolean m1516a(Object obj) {
        if ((obj instanceof C0210c) || (obj instanceof C0208a) || (obj instanceof C0209b)) {
            return true;
        }
        return false;
    }

    public static StringBuilder m1515a(String str) {
        if (str == null) {
            return new StringBuilder("null");
        }
        return new StringBuilder("\"").append(C0211e.m1517b(str)).append("\"");
    }

    private static StringBuilder m1517b(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        for (char valueOf : str.toCharArray()) {
            Character valueOf2 = Character.valueOf(valueOf);
            if (Character.getType(valueOf2.charValue()) == 15) {
                stringBuilder.append(String.format("\\u%04x", new Object[]{Integer.valueOf(valueOf2.charValue())}));
            } else if (valueOf2.charValue() == '\\' || valueOf2.charValue() == '\"') {
                stringBuilder.append('\\').append(valueOf2);
            } else {
                stringBuilder.append(valueOf2);
            }
        }
        return stringBuilder;
    }
}
