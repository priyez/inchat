package com.facebook.lite.widget;

final class an implements Runnable {
    private long f2068a;
    private boolean f2069b;
    private boolean f2070c;
    private float f2071d;
    private float f2072e;
    private final PhotoView f2073f;

    public an(PhotoView photoView) {
        this.f2068a = -1;
        this.f2073f = photoView;
    }

    public final void run() {
        if (!this.f2070c) {
            long currentTimeMillis = System.currentTimeMillis();
            float f = this.f2068a != -1 ? ((float) (currentTimeMillis - this.f2068a)) / 1000.0f : 0.0f;
            boolean a = this.f2073f.m3232a(this.f2071d * f, this.f2072e * f);
            this.f2068a = currentTimeMillis;
            f *= 1000.0f;
            if (this.f2071d > 0.0f) {
                this.f2071d -= f;
                if (this.f2071d < 0.0f) {
                    this.f2071d = 0.0f;
                }
            } else {
                this.f2071d += f;
                if (this.f2071d > 0.0f) {
                    this.f2071d = 0.0f;
                }
            }
            if (this.f2072e > 0.0f) {
                this.f2072e -= f;
                if (this.f2072e < 0.0f) {
                    this.f2072e = 0.0f;
                }
            } else {
                this.f2072e = f + this.f2072e;
                if (this.f2072e > 0.0f) {
                    this.f2072e = 0.0f;
                }
            }
            if ((this.f2071d == 0.0f && this.f2072e == 0.0f) || !a) {
                m3281a();
                this.f2073f.m3240c(false);
            }
            if (!this.f2070c) {
                this.f2073f.post(this);
            }
        }
    }

    public final boolean m3282a(float f, float f2) {
        if (this.f2069b) {
            return false;
        }
        this.f2068a = -1;
        this.f2071d = f;
        this.f2072e = f2;
        this.f2070c = false;
        this.f2069b = true;
        this.f2073f.post(this);
        return true;
    }

    public final void m3281a() {
        this.f2069b = false;
        this.f2070c = true;
    }
}
