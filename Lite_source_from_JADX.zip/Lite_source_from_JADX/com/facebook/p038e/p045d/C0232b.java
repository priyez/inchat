package com.facebook.p038e.p045d;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Build.VERSION;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.Process;
import android.os.SystemClock;
import android.util.Log;
import android.util.SparseArray;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.json.JSONObject;

/* renamed from: com.facebook.e.d.b */
public class C0232b {
    private static final String f875a;
    private static long f876b;
    private static long f877c;
    private long f878d;
    private long f879e;
    private long f880f;
    private long f881g;
    private long f882h;
    private long f883i;
    private long f884j;
    private volatile C0231a f885k;
    private final Context f886l;
    private final boolean f887m;
    private final PackageManager f888n;

    static {
        f875a = C0232b.class.getSimpleName();
    }

    public C0232b(Context context) {
        this.f887m = true;
        this.f886l = context;
        this.f888n = this.f886l.getPackageManager();
        this.f885k = new C0231a();
    }

    private boolean m1596b() {
        if (VERSION.SDK_INT >= 9) {
            return true;
        }
        this.f885k.m1581a("Build is pre-gingerbread. Current version is " + VERSION.SDK_INT);
        return false;
    }

    public final synchronized C0231a m1603a() {
        if (m1596b()) {
            m1599c();
        }
        return this.f885k;
    }

    private double m1589a(JSONObject jSONObject, Class cls, Object obj, Class cls2, Object obj2, Class cls3, Object obj3, long j) {
        return m1588a(jSONObject, cls, obj, cls3, obj3, j) + ((((0.0d + m1586a(jSONObject, cls, cls3, obj3, obj)) + m1595b(jSONObject, cls, obj, cls3, obj3, j)) + m1587a(jSONObject, cls, obj, cls2, cls3, obj3, obj2)) + m1598c(jSONObject, cls, obj, cls3, obj3, j));
    }

    private void m1592a(JSONObject jSONObject, int i) {
        try {
            String[] packagesForUid = this.f888n.getPackagesForUid(i);
            if (packagesForUid != null && packagesForUid.length > 0) {
                PackageInfo packageInfo = this.f888n.getPackageInfo(packagesForUid[0], 0);
                if (packageInfo != null) {
                    jSONObject.put("version_name", packageInfo.versionName);
                }
            }
        } catch (Throwable th) {
            m1591a(th, "Unable to retrieve version number");
        }
    }

    private double m1586a(JSONObject jSONObject, Class cls, Class cls2, Object obj, Object obj2) {
        double d = 0.0d;
        try {
            int i;
            Object obj3 = obj;
            int intValue = ((Integer) cls2.getDeclaredMethod("getNumSpeedSteps", new Class[0]).invoke(obj3, new Object[0])).intValue();
            double[] dArr = new double[intValue];
            long[] jArr = new long[intValue];
            for (i = 0; i < intValue; i++) {
                Class cls3 = cls2;
                dArr[i] = ((Double) cls3.getDeclaredMethod("getAveragePower", new Class[]{String.class, Integer.TYPE}).invoke(obj, new Object[]{"cpu.active", Integer.valueOf(i)})).doubleValue();
            }
            Class cls4 = Class.forName("com.android.internal.os.BatteryStatsImpl$Uid$Proc");
            for (Entry entry : m1590a(cls, obj2).entrySet()) {
                int i2;
                JSONObject jSONObject2 = new JSONObject();
                Object value = entry.getValue();
                long longValue = 10 * ((Long) cls4.getDeclaredMethod("getUserTime", new Class[]{Integer.TYPE}).invoke(value, new Object[]{Integer.valueOf(0)})).longValue();
                long longValue2 = 10 * ((Long) cls4.getDeclaredMethod("getSystemTime", new Class[]{Integer.TYPE}).invoke(value, new Object[]{Integer.valueOf(0)})).longValue();
                ((Long) cls4.getDeclaredMethod("getForegroundTime", new Class[]{Integer.TYPE}).invoke(value, new Object[]{Integer.valueOf(0)})).longValue();
                longValue += longValue2;
                i = 0;
                JSONObject jSONObject3 = new JSONObject();
                for (int i3 = 0; i3 < intValue; i3++) {
                    longValue2 = ((Long) cls4.getDeclaredMethod("getTimeAtCpuSpeedStep", new Class[]{Integer.TYPE, Integer.TYPE}).invoke(value, new Object[]{Integer.valueOf(i3), Integer.valueOf(0)})).longValue();
                    jArr[i3] = longValue2;
                    i = (int) (((long) i) + longValue2);
                }
                if (i == 0) {
                    i2 = 1;
                } else {
                    i2 = i;
                }
                double d2 = 0.0d;
                for (i = 0; i < intValue; i++) {
                    double d3 = (double) longValue;
                    d2 += ((((double) jArr[i]) / ((double) i2)) * r0) * dArr[i];
                }
                d += d2 / 1000.0d;
                this.f878d = (long) (((double) this.f878d) + d);
            }
            jSONObject.put("cpu_power", d);
            return d;
        } catch (Throwable th) {
            Throwable th2 = th;
            double d4 = d;
            m1591a(th2, "Failed to extract CPU power stats");
            return d4;
        }
    }

    private double m1587a(JSONObject jSONObject, Class cls, Object obj, Class cls2, Class cls3, Object obj2, Object obj3) {
        double a;
        Throwable th;
        double d = 0.0d;
        try {
            long longValue = ((Long) cls.getDeclaredMethod("getTcpBytesReceived", new Class[]{Integer.TYPE}).invoke(obj, new Object[]{Integer.valueOf(0)})).longValue();
            long longValue2 = ((Long) cls.getDeclaredMethod("getTcpBytesSent", new Class[]{Integer.TYPE}).invoke(obj, new Object[]{Integer.valueOf(0)})).longValue();
            this.f881g += longValue;
            this.f882h += longValue2;
            a = (((double) (longValue2 + longValue)) * C0232b.m1585a(obj3, cls2, cls3, obj2)) + 0.0d;
            try {
                this.f879e = (long) (((double) this.f879e) + a);
                jSONObject.put("data_power", a);
            } catch (Throwable th2) {
                th = th2;
                m1591a(th, "Failed to extract data stats");
                return a;
            }
        } catch (Throwable th3) {
            Throwable th4 = th3;
            a = d;
            th = th4;
            m1591a(th, "Failed to extract data stats");
            return a;
        }
        return a;
    }

    private double m1588a(JSONObject jSONObject, Class cls, Object obj, Class cls2, Object obj2, long j) {
        Throwable th;
        double d;
        double d2 = 0.0d;
        try {
            SensorManager sensorManager = (SensorManager) this.f886l.getSystemService("sensor");
            Class cls3 = Class.forName("com.android.internal.os.BatteryStatsImpl$Uid$Sensor");
            Class cls4 = Class.forName("com.android.internal.os.BatteryStatsImpl$Timer");
            Object obj3 = obj;
            Map map = (Map) cls.getDeclaredMethod("getSensorStats", new Class[0]).invoke(obj3, new Object[0]);
            double d3 = 0.0d;
            JSONObject jSONObject2 = new JSONObject();
            for (Entry entry : map.entrySet()) {
                try {
                    double doubleValue;
                    Object value = entry.getValue();
                    int intValue = ((Integer) cls3.getDeclaredMethod("getHandle", new Class[0]).invoke(value, new Object[0])).intValue();
                    value = cls3.getDeclaredMethod("getSensorTime", new Class[0]).invoke(value, new Object[0]);
                    long longValue = ((Long) cls4.getDeclaredMethod("getTotalTimeLocked", new Class[]{Long.TYPE, Integer.TYPE}).invoke(value, new Object[]{Long.valueOf(j), Integer.valueOf(0)})).longValue() / 1000;
                    int intValue2 = ((Integer) cls4.getDeclaredMethod("getCountLocked", new Class[]{Integer.TYPE}).invoke(value, new Object[]{Integer.valueOf(0)})).intValue();
                    jSONObject2.put(intValue + " ", longValue);
                    if (intValue == -10000) {
                        Class cls5 = cls2;
                        doubleValue = ((Double) cls5.getDeclaredMethod("getAveragePower", new Class[]{String.class}).invoke(obj2, new Object[]{"gps.on"})).doubleValue();
                        try {
                            jSONObject2.put(intValue + "_msec", longValue);
                            jSONObject2.put(intValue + "_count", intValue2);
                        } catch (Throwable th2) {
                            Throwable th3 = th2;
                            d3 = doubleValue;
                            th = th3;
                            m1591a(th, "Failed to extract stat of sensor " + entry.getKey());
                        }
                    } else {
                        Sensor defaultSensor = sensorManager.getDefaultSensor(intValue);
                        if (defaultSensor != null) {
                            d3 = (double) defaultSensor.getPower();
                            String str = "_msec";
                            jSONObject2.put(defaultSensor.getName() + r18, longValue);
                            jSONObject2.put(defaultSensor.getName() + "_count", intValue2);
                        }
                        doubleValue = d3;
                        jSONObject2.put(intValue + "_msec", longValue);
                        jSONObject2.put(intValue + "_count", intValue2);
                    }
                    d2 += (((double) longValue) * doubleValue) / 1000.0d;
                    d3 = doubleValue;
                } catch (Throwable th4) {
                    th = th4;
                    m1591a(th, "Failed to extract stat of sensor " + entry.getKey());
                }
            }
            jSONObject.put("sensor_power", d2);
            d = d2;
        } catch (Throwable th5) {
            th = th5;
            d = d2;
            m1591a(th, "Unable to retrieve Sensor power stats");
        }
        this.f880f = (long) (((double) this.f880f) + d);
        return d;
    }

    private double m1595b(JSONObject jSONObject, Class cls, Object obj, Class cls2, Object obj2, long j) {
        double doubleValue;
        Throwable th;
        try {
            Class cls3 = Class.forName("com.android.internal.os.BatteryStatsImpl$Uid$Wakelock");
            Class cls4 = Class.forName("com.android.internal.os.BatteryStatsImpl$Timer");
            Object obj3 = obj;
            Map map = (Map) cls.getDeclaredMethod("getWakelockStats", new Class[0]).invoke(obj3, new Object[0]);
            JSONObject jSONObject2 = new JSONObject();
            long j2 = 0;
            for (Entry entry : map.entrySet()) {
                entry.getKey();
                Object value = entry.getValue();
                Object invoke = cls3.getDeclaredMethod("getWakeTime", new Class[]{Integer.TYPE}).invoke(value, new Object[]{Integer.valueOf(0)});
                if (invoke != null) {
                    j2 += ((Long) cls4.getDeclaredMethod("getTotalTimeLocked", new Class[]{Long.TYPE, Integer.TYPE}).invoke(invoke, new Object[]{Long.valueOf(j), Integer.valueOf(0)})).longValue() / 1000;
                    ((Integer) cls4.getDeclaredMethod("getCountLocked", new Class[]{Integer.TYPE}).invoke(invoke, new Object[]{Integer.valueOf(0)})).intValue();
                }
                j2 = j2;
            }
            Class cls5 = cls2;
            doubleValue = (((Double) cls5.getDeclaredMethod("getAveragePower", new Class[]{String.class}).invoke(obj2, new Object[]{"cpu.awake"})).doubleValue() * ((double) j2)) / 1000.0d;
            try {
                jSONObject.put("wakelock_power", doubleValue);
                f877c = j2 + f877c;
                this.f883i = (long) (((double) this.f883i) + doubleValue);
            } catch (Throwable th2) {
                th = th2;
                m1591a(th, "Failed to extract Wakelock power stats");
                return doubleValue;
            }
        } catch (Throwable th3) {
            th = th3;
            doubleValue = 0.0d;
            m1591a(th, "Failed to extract Wakelock power stats");
            return doubleValue;
        }
        return doubleValue;
    }

    private double m1598c(JSONObject jSONObject, Class cls, Object obj, Class cls2, Object obj2, long j) {
        double doubleValue;
        Throwable th;
        try {
            long longValue;
            Class cls3 = cls;
            long longValue2 = ((Long) cls3.getDeclaredMethod("getWifiRunningTime", new Class[]{Long.TYPE, Integer.TYPE}).invoke(obj, new Object[]{Long.valueOf(j), Integer.valueOf(0)})).longValue() / 1000;
            f876b += longValue2;
            try {
                cls3 = cls;
                longValue = ((Long) cls3.getDeclaredMethod("getWifiScanTime", new Class[]{Long.TYPE, Integer.TYPE}).invoke(obj, new Object[]{Long.valueOf(j), Integer.valueOf(0)})).longValue() / 1000;
            } catch (NoSuchMethodException e) {
                longValue = 0;
            }
            cls3 = cls2;
            double doubleValue2 = ((Double) cls3.getDeclaredMethod("getAveragePower", new Class[]{String.class}).invoke(obj2, new Object[]{"wifi.on"})).doubleValue() / 1000.0d;
            cls3 = cls2;
            doubleValue = ((((Double) cls3.getDeclaredMethod("getAveragePower", new Class[]{String.class}).invoke(obj2, new Object[]{"wifi.scan"})).doubleValue() / 1000.0d) * ((double) longValue)) + (0.0d + (((double) longValue2) * doubleValue2));
            try {
                jSONObject.put("wifi_power", doubleValue);
            } catch (Throwable th2) {
                th = th2;
                m1591a(th, "Unable to retrieve Data power stats");
                this.f884j = (long) (((double) this.f884j) + doubleValue);
                return doubleValue;
            }
        } catch (Throwable th3) {
            Throwable th4 = th3;
            doubleValue = 0.0d;
            th = th4;
            m1591a(th, "Unable to retrieve Data power stats");
            this.f884j = (long) (((double) this.f884j) + doubleValue);
            return doubleValue;
        }
        this.f884j = (long) (((double) this.f884j) + doubleValue);
        return doubleValue;
    }

    private double m1584a(C0231a c0231a, Class cls, Object obj, Class cls2, Object obj2, long j) {
        double doubleValue;
        try {
            Class cls3 = cls;
            long longValue = ((Long) cls3.getDeclaredMethod("getBluetoothOnTime", new Class[]{Long.TYPE, Integer.TYPE}).invoke(obj, new Object[]{Long.valueOf(j), Integer.valueOf(0)})).longValue() / 1000;
            cls3 = cls2;
            double doubleValue2 = ((Double) cls3.getDeclaredMethod("getAveragePower", new Class[]{String.class}).invoke(obj2, new Object[]{"bluetooth.on"})).doubleValue() / 1000.0d;
            Object obj3 = obj;
            long intValue = (long) ((Integer) cls.getDeclaredMethod("getBluetoothPingCount", new Class[0]).invoke(obj3, new Object[0])).intValue();
            cls3 = cls2;
            doubleValue = ((((Double) cls3.getDeclaredMethod("getAveragePower", new Class[]{String.class}).invoke(obj2, new Object[]{"bluetooth.at"})).doubleValue() / 1000.0d) * ((double) intValue)) + (0.0d + (((double) longValue) * doubleValue2));
        } catch (Throwable th) {
            m1591a(th, "Unable to retrieve bluetooth power stats");
            doubleValue = 0.0d;
        }
        c0231a.m1582a("device_bluetooth_power", doubleValue);
        return doubleValue;
    }

    private double m1594b(C0231a c0231a, Class cls, Object obj, Class cls2, Object obj2, long j) {
        double doubleValue;
        try {
            long longValue = (j - ((Long) cls.getDeclaredMethod("getScreenOnTime", new Class[]{Long.TYPE, Integer.TYPE}).invoke(obj, new Object[]{Long.valueOf(j), Integer.valueOf(0)})).longValue()) / 1000;
            doubleValue = ((((Double) cls2.getDeclaredMethod("getAveragePower", new Class[]{String.class}).invoke(obj2, new Object[]{"cpu.idle"})).doubleValue() / 1000.0d) * ((double) longValue)) + 0.0d;
        } catch (Throwable th) {
            m1591a(th, "Unable to retrieve idle power stats");
            doubleValue = 0.0d;
        }
        c0231a.m1582a("device_idle_power", doubleValue);
        return doubleValue;
    }

    private double m1597c(C0231a c0231a, Class cls, Object obj, Class cls2, Object obj2, long j) {
        double doubleValue;
        Throwable th;
        try {
            long longValue = ((Long) cls.getDeclaredMethod("getPhoneOnTime", new Class[]{Long.TYPE, Integer.TYPE}).invoke(obj, new Object[]{Long.valueOf(j), Integer.valueOf(0)})).longValue() / 1000;
            doubleValue = ((((Double) cls2.getDeclaredMethod("getAveragePower", new Class[]{String.class}).invoke(obj2, new Object[]{"radio.active"})).doubleValue() / 1000.0d) * ((double) longValue)) + 0.0d;
            try {
                c0231a.m1582a("device_phone_power", doubleValue);
            } catch (Throwable th2) {
                th = th2;
                m1591a(th, "Unable to retrieve phone usage power stats");
                return doubleValue;
            }
        } catch (Throwable th3) {
            Throwable th4 = th3;
            doubleValue = 0.0d;
            th = th4;
            m1591a(th, "Unable to retrieve phone usage power stats");
            return doubleValue;
        }
        return doubleValue;
    }

    private double m1600d(C0231a c0231a, Class cls, Object obj, Class cls2, Object obj2, long j) {
        double d;
        double d2 = 0.0d;
        int i = 0;
        while (i < 5) {
            try {
                d2 += (((double) (((Long) cls.getDeclaredMethod("getPhoneSignalStrengthTime", new Class[]{Integer.TYPE, Long.TYPE, Integer.TYPE}).invoke(obj, new Object[]{Integer.valueOf(i), Long.valueOf(j), Integer.valueOf(0)})).longValue() / 1000)) * ((Double) cls2.getDeclaredMethod("getAveragePower", new Class[]{String.class, Integer.TYPE}).invoke(obj2, new Object[]{"radio.on", Integer.valueOf(i)})).doubleValue()) / 1000.0d;
                i++;
            } catch (Throwable th) {
                Throwable th2 = th;
                d = d2;
                Throwable th3 = th2;
            }
        }
        long longValue = ((Long) cls.getDeclaredMethod("getPhoneSignalScanningTime", new Class[]{Long.TYPE, Integer.TYPE}).invoke(obj, new Object[]{Long.valueOf(j), Integer.valueOf(0)})).longValue() / 1000;
        d = ((((Double) cls2.getDeclaredMethod("getAveragePower", new Class[]{String.class}).invoke(obj2, new Object[]{"radio.scanning"})).doubleValue() / 1000.0d) * ((double) longValue)) + d2;
        try {
            c0231a.m1582a("device_radio_power", d);
        } catch (Throwable th4) {
            th3 = th4;
            m1591a(th3, "Unable to retrieve radio power stats");
            return d;
        }
        return d;
    }

    private double m1601e(C0231a c0231a, Class cls, Object obj, Class cls2, Object obj2, long j) {
        double d;
        try {
            Class cls3 = cls;
            long longValue = ((Long) cls3.getDeclaredMethod("getScreenOnTime", new Class[]{Long.TYPE, Integer.TYPE}).invoke(obj, new Object[]{Long.valueOf(j), Integer.valueOf(0)})).longValue() / 1000;
            cls3 = cls2;
            double doubleValue = 0.0d + (((Double) cls3.getDeclaredMethod("getAveragePower", new Class[]{String.class}).invoke(obj2, new Object[]{"screen.on"})).doubleValue() * ((double) longValue));
            cls3 = cls2;
            double doubleValue2 = ((Double) cls3.getDeclaredMethod("getAveragePower", new Class[]{String.class}).invoke(obj2, new Object[]{"screen.full"})).doubleValue();
            for (int i = 0; i < 5; i++) {
                cls3 = cls;
                doubleValue += ((((double) (((float) i) + 0.5f)) * doubleValue2) / 5.0d) * ((double) (((Long) cls3.getDeclaredMethod("getScreenBrightnessTime", new Class[]{Integer.TYPE, Long.TYPE, Integer.TYPE}).invoke(obj, new Object[]{Integer.valueOf(i), Long.valueOf(j), Integer.valueOf(0)})).longValue() / 1000));
            }
            d = doubleValue / 1000.0d;
        } catch (Throwable th) {
            Throwable th2 = th;
            d = 0.0d;
            m1591a(th2, "Unable to retrieve screen power stats");
        }
        c0231a.m1582a("device_screen_power", d);
        return d;
    }

    private double m1602f(C0231a c0231a, Class cls, Object obj, Class cls2, Object obj2, long j) {
        double doubleValue;
        long j2 = 0;
        try {
            long longValue = (((Long) cls.getDeclaredMethod("getGlobalWifiRunningTime", new Class[]{Long.TYPE, Integer.TYPE}).invoke(obj, new Object[]{Long.valueOf(j), Integer.valueOf(0)})).longValue() / 1000) - f876b;
            if (longValue >= 0) {
                j2 = longValue;
            }
            doubleValue = ((((Double) cls2.getDeclaredMethod("getAveragePower", new Class[]{String.class}).invoke(obj2, new Object[]{"wifi.on"})).doubleValue() / 1000.0d) * ((double) j2)) + 0.0d;
        } catch (Throwable th) {
            m1591a(th, "Unable to retrieve Wifi power stats");
            doubleValue = 0.0d;
        }
        c0231a.m1582a("device_wifi_power", doubleValue);
        return doubleValue;
    }

    private static double m1585a(Object obj, Class cls, Class cls2, Object obj2) {
        double doubleValue = ((Double) cls2.getDeclaredMethod("getAveragePower", new Class[]{String.class}).invoke(obj2, new Object[]{"wifi.active"})).doubleValue() / 3600.0d;
        double doubleValue2 = ((Double) cls2.getDeclaredMethod("getAveragePower", new Class[]{String.class}).invoke(obj2, new Object[]{"radio.active"})).doubleValue() / 3600.0d;
        long longValue = ((Long) cls.getDeclaredMethod("getMobileTcpBytesReceived", new Class[]{Integer.TYPE}).invoke(obj, new Object[]{Integer.valueOf(0)})).longValue();
        Class cls3 = cls;
        long longValue2 = (((Long) cls3.getDeclaredMethod("getTotalTcpBytesSent", new Class[]{Integer.TYPE}).invoke(obj, new Object[]{Integer.valueOf(0)})).longValue() + ((Long) cls.getDeclaredMethod("getTotalTcpBytesReceived", new Class[]{Integer.TYPE}).invoke(obj, new Object[]{Integer.valueOf(0)})).longValue()) - longValue;
        long longValue3 = ((Long) cls.getDeclaredMethod("getRadioDataUptime", new Class[0]).invoke(obj, new Object[0])).longValue() / 1000;
        double d = doubleValue2 / (((double) (longValue3 == 0 ? 200000 : ((8 * longValue) * 1000) / longValue3)) / 8.0d);
        doubleValue /= 125000.0d;
        if (longValue2 + longValue > 0) {
            return ((d * ((double) longValue)) + (doubleValue * ((double) longValue2))) / ((double) (longValue + longValue2));
        }
        return 0.0d;
    }

    private Map m1590a(Class cls, Object obj) {
        try {
            return (Map) cls.getDeclaredMethod("getProcessStats", new Class[0]).invoke(obj, new Object[0]);
        } catch (Throwable th) {
            m1591a(th, "Failed to extract CPU power stats");
            return new HashMap();
        }
    }

    private void m1591a(Throwable th, String str) {
        Writer stringWriter = new StringWriter();
        stringWriter.write(str + "\n");
        th.printStackTrace(new PrintWriter(stringWriter));
        Log.w(f875a, "batteryusagemanager/" + stringWriter.toString());
        this.f885k.m1581a(stringWriter.toString());
    }

    private static boolean m1593a(String str) {
        return str.startsWith("com.facebook.lite");
    }

    private void m1599c() {
        this.f885k = new C0231a();
        try {
            if (this.f888n == null || this.f886l == null || this.f888n.checkPermission("android.permission.BATTERY_STATS", this.f886l.getPackageName()) == 0) {
                double d;
                double doubleValue;
                Class cls = Class.forName("com.android.internal.app.IBatteryStats");
                Class cls2 = Class.forName("com.android.internal.app.IBatteryStats$Stub");
                Class cls3 = Class.forName("android.os.ServiceManager");
                Class cls4 = Class.forName("com.android.internal.os.BatteryStatsImpl");
                Class cls5 = Class.forName("com.android.internal.os.BatteryStatsImpl$Uid");
                Class cls6 = Class.forName("com.android.internal.os.PowerProfile");
                IBinder iBinder = (IBinder) cls3.getDeclaredMethod("getService", new Class[]{String.class}).invoke(null, new Object[]{"batteryinfo"});
                Object invoke = cls2.getDeclaredMethod("asInterface", new Class[]{IBinder.class}).invoke(null, new Object[]{iBinder});
                Object newInstance = cls6.getDeclaredConstructor(new Class[]{Context.class}).newInstance(new Object[]{this.f886l});
                byte[] bArr = (byte[]) cls.getDeclaredMethod("getStatistics", new Class[0]).invoke(invoke, new Object[0]);
                Parcel obtain = Parcel.obtain();
                obtain.unmarshall(bArr, 0, bArr.length);
                obtain.setDataPosition(0);
                Object createFromParcel = ((Creator) cls4.getDeclaredField("CREATOR").get(null)).createFromParcel(obtain);
                obtain.recycle();
                long elapsedRealtime = SystemClock.elapsedRealtime() * 1000;
                long longValue = ((Long) cls4.getDeclaredMethod("computeBatteryRealtime", new Class[]{Long.TYPE, Integer.TYPE}).invoke(createFromParcel, new Object[]{Long.valueOf(elapsedRealtime), Integer.valueOf(0)})).longValue();
                elapsedRealtime = SystemClock.uptimeMillis() * 1000;
                long longValue2 = ((Long) cls4.getDeclaredMethod("computeBatteryUptime", new Class[]{Long.TYPE, Integer.TYPE}).invoke(createFromParcel, new Object[]{Long.valueOf(elapsedRealtime), Integer.valueOf(0)})).longValue() / 1000;
                cls4.getDeclaredMethod("distributeWorkLocked", new Class[]{Integer.TYPE}).invoke(createFromParcel, new Object[]{Integer.valueOf(0)});
                SparseArray sparseArray = (SparseArray) cls4.getDeclaredMethod("getUidStats", new Class[0]).invoke(createFromParcel, new Object[0]);
                int myUid = Process.myUid();
                double d2 = 0.0d;
                double d3 = 0.0d;
                this.f883i = 0;
                this.f878d = 0;
                this.f880f = 0;
                this.f881g = 0;
                this.f882h = 0;
                this.f884j = 0;
                this.f879e = 0;
                int i = 0;
                Object obj = null;
                while (i < sparseArray.size()) {
                    Object valueAt = sparseArray.valueAt(i);
                    int intValue = ((Integer) cls5.getDeclaredMethod("getUid", new Class[0]).invoke(valueAt, new Object[0])).intValue();
                    JSONObject jSONObject = new JSONObject();
                    Map a = m1590a(cls5, valueAt);
                    double a2 = m1589a(jSONObject, cls5, valueAt, cls4, createFromParcel, cls6, newInstance, longValue);
                    for (Entry key : a.entrySet()) {
                        if (C0232b.m1593a((String) key.getKey())) {
                            jSONObject.put("total_app_power", a2);
                            m1592a(jSONObject, intValue);
                            this.f885k.m1583a("lite", jSONObject);
                        }
                    }
                    if (intValue == myUid) {
                        d = a2;
                    } else {
                        d = d3;
                    }
                    d2 += a2;
                    i++;
                    d3 = d;
                    obj = valueAt;
                }
                this.f885k.m1582a("app_power", d2);
                elapsedRealtime = SystemClock.elapsedRealtime() * 1000;
                SystemClock.uptimeMillis();
                elapsedRealtime = longValue2 - ((((Long) cls4.getDeclaredMethod("getScreenOnTime", new Class[]{Long.TYPE, Integer.TYPE}).invoke(createFromParcel, new Object[]{Long.valueOf(elapsedRealtime), Integer.valueOf(0)})).longValue() / 1000) + f877c);
                if (elapsedRealtime > 0) {
                    doubleValue = (((Double) cls6.getDeclaredMethod("getAveragePower", new Class[]{String.class}).invoke(newInstance, new Object[]{"cpu.awake"})).doubleValue() * ((double) elapsedRealtime)) / 1000.0d;
                    d = d2 + doubleValue;
                    this.f885k.m1582a("device_wakelock_power", doubleValue);
                } else {
                    d = d2;
                }
                doubleValue = m1600d(this.f885k, cls4, createFromParcel, cls6, newInstance, longValue) + (((((d + m1597c(this.f885k, cls4, createFromParcel, cls6, newInstance, longValue)) + m1601e(this.f885k, cls4, createFromParcel, cls6, newInstance, longValue)) + m1602f(this.f885k, cls4, createFromParcel, cls6, newInstance, longValue)) + m1584a(this.f885k, cls4, createFromParcel, cls6, newInstance, longValue)) + m1594b(this.f885k, cls4, createFromParcel, cls6, newInstance, longValue));
                this.f885k.m1580a(doubleValue > 0.0d ? (100.0d * d3) / doubleValue : 0.0d);
                this.f885k.m1582a("facebook_lite_power", d3);
                this.f885k.m1582a("total_device_power", doubleValue);
                if (obj == null) {
                    Log.w(f875a, "Failed to find Uid");
                    return;
                }
                return;
            }
            this.f885k.m1581a("Package does not have permission to access battery stats");
        } catch (Throwable th) {
            m1591a(th, "Error in Initialization");
        }
    }
}
