package com.facebook.lite.ui.gl;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;

public class EGLWrapper implements EGL10 {
    private final EGL10 mEgl;

    public EGLWrapper(EGL10 egl10) {
        this.mEgl = egl10;
    }

    public boolean eglChooseConfig(EGLDisplay eGLDisplay, int[] iArr, EGLConfig[] eGLConfigArr, int i, int[] iArr2) {
        boolean eglChooseConfig = this.mEgl.eglChooseConfig(eGLDisplay, iArr, eGLConfigArr, i, iArr2);
        checkError();
        return eglChooseConfig;
    }

    public boolean eglCopyBuffers(EGLDisplay eGLDisplay, EGLSurface eGLSurface, Object obj) {
        boolean eglCopyBuffers = this.mEgl.eglCopyBuffers(eGLDisplay, eGLSurface, obj);
        checkError();
        return eglCopyBuffers;
    }

    public EGLContext eglCreateContext(EGLDisplay eGLDisplay, EGLConfig eGLConfig, EGLContext eGLContext, int[] iArr) {
        EGLContext eglCreateContext = this.mEgl.eglCreateContext(eGLDisplay, eGLConfig, eGLContext, iArr);
        checkError();
        return eglCreateContext;
    }

    public EGLSurface eglCreatePbufferSurface(EGLDisplay eGLDisplay, EGLConfig eGLConfig, int[] iArr) {
        EGLSurface eglCreatePbufferSurface = this.mEgl.eglCreatePbufferSurface(eGLDisplay, eGLConfig, iArr);
        checkError();
        return eglCreatePbufferSurface;
    }

    public EGLSurface eglCreatePixmapSurface(EGLDisplay eGLDisplay, EGLConfig eGLConfig, Object obj, int[] iArr) {
        EGLSurface eglCreatePixmapSurface = this.mEgl.eglCreatePixmapSurface(eGLDisplay, eGLConfig, obj, iArr);
        checkError();
        return eglCreatePixmapSurface;
    }

    public EGLSurface eglCreateWindowSurface(EGLDisplay eGLDisplay, EGLConfig eGLConfig, Object obj, int[] iArr) {
        EGLSurface eglCreateWindowSurface = this.mEgl.eglCreateWindowSurface(eGLDisplay, eGLConfig, obj, iArr);
        checkError();
        return eglCreateWindowSurface;
    }

    public boolean eglDestroyContext(EGLDisplay eGLDisplay, EGLContext eGLContext) {
        boolean eglDestroyContext = this.mEgl.eglDestroyContext(eGLDisplay, eGLContext);
        checkError();
        return eglDestroyContext;
    }

    public boolean eglDestroySurface(EGLDisplay eGLDisplay, EGLSurface eGLSurface) {
        boolean eglDestroySurface = this.mEgl.eglDestroySurface(eGLDisplay, eGLSurface);
        checkError();
        return eglDestroySurface;
    }

    public boolean eglGetConfigAttrib(EGLDisplay eGLDisplay, EGLConfig eGLConfig, int i, int[] iArr) {
        boolean eglGetConfigAttrib = this.mEgl.eglGetConfigAttrib(eGLDisplay, eGLConfig, i, iArr);
        checkError();
        return eglGetConfigAttrib;
    }

    public boolean eglGetConfigs(EGLDisplay eGLDisplay, EGLConfig[] eGLConfigArr, int i, int[] iArr) {
        boolean eglGetConfigs = this.mEgl.eglGetConfigs(eGLDisplay, eGLConfigArr, i, iArr);
        checkError();
        return eglGetConfigs;
    }

    public EGLContext eglGetCurrentContext() {
        EGLContext eglGetCurrentContext = this.mEgl.eglGetCurrentContext();
        checkError();
        return eglGetCurrentContext;
    }

    public EGLDisplay eglGetCurrentDisplay() {
        EGLDisplay eglGetCurrentDisplay = this.mEgl.eglGetCurrentDisplay();
        checkError();
        return eglGetCurrentDisplay;
    }

    public EGLSurface eglGetCurrentSurface(int i) {
        EGLSurface eglGetCurrentSurface = this.mEgl.eglGetCurrentSurface(i);
        checkError();
        return eglGetCurrentSurface;
    }

    public EGLDisplay eglGetDisplay(Object obj) {
        EGLDisplay eglGetDisplay = this.mEgl.eglGetDisplay(obj);
        checkError();
        return eglGetDisplay;
    }

    public int eglGetError() {
        return this.mEgl.eglGetError();
    }

    public boolean eglInitialize(EGLDisplay eGLDisplay, int[] iArr) {
        boolean eglInitialize = this.mEgl.eglInitialize(eGLDisplay, iArr);
        checkError();
        return eglInitialize;
    }

    public boolean eglMakeCurrent(EGLDisplay eGLDisplay, EGLSurface eGLSurface, EGLSurface eGLSurface2, EGLContext eGLContext) {
        boolean eglMakeCurrent = this.mEgl.eglMakeCurrent(eGLDisplay, eGLSurface, eGLSurface2, eGLContext);
        checkError();
        return eglMakeCurrent;
    }

    public boolean eglQueryContext(EGLDisplay eGLDisplay, EGLContext eGLContext, int i, int[] iArr) {
        boolean eglQueryContext = this.mEgl.eglQueryContext(eGLDisplay, eGLContext, i, iArr);
        checkError();
        return eglQueryContext;
    }

    public String eglQueryString(EGLDisplay eGLDisplay, int i) {
        String eglQueryString = this.mEgl.eglQueryString(eGLDisplay, i);
        checkError();
        return eglQueryString;
    }

    public boolean eglQuerySurface(EGLDisplay eGLDisplay, EGLSurface eGLSurface, int i, int[] iArr) {
        boolean eglQuerySurface = this.mEgl.eglQuerySurface(eGLDisplay, eGLSurface, i, iArr);
        checkError();
        return eglQuerySurface;
    }

    public boolean eglSwapBuffers(EGLDisplay eGLDisplay, EGLSurface eGLSurface) {
        boolean eglSwapBuffers = this.mEgl.eglSwapBuffers(eGLDisplay, eGLSurface);
        checkError();
        return eglSwapBuffers;
    }

    public boolean eglTerminate(EGLDisplay eGLDisplay) {
        boolean eglTerminate = this.mEgl.eglTerminate(eGLDisplay);
        checkError();
        return eglTerminate;
    }

    public boolean eglWaitGL() {
        boolean eglWaitGL = this.mEgl.eglWaitGL();
        checkError();
        return eglWaitGL;
    }

    public boolean eglWaitNative(int i, Object obj) {
        boolean eglWaitNative = this.mEgl.eglWaitNative(i, obj);
        checkError();
        return eglWaitNative;
    }

    private void checkError() {
        int eglGetError = this.mEgl.eglGetError();
        if (eglGetError != 12288) {
            throw new C0463a(eglGetError);
        }
    }
}
