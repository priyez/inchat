package com.facebook.rti.push.p048a;

import android.content.Context;
import android.content.Intent;
import com.facebook.rti.p046a.p047b.C0256e;
import com.facebook.rti.p046a.p074f.C0527a;

/* renamed from: com.facebook.rti.push.a.b */
public abstract class C0257b extends C0256e {
    private final Class f950a;

    public C0257b(Class cls) {
        if (cls == null) {
            throw new IllegalArgumentException("intentService cannot be null");
        }
        this.f950a = cls;
    }

    public void onReceive(Context context, Intent intent) {
        C0527a.m3338b("FbnsCallbackReceiver", "onReceive %s", intent.getAction());
        if (intent.getAction() != null) {
            intent.setClass(context, this.f950a);
            if (C0256e.m1696a(context, intent) == null) {
                C0527a.m3344f("FbnsCallbackReceiver", "service %s does not exist", this.f950a.getClass().getCanonicalName());
            }
        }
    }
}
