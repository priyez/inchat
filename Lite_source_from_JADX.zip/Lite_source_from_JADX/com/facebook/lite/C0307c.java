package com.facebook.lite;

import android.os.AsyncTask;
import android.util.Log;
import com.facebook.lite.photo.C0444m;
import com.facebook.p038e.C0251k;

/* renamed from: com.facebook.lite.c */
final class C0307c extends AsyncTask {
    final /* synthetic */ String f1220a;
    final /* synthetic */ C0251k f1221b;
    final /* synthetic */ C0342f f1222c;

    C0307c(C0342f c0342f, String str, C0251k c0251k) {
        this.f1222c = c0342f;
        this.f1220a = str;
        this.f1221b = c0251k;
    }

    protected final /* synthetic */ Object doInBackground(Object[] objArr) {
        return m2209a();
    }

    protected final /* synthetic */ void onPostExecute(Object obj) {
        m2208a((byte[]) obj);
    }

    private byte[] m2209a() {
        return C0444m.m3057a(this.f1222c.f1371u, this.f1222c.f1369s.m2648W(), this.f1220a, this.f1221b, 0);
    }

    private void m2208a(byte[] bArr) {
        if (bArr == null) {
            Log.e(C0342f.f1331b, "gallery/unable to read photo.");
            this.f1222c.f1369s.m2639N().m168a(C0342f.f1341l);
            this.f1221b.m1681b("handling_succeeded", false);
            C0251k.m1672a(this.f1221b, this.f1222c.f1371u);
            return;
        }
        C0342f.f1342m.m79a(bArr);
        this.f1222c.f1369s.m2639N().m168a(C0342f.f1342m);
        this.f1221b.m1681b("handling_succeeded", true);
        C0251k.m1672a(this.f1221b, this.f1222c.f1371u);
    }
}
