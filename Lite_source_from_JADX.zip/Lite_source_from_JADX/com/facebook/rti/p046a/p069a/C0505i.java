package com.facebook.rti.p046a.p069a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* renamed from: com.facebook.rti.a.a.i */
public class C0505i extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        C0497a.f2123a.m3289a();
    }
}
