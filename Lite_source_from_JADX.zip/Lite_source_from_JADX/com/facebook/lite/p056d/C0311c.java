package com.facebook.lite.p056d;

import android.content.Context;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.facebook.lite.d.c */
public final class C0311c {
    private final Map f1226a;

    public C0311c() {
        Map hashMap = new HashMap();
        hashMap.put(C0313f.m2223b().m2226a(), C0313f.m2223b());
        hashMap.put(C0315h.m2234b().m2236a(), C0315h.m2234b());
        this.f1226a = Collections.unmodifiableMap(hashMap);
    }

    public static C0311c m2220a() {
        return C0310b.f1225a;
    }

    public final C0308d m2221a(Context context, String str, String str2) {
        return ((C0308d) this.f1226a.get(str)).m2211a(context, str2);
    }
}
