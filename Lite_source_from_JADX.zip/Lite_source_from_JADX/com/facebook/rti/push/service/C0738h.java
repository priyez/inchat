package com.facebook.rti.push.service;

/* renamed from: com.facebook.rti.push.service.h */
public final class C0738h {
    public String f3170a;
    public String f3171b;
    public String f3172c;

    public C0738h() {
        this.f3170a = "";
        this.f3171b = "";
        this.f3172c = "";
    }
}
