package com.facebook.lite.diode;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Binder;
import com.facebook.lite.p053b.C0300n;
import java.util.ArrayList;

public class UserValuesProvider extends ContentProvider {
    private static final String f1265a;

    static {
        f1265a = UserValuesProvider.class.getSimpleName();
    }

    public int delete(Uri uri, String str, String[] strArr) {
        return 0;
    }

    public String getType(Uri uri) {
        return null;
    }

    public Uri insert(Uri uri, ContentValues contentValues) {
        return null;
    }

    public boolean onCreate() {
        return true;
    }

    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        new StringBuilder("query: ").append(uri.toString());
        if (!"name='active_session_info'".equalsIgnoreCase(str)) {
            throw new IllegalArgumentException("Bad selection");
        } else if (m2265a(getContext())) {
            Cursor matrixCursor = new MatrixCursor(strArr);
            ArrayList arrayList = new ArrayList();
            for (Object obj : strArr) {
                if ("name".equals(obj)) {
                    arrayList.add("active_session_info");
                } else if ("value".equals(obj)) {
                    arrayList.add(C0300n.m2079G(getContext()));
                } else {
                    throw new IllegalArgumentException("Bad projection");
                }
            }
            matrixCursor.addRow(arrayList.toArray());
            return matrixCursor;
        } else {
            throw new SecurityException("Signatures did not match!");
        }
    }

    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        return 0;
    }

    private static boolean m2265a(Context context) {
        int callingUid = Binder.getCallingUid();
        int i = context.getApplicationInfo().uid;
        if (callingUid == i || context.getPackageManager().checkSignatures(i, callingUid) == 0) {
            return true;
        }
        return false;
    }
}
