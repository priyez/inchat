package com.facebook.lite.photo;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;

public class GalleryItem implements Parcelable {
    public static final Creator CREATOR;
    private static final String f1745a;
    private final int f1746b;
    private int f1747c;
    private int f1748d;

    static {
        f1745a = GalleryItem.class.getSimpleName();
        CREATOR = new C0439h();
    }

    public GalleryItem(int i) {
        this.f1747c = 0;
        this.f1746b = i;
        this.f1748d = 0;
    }

    private GalleryItem(int i, int i2, int i3) {
        this.f1747c = i2;
        this.f1746b = i;
        this.f1748d = i3;
    }

    protected GalleryItem(Parcel parcel) {
        this.f1746b = parcel.readInt();
        this.f1747c = parcel.readInt();
        this.f1748d = parcel.readInt();
    }

    public static GalleryItem m2988a(String str) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            return new GalleryItem(jSONObject.getInt("origId"), jSONObject.getInt("order"), jSONObject.getInt("degree"));
        } catch (JSONException e) {
            Log.e(f1745a, "galleryItem/jsonException when create galleryItem from json string " + e);
            return null;
        }
    }

    public int describeContents() {
        return 0;
    }

    public final void m2989a() {
        this.f1747c = 0;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof GalleryItem)) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        GalleryItem galleryItem = (GalleryItem) obj;
        if (galleryItem.f1746b == this.f1746b && galleryItem.f1748d == this.f1748d && galleryItem.f1747c == this.f1747c) {
            return true;
        }
        return false;
    }

    public final int m2991b() {
        return this.f1746b;
    }

    public final int m2993c() {
        return this.f1747c;
    }

    public final int m2995d() {
        return this.f1748d;
    }

    public int hashCode() {
        return ((((this.f1746b + 145) * 29) + this.f1747c) * 29) + this.f1748d;
    }

    public final boolean m2996e() {
        return this.f1747c > 0;
    }

    public final void m2990a(int i) {
        this.f1747c = i;
    }

    public final void m2992b(int i) {
        this.f1747c = i;
    }

    public final void m2994c(int i) {
        this.f1748d = i;
    }

    public final JSONObject m2997f() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("origId", this.f1746b);
            jSONObject.put("order", this.f1747c);
            jSONObject.put("degree", this.f1748d);
            return jSONObject;
        } catch (JSONException e) {
            Log.e(f1745a, "galleryItem/jsonException when write galleryItem to json " + e);
            return null;
        }
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f1746b);
        parcel.writeInt(this.f1747c);
        parcel.writeInt(this.f1748d);
    }
}
