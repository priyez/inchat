package com.facebook.lite.p053b;

import com.facebook.lite.p049a.C0280i;
import com.facebook.lite.p049a.p052c.C0269c;
import com.facebook.lite.p049a.p052c.C0270d;
import com.facebook.p038e.p040b.p041a.p042a.p043a.C0213a;
import com.facebook.p038e.p040b.p041a.p042a.p043a.C0216b;
import com.p008a.p009a.p010a.C0046e;
import com.p008a.p009a.p010a.p012b.C0017i;
import com.p008a.p009a.p010a.p012b.C0018j;
import com.p008a.p009a.p010a.p012b.C0027f;
import com.p008a.p009a.p010a.p012b.C0029k;
import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p016h.C0053e;
import com.p008a.p009a.p010a.p016h.C0055g;
import com.p008a.p009a.p010a.p016h.C0056h;
import com.p008a.p009a.p010a.p019i.C0060d;
import com.p008a.p009a.p010a.p019i.C0062f;
import com.p008a.p009a.p010a.p022l.C0070p;
import com.p008a.p009a.p010a.p022l.C0075d;
import com.p008a.p009a.p010a.p022l.C0076e;
import com.p008a.p009a.p010a.p022l.C0077f;
import com.p008a.p009a.p010a.p022l.C0078g;
import com.p008a.p009a.p010a.p022l.C0080i;
import com.p008a.p009a.p010a.p022l.C0081j;
import com.p008a.p009a.p010a.p022l.C0088r;
import com.p008a.p009a.p010a.p022l.C0093w;
import com.p008a.p009a.p010a.p022l.C0094y;
import com.p008a.p009a.p010a.p023m.C0099a;
import com.p008a.p009a.p010a.p023m.C0114f;
import com.p008a.p009a.p010a.p023m.C0115e;
import com.p008a.p009a.p010a.p023m.C0116b;
import com.p008a.p009a.p010a.p023m.C0120h;
import com.p008a.p009a.p010a.p023m.C0121i;
import com.p008a.p009a.p010a.p023m.C0123k;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

/* renamed from: com.facebook.lite.b.m */
public class C0299m implements C0027f, C0017i, C0053e, C0080i {
    private C0115e f1190a;
    private C0115e f1191b;
    private boolean f1192c;
    private int f1193d;
    private C0081j f1194e;
    private final C0022b f1195f;
    private final C0077f f1196g;
    private final Map f1197h;
    private final C0078g f1198i;
    private final C0055g f1199j;
    private final C0060d f1200k;
    private final C0062f f1201l;
    private final C0298l f1202m;
    private final C0298l f1203n;
    private final C0123k[] f1204o;
    private int f1205p;
    private final C0055g f1206q;
    private final C0018j f1207r;
    private final C0029k f1208s;
    private C0094y f1209t;

    public C0299m(C0022b c0022b, C0029k c0029k, C0077f c0077f, C0060d c0060d, C0018j c0018j, C0055g c0055g, C0055g c0055g2, C0078g c0078g, C0062f c0062f) {
        this.f1190a = new C0116b(40);
        this.f1191b = new C0116b(40);
        this.f1197h = new HashMap();
        this.f1202m = C0298l.m1999k();
        this.f1203n = C0298l.m1999k();
        this.f1204o = new C0123k[3];
        this.f1205p = 0;
        this.f1209t = null;
        this.f1195f = c0022b;
        this.f1208s = c0029k;
        this.f1196g = c0077f;
        this.f1200k = c0060d;
        this.f1207r = c0018j;
        this.f1199j = c0055g;
        this.f1206q = c0055g2;
        this.f1198i = c0078g;
        this.f1201l = c0062f;
        m2065d();
    }

    public final C0076e m2043a(int i, byte[] bArr, int i2, int i3) {
        int length = bArr.length;
        if (bArr[length - 1] == null) {
            Object obj = new byte[(length + 1)];
            System.arraycopy(bArr, 0, obj, 0, length);
            obj[length] = (byte) 1;
            bArr = obj;
        }
        C0297k a = C0298l.m1995a(i, bArr, i2, i3);
        a.f1186l = -1;
        a.f1187m = -1;
        m2018a(a, false);
        return a;
    }

    private boolean m2024b(int i, int i2) {
        return m2027c(i, i2);
    }

    private boolean m2027c(int i, int i2) {
        if (!this.f1192c || this.f1198i == null) {
            return false;
        }
        return this.f1198i.m605a(i, i2, true, (byte) 0);
    }

    private C0076e m2034h(int i) {
        C0297k c = m2025c(i, false);
        if (c == null) {
            return null;
        }
        m2023b(c);
        if (c.m2003a(this.f1195f)) {
            return null;
        }
        return c;
    }

    public final void m2062c() {
        this.f1197h.clear();
    }

    public final void m2047a(int i) {
        if (this.f1194e != null) {
            this.f1194e.m636a(i);
        }
    }

    public final void m2048a(int i, byte b) {
        if (this.f1198i != null) {
            this.f1198i.m602a(i, b);
        }
    }

    public final boolean m2063c(int i) {
        if (this.f1196g.m600o() < ((long) i)) {
            return m2020a(((long) i) - this.f1196g.m600o());
        }
        return true;
    }

    public final void m2046a() {
        if (this.f1191b.m1128n() > 0) {
            m2035h();
        }
        if (this.f1190a.m1128n() > 0) {
            m2033g();
        }
    }

    public final byte[] m2055a(int i, char c) {
        C0075d a = ((C0088r) this.f1197h.get(Integer.valueOf(i))).m752a();
        byte[] a2 = a.m589a(c);
        if (a2 == null) {
            byte[] a3 = a.m589a(' ');
            if (a3 != null) {
                a.m587a(c, a3);
            }
            m2021b(i, c);
        }
        return a2;
    }

    public final C0088r m2045a(int i, boolean z) {
        C0088r c0088r = (C0088r) this.f1197h.get(Integer.valueOf(i));
        if (c0088r != null || z) {
            return c0088r;
        }
        C0088r c0088r2 = (C0088r) this.f1197h.get(Byte.valueOf((byte) 1));
        this.f1195f.m127a((short) 2, (short) 23, null, (long) i);
        return c0088r2;
    }

    public final C0076e m2068e(int i) {
        return m2042a(i, (byte) 0, false);
    }

    public final C0076e m2042a(int i, byte b, boolean z) {
        C0297k c = m2025c(i, false);
        if (c == null) {
            C0270d.m1851c(C0269c.MEM, i);
            if (101 == i || 102 == i) {
                return m2039l(i);
            }
            m2018a(C0298l.m1997b(i), true);
            m2014a(i, 0, b, z);
            return null;
        }
        m2023b(c);
        if (c.m2003a(this.f1195f)) {
            C0270d.m1851c(C0269c.MEM, i);
            return null;
        }
        C0270d.m1845a(C0269c.MEM, i);
        return c;
    }

    public final int[] m2056a(C0093w c0093w, byte b) {
        int i = 0;
        if (c0093w == null) {
            return new int[0];
        }
        List arrayList = new ArrayList();
        Queue linkedList = new LinkedList();
        linkedList.add(c0093w);
        while (!linkedList.isEmpty()) {
            C0070p c0070p = (C0070p) linkedList.remove();
            if (c0070p.m520e() == b) {
                arrayList.add(Integer.valueOf(c0070p.m537l()));
            }
            C0099a f = c0070p.m524f();
            if (f != null) {
                for (int i2 = 0; i2 < f.m1064c(); i2++) {
                    linkedList.add((C0070p) f.m1056a(i2));
                }
            }
        }
        int[] iArr = new int[arrayList.size()];
        while (i < arrayList.size()) {
            iArr[i] = ((Integer) arrayList.get(i)).intValue();
            i++;
        }
        return iArr;
    }

    public final C0121i m2072j() {
        C0121i c0121i = new C0121i();
        c0121i.m1200a(15);
        c0121i.m1200a(21);
        c0121i.m1200a(87);
        c0121i.m1200a(11);
        c0121i.m1200a(19);
        c0121i.m1200a(23);
        c0121i.m1200a(42);
        return c0121i;
    }

    public final C0088r m2044a(int i, short s, int i2, int i3) {
        int a = C0088r.m744a(i);
        C0088r c0088r = (C0088r) this.f1197h.get(Integer.valueOf(a));
        if (c0088r != null) {
            return c0088r;
        }
        c0088r = C0293g.m1947a(i, s, i2, i3);
        this.f1197h.put(Integer.valueOf(a), c0088r);
        return c0088r;
    }

    public final C0062f m2057b() {
        return this.f1201l;
    }

    public final byte[] m2064c(int i, byte b) {
        C0298l d = m2028d((int) b, i);
        if (d == null) {
            return null;
        }
        return d.m2005c();
    }

    public final C0093w m2058b(int i, boolean z) {
        C0297k k = m2038k(i);
        if (k != null) {
            if (k.f1177c) {
                m2036i(i);
            } else {
                m2023b(k);
            }
            return k.f1182h;
        }
        if (z) {
            m2040m(i);
        }
        return null;
    }

    public final C0076e m2070f(int i) {
        if (C0270d.m1849b(i)) {
            return null;
        }
        int i2 = i & 1073741823;
        for (int i3 = 3; i3 > 0; i3--) {
            int i4 = (i3 << 30) | i2;
            if (i4 != i) {
                C0076e h = m2034h(i4);
                if (h != null) {
                    return h;
                }
            }
        }
        for (i4 = 3; i4 > 0; i4--) {
            int i5 = (i4 << 30) | i2;
            if (i5 != i && m2024b(i5, i)) {
                return null;
            }
        }
        return null;
    }

    public final void m2049a(int i, int i2, byte[] bArr, boolean z) {
        try {
            C0298l c = m2025c(i, true);
            if (c.m2005c() == null) {
                m2019a(c, bArr);
                c.m2000l();
                if (this.f1194e != null) {
                    C0081j c0081j = this.f1194e;
                    if (!z) {
                        i2 = i;
                    }
                    c0081j.m636a(i2);
                }
                C0270d.m1850c(i);
            }
        } catch (OutOfMemoryError e) {
            this.f1195f.m127a((short) 1, (short) 124, e.getMessage(), this.f1196g.m600o());
        }
    }

    public final void m2065d() {
        for (int i = 0; i < this.f1204o.length; i++) {
            if (i != 2) {
                this.f1204o[i] = new C0123k();
            }
        }
        this.f1203n.a = this.f1202m;
        this.f1202m.b = this.f1203n;
        this.f1205p = 0;
    }

    public final boolean m2061b(int i, byte b) {
        if (!this.f1192c || this.f1198i == null) {
            return false;
        }
        return this.f1198i.m606b(i, b);
    }

    public final boolean m2067d(int i, byte b) {
        return this.f1204o[b].m1219a(i);
    }

    public final void m2060b(int i, C0114f c0114f) {
        m2063c(40000);
        switch (i) {
            case 11:
                m2031e(c0114f);
            case 15:
                m2022b(c0114f);
            case 19:
                int h = c0114f.m1122h();
                m2036i(h);
                C0121i c0121i = new C0121i();
                c0121i.m1200a(h);
                m2017a(c0121i, null);
            case 21:
                m2026c(c0114f);
            case 23:
                m2065d();
                this.f1195f.m126a((short) 5, (short) 72, Long.toString(this.f1196g.m600o()));
            case 42:
                m2029d(c0114f);
            case 87:
                m2016a(c0114f);
            default:
                this.f1195f.m125a((short) 2, (short) 24);
        }
    }

    public final void m2050a(int i, C0088r c0088r) {
        if (!this.f1197h.containsKey(Integer.valueOf(i))) {
            this.f1197h.put(Integer.valueOf(i), c0088r);
        }
    }

    public final void m2071g(int i) {
        m2041a(1, i);
    }

    public final int m2041a(int i, int i2) {
        if (i != 2) {
            return m2011a(i, i2, (C0297k) this.f1204o[i].m1220b(i2));
        }
        throw new UnsupportedOperationException("we shouldn't have font cached in resourceCacheEntry");
    }

    private void m2036i(int i) {
        m2041a(0, i);
    }

    public final void m2059b(int i) {
        m2014a(i, 0, (byte) -1, false);
    }

    private void m2032f() {
        this.f1207r.m111a(this.f1193d);
        this.f1193d = this.f1207r.m110a(this, 500);
    }

    public final void m2053a(boolean z) {
        this.f1192c = z;
    }

    public final void m2051a(C0081j c0081j) {
        this.f1194e = c0081j;
    }

    public final void m2052a(C0094y c0094y) {
        this.f1209t = c0094y;
    }

    public final void m2066d(int i) {
        if (i == this.f1193d) {
            m2046a();
        }
    }

    public final boolean m2054a(int i, byte b, byte b2) {
        if (this.f1198i != null) {
            return this.f1198i.m604a(i, b, b2);
        }
        return false;
    }

    public final void m2069e() {
        if (this.f1198i != null) {
            this.f1198i.m608w();
        }
    }

    private boolean m2020a(long j) {
        C0121i c0121i = new C0121i();
        C0123k c0123k = new C0123k();
        C0297k c0297k = this.f1203n.a;
        int i = 0;
        while (((long) i) < j && this.f1202m != c0297k) {
            int a;
            if (c0297k instanceof C0298l) {
                a = m2013a((C0298l) c0297k, c0121i) + i;
            } else {
                a = i;
            }
            c0297k = c0297k.f1175a;
            i = a;
        }
        if (c0121i.m1201b() > 0 || c0123k.m1222c() > 0) {
            m2017a(c0121i, c0123k);
        }
        return ((long) i) >= j;
    }

    private C0298l m2025c(int i, boolean z) {
        C0298l d = m2028d(1, i);
        if (d != null || !z) {
            return d;
        }
        C0297k b = C0298l.m1997b(i);
        m2018a(b, false);
        return b;
    }

    private static int m2012a(C0297k c0297k) {
        if (c0297k instanceof C0298l) {
            return ((C0298l) c0297k).f1179e;
        }
        return (((((byte[]) c0297k.m1214j()).length + 8) + 12) + 8) + 8;
    }

    private static int m2037j(int i) {
        return i * 4;
    }

    private void m2016a(C0114f c0114f) {
        int h = c0114f.m1122h();
        int h2 = c0114f.m1122h();
        int h3 = c0114f.m1122h();
        int h4 = c0114f.m1122h();
        byte g = c0114f.m1121g();
        if (this.f1201l != null && this.f1201l.m404t()) {
            C0046e.m320a(h, -1, h4);
        }
        m2015a(h, h2, h4, h3, g, c0114f);
    }

    private int m2013a(C0298l c0298l, C0121i c0121i) {
        int i = 0;
        if (!(c0298l.f1180f || (c0298l.f1181g == null && c0298l.f1182h.m873S()))) {
            boolean z = c0298l.f1181g == (byte) 1 && c0298l.m2005c() == null;
            if (!z || c0298l.f1178d) {
                if (z) {
                    this.f1195f.m127a((short) 5, (short) 86, null, (long) c0298l.m1213i());
                }
                i = m2011a(c0298l.f1181g, c0298l.m1213i(), (C0297k) c0298l);
                if (c0298l.f1181g == null) {
                    c0121i.m1200a(c0298l.m1213i());
                }
            } else {
                c0298l.f1178d = true;
            }
        }
        return i;
    }

    private void m2022b(C0114f c0114f) {
        try {
            C0293g.m1948a(c0114f, this);
            if (this.f1194e != null) {
                this.f1194e.m635a();
            }
        } catch (Throwable e) {
            this.f1195f.m124a((short) 27, null, e);
        }
    }

    private C0298l m2028d(int i, int i2) {
        return (C0298l) this.f1204o[i].m1220b(i2);
    }

    private C0298l m2038k(int i) {
        return m2028d(0, i);
    }

    private void m2015a(int i, int i2, int i3, int i4, byte b, C0114f c0114f) {
        C0298l c = m2025c(i, i4 == 0);
        if (c == null) {
            this.f1195f.m127a((short) 3, (short) 28, null, (long) i4);
            return;
        }
        byte[] b2;
        if (i4 == 0) {
            b2 = this.f1196g.m599b(i2 + 1);
            if (b2 == null) {
                m2041a(1, i);
                return;
            } else {
                b2[i2] = (byte) 0;
                m2019a(c, b2);
            }
        } else {
            b2 = c.m2005c();
        }
        c0114f.m1112a(b2, i4, i3);
        if (i2 == i4 + i3) {
            b2[i2] = (byte) 1;
            c.m2000l();
            if (this.f1192c && this.f1198i != null) {
                byte a;
                if (this.f1209t.m993d().m435d(i)) {
                    C0299m.class.getSimpleName();
                    a = this.f1209t.m993d().m431a(i);
                } else {
                    C0299m.class.getSimpleName();
                    a = C0120h.m1194a((int) b);
                }
                this.f1198i.m603a(i, b2, a);
            }
            if (this.f1194e != null) {
                long currentTimeMillis = System.currentTimeMillis();
                this.f1194e.m636a(i);
                if (this.f1201l != null && this.f1201l.m404t()) {
                    C0046e.m321a(i, c.m2008f(), c.m2004b(), c.m2007e());
                    this.f1201l.m399a(C0046e.m322b(i));
                    C0046e.m318a(i);
                }
                C0213a a2 = C0216b.m1526a(i, c.m2008f(), c.m2004b(), i2, c.m2007e(), currentTimeMillis);
                if (a2 != null) {
                    this.f1208s.m227a(i, a2.f800d, a2.f797a, a2.f802f, a2.f807k, a2.f804h, a2.f803g, a2.f801e, a2.f806j, a2.f805i);
                }
            }
        }
    }

    private void m2026c(C0114f c0114f) {
        int h = c0114f.m1122h();
        int h2 = c0114f.m1122h();
        int h3 = c0114f.m1122h();
        int i = h2 * 14000;
        int h4 = c0114f.m1122h();
        byte g = c0114f.m1121g();
        new StringBuilder("conn/image/id: ").append(h).append("/part: ").append(h2).append("/size: ").append(h4);
        if (this.f1201l != null && this.f1201l.m404t()) {
            C0046e.m320a(h, h2, h4);
        }
        m2015a(h, h3, h4, i, g, c0114f);
        if (h3 > (h2 + 2) * 14000) {
            m2030e(h, h2 + 2);
        }
    }

    private void m2023b(C0297k c0297k) {
        c0297k.f1176b.f1175a = c0297k.f1175a;
        c0297k.f1175a.f1176b = c0297k.f1176b;
        c0297k.f1175a = this.f1202m;
        c0297k.f1176b = this.f1202m.b;
        c0297k.f1176b.f1175a = c0297k;
        this.f1202m.b = c0297k;
    }

    private void m2018a(C0297k c0297k, boolean z) {
        if (c0297k instanceof C0298l) {
            C0298l c0298l = (C0298l) c0297k;
            int i = c0298l.m1213i();
            m2041a(c0298l.f1181g, i);
            this.f1204o[c0298l.f1181g].m1217a(i, c0297k);
            this.f1205p += C0299m.m2012a(c0297k);
        }
        if (z) {
            c0297k.f1175a = this.f1202m;
            c0297k.f1176b = this.f1202m.b;
            c0297k.f1176b.f1175a = c0297k;
            this.f1202m.b = c0297k;
        } else {
            c0297k.f1176b = this.f1203n;
            c0297k.f1175a = this.f1203n.a;
            c0297k.f1175a.f1176b = c0297k;
            this.f1203n.a = c0297k;
        }
        if (this.f1205p > this.f1200k.m391i()) {
            m2020a((long) (this.f1205p - this.f1200k.m391i()));
        }
    }

    private C0076e m2039l(int i) {
        try {
            C0297k a = C0298l.m1994a(i, C0056h.m368a(this.f1200k.m381b(i)).m1130p());
            a.m2000l();
            m2018a(a, true);
            return a;
        } catch (IOException e) {
            this.f1195f.m126a((short) 2, (short) 66, "l" + i);
            return null;
        }
    }

    private int m2011a(int i, int i2, C0297k c0297k) {
        this.f1204o[i].m1224d(i2);
        int i3 = 0;
        if (c0297k != null) {
            c0297k.f1176b.f1175a = c0297k.f1175a;
            c0297k.f1175a.f1176b = c0297k.f1176b;
            i3 = C0299m.m2012a(c0297k);
            this.f1205p -= i3;
            if (i == 1) {
                C0270d.m1848b(C0269c.MEM, i2);
            }
        }
        return i3;
    }

    private void m2021b(int i, char c) {
        this.f1190a.m1141d(i);
        this.f1190a.m1141d((int) c);
        m2032f();
    }

    private void m2030e(int i, int i2) {
        m2014a(i, i2, (byte) 0, false);
    }

    private void m2014a(int i, int i2, byte b, boolean z) {
        if (!z && this.f1192c && this.f1198i != null && C0280i.m1881b(b) && this.f1198i.m607c(i, b)) {
            C0270d.m1844a(i);
            return;
        }
        if (i2 == 0 && !z) {
            C0216b.m1528a(i, System.currentTimeMillis());
        }
        if (this.f1201l != null && this.f1201l.m404t()) {
            C0046e.m323b(i, i2);
        }
        C0270d.m1851c(C0269c.DISK, i);
        if (this.f1201l == null || !this.f1201l.m403r()) {
            this.f1191b.m1141d(i);
            this.f1191b.m1141d(i2);
            m2032f();
            return;
        }
        C0115e c0116b = new C0116b(40);
        this.f1208s.m226a((byte) 9, c0116b);
        c0116b.m1141d(i);
        c0116b.m1141d(i2);
        this.f1208s.m229a(c0116b);
        if (this.f1201l.m404t()) {
            C0046e.m319a(i, i2);
        }
    }

    private void m2040m(int i) {
        C0115e c0116b = new C0116b(40);
        this.f1208s.m226a((byte) 3, c0116b);
        c0116b.m1141d(i);
        this.f1208s.m229a(c0116b);
    }

    private void m2029d(C0114f c0114f) {
        int h = c0114f.m1122h();
        C0093w b = m2058b(h, false);
        if (b != null) {
            b.m893f(c0114f);
            this.f1209t.m1030q(h);
            this.f1194e.m639b(h);
        }
    }

    private void m2031e(C0114f c0114f) {
        boolean z = true;
        int h = c0114f.m1122h();
        byte g = c0114f.m1121g();
        new StringBuilder("conn/screen/id: ").append(h).append("/part: ").append(g);
        try {
            boolean f = c0114f.m1120f();
            int h2 = c0114f.m1122h();
            int o = c0114f.m1129o();
            int j = C0299m.m2037j(o);
            if (g == null) {
                boolean z2;
                C0093w c0093w = new C0093w(this.f1209t);
                c0093w.m884a(c0114f);
                c0093w.m901o(o);
                this.f1209t.m1030q(h);
                boolean z3 = (h2 & 8) != 0;
                if ((h2 & 4) != 0) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                if (z3) {
                    z3 = false;
                } else {
                    z3 = true;
                }
                m2018a(C0298l.m1993a(h, c0093w, j, z2, z3), true);
                if ((h2 & 16) == 0) {
                    z = false;
                }
                if (this.f1194e != null) {
                    this.f1194e.m637a(h, c0093w, f, z);
                }
            } else if (m2063c(40000 + j)) {
                C0298l k = m2038k(h);
                if (k == null) {
                    this.f1194e.m638a(h, c0114f);
                    return;
                }
                C0093w c0093w2 = k.f1182h;
                if (c0093w2 == null) {
                    this.f1195f.m127a((short) 3, (short) 92, null, (long) h);
                    return;
                }
                c0093w2.m892e(c0114f);
                k.f1179e += j;
                this.f1205p += j;
            } else {
                this.f1195f.m127a((short) 3, (short) 122, null, (long) h);
            }
        } catch (Throwable e) {
            this.f1195f.m124a((short) 34, h + "," + g, e);
        }
    }

    private void m2017a(C0121i c0121i, C0123k c0123k) {
        int b = c0121i.m1201b();
        C0115e c0116b = new C0116b(40);
        this.f1208s.m226a((byte) 8, c0116b);
        c0116b.m1135a((short) b);
        for (int i = 0; i < b; i++) {
            c0116b.m1141d(c0121i.m1202b(i));
        }
        if (c0123k == null) {
            c0116b.m1131a((byte) 0);
        } else {
            int[] b2 = c0123k.m1221b();
            c0116b.m1131a((byte) b2.length);
            for (int i2 : b2) {
                StringBuffer stringBuffer = (StringBuffer) c0123k.m1220b(i2);
                c0116b.m1131a((byte) i2);
                c0116b.m1138b(stringBuffer.toString());
            }
        }
        this.f1208s.m229a(c0116b);
    }

    private void m2033g() {
        C0115e c0116b = new C0116b(40);
        this.f1208s.m226a((byte) 36, c0116b);
        this.f1190a.m1118e();
        c0116b.m1133a(this.f1190a);
        this.f1208s.m229a(c0116b);
        this.f1190a = new C0116b(40);
    }

    private void m2035h() {
        if (this.f1201l == null || !this.f1201l.m403r()) {
            C0115e c0116b = new C0116b(40);
            this.f1208s.m226a((byte) 9, c0116b);
            this.f1191b.m1118e();
            c0116b.m1133a(this.f1191b);
            this.f1208s.m229a(c0116b);
            if (this.f1201l != null && this.f1201l.m404t()) {
                this.f1191b.m1118e();
                while (this.f1191b.m1129o() >= 8) {
                    C0046e.m319a(this.f1191b.m1122h(), this.f1191b.m1122h());
                }
            }
            this.f1191b = new C0116b(40);
        }
    }

    private void m2019a(C0298l c0298l, byte[] bArr) {
        int a = c0298l.m2002a(bArr);
        this.f1205p = (c0298l.f1179e - a) + this.f1205p;
    }
}
