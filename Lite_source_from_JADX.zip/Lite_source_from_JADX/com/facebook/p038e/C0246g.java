package com.facebook.p038e;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/* renamed from: com.facebook.e.g */
final class C0246g {
    final AtomicInteger f921a;
    final boolean f922b;
    final AtomicLong f923c;

    public C0246g(boolean z, long j) {
        this.f921a = new AtomicInteger(1);
        this.f922b = z;
        this.f923c = new AtomicLong(j);
    }
}
