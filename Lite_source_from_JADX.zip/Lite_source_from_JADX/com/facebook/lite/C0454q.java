package com.facebook.lite;

import com.facebook.lite.p053b.C0294h;

/* renamed from: com.facebook.lite.q */
final class C0454q implements Runnable {
    final /* synthetic */ long f1809a;
    final /* synthetic */ C0455r f1810b;

    C0454q(C0455r c0455r, long j) {
        this.f1810b = c0455r;
        this.f1809a = j;
    }

    public final void run() {
        if (this.f1810b.f1816f.f984p != null && !this.f1810b.f1816f.isFinishing() && !this.f1810b.f1816f.f984p.isShowing() && !C0294h.m1972e()) {
            this.f1810b.f1816f.m1784b(this.f1810b.f1812b, this.f1810b.f1813c);
            this.f1810b.f1816f.f980l = this.f1809a;
        }
    }
}
