package com.facebook.p038e.p045d;

import android.os.Build.VERSION;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

/* renamed from: com.facebook.e.d.j */
public class C0240j {
    private static final Class f901a;
    private int f902b;
    private int f903c;
    private int f904d;
    private int f905e;

    static {
        f901a = C0240j.class;
    }

    public C0240j() {
        this.f902b = 0;
        this.f903c = Integer.MAX_VALUE;
    }

    public final int m1624a() {
        if (VERSION.SDK_INT <= 10) {
            return 1;
        }
        int e = m1628e();
        if (e == -1) {
            return m1627d();
        }
        return e;
    }

    public final Integer m1625b() {
        if (this.f902b == 0) {
            m1623f();
        }
        return Integer.valueOf(this.f902b);
    }

    public final Integer m1626c() {
        if (this.f902b == 0) {
            m1623f();
        }
        return Integer.valueOf(this.f903c);
    }

    public final int m1627d() {
        if (this.f905e == 0) {
            this.f905e = Math.max(Runtime.getRuntime().availableProcessors(), 1);
        }
        return this.f905e;
    }

    public final int m1628e() {
        if (this.f904d == 0) {
            try {
                this.f904d = new File("/sys/devices/system/cpu/").listFiles(new C0239i(this)).length;
                if (this.f904d == 0) {
                    this.f904d = -1;
                }
            } catch (Exception e) {
                this.f904d = -1;
            }
        }
        return this.f904d;
    }

    private void m1623f() {
        BufferedReader bufferedReader;
        try {
            m1622b(0);
            if (m1628e() > 1) {
                m1622b(m1628e() - 1);
            }
            if (this.f902b == 0) {
                File file = new File("/proc/cpuinfo");
                if (file.exists()) {
                    String readLine;
                    bufferedReader = new BufferedReader(new FileReader(file));
                    do {
                        readLine = bufferedReader.readLine();
                        if (readLine != null) {
                        }
                        break;
                    } while (!readLine.startsWith("cpu MHz"));
                    m1621a((int) (Float.parseFloat(readLine.substring(readLine.lastIndexOf(58) + 2)) * 1000.0f));
                    break;
                    bufferedReader.close();
                }
            }
        } catch (Exception e) {
            this.f902b = -1;
        } catch (Throwable th) {
            bufferedReader.close();
        }
        if (this.f902b <= this.f903c) {
            if (this.f902b == 0) {
                this.f902b = -1;
            }
            this.f903c = -1;
        }
    }

    private void m1621a(int i) {
        if (i > this.f902b) {
            this.f902b = i;
        }
        if (i < this.f903c) {
            this.f903c = i;
        }
    }

    private void m1622b(int i) {
        File file = new File(String.format(null, "/sys/devices/system/cpu/cpu%d/cpufreq/cpuinfo_max_freq", new Object[]{Integer.valueOf(i)}));
        if (file.exists()) {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            try {
                m1621a(Integer.parseInt(bufferedReader.readLine()));
            } finally {
                bufferedReader.close();
            }
        }
    }
}
