package com.facebook.lite.net;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build.VERSION;
import android.telephony.CellInfo;
import android.telephony.CellInfoCdma;
import android.telephony.CellInfoGsm;
import android.telephony.CellInfoLte;
import android.telephony.CellInfoWcdma;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.p058f.C0336d;
import java.util.List;

/* renamed from: com.facebook.lite.net.k */
public class C0406k extends PhoneStateListener implements C0388g {
    private static final String f1636a;
    private final Context f1637b;

    static {
        f1636a = C0406k.class.getSimpleName();
    }

    public C0406k(Context context) {
        this.f1637b = context;
        ConnectivityReceiver.m2723a((C0388g) this);
    }

    public final void m2880a(Context context) {
        C0406k.m2877a(context, null);
    }

    public void onSignalStrengthsChanged(SignalStrength signalStrength) {
        super.onSignalStrengthsChanged(signalStrength);
        C0406k.m2877a(this.f1637b, signalStrength);
    }

    private static int m2874a(int i) {
        if (i == 99) {
            return 0;
        }
        return (i * 2) - 113;
    }

    private static int m2875a(Context context, NetworkInfo networkInfo, SignalStrength signalStrength) {
        int i = 0;
        if (networkInfo == null) {
            return 0;
        }
        if (1 == networkInfo.getType()) {
            return C0406k.m2879c(context);
        }
        if (networkInfo.getType() != 0) {
            return 0;
        }
        int a = C0406k.m2876a(signalStrength);
        if (VERSION.SDK_INT >= 17) {
            i = C0406k.m2878b(context);
        }
        if (i == 0) {
            return a;
        }
        return i;
    }

    private static int m2878b(Context context) {
        List allCellInfo = ((TelephonyManager) context.getSystemService("phone")).getAllCellInfo();
        if (allCellInfo == null || allCellInfo.isEmpty()) {
            return 0;
        }
        CellInfo cellInfo = (CellInfo) allCellInfo.get(0);
        if (cellInfo instanceof CellInfoGsm) {
            return ((CellInfoGsm) cellInfo).getCellSignalStrength().getDbm();
        }
        if (cellInfo instanceof CellInfoCdma) {
            return ((CellInfoCdma) cellInfo).getCellSignalStrength().getDbm();
        }
        if (VERSION.SDK_INT < 18 || !(cellInfo instanceof CellInfoWcdma)) {
            return cellInfo instanceof CellInfoLte ? ((CellInfoLte) cellInfo).getCellSignalStrength().getDbm() : 0;
        } else {
            return ((CellInfoWcdma) cellInfo).getCellSignalStrength().getDbm();
        }
    }

    private static int m2876a(SignalStrength signalStrength) {
        if (signalStrength == null) {
            return 0;
        }
        if (signalStrength.isGsm()) {
            new StringBuilder("connstats/onSignalStrengthsChanged: gsmSignalStrength ").append(C0406k.m2874a(signalStrength.getGsmSignalStrength()));
            return C0406k.m2874a(signalStrength.getGsmSignalStrength());
        } else if (signalStrength.getCdmaDbm() > 0) {
            new StringBuilder("connstats/onSignalStrengthsChanged: cdmaDbm ").append(signalStrength.getCdmaDbm());
            return signalStrength.getCdmaDbm();
        } else {
            new StringBuilder("connstats/onSignalStrengthsChanged: evdoDbm ").append(signalStrength.getEvdoDbm());
            return signalStrength.getEvdoDbm();
        }
    }

    private static int m2879c(Context context) {
        WifiInfo connectionInfo = ((WifiManager) context.getSystemService("wifi")).getConnectionInfo();
        if (connectionInfo != null) {
            return connectionInfo.getRssi();
        }
        return 0;
    }

    private static void m2877a(Context context, SignalStrength signalStrength) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        if (activeNetworkInfo != null) {
            int a = C0406k.m2875a(context, activeNetworkInfo, signalStrength);
            C0407l.m2881a().m2884a(activeNetworkInfo.getType(), activeNetworkInfo.getSubtype());
            C0407l.m2881a().m2883a(a);
            if (C0336d.f1316a) {
                ClientApplication.m1691c().m2387S().m2636K().m2334a(activeNetworkInfo.getType());
            }
            new StringBuilder("connstats/activenetwork: ").append(activeNetworkInfo.getTypeName()).append(" - ").append(activeNetworkInfo.getSubtypeName()).append(" - signal strength: ").append(a);
        }
    }
}
