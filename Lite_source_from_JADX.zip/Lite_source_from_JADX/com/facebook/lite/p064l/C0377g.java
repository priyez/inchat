package com.facebook.lite.p064l;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.hardware.SensorManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import com.facebook.lite.C0342f;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p059m.C0387i;
import com.p028c.p029a.C0140a;
import com.p028c.p029a.C0144e;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

/* renamed from: com.facebook.lite.l.g */
public class C0377g implements C0140a {
    private static final String f1450a;
    private static final String[] f1451b;
    private final Context f1452c;
    private volatile boolean f1453d;
    private long f1454e;
    private int f1455f;
    private final C0144e f1456g;
    private final Executor f1457h;

    static {
        f1450a = C0377g.class.getSimpleName();
        f1451b = new String[]{"bugs_Facebooklite@fb.com"};
    }

    public C0377g(Activity activity) {
        this.f1452c = activity;
        this.f1456g = new C0144e(this);
        this.f1457h = new C0376f(this);
    }

    public final void m2555a() {
        long uptimeMillis = SystemClock.uptimeMillis();
        if (uptimeMillis - this.f1454e < 500) {
            this.f1455f++;
        } else {
            this.f1455f = 1;
        }
        this.f1454e = uptimeMillis;
        if (this.f1455f == 2) {
            m2551e();
        }
    }

    public final void m2556b() {
        this.f1456g.m1311a((SensorManager) this.f1452c.getSystemService("sensor"));
    }

    public final void m2557c() {
        this.f1456g.m1310a();
    }

    private void m2551e() {
        if (!this.f1453d) {
            this.f1453d = true;
            try {
                this.f1457h.execute(new C0371a(this, m2553g()));
            } catch (Throwable e) {
                Log.e(f1450a, "rageshake/failed to create attachments.", e);
                this.f1453d = false;
            }
        }
    }

    private Uri m2552f() {
        Throwable th;
        Throwable th2;
        FileOutputStream fileOutputStream = null;
        C0342f c = ClientApplication.m1691c();
        C0387i S = c.m2387S();
        FileOutputStream openFileOutput;
        try {
            openFileOutput = this.f1452c.openFileOutput("debug_info.txt", 1);
            try {
                StringBuilder stringBuilder = new StringBuilder(500);
                if (S == null) {
                    stringBuilder.append("No client session.");
                } else {
                    stringBuilder.append("User Info:\n");
                    stringBuilder.append("-----------------------------------------------\n");
                    Long valueOf = Long.valueOf(S.m2641P());
                    if (valueOf == null || valueOf.longValue() == 0) {
                        stringBuilder.append("No Logged in user\n");
                    } else {
                        stringBuilder.append("User id: " + valueOf + "\n");
                    }
                    stringBuilder.append("Client id: " + S.m2632G() + "\n");
                    stringBuilder.append("Session cookies: " + S.m2640O() + "\n");
                }
                stringBuilder.append("\n\n");
                stringBuilder.append("Device Info:\n");
                stringBuilder.append("-----------------------------------------------\n");
                stringBuilder.append("Manufacturer: " + Build.MANUFACTURER + "\n");
                stringBuilder.append("Model: " + Build.MODEL + "\n");
                stringBuilder.append("SDK: " + VERSION.SDK_INT + "\n");
                stringBuilder.append("Device locale: " + c.m2450h() + "\n");
                stringBuilder.append("Server locale: " + C0294h.m1977h(this.f1452c) + "\n");
                stringBuilder.append("\n\n");
                stringBuilder.append("Connectivity Info:\n");
                stringBuilder.append("-----------------------------------------------\n");
                openFileOutput.write(stringBuilder.toString().getBytes());
                for (NetworkInfo networkInfo : ((ConnectivityManager) this.f1452c.getSystemService("connectivity")).getAllNetworkInfo()) {
                    openFileOutput.write((networkInfo.toString() + "\n").getBytes());
                }
                if (openFileOutput != null) {
                    try {
                        openFileOutput.close();
                    } catch (IOException e) {
                        Log.e(f1450a, "rageshake/fail to close file output stream for debug info.");
                    }
                }
            } catch (IOException e2) {
                fileOutputStream = openFileOutput;
                try {
                    Log.e(f1450a, "rageshake/fail to get debug info.");
                    if (fileOutputStream != null) {
                        try {
                            fileOutputStream.close();
                        } catch (IOException e3) {
                            Log.e(f1450a, "rageshake/fail to close file output stream for debug info.");
                        }
                    }
                    return Uri.fromFile(new File(this.f1452c.getFilesDir(), "debug_info.txt"));
                } catch (Throwable th3) {
                    th = th3;
                    openFileOutput = fileOutputStream;
                    th2 = th;
                    if (openFileOutput != null) {
                        try {
                            openFileOutput.close();
                        } catch (IOException e4) {
                            Log.e(f1450a, "rageshake/fail to close file output stream for debug info.");
                        }
                    }
                    throw th2;
                }
            } catch (Throwable th4) {
                th2 = th4;
                if (openFileOutput != null) {
                    openFileOutput.close();
                }
                throw th2;
            }
        } catch (IOException e5) {
            Log.e(f1450a, "rageshake/fail to get debug info.");
            if (fileOutputStream != null) {
                fileOutputStream.close();
            }
            return Uri.fromFile(new File(this.f1452c.getFilesDir(), "debug_info.txt"));
        } catch (Throwable th32) {
            th = th32;
            openFileOutput = null;
            th2 = th;
            if (openFileOutput != null) {
                openFileOutput.close();
            }
            throw th2;
        }
        return Uri.fromFile(new File(this.f1452c.getFilesDir(), "debug_info.txt"));
    }

    private List m2553g() {
        List arrayList = new ArrayList();
        arrayList.add(m2554h());
        arrayList.add(m2545a("-d"));
        arrayList.add(m2552f());
        return arrayList;
    }

    private Uri m2545a(String str) {
        FileOutputStream openFileOutput;
        Process exec;
        FileOutputStream fileOutputStream;
        BufferedReader bufferedReader;
        Throwable th;
        Throwable th2;
        Process process = null;
        BufferedReader bufferedReader2;
        try {
            openFileOutput = this.f1452c.openFileOutput("logcat.txt", 1);
            try {
                exec = Runtime.getRuntime().exec("logcat " + str);
            } catch (IOException e) {
                exec = null;
                fileOutputStream = openFileOutput;
                try {
                    Log.e(f1450a, "rageshake/fail to read logs.");
                    if (exec != null) {
                        exec.destroy();
                    }
                    if (bufferedReader != null) {
                        try {
                            bufferedReader.close();
                        } catch (IOException e2) {
                            Log.e(f1450a, "rageshake/fail to close buffered reader for logs.");
                        }
                    }
                    if (fileOutputStream != null) {
                        try {
                            fileOutputStream.close();
                        } catch (IOException e3) {
                            Log.e(f1450a, "rageshake/fail to close output stream for logs.");
                        }
                    }
                    return Uri.fromFile(new File(this.f1452c.getFilesDir(), "logcat.txt"));
                } catch (Throwable th3) {
                    th = th3;
                    openFileOutput = fileOutputStream;
                    bufferedReader2 = bufferedReader;
                    process = exec;
                    th2 = th;
                    if (process != null) {
                        process.destroy();
                    }
                    if (bufferedReader2 != null) {
                        try {
                            bufferedReader2.close();
                        } catch (IOException e4) {
                            Log.e(f1450a, "rageshake/fail to close buffered reader for logs.");
                        }
                    }
                    if (openFileOutput != null) {
                        try {
                            openFileOutput.close();
                        } catch (IOException e5) {
                            Log.e(f1450a, "rageshake/fail to close output stream for logs.");
                        }
                    }
                    throw th2;
                }
            } catch (Throwable th4) {
                th2 = th4;
                bufferedReader2 = null;
                if (process != null) {
                    process.destroy();
                }
                if (bufferedReader2 != null) {
                    bufferedReader2.close();
                }
                if (openFileOutput != null) {
                    openFileOutput.close();
                }
                throw th2;
            }
            try {
                bufferedReader2 = new BufferedReader(new InputStreamReader(exec.getInputStream()));
                while (true) {
                    try {
                        String readLine = bufferedReader2.readLine();
                        if (readLine == null) {
                            break;
                        }
                        openFileOutput.write((readLine + "\n").getBytes());
                    } catch (IOException e6) {
                        bufferedReader = bufferedReader2;
                        fileOutputStream = openFileOutput;
                    } catch (Throwable th5) {
                        th = th5;
                        process = exec;
                        th2 = th;
                    }
                }
                if (exec != null) {
                    exec.destroy();
                }
                try {
                    bufferedReader2.close();
                } catch (IOException e7) {
                    Log.e(f1450a, "rageshake/fail to close buffered reader for logs.");
                }
                if (openFileOutput != null) {
                    try {
                        openFileOutput.close();
                    } catch (IOException e8) {
                        Log.e(f1450a, "rageshake/fail to close output stream for logs.");
                    }
                }
            } catch (IOException e9) {
                fileOutputStream = openFileOutput;
                Log.e(f1450a, "rageshake/fail to read logs.");
                if (exec != null) {
                    exec.destroy();
                }
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
                return Uri.fromFile(new File(this.f1452c.getFilesDir(), "logcat.txt"));
            } catch (Throwable th6) {
                th = th6;
                bufferedReader2 = null;
                process = exec;
                th2 = th;
                if (process != null) {
                    process.destroy();
                }
                if (bufferedReader2 != null) {
                    bufferedReader2.close();
                }
                if (openFileOutput != null) {
                    openFileOutput.close();
                }
                throw th2;
            }
        } catch (IOException e10) {
            exec = null;
            fileOutputStream = null;
            Log.e(f1450a, "rageshake/fail to read logs.");
            if (exec != null) {
                exec.destroy();
            }
            if (bufferedReader != null) {
                bufferedReader.close();
            }
            if (fileOutputStream != null) {
                fileOutputStream.close();
            }
            return Uri.fromFile(new File(this.f1452c.getFilesDir(), "logcat.txt"));
        } catch (Throwable th7) {
            th2 = th7;
            bufferedReader2 = null;
            openFileOutput = null;
            if (process != null) {
                process.destroy();
            }
            if (bufferedReader2 != null) {
                bufferedReader2.close();
            }
            if (openFileOutput != null) {
                openFileOutput.close();
            }
            throw th2;
        }
        return Uri.fromFile(new File(this.f1452c.getFilesDir(), "logcat.txt"));
    }

    private void m2547a(List list) {
        View editText = new EditText(this.f1452c);
        editText.setLines(4);
        editText.setMaxLines(4);
        editText.setGravity(48);
        editText.setInputType(16384);
        AlertDialog create = new Builder(this.f1452c).setTitle("Rage Shake").setMessage("Please provide any details that may help the team debug this issue.").setView(editText).setCancelable(true).setNegativeButton("Cancel", new C0373c(this, editText)).setPositiveButton("Send", new C0372b(this, editText, list)).create();
        create.setOnDismissListener(new C0374d(this));
        editText.setOnFocusChangeListener(new C0375e(this, create));
        create.show();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private android.net.Uri m2554h() {
        /*
        r6 = this;
        r0 = 0;
        r1 = com.facebook.lite.ClientApplication.m1691c();
        r1 = r1.m2381M();
        if (r1 != 0) goto L_0x000c;
    L_0x000b:
        return r0;
    L_0x000c:
        r1 = r1.m1790h();
        r2 = r1.getScreenshot();
        if (r2 == 0) goto L_0x000b;
    L_0x0016:
        r1 = r6.f1452c;	 Catch:{ IOException -> 0x004f, all -> 0x006f }
        r3 = "screenshot.png";
        r4 = 1;
        r0 = r1.openFileOutput(r3, r4);	 Catch:{ IOException -> 0x004f, all -> 0x006f }
        r1 = android.graphics.Bitmap.CompressFormat.PNG;	 Catch:{ IOException -> 0x004f }
        r3 = 90;
        r2.compress(r1, r3, r0);	 Catch:{ IOException -> 0x004f }
        r1 = r2.isRecycled();
        if (r1 != 0) goto L_0x002f;
    L_0x002c:
        r2.recycle();
    L_0x002f:
        if (r0 == 0) goto L_0x0034;
    L_0x0031:
        r0.close();	 Catch:{ IOException -> 0x0046 }
    L_0x0034:
        r0 = new java.io.File;
        r1 = r6.f1452c;
        r1 = r1.getFilesDir();
        r2 = "screenshot.png";
        r0.<init>(r1, r2);
        r0 = android.net.Uri.fromFile(r0);
        goto L_0x000b;
    L_0x0046:
        r0 = move-exception;
        r0 = f1450a;
        r1 = "rageshake/fail to close output stream for screen shot.";
        android.util.Log.e(r0, r1);
        goto L_0x0034;
    L_0x004f:
        r1 = move-exception;
        r1 = f1450a;	 Catch:{ all -> 0x008b }
        r3 = "rageshake/fail to get screen shot.";
        android.util.Log.e(r1, r3);	 Catch:{ all -> 0x008b }
        r1 = r2.isRecycled();
        if (r1 != 0) goto L_0x0060;
    L_0x005d:
        r2.recycle();
    L_0x0060:
        if (r0 == 0) goto L_0x0034;
    L_0x0062:
        r0.close();	 Catch:{ IOException -> 0x0066 }
        goto L_0x0034;
    L_0x0066:
        r0 = move-exception;
        r0 = f1450a;
        r1 = "rageshake/fail to close output stream for screen shot.";
        android.util.Log.e(r0, r1);
        goto L_0x0034;
    L_0x006f:
        r1 = move-exception;
        r5 = r1;
        r1 = r0;
        r0 = r5;
    L_0x0073:
        r3 = r2.isRecycled();
        if (r3 != 0) goto L_0x007c;
    L_0x0079:
        r2.recycle();
    L_0x007c:
        if (r1 == 0) goto L_0x0081;
    L_0x007e:
        r1.close();	 Catch:{ IOException -> 0x0082 }
    L_0x0081:
        throw r0;
    L_0x0082:
        r1 = move-exception;
        r1 = f1450a;
        r2 = "rageshake/fail to close output stream for screen shot.";
        android.util.Log.e(r1, r2);
        goto L_0x0081;
    L_0x008b:
        r1 = move-exception;
        r5 = r1;
        r1 = r0;
        r0 = r5;
        goto L_0x0073;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.l.g.h():android.net.Uri");
    }
}
