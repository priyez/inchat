package com.facebook.p038e.p040b.p041a.p042a;

import android.content.Context;
import com.facebook.p038e.C0251k;
import com.facebook.p038e.C0253n;
import com.facebook.p038e.p040b.p041a.C0215a;
import com.facebook.p038e.p040b.p041a.C0220b;

/* renamed from: com.facebook.e.b.a.a.b */
public final class C0219b extends C0215a {
    private final C0220b f832a;
    private final C0220b f833b;

    public C0219b(Context context) {
        super("push_notification", C0253n.MUST_HAVE);
        this.f833b = new C0220b(context, "push_received_count");
        this.f832a = new C0220b(context, "push_shown");
    }

    public final void m1544d() {
        this.f832a.m1550c();
    }

    public final void m1545e() {
        this.f833b.m1550c();
    }

    protected final C0220b[] m1543c() {
        return new C0220b[]{this.f832a, this.f833b};
    }

    protected final void m1542a(C0251k c0251k) {
        c0251k.m1680b("step", "push_counters");
    }
}
