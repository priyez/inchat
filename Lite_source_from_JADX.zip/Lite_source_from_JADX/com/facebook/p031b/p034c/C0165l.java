package com.facebook.p031b.p034c;

import com.facebook.p031b.C0148a;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;

/* renamed from: com.facebook.b.c.l */
public final class C0165l implements C0155b {
    private Proxy f638a;

    public C0165l(Proxy proxy) {
        this.f638a = proxy;
    }

    public final HttpURLConnection m1357a(URL url) {
        return C0165l.m1356a((HttpURLConnection) (this.f638a != null ? url.openConnection(this.f638a) : url.openConnection()));
    }

    private static HttpURLConnection m1356a(HttpURLConnection httpURLConnection) {
        C0148a.m1327a();
        httpURLConnection.setConnectTimeout(3000);
        C0148a.m1327a();
        httpURLConnection.setReadTimeout(3000);
        return httpURLConnection;
    }
}
