package com.facebook.p038e.p045d;

import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;

@TargetApi(16)
/* renamed from: com.facebook.e.d.e */
public final class C0235e extends C0233c {
    public C0235e(ActivityManager activityManager) {
        super(activityManager);
    }

    protected final long m1614a(MemoryInfo memoryInfo) {
        if (memoryInfo != null) {
            return memoryInfo.totalMem;
        }
        return -1;
    }
}
