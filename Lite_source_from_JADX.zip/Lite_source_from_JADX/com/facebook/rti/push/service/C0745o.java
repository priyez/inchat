package com.facebook.rti.push.service;

import com.facebook.rti.p046a.p074f.C0527a;
import com.facebook.rti.p078b.p096g.C0716y;

/* renamed from: com.facebook.rti.push.service.o */
final class C0745o implements C0716y {
    final /* synthetic */ FbnsService f3185a;

    C0745o(FbnsService fbnsService) {
        this.f3185a = fbnsService;
    }

    public final void m3974a() {
        C0527a.m3338b("FbnsService", "Publish successful", new Object[0]);
        this.f3185a.f3114u.m3957a(C0732b.UNREGISTER_REQUEST_SENT_SUCCESS, null);
    }

    public final void m3975b() {
        C0527a.m3338b("FbnsService", "Publish failed", new Object[0]);
        this.f3185a.f3114u.m3957a(C0732b.UNREGISTER_REQUEST_SENT_FAIL, null);
    }
}
