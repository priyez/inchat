package com.facebook.lite;

final class ab implements Runnable {
    final /* synthetic */ int f1109a;
    final /* synthetic */ String f1110b;
    final /* synthetic */ String f1111c;
    final /* synthetic */ String f1112d;
    final /* synthetic */ int f1113e;
    final /* synthetic */ MainActivity f1114f;

    ab(MainActivity mainActivity, int i, String str, String str2, String str3, int i2) {
        this.f1114f = mainActivity;
        this.f1109a = i;
        this.f1110b = str;
        this.f1111c = str2;
        this.f1112d = str3;
        this.f1113e = i2;
    }

    public final void run() {
        this.f1114f.f976h.m3185a(this.f1109a, this.f1110b, this.f1111c, this.f1113e);
    }
}
