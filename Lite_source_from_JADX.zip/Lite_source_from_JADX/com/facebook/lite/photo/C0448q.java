package com.facebook.lite.photo;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import com.facebook.p038e.C0251k;

/* renamed from: com.facebook.lite.photo.q */
public final class C0448q extends AsyncTask {
    final /* synthetic */ PreviewActivity f1791a;

    public C0448q(PreviewActivity previewActivity) {
        this.f1791a = previewActivity;
    }

    protected final /* synthetic */ Object doInBackground(Object[] objArr) {
        return m3072a((String[]) objArr);
    }

    protected final /* synthetic */ void onPostExecute(Object obj) {
        m3073a((Bitmap) obj);
    }

    private Bitmap m3072a(String... strArr) {
        Bitmap a = C0444m.m3044a(strArr[0], new C0251k("ema_launch_preview"), this.f1791a.f1751b, this.f1791a.f1754e);
        this.f1791a.f1754e = 0;
        this.f1791a.f1752c = C0444m.m3041a(a);
        return this.f1791a.f1752c;
    }

    private void m3073a(Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            this.f1791a.f1753d.setImageBitmap(bitmap);
            this.f1791a.f1755f.setVisibility(0);
        }
    }
}
