package com.facebook.lite.p068p;

import java.net.SocketException;
import java.util.concurrent.RejectedExecutionException;

/* renamed from: com.facebook.lite.p.a */
final class C0427a extends Thread {
    final /* synthetic */ C0429c f1711a;

    private C0427a(C0429c c0429c) {
        this.f1711a = c0429c;
    }

    public final void run() {
        Exception e;
        while (this.f1711a.f1718e) {
            try {
                try {
                    this.f1711a.f1717d.submit(new C0428b(this.f1711a, this.f1711a.f1721h.accept()));
                } catch (SocketException e2) {
                    e = e2;
                    C0429c.f1714a;
                    new StringBuilder("Exception in ServerSocketThread.run: ").append(e.getMessage());
                } catch (RejectedExecutionException e3) {
                    e = e3;
                    C0429c.f1714a;
                    new StringBuilder("Exception in ServerSocketThread.run: ").append(e.getMessage());
                }
            } catch (Throwable e4) {
                this.f1711a.f1719f.m124a((short) 294, null, e4);
                this.f1711a.m2962d();
                return;
            }
        }
    }
}
