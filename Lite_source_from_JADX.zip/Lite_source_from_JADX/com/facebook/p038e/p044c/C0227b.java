package com.facebook.p038e.p044c;

/* renamed from: com.facebook.e.c.b */
public final class C0227b {
    public static final int f853a;
    public static final int f854b;
    public static final int f855c;
    public static final int f856d;
    private static final /* synthetic */ int[] f857e;

    static {
        f853a = 1;
        f854b = 2;
        f855c = 3;
        f856d = 4;
        f857e = new int[]{f853a, f854b, f855c, f856d};
    }

    public static int[] m1563a() {
        return (int[]) f857e.clone();
    }
}
