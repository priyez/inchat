package com.facebook.lite.p063k;

import com.p008a.p009a.p010a.C0010a;
import java.util.ArrayList;
import java.util.List;

/* renamed from: com.facebook.lite.k.b */
public final class C0369b {
    private final List f1433a;
    private final String f1434b;
    private final List f1435c;

    public C0369b(String str) {
        this.f1433a = new ArrayList();
        this.f1435c = new ArrayList();
        this.f1434b = str;
    }

    public final void m2541a(String str) {
        this.f1433a.add(str);
    }

    public final void m2542b(String str) {
        this.f1435c.add(str);
    }

    public final void m2540a(C0010a c0010a) {
        c0010a.m67a(105, this.f1434b);
        for (String a : this.f1433a) {
            c0010a.m67a(103, a);
        }
        for (String a2 : this.f1435c) {
            c0010a.m67a(115, a2);
        }
        c0010a.m69b();
    }
}
