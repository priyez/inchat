package com.facebook.p031b.p034c;

import com.facebook.p031b.C0148a;
import java.net.Proxy;
import java.net.URL;
import java.util.Map;
import org.json.JSONObject;

/* renamed from: com.facebook.b.c.g */
public final class C0160g {
    public static void m1346a(Map map, URL url, String str, Proxy proxy) {
        C0156c b;
        C0155b c0165l;
        if (str == "application/json") {
            b = C0160g.m1347b(map);
        } else {
            b = C0160g.m1345a(map);
        }
        if (C0148a.m1327a().m1317d()) {
            c0165l = new C0165l(proxy);
        } else {
            Object c0170q = new C0170q(proxy);
        }
        URL url2 = url;
        new C0158e(c0165l).m1343a(url2, b, new C0154a(), str, C0148a.m1327a().m1319f());
    }

    private static C0156c m1345a(Map map) {
        return new C0159f(map);
    }

    private static C0156c m1347b(Map map) {
        return new C0157d(new JSONObject(map).toString());
    }
}
