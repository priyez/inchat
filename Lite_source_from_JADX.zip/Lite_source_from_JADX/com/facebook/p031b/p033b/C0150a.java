package com.facebook.p031b.p033b;

/* renamed from: com.facebook.b.b.a */
public interface C0150a extends C0149c {
    boolean m1333a(String str);
}
