package com.facebook.lite.photo;

import android.graphics.Bitmap;
import android.os.Build.VERSION;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.p049a.C0283l;
import com.p008a.p009a.p010a.p012b.C0011a;

/* renamed from: com.facebook.lite.photo.i */
final class C0440i extends C0283l {
    final /* synthetic */ C0443l f1766a;

    C0440i(C0443l c0443l, int i) {
        this.f1766a = c0443l;
        super(i);
    }

    protected final /* synthetic */ void m3017c(Object obj) {
        C0440i.m3016b((Bitmap) obj);
    }

    protected final /* synthetic */ int m3018d(Object obj) {
        return C0440i.m3015a((Bitmap) obj);
    }

    private static int m3015a(Bitmap bitmap) {
        if (VERSION.SDK_INT >= 12) {
            return bitmap.getByteCount();
        }
        return bitmap.getRowBytes() * bitmap.getHeight();
    }

    private static void m3016b(Bitmap bitmap) {
        ClientApplication.m1691c().m2387S().m2639N().m168a(C0011a.m76a((Object) bitmap));
    }
}
