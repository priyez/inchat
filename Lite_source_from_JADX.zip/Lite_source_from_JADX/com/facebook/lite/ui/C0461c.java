package com.facebook.lite.ui;

/* renamed from: com.facebook.lite.ui.c */
public interface C0461c {
    void m3124a(int i);
}
