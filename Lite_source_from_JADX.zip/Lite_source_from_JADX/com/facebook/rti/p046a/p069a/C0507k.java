package com.facebook.rti.p046a.p069a;

import android.os.Handler;
import android.os.Message;

/* renamed from: com.facebook.rti.a.a.k */
final class C0507k extends Handler {
    final /* synthetic */ C0512p f2153a;

    C0507k(C0512p c0512p) {
        this.f2153a = c0512p;
    }

    public final void handleMessage(Message message) {
        C0512p c0512p;
        if (message.what == 1) {
            c0512p = this.f2153a;
            if (c0512p.f2165g.compareAndSet(false, true)) {
                c0512p.f2164f.execute(c0512p.f2166h);
            }
        } else if (message.what == 2) {
            c0512p = this.f2153a;
            c0512p.f2163e.add(new C0510n((byte) 0));
            if (c0512p.f2165g.compareAndSet(false, true)) {
                c0512p.f2164f.execute(c0512p.f2166h);
            }
            c0512p = this.f2153a;
            c0512p.f2163e.add(new C0511o((byte) 0));
            if (c0512p.f2165g.compareAndSet(false, true)) {
                c0512p.f2164f.execute(c0512p.f2166h);
            }
        }
    }
}
