package com.facebook.lite.photo;

import android.graphics.Bitmap;

/* renamed from: com.facebook.lite.photo.v */
public interface C0433v {
    void m3008a(Object obj, Bitmap bitmap);
}
