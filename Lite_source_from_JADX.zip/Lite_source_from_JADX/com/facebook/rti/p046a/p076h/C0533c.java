package com.facebook.rti.p046a.p076h;

import android.os.SystemClock;

/* renamed from: com.facebook.rti.a.h.c */
public final class C0533c implements C0532b {
    private static final C0533c f2216a;

    static {
        f2216a = new C0533c();
    }

    private C0533c() {
    }

    public static C0533c m3352b() {
        return f2216a;
    }

    public final long m3353a() {
        return SystemClock.elapsedRealtime();
    }
}
