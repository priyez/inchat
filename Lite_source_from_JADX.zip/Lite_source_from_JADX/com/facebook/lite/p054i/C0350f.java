package com.facebook.lite.p054i;

import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;

/* renamed from: com.facebook.lite.i.f */
final class C0350f implements LocationListener {
    final /* synthetic */ C0351g f1385a;

    private C0350f(C0351g c0351g) {
        this.f1385a = c0351g;
    }

    public final void onLocationChanged(Location location) {
        Location a = C0351g.m2477b(location);
        if (a != null) {
            this.f1385a.m2481c(a);
        }
        if (this.f1385a.f1394i) {
            this.f1385a.m2496b();
        }
    }

    public final void onProviderDisabled(String str) {
    }

    public final void onProviderEnabled(String str) {
    }

    public final void onStatusChanged(String str, int i, Bundle bundle) {
    }
}
