package com.facebook.p038e.p044c;

import android.content.Context;
import com.facebook.lite.ClientApplication;
import com.facebook.p038e.C0251k;

/* renamed from: com.facebook.e.c.d */
public final class C0229d {
    private Context f865a;
    private final C0228c f866b;

    public C0229d() {
        this.f866b = new C0228c();
    }

    public final void m1575a(long j) {
        m1574c(C0227b.f853a, j);
        m1573b(C0227b.f853a, j);
    }

    public final void m1576b(long j) {
        m1574c(C0227b.f855c, j);
        m1573b(C0227b.f855c, j);
    }

    public final void m1577c(long j) {
        m1574c(C0227b.f854b, j);
    }

    public final void m1578d(long j) {
        m1574c(C0227b.f856d, j);
    }

    private void m1572a(C0251k c0251k) {
        if (c0251k != null && ClientApplication.m1691c().m2391W()) {
            if (this.f865a == null) {
                this.f865a = ClientApplication.m1691c().m2377I();
            }
            C0251k.m1672a(c0251k, this.f865a);
        }
    }

    private static C0251k m1571a(int i, long j) {
        String str;
        if (i == C0227b.f855c) {
            str = "foreground";
        } else if (i != C0227b.f853a) {
            return null;
        } else {
            str = "background";
        }
        C0251k c0251k = new C0251k("app_state");
        c0251k.m1680b("state", str);
        c0251k.m1661a(j);
        return c0251k;
    }

    private void m1573b(int i, long j) {
        m1572a(C0229d.m1571a(i, j));
    }

    private void m1574c(int i, long j) {
        m1572a(this.f866b.m1570a(j, i));
    }
}
