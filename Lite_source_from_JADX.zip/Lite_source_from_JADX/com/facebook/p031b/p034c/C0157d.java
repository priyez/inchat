package com.facebook.p031b.p034c;

import java.io.OutputStream;

/* renamed from: com.facebook.b.c.d */
public final class C0157d implements C0156c {
    private final String f629a;

    public C0157d(String str) {
        this.f629a = str;
    }

    public final void m1342a(OutputStream outputStream) {
        outputStream.write(this.f629a.getBytes());
    }
}
