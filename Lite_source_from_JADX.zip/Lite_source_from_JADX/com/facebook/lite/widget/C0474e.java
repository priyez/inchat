package com.facebook.lite.widget;

import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;

/* renamed from: com.facebook.lite.widget.e */
final class C0474e implements Runnable {
    final /* synthetic */ int f2078a;
    final /* synthetic */ int f2079b;
    final /* synthetic */ ConnectivityBar f2080c;

    C0474e(ConnectivityBar connectivityBar, int i, int i2) {
        this.f2080c = connectivityBar;
        this.f2078a = i;
        this.f2079b = i2;
    }

    public final void run() {
        LayoutParams layoutParams = new FrameLayout.LayoutParams(this.f2078a, this.f2079b);
        layoutParams.setMargins(0, 0, 0, 0);
        layoutParams.gravity = 48;
        this.f2080c.setLayoutParams(layoutParams);
        this.f2080c.setVisibility(0);
    }
}
