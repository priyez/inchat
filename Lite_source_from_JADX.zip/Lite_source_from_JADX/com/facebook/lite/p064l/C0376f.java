package com.facebook.lite.p064l;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executor;

/* renamed from: com.facebook.lite.l.f */
final class C0376f implements Executor {
    final /* synthetic */ C0377g f1448a;
    private final Handler f1449b;

    C0376f(C0377g c0377g) {
        this.f1448a = c0377g;
        this.f1449b = new Handler(Looper.getMainLooper());
    }

    public final void execute(Runnable runnable) {
        this.f1449b.post(runnable);
    }
}
