package com.facebook.lite;

public final class an {
    public static final int app_full_name = 2131165185;
    public static final int app_name = 2131165184;
    public static final int dialog_install = 2131165188;
    public static final int dialog_update = 2131165187;
    public static final int multipicker_next = 2131165189;
    public static final int multipicker_upload_photo_text = 2131165190;
    public static final int notification_update = 2131165186;
    public static final int preview_rotate_image = 2131165192;
    public static final int preview_select = 2131165191;
    public static final int video_loading_text = 2131165193;
}
