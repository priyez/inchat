package com.facebook.lite.widget;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

/* renamed from: com.facebook.lite.widget.y */
final class C0492y implements OnItemClickListener {
    final /* synthetic */ InlineTextBox f2113a;

    C0492y(InlineTextBox inlineTextBox) {
        this.f2113a = inlineTextBox;
    }

    public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
        this.f2113a.m3204a(view);
    }
}
