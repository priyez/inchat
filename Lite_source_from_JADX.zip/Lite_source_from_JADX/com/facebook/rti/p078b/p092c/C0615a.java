package com.facebook.rti.p078b.p092c;

import android.net.NetworkInfo;
import com.facebook.rti.p078b.p080b.p081a.C0539a;
import java.util.Map;

/* renamed from: com.facebook.rti.b.c.a */
public abstract class C0615a {
    final C0539a f2525a;

    protected abstract String m3529a();

    public final boolean m3531a(Map map) {
        return m3532b(map);
    }

    public C0615a(C0539a c0539a) {
        this.f2525a = c0539a;
    }

    protected boolean m3532b(Map map) {
        return true;
    }

    protected final void m3530a(Map map, NetworkInfo networkInfo) {
        if (map != null) {
            if (networkInfo == null) {
                map.put(m3529a(), "no_info");
                return;
            }
            map.put(m3529a(), String.format(null, "%s_%s_%s", new Object[]{Integer.valueOf(networkInfo.getType()), Integer.valueOf(networkInfo.getSubtype()), networkInfo.getState()}));
        }
    }
}
