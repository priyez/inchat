package com.facebook.lite;

import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;

/* renamed from: com.facebook.lite.p */
final class C0430p implements OnCancelListener {
    final /* synthetic */ C0455r f1725a;

    C0430p(C0455r c0455r) {
        this.f1725a = c0455r;
    }

    public final void onCancel(DialogInterface dialogInterface) {
        if (this.f1725a.f1812b) {
            this.f1725a.f1816f.m1747b(this.f1725a.f1816f.f984p);
        } else {
            this.f1725a.f1816f.m1737a(this.f1725a.f1816f.f984p);
        }
    }
}
