package com.facebook.lite;

import android.view.View;
import android.view.View.OnClickListener;
import com.facebook.lite.widget.ae;

final class aa implements OnClickListener {
    final /* synthetic */ ae f1106a;
    final /* synthetic */ boolean f1107b;
    final /* synthetic */ MainActivity f1108c;

    aa(MainActivity mainActivity, ae aeVar, boolean z) {
        this.f1108c = mainActivity;
        this.f1106a = aeVar;
        this.f1107b = z;
    }

    public final void onClick(View view) {
        this.f1108c.m1747b(this.f1106a);
    }
}
