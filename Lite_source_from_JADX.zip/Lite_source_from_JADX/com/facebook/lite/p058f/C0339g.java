package com.facebook.lite.p058f;

import com.facebook.lite.p053b.C0294h;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TimeZone;

/* renamed from: com.facebook.lite.f.g */
public final class C0339g {
    public static final TimeZone f1328a;
    public static final Calendar f1329b;

    static {
        TimeZone b = C0294h.m1964b();
        f1328a = b;
        f1329b = C0339g.m2343a(b);
    }

    public static String m2342a(long j) {
        if (j < 1000) {
            return j + "B";
        }
        int log = (int) (Math.log((double) j) / Math.log(1000.0d));
        String substring = "KMGTPE".substring(log - 1, log);
        return String.format("%.1f%s", new Object[]{Double.valueOf(((double) j) / Math.pow(1000.0d, (double) log)), substring});
    }

    public static int m2341a() {
        int i = 0;
        Calendar instance = Calendar.getInstance(f1328a);
        instance.set(11, 0);
        instance.set(12, 0);
        instance.set(13, 0);
        instance.set(14, 0);
        while (instance.after(f1329b)) {
            instance.add(5, -1);
            i++;
        }
        return i;
    }

    public static List m2344a(int i) {
        List arrayList = new ArrayList(2);
        Calendar calendar = (Calendar) f1329b.clone();
        calendar.add(5, i);
        arrayList.add(Long.valueOf(calendar.getTime().getTime()));
        calendar.add(5, 1);
        arrayList.add(Long.valueOf(calendar.getTime().getTime() - 1));
        return arrayList;
    }

    public static Map m2345a(Map map, Map map2) {
        for (Entry entry : map2.entrySet()) {
            C0338f c0338f = (C0338f) entry.getKey();
            if (map.containsKey(c0338f)) {
                ((C0333a) map.get(c0338f)).m2318a((C0333a) entry.getValue());
            } else {
                map.put(c0338f, new C0333a((C0333a) entry.getValue()));
            }
        }
        return map;
    }

    private static Calendar m2343a(TimeZone timeZone) {
        Calendar instance = Calendar.getInstance(timeZone);
        instance.set(1970, 1, 1, 0, 0, 0);
        instance.set(14, 0);
        return instance;
    }
}
