package com.facebook.lite.net.p066a;

/* renamed from: com.facebook.lite.net.a.b */
public enum C0394b {
    FREE(1),
    PAID(0);
    
    private int f1565c;

    private C0394b(int i) {
        this.f1565c = i;
    }

    public static C0394b m2727a(int i) {
        if (i == FREE.m2728a()) {
            return FREE;
        }
        return PAID;
    }

    public final int m2728a() {
        return this.f1565c;
    }
}
