package com.facebook.p038e.p045d;

import android.app.ActivityManager.MemoryInfo;

/* renamed from: com.facebook.e.d.g */
public final class C0237g {
    private final MemoryInfo f897a;
    private final long f898b;

    C0237g(MemoryInfo memoryInfo, long j) {
        this.f897a = memoryInfo;
        this.f898b = j;
    }

    public final long m1619a() {
        return this.f898b;
    }
}
