package com.facebook.lite;

import android.os.Handler;
import com.facebook.lite.p065n.C0391a;

/* renamed from: com.facebook.lite.r */
final class C0455r implements Runnable {
    final /* synthetic */ boolean f1811a;
    final /* synthetic */ boolean f1812b;
    final /* synthetic */ boolean f1813c;
    final /* synthetic */ boolean f1814d;
    final /* synthetic */ String f1815e;
    final /* synthetic */ MainActivity f1816f;

    C0455r(MainActivity mainActivity, boolean z, boolean z2, boolean z3, boolean z4, String str) {
        this.f1816f = mainActivity;
        this.f1811a = z;
        this.f1812b = z2;
        this.f1813c = z3;
        this.f1814d = z4;
        this.f1815e = str;
    }

    public final void run() {
        if (this.f1811a) {
            String a;
            this.f1816f.f977i = this.f1812b;
            this.f1816f.f991w = this.f1813c;
            if (this.f1814d) {
                this.f1816f.m1748b(this.f1815e);
                this.f1816f.f982n = this.f1815e;
            }
            String a2 = this.f1816f.f991w ? C0391a.m2719a(5) : C0391a.m2719a(6);
            if (this.f1816f.f991w) {
                a = C0391a.m2719a(7);
            } else {
                a = C0391a.m2719a(8);
            }
            this.f1816f.f984p = this.f1816f.m1732a(a2, a);
            a2 = "right";
            if (this.f1816f.f991w) {
                this.f1816f.f984p.m3271b(C0391a.m2719a(1), new C0426o(this));
            } else {
                a2 = "central";
            }
            if (this.f1812b) {
                this.f1816f.m1739a(this.f1816f.f984p, C0391a.m2719a(0), false, a2);
            } else {
                this.f1816f.m1738a(this.f1816f.f984p, a2);
            }
            this.f1816f.f984p.setOnCancelListener(new C0430p(this));
        }
        if (!this.f1816f.isFinishing() && !this.f1816f.f984p.isShowing()) {
            if (this.f1816f.f988t != null && this.f1816f.f988t.isShowing()) {
                this.f1816f.f988t.dismiss();
            }
            long currentTimeMillis = System.currentTimeMillis();
            if (this.f1816f.f991w) {
                long M = ClientApplication.m1691c().m2387S().m2638M();
                if (this.f1816f.f980l == 0) {
                    new Handler().postDelayed(new C0454q(this, currentTimeMillis), M);
                    return;
                } else if (this.f1816f.f980l > 0 && currentTimeMillis - this.f1816f.f980l > M) {
                    this.f1816f.m1784b(this.f1812b, this.f1813c);
                    this.f1816f.f980l = currentTimeMillis;
                    return;
                } else {
                    return;
                }
            }
            this.f1816f.m1784b(this.f1812b, this.f1813c);
            this.f1816f.f980l = currentTimeMillis;
        }
    }
}
