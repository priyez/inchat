package com.facebook.p038e.p040b.p041a;

import com.facebook.p038e.C0251k;
import com.facebook.p038e.C0253n;
import com.facebook.p038e.p040b.C0214a;

/* renamed from: com.facebook.e.b.a.a */
public abstract class C0215a implements C0214a {
    private final String f811a;
    private final C0253n f812b;

    protected abstract C0220b[] m1525c();

    protected C0215a(String str, C0253n c0253n) {
        this.f811a = str;
        this.f812b = c0253n;
    }

    public final C0253n m1522a() {
        return this.f812b;
    }

    public final C0251k m1524b() {
        C0251k c0251k = new C0251k(this.f811a);
        Object obj = null;
        for (C0220b c0220b : m1525c()) {
            int b = c0220b.m1549b();
            c0251k.m1679b(c0220b.m1548a(), (long) b);
            if (obj != null || b > 0) {
                obj = 1;
            } else {
                obj = null;
            }
        }
        if (obj == null) {
            return null;
        }
        m1523a(c0251k);
        return c0251k;
    }

    protected void m1523a(C0251k c0251k) {
    }
}
