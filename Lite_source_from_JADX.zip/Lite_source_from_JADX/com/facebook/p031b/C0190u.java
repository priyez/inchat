package com.facebook.p031b;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* renamed from: com.facebook.b.u */
public final class C0190u {
    public static String m1462a(Class cls) {
        StringBuilder stringBuilder = new StringBuilder();
        for (Field field : cls.getFields()) {
            stringBuilder.append(field.getName()).append("=");
            try {
                stringBuilder.append(field.get(null).toString());
            } catch (Exception e) {
                stringBuilder.append("N/A");
            }
            stringBuilder.append("\n");
        }
        return stringBuilder.toString();
    }

    public static String m1463b(Class cls) {
        StringBuilder stringBuilder = new StringBuilder();
        for (Method method : cls.getMethods()) {
            if (method.getParameterTypes().length == 0 && ((method.getName().startsWith("get") || method.getName().startsWith("is")) && !method.getName().equals("getClass"))) {
                try {
                    stringBuilder.append(method.getName()).append('=').append(method.invoke(null, null)).append("\n");
                } catch (IllegalArgumentException e) {
                } catch (IllegalAccessException e2) {
                } catch (InvocationTargetException e3) {
                }
            }
        }
        return stringBuilder.toString();
    }
}
