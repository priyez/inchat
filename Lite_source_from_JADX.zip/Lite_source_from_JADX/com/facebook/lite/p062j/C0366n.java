package com.facebook.lite.p062j;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Typeface;
import com.facebook.lite.p059m.C0387i;

/* renamed from: com.facebook.lite.j.n */
public final class C0366n implements C0353a {
    private final C0387i f1424a;
    private final Paint f1425b;
    private final C0362j f1426c;
    private final StringBuilder f1427d;
    private final Paint f1428e;
    private float f1429f;
    private final C0358i[] f1430g;

    public C0366n(C0387i c0387i) {
        this.f1426c = new C0362j();
        this.f1427d = new StringBuilder();
        this.f1430g = new C0358i[]{new C0364l(), new C0359f(this), new C0365m(this), new C0360g(), new C0363k(), new C0361h()};
        this.f1424a = c0387i;
        this.f1425b = new Paint();
        this.f1425b.setTypeface(Typeface.MONOSPACE);
        this.f1425b.setColor(-1);
        this.f1425b.setStrokeWidth(1.0f);
        this.f1425b.setStyle(Style.FILL);
        this.f1425b.setAntiAlias(true);
        this.f1428e = new Paint(this.f1425b);
        this.f1428e.setColor(-16777216);
        this.f1428e.setStyle(Style.STROKE);
        this.f1429f = this.f1428e.getTextSize();
    }

    public final void m2536a(Canvas canvas) {
        float f = this.f1429f;
        for (int i = 0; i < this.f1430g.length && this.f1428e.descent() + f < ((float) canvas.getHeight()); i++) {
            m2532a(canvas, this.f1430g[i].m2516a(this.f1427d), f);
            f += this.f1429f;
            this.f1427d.delete(0, this.f1427d.length());
        }
    }

    public final C0362j m2535a() {
        return this.f1426c;
    }

    public final int m2534a(int i) {
        Integer a = this.f1424a.m2647V().m356a(62);
        if (a == null || a.intValue() != 1) {
            return 0;
        }
        this.f1429f = (float) (((((double) (((float) i) - 5.0f)) / 50.0d) / ((double) this.f1428e.measureText("0"))) * ((double) this.f1429f));
        this.f1428e.setTextSize(this.f1429f);
        this.f1425b.setTextSize(this.f1429f);
        return (int) Math.ceil((double) (this.f1428e.descent() + (((float) this.f1430g.length) * (this.f1429f + 1.0f))));
    }

    private void m2532a(Canvas canvas, String str, float f) {
        canvas.drawText(str, 5.0f, f, this.f1425b);
        canvas.drawText(str, 5.0f, f, this.f1428e);
    }
}
