package com.facebook.lite.p049a.p051b;

import com.p008a.p009a.p010a.p014e.C0022b;
import com.p008a.p009a.p010a.p021k.C0068a;
import com.p008a.p009a.p010a.p021k.C0069b;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

/* renamed from: com.facebook.lite.a.b.a */
public class C0264a implements C0068a {
    private static final String f1003a;
    private static C0264a f1004b;
    private final Map f1005c;
    private final Map f1006d;
    private final C0022b f1007e;

    static {
        f1003a = C0264a.class.getSimpleName();
    }

    private C0264a(C0022b c0022b) {
        this.f1007e = c0022b;
        this.f1006d = new HashMap();
        this.f1005c = new HashMap();
    }

    public static C0264a m1822a(C0022b c0022b) {
        if (f1004b == null) {
            synchronized (C0264a.class) {
                if (f1004b == null) {
                    f1004b = new C0264a(c0022b);
                }
            }
        }
        return f1004b;
    }

    public final void m1824a(C0069b c0069b) {
        C0069b c0069b2 = (C0069b) this.f1005c.get(Integer.valueOf(c0069b.m436a()));
        if (c0069b2 == null || c0069b2.m440c() == 2) {
            for (int valueOf : c0069b.m439b()) {
                Integer valueOf2 = Integer.valueOf(valueOf);
                this.f1006d.put(valueOf2, c0069b);
                new StringBuilder("imagedownloadmanager/").append(c0069b.m436a()).append("/ adding ").append(valueOf2);
            }
            new StringBuilder("imagedownloadmanager/added batch ").append(c0069b.m436a());
            this.f1005c.put(Integer.valueOf(c0069b.m436a()), c0069b);
        }
    }

    public final byte m1823a(int i) {
        C0069b c0069b = (C0069b) this.f1006d.get(Integer.valueOf(i));
        if (c0069b == null) {
            return Byte.MIN_VALUE;
        }
        return c0069b.m443e();
    }

    public final boolean m1825b(int i) {
        if (this.f1005c.remove(Integer.valueOf(i)) == null) {
            return false;
        }
        Iterator it = this.f1006d.entrySet().iterator();
        while (it.hasNext()) {
            Entry entry = (Entry) it.next();
            if (((C0069b) entry.getValue()).m436a() == i) {
                new StringBuilder("imagedownloadmanager/removingtracker/imageId removed map ").append(entry.getKey());
                it.remove();
            }
        }
        return true;
    }

    public final boolean m1826c(int i) {
        C0069b c0069b = (C0069b) this.f1005c.get(Integer.valueOf(i));
        if (c0069b == null) {
            return false;
        }
        return c0069b.m437a(i);
    }

    public final boolean m1827d(int i) {
        C0069b c0069b = (C0069b) this.f1006d.get(Integer.valueOf(i));
        if (c0069b == null) {
            return false;
        }
        return c0069b.m438b(i);
    }
}
