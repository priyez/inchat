package com.facebook.lite.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build.VERSION;
import android.text.InputFilter;
import android.text.InputFilter.LengthFilter;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.facebook.lite.ClientApplication;
import com.facebook.lite.ao;
import com.facebook.lite.ap;
import com.facebook.lite.ar;
import com.facebook.lite.as;
import com.facebook.lite.av;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p053b.C0302p;
import com.facebook.lite.p057e.C0320a;
import com.facebook.lite.p057e.C0322c;
import com.facebook.lite.p057e.C0323d;
import com.facebook.lite.p057e.C0329i;
import com.p008a.p009a.p010a.p023m.C0099a;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class InlineTextBox extends RelativeLayout {
    private static final InputFilter[] f1919a;
    private static final List f1920b;
    private int f1921A;
    private int f1922B;
    private int f1923C;
    private int f1924D;
    private long f1925E;
    private String f1926F;
    private Set f1927G;
    private final TextWatcher f1928H;
    private boolean f1929I;
    private int f1930c;
    private int f1931d;
    private int f1932e;
    private boolean f1933f;
    private int f1934g;
    private boolean f1935h;
    private final LayoutParams f1936i;
    private final aa f1937j;
    private String f1938k;
    private C0476g f1939l;
    private C0323d f1940m;
    private C0329i f1941n;
    private boolean f1942o;
    private final ac f1943p;
    private Set f1944q;
    private final ListView f1945r;
    private final EditText f1946s;
    private final TextView f1947t;
    private final TextView f1948u;
    private final RelativeLayout f1949v;
    private int f1950w;
    private int f1951x;
    private short f1952y;
    private String f1953z;

    static {
        f1919a = new InputFilter[0];
        f1920b = Arrays.asList(new Byte[]{Byte.valueOf((byte) 3), Byte.valueOf((byte) 6), Byte.valueOf((byte) 2)});
    }

    public InlineTextBox(Context context) {
        this(context, null);
    }

    public InlineTextBox(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(ap.inline_textbox, this, true);
        this.f1936i = new LayoutParams(0, 0);
        this.f1949v = (RelativeLayout) findViewById(as.inline_textbox_tool_bar);
        this.f1947t = (TextView) findViewById(as.inline_textbox_right_button);
        this.f1946s = (EditText) findViewById(as.inline_textbox_edittext);
        this.f1945r = (ListView) findViewById(as.inline_textbox_contact_list);
        this.f1948u = (TextView) findViewById(as.contact_list_suggestions);
        this.f1946s.setOnFocusChangeListener(new C0487t(this));
        this.f1949v.setOnTouchListener(new C0488u(this));
        this.f1946s.setOnEditorActionListener(new C0489v(this, context));
        this.f1947t.setOnClickListener(new C0490w(this, context));
        this.f1937j = new aa();
        this.f1943p = new ac();
        this.f1944q = new TreeSet();
        this.f1927G = new HashSet();
        this.f1929I = false;
        this.f1928H = new C0491x(this);
        this.f1939l = new C0476g(getContext(), new ArrayList(), new ArrayList(), new ArrayList(), ClientApplication.m1691c().m2380L(), ClientApplication.m1691c().m2387S().m2714w());
        this.f1945r.setAdapter(this.f1939l);
        this.f1945r.setOnItemClickListener(new C0492y(this));
    }

    public InlineTextBox(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet);
    }

    public boolean dispatchKeyEventPreIme(KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() != 4) {
            return super.dispatchKeyEventPreIme(keyEvent);
        }
        if (getKeyDispatcherState() == null || keyEvent.getAction() != 0 || keyEvent.getRepeatCount() != 0) {
            return super.dispatchKeyEventPreIme(keyEvent);
        }
        if (!this.f1942o) {
            ClientApplication.m1691c().m2411a(new C0099a(this.f1944q.toArray()));
            ClientApplication.m1691c().m2448g(this.f1946s.getText().toString());
        }
        m3221a();
        return true;
    }

    public final void m3221a() {
        C0294h.m1954a(getContext(), this.f1946s);
        setVisibility(8);
    }

    public final boolean m3224b() {
        return getVisibility() == 0;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (m3224b() && this.f1949v.getVisibility() == 0 && C0294h.m1960a(motionEvent, this.f1949v, getResources().getDimensionPixelSize(av.toolbar_button_height))) {
            return super.onTouchEvent(motionEvent);
        }
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        if (x > ((float) this.f1923C) && x < ((float) (this.f1923C + this.f1922B)) && y > ((float) this.f1924D) && y < ((float) (this.f1924D + this.f1921A))) {
            C0294h.m1965b(getContext(), this.f1946s);
            return super.onTouchEvent(motionEvent);
        } else if (this.f1942o) {
            m3221a();
            return true;
        } else {
            C0341s c = ClientApplication.m1691c();
            ClientApplication.m1691c().m2411a(new C0099a(this.f1944q.toArray()));
            c.m2348g(this.f1946s.getText().toString());
            m3221a();
            return super.onTouchEvent(motionEvent);
        }
    }

    public final void m3222a(int i, String str, String str2, int i2, boolean z, int i3, int i4, int i5, int i6, String str3, String str4, C0329i c0329i, boolean z2, int i7, short s, String str5, C0099a c0099a, C0099a c0099a2, C0099a c0099a3, String str6, long j, C0323d c0323d) {
        if (i3 >= 0 && i4 >= 0 && i5 >= 0 && i6 >= 0) {
            boolean z3;
            int i8;
            this.f1923C = i3;
            this.f1924D = i4;
            this.f1922B = i5;
            this.f1921A = i6;
            this.f1936i.width = i5;
            this.f1936i.height = i6;
            this.f1936i.setMargins(i3, i4, 0, 0);
            this.f1946s.setLayoutParams(this.f1936i);
            this.f1946s.requestFocus();
            this.f1941n = c0329i;
            this.f1935h = z2;
            this.f1934g = i7;
            this.f1952y = s;
            this.f1938k = str5;
            this.f1953z = str6;
            this.f1925E = j;
            this.f1940m = c0323d;
            setVisibility(0);
            this.f1942o = (983040 & i) == 131072;
            if ((251658240 & i) == 0) {
                z3 = true;
            } else {
                z3 = false;
            }
            int i9 = i & 240;
            int i10 = ((15728640 & i) >>> 20) | i9;
            if ((i & 1024) > 0) {
                i10 |= 16384;
            }
            switch (i & 768) {
                case 0:
                    i10 |= 32768;
                    break;
                case 512:
                    i10 |= 32768;
                    break;
                case 768:
                    break;
            }
            i10 |= 524288;
            this.f1946s.setInputType(i10);
            this.f1946s.setImeOptions(i & 15);
            this.f1946s.setText(str);
            Object obj = (-268435456 & i) != 0 ? 1 : null;
            if (str3 != null) {
                Bitmap createBitmap = Bitmap.createBitmap(i5, i6, Config.ARGB_8888);
                Canvas canvas = new Canvas(createBitmap);
                canvas.drawColor(Color.parseColor(str3));
                Paint paint = new Paint();
                paint.setColor(Color.parseColor(str4));
                canvas.drawLine(0.0f, 0.0f, 0.0f, (float) (i6 - 1), paint);
                canvas.drawLine(0.0f, 0.0f, (float) (i5 - 1), 0.0f, paint);
                canvas.drawLine(0.0f, (float) (i6 - 1), (float) (i5 - 1), (float) (i6 - 1), paint);
                canvas.drawLine((float) (i5 - 1), 0.0f, (float) (i5 - 1), (float) (i6 - 1), paint);
                if (VERSION.SDK_INT < 16) {
                    this.f1946s.setBackgroundDrawable(new BitmapDrawable(getContext().getResources(), createBitmap));
                } else {
                    this.f1946s.setBackground(new BitmapDrawable(getContext().getResources(), createBitmap));
                }
            } else if (VERSION.SDK_INT < 16) {
                EditText editText = this.f1946s;
                Resources resources = getResources();
                if (obj != null) {
                    i10 = ao.inline_text_box_dark_background;
                } else {
                    i10 = ao.inline_text_box_light_background;
                }
                editText.setBackgroundDrawable(resources.getDrawable(i10));
            } else {
                this.f1946s.setBackground(getResources().getDrawable(obj != null ? ao.inline_text_box_dark_background : ao.inline_text_box_light_background));
            }
            this.f1946s.setTextColor(getResources().getColor(obj != null ? ar.light_gray : ar.black));
            if (z || i9 == 128 || i9 == 224) {
                this.f1946s.setTransformationMethod(this.f1937j);
            } else {
                this.f1946s.setTransformationMethod(this.f1943p);
                this.f1946s.setSingleLine(z3);
                this.f1946s.setGravity(z3 ? 16 : 48);
            }
            if (i2 > 0) {
                this.f1946s.setFilters(new InputFilter[]{new LengthFilter(i2)});
            } else {
                this.f1946s.setFilters(f1919a);
            }
            this.f1946s.setVerticalScrollBarEnabled(!z3);
            Object obj2 = (61440 & i) != 0 ? 1 : null;
            Object obj3 = !C0302p.m2177b((CharSequence) str2) ? 1 : null;
            this.f1947t.setText(str2);
            RelativeLayout relativeLayout = this.f1949v;
            i10 = (obj2 == null || obj3 == null) ? 8 : 0;
            relativeLayout.setVisibility(i10);
            if (this.f1946s.getText() != null) {
                this.f1946s.setSelection(this.f1946s.getText().length());
            }
            this.f1944q = new TreeSet();
            this.f1927G = new HashSet();
            this.f1929I = true;
            this.f1933f = true;
            for (i8 = 0; i8 < c0099a.m1064c(); i8++) {
                this.f1944q.add(new ad(((Short) c0099a2.m1056a(i8)).shortValue(), ((Short) c0099a3.m1056a(i8)).shortValue(), ((Long) c0099a.m1056a(i8)).longValue()));
                this.f1927G.add(Long.valueOf(((Long) c0099a.m1056a(i8)).longValue()));
            }
            if (z2) {
                setContactListVisible(false);
                this.f1946s.addTextChangedListener(this.f1928H);
                m3207a(str, str.length());
            }
            ViewGroup.LayoutParams layoutParams = new LayoutParams(-2, -2);
            i8 = this.f1946s.getLineHeight();
            layoutParams.height = (int) (((double) i7) * 0.6666666666666666d);
            layoutParams.width = ClientApplication.m1691c().m2372D();
            layoutParams.setMargins(0, (i8 * 2) + i4, 0, 0);
            this.f1948u.setLayoutParams(layoutParams);
            this.f1948u.setText(str6);
        }
    }

    public final void m3223a(boolean z, List list) {
        if (!z || list == null || list.isEmpty()) {
            setContactListVisible(false);
            return;
        }
        List arrayList = new ArrayList();
        List arrayList2 = new ArrayList();
        List arrayList3 = new ArrayList();
        for (List list2 : list) {
            arrayList.add(Long.valueOf(((Long) list2.get(0)).longValue()));
            arrayList2.add((String) list2.get(1));
            arrayList3.add(Integer.valueOf(((Integer) list2.get(2)).intValue()));
        }
        this.f1939l.m3284a(arrayList, arrayList2, arrayList3, this.f1927G, this.f1934g);
        setContactListVisible(true);
    }

    private void m3204a(View view) {
        TextView textView = (TextView) ((RelativeLayout) view).getChildAt(1);
        String charSequence = textView.getText().toString();
        long longValue = ((Long) textView.getTag()).longValue();
        m3202a(this.f1951x, this.f1950w - this.f1951x, charSequence.length());
        BreakIterator wordInstance = BreakIterator.getWordInstance(getContext().getResources().getConfiguration().locale);
        wordInstance.setText(charSequence);
        int first = wordInstance.first();
        for (int next = wordInstance.next(); next != -1; next = wordInstance.next()) {
            if (!"".equals(charSequence.substring(first, next).replaceAll("\\s+", ""))) {
                ad adVar = new ad((short) (first + this.f1951x), (short) (this.f1951x + next), longValue);
                this.f1927G.add(Long.valueOf(longValue));
                this.f1944q.add(adVar);
            }
            first = next;
        }
        this.f1933f = false;
        String obj = this.f1946s.getText().toString();
        m3207a(obj.substring(0, this.f1951x) + charSequence + obj.substring(this.f1950w), this.f1951x + charSequence.length());
        setContactListVisible(false);
        this.f1946s.setMaxLines(Integer.MAX_VALUE);
    }

    private void m3211c() {
        short selectionStart = this.f1946s.getSelectionStart();
        String substring = this.f1946s.getText().toString().substring(0, selectionStart);
        if (this.f1925E == 0 || "".equals(substring)) {
            setContactListVisible(false);
            return;
        }
        boolean z;
        for (ad adVar : this.f1944q) {
            if (selectionStart > adVar.m3264b() && selectionStart <= adVar.m3262a()) {
                setContactListVisible(false);
                return;
            }
        }
        int lastIndexOf = substring.lastIndexOf(32);
        int lastIndexOf2 = substring.lastIndexOf(10);
        int lastIndexOf3 = substring.lastIndexOf(64);
        if (lastIndexOf3 >= 0 && lastIndexOf3 > lastIndexOf && lastIndexOf3 > lastIndexOf2) {
            lastIndexOf2 = lastIndexOf3 + 1;
            z = true;
        } else if (lastIndexOf < lastIndexOf2) {
            lastIndexOf2++;
            z = false;
        } else {
            lastIndexOf2 = lastIndexOf + 1;
            z = false;
        }
        substring = substring.substring(lastIndexOf2);
        if ("".equals(substring)) {
            setContactListVisible(false);
        } else if (z || ((!Character.isUpperCase(substring.charAt(0)) || substring.length() >= 3) && (!Character.isLowerCase(substring.charAt(0)) || substring.length() >= 4))) {
            this.f1940m.m2279a(new C0320a(C0322c.f1274b, "contact_table" + this.f1925E, f1920b, substring));
            if (z) {
                this.f1951x = lastIndexOf2 - 1;
            } else {
                this.f1951x = lastIndexOf2;
            }
            this.f1950w = substring.length() + lastIndexOf2;
        } else {
            setContactListVisible(false);
        }
    }

    private void setContactListVisible(boolean z) {
        if (z) {
            this.f1945r.setVisibility(0);
            this.f1948u.setVisibility(0);
            this.f1946s.setMaxLines(2);
            return;
        }
        this.f1945r.setVisibility(8);
        this.f1948u.setVisibility(8);
        this.f1946s.setMaxLines(Integer.MAX_VALUE);
    }

    private void m3214d() {
        ClientApplication.m1691c().m2411a(new C0099a(this.f1944q.toArray()));
        ClientApplication.m1691c().m2448g(this.f1946s.getText().toString());
        m3221a();
    }

    private List m3202a(int i, int i2, int i3) {
        Collection treeSet = new TreeSet();
        int selectionStart = this.f1946s.getSelectionStart();
        int i4 = i + i2;
        this.f1927G.clear();
        int i5 = i4;
        for (ad adVar : this.f1944q) {
            short b = adVar.m3264b();
            short a = adVar.m3262a();
            int i6 = (i - i5) + i3;
            if (i5 == b) {
                this.f1929I = true;
            }
            int i7 = ((b >= i || i >= a) && ((b >= i5 || i5 >= a) && ((b >= i || a <= i5) && (b != i || i2 <= 0)))) ? 0 : true;
            if (i3 == 0) {
                if (i7 != 0 && b < i) {
                    i = b;
                }
                if (i7 != 0 && a > i5) {
                    i5 = a;
                }
            }
            if (i7 != 0) {
                this.f1929I = true;
            } else {
                if (b >= r1) {
                    adVar.m3265b((short) (b + i6));
                    adVar.m3263a((short) (a + i6));
                }
                treeSet.add(adVar);
                this.f1927G.add(Long.valueOf(adVar.m3266c()));
            }
        }
        this.f1944q.clear();
        this.f1944q.addAll(treeSet);
        i4 = ((selectionStart + i) - i5) + i2;
        EditText editText = this.f1946s;
        if (i4 <= 0) {
            i4 = 0;
        }
        editText.setSelection(i4);
        return Arrays.asList(new Integer[]{Integer.valueOf(i), Integer.valueOf(i5)});
    }

    private void m3207a(String str, int i) {
        CharSequence spannableString = new SpannableString(str);
        long j = 0;
        int i2 = 0;
        for (ad adVar : this.f1944q) {
            short b = adVar.m3264b();
            short a = adVar.m3262a();
            int color = getContext().getResources().getColor(ar.mention_highlight);
            if (j == adVar.m3266c()) {
                spannableString.setSpan(new ForegroundColorSpan(color), i2, a, 0);
                spannableString.setSpan(new StyleSpan(1), i2, a, 0);
            } else {
                spannableString.setSpan(new ForegroundColorSpan(color), b, a, 0);
                spannableString.setSpan(new StyleSpan(1), b, a, 0);
            }
            j = adVar.m3266c();
            short s = a;
        }
        this.f1929I = false;
        this.f1933f = false;
        this.f1946s.setText(spannableString);
        this.f1946s.setSelection(i);
    }
}
