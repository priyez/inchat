package com.facebook.rti.p046a.p077i;

import java.io.UnsupportedEncodingException;

/* renamed from: com.facebook.rti.a.i.c */
public final class C0537c {
    public static String m3360a(byte[] bArr) {
        try {
            return new String(bArr, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("UTF-8 not supported");
        }
    }

    public static byte[] m3361a(String str) {
        try {
            return str.getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("UTF-8 not supported");
        }
    }
}
