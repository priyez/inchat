package com.facebook.lite;

final class ak implements Runnable {
    final /* synthetic */ MainActivity f1156a;

    ak(MainActivity mainActivity) {
        this.f1156a = mainActivity;
    }

    public final void run() {
        this.f1156a.f978j.m3221a();
        this.f1156a.f976h.m3187b();
        this.f1156a.f976h.m3184a();
    }
}
