package com.p028c.p029a;

/* renamed from: com.c.a.c */
final class C0142c {
    private C0141b f609a;

    C0142c() {
    }

    final C0141b m1303a() {
        C0141b c0141b = this.f609a;
        if (c0141b == null) {
            return new C0141b();
        }
        this.f609a = c0141b.f608c;
        return c0141b;
    }

    final void m1304a(C0141b c0141b) {
        c0141b.f608c = this.f609a;
        this.f609a = c0141b;
    }
}
