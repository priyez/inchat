package com.facebook.lite.p057e;

import com.facebook.lite.ClientApplication;
import com.facebook.lite.MainActivity;
import com.facebook.lite.widget.InlineTextBox;
import java.util.List;

/* renamed from: com.facebook.lite.e.g */
public final class C0327g implements C0326k {
    public final void m2282a(C0320a c0320a) {
        MainActivity M = ClientApplication.m1691c().m2381M();
        if (M != null) {
            InlineTextBox g = M.m1789g();
            if (g != null) {
                String str = c0320a.f1267a;
                C0329i K = ClientApplication.m1691c().m2379K();
                if (K != null) {
                    List a = K.m2295a(c0320a.m2274d(), c0320a.m2272b(), str);
                    if (a == null || a.isEmpty()) {
                        M.runOnUiThread(new C0324e(this, g));
                    } else {
                        M.runOnUiThread(new C0325f(this, g, a));
                    }
                }
            }
        }
    }
}
