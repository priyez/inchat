package com.facebook.lite.widget;

/* renamed from: com.facebook.lite.widget.c */
final class C0472c implements Runnable {
    final /* synthetic */ BannerView f2076a;

    C0472c(BannerView bannerView) {
        this.f2076a = bannerView;
    }

    public final void run() {
        this.f2076a.invalidate();
    }
}
