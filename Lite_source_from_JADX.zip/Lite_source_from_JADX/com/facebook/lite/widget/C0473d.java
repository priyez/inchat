package com.facebook.lite.widget;

/* renamed from: com.facebook.lite.widget.d */
final class C0473d implements Runnable {
    final /* synthetic */ ConnectivityBar f2077a;

    C0473d(ConnectivityBar connectivityBar) {
        this.f2077a = connectivityBar;
    }

    public final void run() {
        this.f2077a.setVisibility(8);
    }
}
