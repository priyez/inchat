package com.facebook.p031b.p034c;

/* renamed from: com.facebook.b.c.a */
public final class C0154a {
    private int f628a;

    public final void m1339a(int i) {
        this.f628a = i;
    }
}
