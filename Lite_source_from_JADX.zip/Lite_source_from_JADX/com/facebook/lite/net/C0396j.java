package com.facebook.lite.net;

import com.p008a.p009a.p010a.p023m.C0115e;

/* renamed from: com.facebook.lite.net.j */
public interface C0396j {
    void m2739a();

    void m2740a(long j);

    void m2741a(C0115e c0115e);

    void m2742a(C0411r c0411r);

    void m2743a(short s);

    void m2744b();

    boolean m2745b(C0411r c0411r);

    boolean m2746c();

    void m2747d();

    void m2748e();

    void m2749f();

    void m2750q();
}
