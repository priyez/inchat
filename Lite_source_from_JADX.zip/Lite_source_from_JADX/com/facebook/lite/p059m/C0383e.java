package com.facebook.lite.p059m;

import com.facebook.lite.net.C0403i;
import com.facebook.lite.net.p066a.C0394b;

/* renamed from: com.facebook.lite.m.e */
final class C0383e implements Runnable {
    final /* synthetic */ boolean f1475a;
    final /* synthetic */ boolean f1476b;
    final /* synthetic */ C0387i f1477c;

    C0383e(C0387i c0387i, boolean z, boolean z2) {
        this.f1477c = c0387i;
        this.f1475a = z;
        this.f1476b = z2;
    }

    public final void run() {
        if (this.f1475a) {
            this.f1477c.f1533q = 0;
        }
        if (this.f1476b) {
            this.f1477c.f1502H = 0;
        }
        if (this.f1477c.f1533q <= C0403i.f1627b) {
            if (this.f1477c.f1501G == null) {
                this.f1477c.aQ();
                this.f1477c.f1501G = this.f1477c.aL();
            } else {
                C0394b a = this.f1477c.f1508N.m2725a();
                if (this.f1477c.f1509O != a) {
                    if (this.f1477c.f1501G.m2745b(this.f1477c.m2569a(a))) {
                        this.f1477c.f1509O = a;
                    }
                }
            }
            this.f1477c.f1501G.m2750q();
        }
    }
}
