package com.facebook.p038e;

import android.accounts.AccountManager;
import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ConfigurationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Point;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Environment;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.text.format.Time;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import com.facebook.lite.p053b.C0300n;
import com.facebook.p038e.p039a.C0208a;
import com.facebook.p038e.p045d.C0233c;
import com.facebook.p038e.p045d.C0234d;
import com.facebook.p038e.p045d.C0235e;
import com.facebook.p038e.p045d.C0236f;
import com.facebook.p038e.p045d.C0238h;
import com.facebook.p038e.p045d.C0240j;
import com.facebook.p038e.p045d.C0241k;
import com.facebook.p038e.p045d.C0242l;
import java.io.File;
import java.util.Locale;

/* renamed from: com.facebook.e.e */
public final class C0244e {
    private final ActivityManager f910a;
    private final Context f911b;
    private final C0233c f912c;
    private final C0234d f913d;
    private final Locale f914e;
    private final PackageManager f915f;
    private final C0240j f916g;
    private final C0241k f917h;
    private final TelephonyManager f918i;

    public C0244e(Context context) {
        this.f911b = context.getApplicationContext();
        this.f915f = this.f911b.getPackageManager();
        this.f910a = (ActivityManager) this.f911b.getSystemService("activity");
        this.f918i = (TelephonyManager) this.f911b.getSystemService("phone");
        this.f914e = Locale.getDefault();
        this.f916g = new C0240j();
        if (VERSION.SDK_INT >= 16) {
            this.f912c = new C0235e(this.f910a);
        } else {
            this.f912c = new C0238h(this.f910a, new C0236f());
        }
        this.f913d = new C0234d(this.f916g, this.f912c);
        this.f917h = new C0241k(context);
    }

    public final C0251k m1651a(String str) {
        return m1644b(str);
    }

    private static String m1642a() {
        return "device_info";
    }

    private void m1643a(C0251k c0251k) {
        C0243d a = m1641a("com.amazon.venezia", "com.amazon.mShop.android");
        if (a.f907a != C0230c.SERVICE_MISSING) {
            c0251k.m1675a("amazon_app_store_installation_status", a.m1639a());
        }
    }

    private void m1645b(C0251k c0251k) {
        c0251k.m1679b("google_accounts", (long) AccountManager.get(this.f911b).getAccountsByType("com.google").length);
    }

    private void m1648c(C0251k c0251k) {
        C0243d c = m1647c();
        c0251k.m1680b("google_play_services_installation", c.f907a.name());
        c0251k.m1679b("google_play_services_version", (long) c.f909c);
    }

    private void m1649d(C0251k c0251k) {
        C0208a c0208a = new C0208a();
        String[] strArr = new String[]{"com.android.vending", "com.google.market", "com.google.android.finsky"};
        for (int i = 0; i < 3; i++) {
            C0243d a = m1641a(strArr[i]);
            if (a.f907a != C0230c.SERVICE_MISSING) {
                c0208a.m1512a(a.m1639a());
            }
        }
        c0251k.m1674a("google_play_store", c0208a);
    }

    private void m1650e(C0251k c0251k) {
        c0251k.m1675a("gsf_installation_status", m1641a("com.google.android.gsf").m1639a());
    }

    private C0251k m1644b(String str) {
        String format3339;
        String format33392;
        C0251k c0251k = new C0251k(C0244e.m1642a(), "device");
        c0251k.m1662a(str);
        c0251k.m1680b("carrier", this.f918i.getNetworkOperatorName());
        c0251k.m1680b("carrier_country_iso", this.f918i.getNetworkCountryIso());
        c0251k.m1680b("network_type", C0242l.m1632a(this.f918i.getNetworkType()));
        c0251k.m1680b("phone_type", C0242l.m1633a(this.f918i));
        c0251k.m1680b("sim_country_iso", this.f918i.getSimCountryIso());
        if (this.f918i.getSimState() == 5) {
            c0251k.m1680b("sim_operator", this.f918i.getSimOperatorName());
        }
        c0251k.m1680b("locale", this.f914e.toString());
        DisplayMetrics displayMetrics = this.f911b.getResources().getDisplayMetrics();
        Point a = m1640a(displayMetrics);
        c0251k.m1680b("device_type", Build.MODEL);
        c0251k.m1680b("brand", Build.BRAND);
        c0251k.m1680b("manufacturer", Build.MANUFACTURER);
        c0251k.m1680b("os_type", "Android");
        c0251k.m1680b("os_ver", VERSION.RELEASE);
        c0251k.m1680b("cpu_abi", Build.CPU_ABI);
        if (VERSION.SDK_INT >= 8) {
            c0251k.m1680b("cpu_abi2", Build.CPU_ABI2);
        }
        c0251k.m1679b("unreliable_core_count", (long) this.f916g.m1627d());
        c0251k.m1679b("reliable_core_count", (long) this.f916g.m1628e());
        c0251k.m1679b("cpu_max_freq", (long) this.f916g.m1625b().intValue());
        if (this.f916g.m1626c().intValue() != -1) {
            c0251k.m1679b("low_power_cpu_max_freq", (long) this.f916g.m1626c().intValue());
        }
        c0251k.m1679b("year_class", (long) this.f913d.m1613a());
        c0251k.m1681b("cgroups_supported", C0244e.m1646b());
        if (VERSION.SDK_INT >= 9) {
            try {
                PackageInfo packageInfo = this.f915f.getPackageInfo(this.f911b.getPackageName(), 0);
                Time time = new Time();
                time.set(packageInfo.firstInstallTime);
                format3339 = time.format3339(false);
                Time time2 = new Time();
                time2.set(packageInfo.lastUpdateTime);
                format33392 = time2.format3339(false);
            } catch (NameNotFoundException e) {
                format3339 = "unknown";
                format33392 = "unknown";
            }
            c0251k.m1680b("first_install_time", format3339);
            c0251k.m1680b("last_upgrade_time", format33392);
        }
        try {
            if ((this.f915f.getApplicationInfo(this.f911b.getPackageName(), 0).flags & 262144) == 0) {
                format33392 = "internal_storage";
            } else if (VERSION.SDK_INT < 9) {
                format33392 = "sdcard";
            } else if (Environment.isExternalStorageRemovable()) {
                format33392 = "sdcard";
            } else {
                format33392 = "external_storage";
            }
        } catch (NameNotFoundException e2) {
            format33392 = "unknown";
        }
        c0251k.m1680b("install_location", format33392);
        c0251k.m1678b("density", (double) displayMetrics.density);
        c0251k.m1679b("screen_width", (long) a.x);
        c0251k.m1679b("screen_height", (long) a.y);
        c0251k.m1681b("front_camera", this.f915f.hasSystemFeature("android.hardware.camera.front"));
        c0251k.m1681b("rear_camera", this.f915f.hasSystemFeature("android.hardware.camera"));
        c0251k.m1680b("allows_non_market_installs", Secure.getString(this.f911b.getContentResolver(), "install_non_market_apps"));
        c0251k.m1680b("android_id", Secure.getString(this.f911b.getContentResolver(), "android_id"));
        ConfigurationInfo deviceConfigurationInfo = this.f910a.getDeviceConfigurationInfo();
        if (deviceConfigurationInfo != null) {
            c0251k.m1679b("opengl_version", (long) deviceConfigurationInfo.reqGlEsVersion);
        }
        m1648c(c0251k);
        m1645b(c0251k);
        format33392 = this.f915f.getInstallerPackageName(this.f911b.getPackageName());
        format3339 = "installer";
        if (format33392 == null) {
            format33392 = "";
        }
        c0251k.m1680b(format3339, format33392);
        m1643a(c0251k);
        c0251k.m1677a(this.f917h.m1630a());
        m1649d(c0251k);
        m1650e(c0251k);
        format33392 = C0300n.m2160r(this.f911b);
        if (format33392 != null) {
            c0251k.m1680b("advertiser_id", format33392);
        }
        c0251k.m1681b("allow_ads_tracking", !C0300n.m2161s(this.f911b));
        return c0251k;
    }

    private C0243d m1641a(String... strArr) {
        int i = 0;
        int length = strArr.length;
        while (i < length) {
            String str = strArr[i];
            try {
                PackageInfo packageInfo = this.f915f.getPackageInfo(str, 64);
                try {
                    if (this.f915f.getApplicationInfo(str, 0).enabled) {
                        return new C0243d(str, C0230c.SERVICE_ENABLED, packageInfo.versionCode);
                    }
                    return new C0243d(str, C0230c.SERVICE_DISABLED, packageInfo.versionCode);
                } catch (NameNotFoundException e) {
                }
            } catch (NameNotFoundException e2) {
                i++;
            }
        }
        return new C0243d("", C0230c.SERVICE_MISSING, -1);
    }

    private static boolean m1646b() {
        try {
            return new File("/dev/cpuctl/tasks").exists();
        } catch (Exception e) {
            return false;
        }
    }

    @TargetApi(14)
    private Point m1640a(DisplayMetrics displayMetrics) {
        Point point = new Point();
        if (VERSION.SDK_INT >= 14) {
            ((WindowManager) this.f911b.getSystemService("window")).getDefaultDisplay().getSize(point);
        } else {
            point.x = displayMetrics.widthPixels;
            point.y = displayMetrics.heightPixels;
        }
        return point;
    }

    private C0243d m1647c() {
        try {
            this.f915f.getPackageInfo("com.android.vending", 64);
            return m1641a("com.google.android.gms");
        } catch (NameNotFoundException e) {
            return new C0243d("com.android.vending", C0230c.SERVICE_MISSING, -1);
        }
    }
}
