package com.facebook.lite.p049a.p052c;

import android.content.Context;
import android.util.Log;
import com.facebook.lite.p049a.p050a.C0261a;
import com.facebook.lite.p053b.C0295i;
import com.facebook.lite.p053b.C0300n;
import com.facebook.p038e.C0251k;
import com.p008a.p009a.p010a.p014e.C0022b;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: com.facebook.lite.a.c.g */
public class C0273g {
    private static final String f1046a;

    static {
        f1046a = C0273g.class.getSimpleName();
    }

    private C0273g() {
    }

    private static Set m1862a(String str) {
        JSONArray jSONArray = new JSONArray(str);
        Set hashSet = new HashSet(jSONArray.length());
        for (int i = 0; i < jSONArray.length(); i++) {
            hashSet.add(C0273g.m1859a(jSONArray.getJSONObject(i)));
        }
        return hashSet;
    }

    public static String m1861a(Map map, String str) {
        if (str == null || str.trim().length() == 0) {
            return C0273g.m1860a(map);
        }
        return C0273g.m1864b(map, str);
    }

    public static void m1863a(Context context, C0022b c0022b) {
        String q = C0300n.m2159q(context);
        try {
            if (!C0295i.m1988a(C0300n.m2130f(context), System.currentTimeMillis()) && c0022b != null) {
                for (C0272f c0272f : C0273g.m1862a(q)) {
                    int b = c0272f.m1856b();
                    int d = c0272f.m1858d();
                    int c = c0272f.m1857c();
                    int a = c0272f.m1855a();
                    new StringBuilder("genericcache/").append(b).append("/requestCount:").append(d).append(", hitCount:").append(c).append(", dataSavedInBytes:").append(a);
                    if (d > 0) {
                        C0251k c0251k = new C0251k("ema_cache_stats");
                        c0251k.m1679b("cache_request_count_" + b, (long) d);
                        c0251k.m1679b("cache_hit_count_" + b, (long) c);
                        c0251k.m1679b("cache_data_saved_" + b, (long) a);
                        C0251k.m1672a(c0251k, context);
                    }
                }
                C0300n.m2088P(context);
                C0300n.m2115c(context, System.currentTimeMillis());
            }
        } catch (JSONException e) {
            Log.e(f1046a, "diskcache/error unpacking get generic cache stat json " + q);
        }
    }

    private static String m1860a(Map map) {
        JSONArray jSONArray = new JSONArray();
        for (Entry entry : map.entrySet()) {
            JSONObject jSONObject = new JSONObject();
            C0261a c0261a = (C0261a) entry.getValue();
            jSONObject.put("cacheId", c0261a.m1804b());
            jSONObject.put("requestCount", c0261a.m1809g());
            jSONObject.put("hitCount", c0261a.m1807e());
            jSONObject.put("bytesSaved", c0261a.m1805c());
            jSONArray.put(jSONObject);
        }
        return jSONArray.toString();
    }

    private static C0272f m1859a(JSONObject jSONObject) {
        return new C0272f(jSONObject.getInt("cacheId"), jSONObject.getInt("requestCount"), jSONObject.getInt("hitCount"), jSONObject.getInt("bytesSaved"));
    }

    private static String m1864b(Map map, String str) {
        Set<C0272f> a = C0273g.m1862a(str);
        Map hashMap = new HashMap(a.size());
        for (C0272f c0272f : a) {
            hashMap.put(Integer.valueOf(c0272f.m1856b()), c0272f);
        }
        JSONArray jSONArray = new JSONArray();
        for (Entry entry : map.entrySet()) {
            JSONObject jSONObject = new JSONObject();
            C0261a c0261a = (C0261a) entry.getValue();
            C0272f c0272f2 = (C0272f) hashMap.get(Integer.valueOf(c0261a.m1804b()));
            int d = c0272f2 == null ? 0 : c0272f2.m1858d();
            int c = c0272f2 == null ? 0 : c0272f2.m1857c();
            int a2 = c0272f2 == null ? 0 : c0272f2.m1855a();
            jSONObject.put("cacheId", c0261a.m1804b());
            jSONObject.put("requestCount", d + c0261a.m1809g());
            jSONObject.put("hitCount", c + c0261a.m1807e());
            jSONObject.put("bytesSaved", c0261a.m1805c() + a2);
            jSONArray.put(jSONObject);
        }
        return jSONArray.toString();
    }
}
