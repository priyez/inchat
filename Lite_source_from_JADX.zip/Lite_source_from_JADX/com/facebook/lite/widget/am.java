package com.facebook.lite.widget;

final class am implements Runnable {
    private boolean f2062a;
    private long f2063b;
    private boolean f2064c;
    private float f2065d;
    private float f2066e;
    private final PhotoView f2067f;

    public am(PhotoView photoView) {
        this.f2063b = -1;
        this.f2067f = photoView;
    }

    public final void run() {
        if (!this.f2064c) {
            float f;
            long currentTimeMillis = System.currentTimeMillis();
            float f2 = this.f2063b != -1 ? (float) (currentTimeMillis - this.f2063b) : 0.0f;
            if (this.f2063b == -1) {
                this.f2063b = currentTimeMillis;
            }
            if (f2 >= 100.0f) {
                f2 = this.f2065d;
            } else {
                f = (this.f2065d / (100.0f - f2)) * 10.0f;
                float f3 = (this.f2066e / (100.0f - f2)) * 10.0f;
                if (Math.abs(f) > Math.abs(this.f2065d) || f == Float.NaN) {
                    f2 = this.f2065d;
                } else {
                    f2 = f;
                }
                if (Math.abs(f3) <= Math.abs(this.f2066e) && f3 != Float.NaN) {
                    f = f2;
                    f2 = f3;
                    this.f2067f.m3232a(f, f2);
                    this.f2065d -= f;
                    this.f2066e -= f2;
                    if (this.f2065d == 0.0f && this.f2066e == 0.0f) {
                        m3278a();
                    }
                    if (!this.f2064c) {
                        this.f2067f.post(this);
                    }
                }
            }
            f = f2;
            f2 = this.f2066e;
            this.f2067f.m3232a(f, f2);
            this.f2065d -= f;
            this.f2066e -= f2;
            m3278a();
            if (!this.f2064c) {
                this.f2067f.post(this);
            }
        }
    }

    public final boolean m3279a(float f, float f2) {
        if (this.f2062a) {
            return false;
        }
        this.f2063b = -1;
        this.f2065d = f;
        this.f2066e = f2;
        this.f2064c = false;
        this.f2062a = true;
        this.f2067f.postDelayed(this, 250);
        return true;
    }

    public final void m3278a() {
        this.f2062a = false;
        this.f2064c = true;
    }
}
