package com.facebook.p038e;

import java.util.HashMap;

/* renamed from: com.facebook.e.f */
final class C0245f extends HashMap {
    final /* synthetic */ long f919a;
    final /* synthetic */ C0248h f920b;

    C0245f(C0248h c0248h, long j) {
        this.f920b = c0248h;
        this.f919a = j;
        put("ema_cancel_launched_camera", new C0246g(false, this.f919a));
        put("ema_cancel_launched_photo_picker", new C0246g(false, this.f919a));
        put("ema_handle_camera_result", new C0246g(false, this.f919a));
        put("ema_handle_external_request", new C0246g(false, this.f919a));
        put("ema_handle_photo_picker_result", new C0246g(false, this.f919a));
        put("ema_init_client_session", new C0246g(false, this.f919a));
        put("ema_launch_camera", new C0246g(false, this.f919a));
        put("ema_launch_photo_picker", new C0246g(false, this.f919a));
        put("ema_no_connectivity_dialog", new C0246g(false, this.f919a));
        put("ema_open_url", new C0246g(false, this.f919a));
        put("ema_phone_call", new C0246g(false, this.f919a));
        put("ema_register_push", new C0246g(false, this.f919a));
        put("ema_retry_connectivity_dialog", new C0246g(false, this.f919a));
        put("ema_show_webview", new C0246g(false, this.f919a));
        put("ema_switch_user", new C0246g(false, this.f919a));
        put("ema_upload_contacts", new C0246g(false, this.f919a));
        put("ema_connection_quality_changed", new C0246g(true, this.f919a));
        put("ema_push_notification_received", new C0246g(true, this.f919a));
        put("ema_update_badge", new C0246g(true, this.f919a));
        put("ema_photo_perf", new C0246g(false, this.f919a));
        put("ema_launch_multi_photo_picker", new C0246g(false, this.f919a));
        put("ema_handle_multi_photo_picker_result", new C0246g(false, this.f919a));
        put("ema_cancel_launched_multi_photo_picker", new C0246g(false, this.f919a));
        put("ema_sticker_selection", new C0246g(false, this.f919a));
    }
}
