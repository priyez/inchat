package com.facebook.p038e.p045d;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/* renamed from: com.facebook.e.d.f */
public final class C0236f {
    byte[] f893a;
    private long f894b;
    private long f895c;
    private long f896d;

    public C0236f() {
        this.f893a = new byte[1024];
    }

    public final long m1617a() {
        return this.f896d;
    }

    public final void m1618b() {
        FileInputStream fileInputStream;
        int i = 0;
        try {
            this.f896d = 0;
            this.f895c = 0;
            this.f894b = 0;
            fileInputStream = new FileInputStream("/proc/meminfo");
            int read = fileInputStream.read(this.f893a);
            fileInputStream.close();
            int length = this.f893a.length;
            int i2 = 0;
            while (i < read && i2 < 3) {
                if (C0236f.m1616a(this.f893a, i, "MemTotal")) {
                    i += 8;
                    this.f896d = C0236f.m1615a(this.f893a, i);
                    i2++;
                } else if (C0236f.m1616a(this.f893a, i, "MemFree")) {
                    i += 7;
                    this.f895c = C0236f.m1615a(this.f893a, i);
                    i2++;
                } else if (C0236f.m1616a(this.f893a, i, "Cached")) {
                    i += 6;
                    this.f894b = C0236f.m1615a(this.f893a, i);
                    i2++;
                }
                while (i < length && this.f893a[i] != 10) {
                    i++;
                }
                i++;
            }
        } catch (FileNotFoundException e) {
        } catch (IOException e2) {
        } catch (Throwable th) {
            fileInputStream.close();
        }
    }

    private static long m1615a(byte[] bArr, int i) {
        while (i < bArr.length && bArr[i] != 10) {
            if (bArr[i] < (byte) 48 || bArr[i] > (byte) 57) {
                i++;
            } else {
                int i2 = i + 1;
                while (i2 < bArr.length && bArr[i2] >= (byte) 48 && bArr[i2] <= (byte) 57) {
                    i2++;
                }
                return ((long) Integer.parseInt(new String(bArr, 0, i, i2 - i))) * 1024;
            }
        }
        return 0;
    }

    private static boolean m1616a(byte[] bArr, int i, String str) {
        int length = str.length();
        if (i + length >= bArr.length) {
            return false;
        }
        for (int i2 = 0; i2 < length; i2++) {
            if (bArr[i + i2] != str.charAt(i2)) {
                return false;
            }
        }
        return true;
    }
}
