package com.facebook.p038e;

import com.facebook.p038e.p039a.C0209b;
import com.facebook.p038e.p039a.C0210c;

/* renamed from: com.facebook.e.d */
final class C0243d {
    private final C0230c f907a;
    private final String f908b;
    private final int f909c;

    C0243d(String str, C0230c c0230c, int i) {
        this.f908b = str;
        this.f909c = i;
        this.f907a = c0230c;
    }

    public final C0209b m1639a() {
        C0209b c0209b = new C0209b();
        c0209b.m1513a(new C0210c("installation_status"), new C0210c(this.f907a.toString()));
        c0209b.m1513a(new C0210c("package_name"), new C0210c(this.f908b));
        c0209b.m1513a(new C0210c("version"), new C0210c((long) this.f909c));
        return c0209b;
    }
}
