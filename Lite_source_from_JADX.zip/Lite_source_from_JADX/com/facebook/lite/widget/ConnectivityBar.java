package com.facebook.lite.widget;

import android.content.Context;
import android.util.AttributeSet;
import com.facebook.lite.ClientApplication;
import com.p008a.p009a.p010a.p022l.C0070p;
import com.p008a.p009a.p010a.p022l.C0087q;
import com.p008a.p009a.p010a.p022l.C0093w;

public class ConnectivityBar extends BannerView {
    private static int f1889b;
    private final Object f1890c;
    private boolean f1891d;
    private int f1892e;
    private boolean f1893f;
    private boolean f1894g;

    public ConnectivityBar(Context context) {
        super(context);
        this.f1890c = new Object();
    }

    public ConnectivityBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1890c = new Object();
    }

    public static int getType() {
        return f1889b;
    }

    public static void setType(int i) {
        f1889b = i;
    }

    private void m3159a() {
        ClientApplication.m1692d().runOnUiThread(new C0473d(this));
    }

    public void setBarEnabled(boolean z) {
        this.f1891d = z;
        if (!this.f1891d) {
            m3159a();
        }
    }

    public final void m3165a(C0093w c0093w, int[] iArr, int[][] iArr2) {
        if (this.a == null && c0093w != null) {
            super.m3158a(c0093w, iArr, iArr2);
            this.f1892e = getTextContainer$2687244b().m526g();
        }
    }

    private void m3160a(int i, int i2) {
        ClientApplication.m1692d().runOnUiThread(new C0474e(this, i, i2));
    }

    public final void m3164a(C0093w c0093w) {
        if (this.a != null) {
            int i = 0;
            Object obj = null;
            while (i < c0093w.m736f().m1064c()) {
                Object obj2;
                C0070p c0070p = (C0070p) c0093w.m736f().m1056a(i);
                if (i != 0 || c0070p.m540o() == 0) {
                    obj2 = obj;
                } else {
                    obj2 = 1;
                }
                if (!(obj2 == null || this.f1894g || c0070p.m529h() == (short) 30002)) {
                    c0070p.m532i(c0070p.m540o() - this.f1892e);
                    if (i == 1) {
                        c0070p.m497a((short) (c0070p.m526g() + this.f1892e));
                        if (c0070p instanceof C0087q) {
                            ((C0087q) c0070p).m741l(-this.f1892e);
                        }
                    }
                }
                if (obj2 == null && this.f1894g && c0070p.m529h() != (short) 30002) {
                    c0070p.m532i(c0070p.m540o() + this.f1892e);
                    if (i == 1) {
                        c0070p.m497a((short) (c0070p.m526g() - this.f1892e));
                        if (c0070p instanceof C0087q) {
                            ((C0087q) c0070p).m741l(this.f1892e);
                        }
                    }
                }
                i++;
                obj = obj2;
            }
            if (this.f1894g) {
                m3160a(this.a.m538m(), this.f1892e);
            } else {
                m3159a();
            }
        }
    }

    public final void m3163a(int i, C0093w c0093w) {
        boolean z = false;
        if (c0093w != null && this.f1891d) {
            switch (i) {
                case 1:
                    z = m3161a(false, false);
                    break;
                case 2:
                    z = m3161a(true, true);
                    break;
                case 3:
                    z = m3161a(true, false);
                    break;
            }
            if (z) {
                f1889b = i;
                m3162b();
                m3164a(c0093w);
            }
        }
    }

    private C0087q getTextContainer$2687244b() {
        return (C0087q) ((C0087q) this.a.m736f().m1056a(0)).m736f().m1056a(0);
    }

    private boolean m3161a(boolean z, boolean z2) {
        synchronized (this.f1890c) {
            if (this.f1894g == z && this.f1893f == z2) {
                return false;
            }
            this.f1894g = z;
            this.f1893f = z2;
            return true;
        }
    }

    private void m3162b() {
        if (this.a != null) {
            if (this.f1893f) {
                this.a.m532i(-this.f1892e);
            } else {
                this.a.m532i(0);
            }
            postInvalidate();
        }
    }
}
