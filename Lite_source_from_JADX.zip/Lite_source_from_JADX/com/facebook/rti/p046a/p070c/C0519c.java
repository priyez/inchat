package com.facebook.rti.p046a.p070c;

import android.os.Process;

/* renamed from: com.facebook.rti.a.c.c */
public final class C0519c extends Thread {
    private final int f2193a;

    public C0519c(Runnable runnable, String str) {
        super(runnable, str);
        this.f2193a = 9;
    }

    public final void run() {
        Process.setThreadPriority(this.f2193a);
        super.run();
    }
}
