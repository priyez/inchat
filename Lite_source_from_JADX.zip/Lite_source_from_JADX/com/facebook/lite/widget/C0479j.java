package com.facebook.lite.widget;

import android.net.Uri;
import android.widget.FrameLayout.LayoutParams;

/* renamed from: com.facebook.lite.widget.j */
final class C0479j implements Runnable {
    final /* synthetic */ LayoutParams f2094a;
    final /* synthetic */ FbVideoView f2095b;

    C0479j(FbVideoView fbVideoView, LayoutParams layoutParams) {
        this.f2095b = fbVideoView;
        this.f2094a = layoutParams;
    }

    public final void run() {
        this.f2095b.setLayoutParams(this.f2094a);
        this.f2095b.f1904h.setVisibility(0);
        this.f2095b.f1899c.setVisibility(0);
        this.f2095b.f1899c.setBackgroundColor(-16777216);
        this.f2095b.setVisibility(0);
        this.f2095b.f1904h.setVideoURI(Uri.parse(this.f2095b.f1903g.m2959a()));
    }
}
