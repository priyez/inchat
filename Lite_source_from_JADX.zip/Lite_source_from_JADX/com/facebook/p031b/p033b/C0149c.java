package com.facebook.p031b.p033b;

import com.facebook.p031b.C0173d;

/* renamed from: com.facebook.b.b.c */
public interface C0149c {
    void m1332a(C0173d c0173d);
}
