package com.facebook.lite.p054i;

/* renamed from: com.facebook.lite.i.c */
final class C0348c implements Runnable {
    final /* synthetic */ C0351g f1383a;

    C0348c(C0351g c0351g) {
        this.f1383a = c0351g;
    }

    public final void run() {
        this.f1383a.m2484d();
    }
}
