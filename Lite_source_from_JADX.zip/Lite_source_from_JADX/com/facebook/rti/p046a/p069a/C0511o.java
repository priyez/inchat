package com.facebook.rti.p046a.p069a;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.SystemClock;
import com.facebook.rti.p046a.p074f.C0527a;

/* renamed from: com.facebook.rti.a.a.o */
final class C0511o implements Runnable {
    final /* synthetic */ C0512p f2158a;

    private C0511o(C0512p c0512p) {
        this.f2158a = c0512p;
    }

    public final void run() {
        C0512p c0512p = this.f2158a;
        AlarmManager alarmManager = c0512p.f2160b;
        Intent intent = new Intent(c0512p.f2159a, C0505i.class);
        intent.setPackage(c0512p.f2159a.getPackageName());
        alarmManager.cancel(PendingIntent.getBroadcast(c0512p.f2159a, 0, intent, 134217728));
        if (!this.f2158a.f2168j.m3310a()) {
            c0512p = this.f2158a;
            long elapsedRealtime = SystemClock.elapsedRealtime() + 7200000;
            Intent intent2;
            if (c0512p.f2170l >= 23) {
                alarmManager = c0512p.f2160b;
                intent2 = new Intent(c0512p.f2159a, C0505i.class);
                intent2.setPackage(c0512p.f2159a.getPackageName());
                alarmManager.setAndAllowWhileIdle(2, elapsedRealtime, PendingIntent.getBroadcast(c0512p.f2159a, 0, intent2, 134217728));
            } else {
                alarmManager = c0512p.f2160b;
                intent2 = new Intent(c0512p.f2159a, C0505i.class);
                intent2.setPackage(c0512p.f2159a.getPackageName());
                alarmManager.set(2, elapsedRealtime, PendingIntent.getBroadcast(c0512p.f2159a, 0, intent2, 134217728));
            }
            C0527a.m3338b("DefaultAnalyticsLogger", "scheduleUploadAlarm", new Object[0]);
        }
    }
}
