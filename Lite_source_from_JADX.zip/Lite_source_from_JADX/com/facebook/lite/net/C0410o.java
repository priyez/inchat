package com.facebook.lite.net;

import com.p008a.p009a.p010a.p012b.C0017i;
import java.io.DataInputStream;

/* renamed from: com.facebook.lite.net.o */
public final class C0410o extends Thread implements C0017i {
    final /* synthetic */ C0400q f1653a;
    private final DataInputStream f1654b;

    public C0410o(C0400q c0400q, DataInputStream dataInputStream) {
        this.f1653a = c0400q;
        this.f1654b = dataInputStream;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void run() {
        /*
        r12 = this;
        r4 = java.lang.Thread.currentThread();
    L_0x0004:
        r0 = r12.f1653a;	 Catch:{ Exception -> 0x0081 }
        r0 = r0.f1612r;	 Catch:{ Exception -> 0x0081 }
        if (r0 != r4) goto L_0x00e8;
    L_0x000a:
        r0 = r12.f1653a;	 Catch:{ Exception -> 0x0081 }
        r0 = r0.m2776c();	 Catch:{ Exception -> 0x0081 }
        if (r0 == 0) goto L_0x00e8;
    L_0x0012:
        r0 = 0;
        r1 = r12.f1653a;	 Catch:{ Exception -> 0x0081 }
        r1 = r1.h;	 Catch:{ Exception -> 0x0081 }
        r1 = r1.m2629D();	 Catch:{ Exception -> 0x0081 }
        if (r1 == 0) goto L_0x0027;
    L_0x001d:
        r0 = new com.a.a.a.a.b;	 Catch:{ Exception -> 0x0081 }
        r2 = new com.a.a.a.a.f;	 Catch:{ Exception -> 0x0081 }
        r2.<init>(r1);	 Catch:{ Exception -> 0x0081 }
        r0.<init>(r2);	 Catch:{ Exception -> 0x0081 }
    L_0x0027:
        r5 = new com.a.a.a.a.e;	 Catch:{ Exception -> 0x0081 }
        r1 = r12.f1654b;	 Catch:{ Exception -> 0x0081 }
        r5.<init>(r1, r0);	 Catch:{ Exception -> 0x0081 }
        r1 = r5.m61b();	 Catch:{ Exception -> 0x0081 }
        r0 = r12.f1653a;	 Catch:{ Exception -> 0x0081 }
        r0 = r0.f1606F;	 Catch:{ Exception -> 0x0081 }
        if (r0 == 0) goto L_0x005d;
    L_0x003a:
        r0 = r12.f1653a;	 Catch:{ Exception -> 0x0081 }
        r2 = r0.f1616w;	 Catch:{ Exception -> 0x0081 }
        monitor-enter(r2);	 Catch:{ Exception -> 0x0081 }
        r0 = r12.f1653a;	 Catch:{ all -> 0x00ee }
        r0 = r0.f1606F;	 Catch:{ all -> 0x00ee }
        if (r0 == 0) goto L_0x005c;
    L_0x0049:
        r0 = r12.f1653a;	 Catch:{ all -> 0x00ee }
        r0 = r0.q;	 Catch:{ all -> 0x00ee }
        r3 = r12.f1653a;	 Catch:{ all -> 0x00ee }
        r3 = r3.f1609I;	 Catch:{ all -> 0x00ee }
        r0.m111a(r3);	 Catch:{ all -> 0x00ee }
        r0 = r12.f1653a;	 Catch:{ all -> 0x00ee }
        r3 = 0;
        r0.f1606F = r3;	 Catch:{ all -> 0x00ee }
    L_0x005c:
        monitor-exit(r2);	 Catch:{ all -> 0x00ee }
    L_0x005d:
        r0 = 32768; // 0x8000 float:4.5918E-41 double:1.61895E-319;
        r0 = r0 & r1;
        if (r0 == 0) goto L_0x00f1;
    L_0x0063:
        r1 = r1 & 32767;
        r0 = 1;
        r2 = r0;
        r3 = r1;
    L_0x0068:
        r0 = 15000; // 0x3a98 float:2.102E-41 double:7.411E-320;
        if (r3 <= r0) goto L_0x00f6;
    L_0x006c:
        r0 = new java.io.IOException;	 Catch:{ Exception -> 0x0081 }
        r1 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0081 }
        r2 = "MTL:";
        r1.<init>(r2);	 Catch:{ Exception -> 0x0081 }
        r1 = r1.append(r3);	 Catch:{ Exception -> 0x0081 }
        r1 = r1.toString();	 Catch:{ Exception -> 0x0081 }
        r0.<init>(r1);	 Catch:{ Exception -> 0x0081 }
        throw r0;	 Catch:{ Exception -> 0x0081 }
    L_0x0081:
        r0 = move-exception;
        r1 = r0;
        r0 = new java.lang.StringBuilder;
        r2 = "conn/recv/run/";
        r0.<init>(r2);
        r2 = r1.toString();
        r0.append(r2);
        r0 = r12.f1653a;
        r0 = r0.f1612r;
        if (r0 != r4) goto L_0x00e8;
    L_0x0097:
        r0 = r12.f1653a;
        r0 = r0.m2776c();
        if (r0 == 0) goto L_0x00e8;
    L_0x009f:
        r0 = r12.f1653a;
        r0.m2802b(r4);
        r0 = r12.f1653a;
        r0 = r0.h;
        r0 = r0.m2629D();
        if (r0 == 0) goto L_0x00b9;
    L_0x00ae:
        r0 = r12.f1653a;
        r0 = r0.h;
        r0 = r0.m2629D();
        r0.m58d();
    L_0x00b9:
        r0 = r1 instanceof java.io.InterruptedIOException;
        if (r0 == 0) goto L_0x01e7;
    L_0x00bd:
        r0 = "INTERRUPTED";
    L_0x00bf:
        r2 = r12.f1653a;
        r2 = r2.g;
        r3 = 5;
        r4 = 43;
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r5 = r5.append(r1);
        r6 = ": ";
        r5 = r5.append(r6);
        r1 = r1.getMessage();
        r1 = r5.append(r1);
        r0 = r1.append(r0);
        r0 = r0.toString();
        r2.m126a(r3, r4, r0);
    L_0x00e8:
        r0 = r12.f1654b;	 Catch:{ IOException -> 0x01eb }
        r0.close();	 Catch:{ IOException -> 0x01eb }
    L_0x00ed:
        return;
    L_0x00ee:
        r0 = move-exception;
        monitor-exit(r2);	 Catch:{ all -> 0x00ee }
        throw r0;	 Catch:{ Exception -> 0x0081 }
    L_0x00f1:
        r0 = 0;
        r2 = r0;
        r3 = r1;
        goto L_0x0068;
    L_0x00f6:
        r0 = r12.f1653a;	 Catch:{ Exception -> 0x0081 }
        r0 = r0.m;	 Catch:{ Exception -> 0x0081 }
        r6 = r0.m599b(r3);	 Catch:{ Exception -> 0x0081 }
        if (r6 != 0) goto L_0x0108;
    L_0x0100:
        r0 = new java.io.IOException;	 Catch:{ Exception -> 0x0081 }
        r1 = "E204";
        r0.<init>(r1);	 Catch:{ Exception -> 0x0081 }
        throw r0;	 Catch:{ Exception -> 0x0081 }
    L_0x0108:
        r8 = java.lang.System.currentTimeMillis();	 Catch:{ Exception -> 0x0081 }
        r0 = r12.f1653a;	 Catch:{ Exception -> 0x0081 }
        r0 = r0.f1611K;	 Catch:{ Exception -> 0x0081 }
        if (r0 == 0) goto L_0x01ce;
    L_0x0114:
        r5.m60a(r6);	 Catch:{ Exception -> 0x0081 }
    L_0x0117:
        r0 = r12.f1653a;	 Catch:{ Exception -> 0x0081 }
        r0 = r0.f1607G;	 Catch:{ Exception -> 0x0081 }
        r1 = 2;
        if (r0 >= r1) goto L_0x016f;
    L_0x0120:
        r0 = (long) r3;	 Catch:{ Exception -> 0x0081 }
        r10 = 700; // 0x2bc float:9.81E-43 double:3.46E-321;
        r0 = (r0 > r10 ? 1 : (r0 == r10 ? 0 : -1));
        if (r0 >= 0) goto L_0x016f;
    L_0x0127:
        r0 = r12.f1653a;	 Catch:{ Exception -> 0x0081 }
        r0.f1607G = r0.f1607G + 1;	 Catch:{ Exception -> 0x0081 }
        r0 = java.lang.System.currentTimeMillis();	 Catch:{ Exception -> 0x0081 }
        r0 = r0 - r8;
        r8 = 2000; // 0x7d0 float:2.803E-42 double:9.88E-321;
        r5 = (r0 > r8 ? 1 : (r0 == r8 ? 0 : -1));
        if (r5 <= 0) goto L_0x016f;
    L_0x0137:
        r5 = r12.f1653a;	 Catch:{ Exception -> 0x0081 }
        r5 = r5.g;	 Catch:{ Exception -> 0x0081 }
        r7 = 2;
        r8 = 143; // 0x8f float:2.0E-43 double:7.07E-322;
        r9 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0081 }
        r10 = "l: ";
        r9.<init>(r10);	 Catch:{ Exception -> 0x0081 }
        r3 = r9.append(r3);	 Catch:{ Exception -> 0x0081 }
        r9 = ", t: ";
        r3 = r3.append(r9);	 Catch:{ Exception -> 0x0081 }
        r0 = r3.append(r0);	 Catch:{ Exception -> 0x0081 }
        r1 = ", rf:";
        r0 = r0.append(r1);	 Catch:{ Exception -> 0x0081 }
        r1 = r12.f1653a;	 Catch:{ Exception -> 0x0081 }
        r1 = r1.f1611K;	 Catch:{ Exception -> 0x0081 }
        r0 = r0.append(r1);	 Catch:{ Exception -> 0x0081 }
        r0 = r0.toString();	 Catch:{ Exception -> 0x0081 }
        r5.m126a(r7, r8, r0);	 Catch:{ Exception -> 0x0081 }
        r0 = r12.f1653a;	 Catch:{ Exception -> 0x0081 }
        r0.f1611K = false;	 Catch:{ Exception -> 0x0081 }
    L_0x016f:
        r0 = new com.a.a.a.m.b;	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
        r0.<init>(r6);	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
        if (r2 == 0) goto L_0x01db;
    L_0x0176:
        r1 = r12.f1653a;	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
        r2 = r12.f1653a;	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
        r0 = r2.m2768a(r0);	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
        r2 = r12.f1653a;	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
        r2 = r2.m;	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
        r1.m2772a(r0, r2);	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
    L_0x0185:
        r0 = r12.f1653a;	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
        r1 = r0.f1614u;	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
        monitor-enter(r1);	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
        r0 = r12.f1653a;	 Catch:{ all -> 0x01a0 }
        r2 = java.lang.System.currentTimeMillis();	 Catch:{ all -> 0x01a0 }
        r5 = r12.f1653a;	 Catch:{ all -> 0x01a0 }
        r5 = r5.f1615v;	 Catch:{ all -> 0x01a0 }
        r8 = (long) r5;	 Catch:{ all -> 0x01a0 }
        r2 = r2 + r8;
        r0.f1617x = r2;	 Catch:{ all -> 0x01a0 }
        monitor-exit(r1);	 Catch:{ all -> 0x01a0 }
        goto L_0x0004;
    L_0x01a0:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x01a0 }
        throw r0;	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
    L_0x01a3:
        r0 = move-exception;
    L_0x01a4:
        r1 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0081 }
        r2 = "conn/recv/run/";
        r1.<init>(r2);	 Catch:{ Exception -> 0x0081 }
        r2 = r0.toString();	 Catch:{ Exception -> 0x0081 }
        r1.append(r2);	 Catch:{ Exception -> 0x0081 }
        r1 = r12.f1653a;	 Catch:{ Exception -> 0x0081 }
        r1 = r1.g;	 Catch:{ Exception -> 0x0081 }
        r2 = 42;
        r3 = 0;
        r3 = r6[r3];	 Catch:{ Exception -> 0x0081 }
        r3 = java.lang.Integer.toString(r3);	 Catch:{ Exception -> 0x0081 }
        r1.m124a(r2, r3, r0);	 Catch:{ Exception -> 0x0081 }
        r0 = r12.f1653a;	 Catch:{ Exception -> 0x0081 }
        r1 = 0;
        r0.d = r1;	 Catch:{ Exception -> 0x0081 }
        r0 = r12.f1653a;	 Catch:{ Exception -> 0x0081 }
        r0.m2802b(r12);	 Catch:{ Exception -> 0x0081 }
        goto L_0x0004;
    L_0x01ce:
        r0 = 0;
    L_0x01cf:
        if (r0 >= r3) goto L_0x0117;
    L_0x01d1:
        r1 = r0 + 1;
        r7 = r5.m59a();	 Catch:{ Exception -> 0x0081 }
        r6[r0] = r7;	 Catch:{ Exception -> 0x0081 }
        r0 = r1;
        goto L_0x01cf;
    L_0x01db:
        r1 = r12.f1653a;	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
        r2 = r12.f1653a;	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
        r2 = r2.m;	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
        r1.m2772a(r0, r2);	 Catch:{ OutOfMemoryError -> 0x01a3, Exception -> 0x01e5 }
        goto L_0x0185;
    L_0x01e5:
        r0 = move-exception;
        goto L_0x01a4;
    L_0x01e7:
        r0 = "";
        goto L_0x00bf;
    L_0x01eb:
        r0 = move-exception;
        goto L_0x00ed;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.lite.net.o.run():void");
    }

    public final void m2897d(int i) {
        this.f1653a.m2833b(4);
        this.f1653a.m2788o();
        this.f1653a.l.m132a(this.f1653a.m2827v(), this.f1653a.m2781h(), this.f1653a.e);
        this.f1653a.f1606F = false;
    }
}
