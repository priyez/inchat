package com.facebook.lite.p053b;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;
import java.util.concurrent.LinkedBlockingQueue;

/* renamed from: com.facebook.lite.b.a */
final class C0287a implements ServiceConnection {
    boolean f1164a;
    private final LinkedBlockingQueue f1165b;

    private C0287a() {
        this.f1165b = new LinkedBlockingQueue(1);
    }

    public final IBinder m1934a() {
        if (this.f1164a) {
            throw new IllegalStateException();
        }
        this.f1164a = true;
        return (IBinder) this.f1165b.take();
    }

    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        try {
            this.f1165b.put(iBinder);
        } catch (Throwable e) {
            Log.e(C0290d.f1169a, "googleadinfo/Could not connect to service.", e);
        }
    }

    public final void onServiceDisconnected(ComponentName componentName) {
    }
}
