package com.facebook.p038e.p045d;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Environment;
import android.os.StatFs;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

/* renamed from: com.facebook.e.d.k */
public final class C0241k {
    private final Context f906a;

    public C0241k(Context context) {
        this.f906a = context;
    }

    @TargetApi(8)
    public final Map m1630a() {
        StatFs statFs;
        long availableBlocks;
        long blockSize;
        long a;
        File externalCacheDir;
        long j = 0;
        Map hashMap = new HashMap();
        try {
            statFs = new StatFs(Environment.getDataDirectory().getPath());
            availableBlocks = ((long) statFs.getAvailableBlocks()) * ((long) statFs.getBlockSize());
            try {
                blockSize = ((long) statFs.getBlockSize()) * ((long) statFs.getBlockCount());
            } catch (Exception e) {
                blockSize = availableBlocks;
                availableBlocks = blockSize;
                blockSize = j;
                hashMap.put("device_free_space", Long.valueOf(availableBlocks));
                hashMap.put("device_total_space", Long.valueOf(blockSize));
                statFs = new StatFs(Environment.getExternalStorageDirectory().getPath());
                availableBlocks = ((long) statFs.getAvailableBlocks()) * ((long) statFs.getBlockSize());
                blockSize = ((long) statFs.getBlockCount()) * ((long) statFs.getBlockSize());
                hashMap.put("sd_free_space", Long.valueOf(availableBlocks));
                hashMap.put("sd_total_space", Long.valueOf(blockSize));
                a = C0241k.m1629a(this.f906a.getCacheDir().getCanonicalFile());
                try {
                    externalCacheDir = this.f906a.getExternalCacheDir();
                    if (externalCacheDir != null) {
                        availableBlocks = j;
                    } else {
                        availableBlocks = C0241k.m1629a(externalCacheDir.getCanonicalFile());
                    }
                    try {
                        blockSize = C0241k.m1629a(this.f906a.getFilesDir().getParentFile().getCanonicalFile());
                        try {
                            j = C0241k.m1629a(this.f906a.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS).getParentFile().getCanonicalFile());
                        } catch (Exception e2) {
                        }
                    } catch (Exception e3) {
                        blockSize = j;
                    }
                } catch (Exception e4) {
                    blockSize = j;
                    availableBlocks = j;
                }
                hashMap.put("cache_size", Long.valueOf(a));
                hashMap.put("external_cache_size", Long.valueOf(availableBlocks));
                hashMap.put("app_data_size", Long.valueOf(blockSize - a));
                hashMap.put("external_app_data_size", Long.valueOf(j - availableBlocks));
                return hashMap;
            }
        } catch (Exception e5) {
            blockSize = j;
            availableBlocks = blockSize;
            blockSize = j;
            hashMap.put("device_free_space", Long.valueOf(availableBlocks));
            hashMap.put("device_total_space", Long.valueOf(blockSize));
            statFs = new StatFs(Environment.getExternalStorageDirectory().getPath());
            availableBlocks = ((long) statFs.getAvailableBlocks()) * ((long) statFs.getBlockSize());
            blockSize = ((long) statFs.getBlockCount()) * ((long) statFs.getBlockSize());
            hashMap.put("sd_free_space", Long.valueOf(availableBlocks));
            hashMap.put("sd_total_space", Long.valueOf(blockSize));
            a = C0241k.m1629a(this.f906a.getCacheDir().getCanonicalFile());
            externalCacheDir = this.f906a.getExternalCacheDir();
            if (externalCacheDir != null) {
                availableBlocks = C0241k.m1629a(externalCacheDir.getCanonicalFile());
            } else {
                availableBlocks = j;
            }
            blockSize = C0241k.m1629a(this.f906a.getFilesDir().getParentFile().getCanonicalFile());
            j = C0241k.m1629a(this.f906a.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS).getParentFile().getCanonicalFile());
            hashMap.put("cache_size", Long.valueOf(a));
            hashMap.put("external_cache_size", Long.valueOf(availableBlocks));
            hashMap.put("app_data_size", Long.valueOf(blockSize - a));
            hashMap.put("external_app_data_size", Long.valueOf(j - availableBlocks));
            return hashMap;
        }
        hashMap.put("device_free_space", Long.valueOf(availableBlocks));
        hashMap.put("device_total_space", Long.valueOf(blockSize));
        try {
            statFs = new StatFs(Environment.getExternalStorageDirectory().getPath());
            availableBlocks = ((long) statFs.getAvailableBlocks()) * ((long) statFs.getBlockSize());
            try {
                blockSize = ((long) statFs.getBlockCount()) * ((long) statFs.getBlockSize());
            } catch (Exception e6) {
                blockSize = availableBlocks;
                availableBlocks = blockSize;
                blockSize = j;
                hashMap.put("sd_free_space", Long.valueOf(availableBlocks));
                hashMap.put("sd_total_space", Long.valueOf(blockSize));
                a = C0241k.m1629a(this.f906a.getCacheDir().getCanonicalFile());
                externalCacheDir = this.f906a.getExternalCacheDir();
                if (externalCacheDir != null) {
                    availableBlocks = C0241k.m1629a(externalCacheDir.getCanonicalFile());
                } else {
                    availableBlocks = j;
                }
                blockSize = C0241k.m1629a(this.f906a.getFilesDir().getParentFile().getCanonicalFile());
                j = C0241k.m1629a(this.f906a.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS).getParentFile().getCanonicalFile());
                hashMap.put("cache_size", Long.valueOf(a));
                hashMap.put("external_cache_size", Long.valueOf(availableBlocks));
                hashMap.put("app_data_size", Long.valueOf(blockSize - a));
                hashMap.put("external_app_data_size", Long.valueOf(j - availableBlocks));
                return hashMap;
            }
        } catch (Exception e7) {
            blockSize = j;
            availableBlocks = blockSize;
            blockSize = j;
            hashMap.put("sd_free_space", Long.valueOf(availableBlocks));
            hashMap.put("sd_total_space", Long.valueOf(blockSize));
            a = C0241k.m1629a(this.f906a.getCacheDir().getCanonicalFile());
            externalCacheDir = this.f906a.getExternalCacheDir();
            if (externalCacheDir != null) {
                availableBlocks = j;
            } else {
                availableBlocks = C0241k.m1629a(externalCacheDir.getCanonicalFile());
            }
            blockSize = C0241k.m1629a(this.f906a.getFilesDir().getParentFile().getCanonicalFile());
            j = C0241k.m1629a(this.f906a.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS).getParentFile().getCanonicalFile());
            hashMap.put("cache_size", Long.valueOf(a));
            hashMap.put("external_cache_size", Long.valueOf(availableBlocks));
            hashMap.put("app_data_size", Long.valueOf(blockSize - a));
            hashMap.put("external_app_data_size", Long.valueOf(j - availableBlocks));
            return hashMap;
        }
        hashMap.put("sd_free_space", Long.valueOf(availableBlocks));
        hashMap.put("sd_total_space", Long.valueOf(blockSize));
        try {
            a = C0241k.m1629a(this.f906a.getCacheDir().getCanonicalFile());
            externalCacheDir = this.f906a.getExternalCacheDir();
            if (externalCacheDir != null) {
                availableBlocks = C0241k.m1629a(externalCacheDir.getCanonicalFile());
            } else {
                availableBlocks = j;
            }
            blockSize = C0241k.m1629a(this.f906a.getFilesDir().getParentFile().getCanonicalFile());
            j = C0241k.m1629a(this.f906a.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS).getParentFile().getCanonicalFile());
        } catch (Exception e8) {
            blockSize = j;
            availableBlocks = j;
            a = j;
        }
        hashMap.put("cache_size", Long.valueOf(a));
        hashMap.put("external_cache_size", Long.valueOf(availableBlocks));
        hashMap.put("app_data_size", Long.valueOf(blockSize - a));
        hashMap.put("external_app_data_size", Long.valueOf(j - availableBlocks));
        return hashMap;
    }

    private static long m1629a(File file) {
        Stack stack = new Stack();
        stack.push(file);
        long j = 0;
        while (!stack.isEmpty()) {
            long j2 = j;
            for (File file2 : ((File) stack.pop()).listFiles()) {
                try {
                    if (file2.getPath().equals(file2.getCanonicalPath())) {
                        if (file2.isDirectory()) {
                            stack.push(file2);
                        } else if (file2.isFile()) {
                            j2 += file2.length();
                        }
                    }
                } catch (IOException e) {
                }
            }
            j = j2;
        }
        return j;
    }
}
