package com.facebook.lite.net.p066a;

import android.content.Context;
import com.facebook.lite.p053b.C0294h;
import com.facebook.lite.p053b.C0300n;
import com.p008a.p009a.p010a.p019i.C0062f;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.facebook.lite.net.a.a */
public class C0393a {
    private final C0062f f1558a;
    private final Map f1559b;
    private final Context f1560c;
    private final String f1561d;

    public C0393a(Context context, C0062f c0062f) {
        this.f1561d = C0393a.class.getSimpleName();
        this.f1560c = context;
        this.f1558a = c0062f;
        this.f1559b = new HashMap(C0300n.m2163u(context));
    }

    public final C0394b m2725a() {
        String b = m2724b();
        C0394b c0394b = (C0394b) this.f1559b.get(b);
        new StringBuilder("conn/ipcache/get key=").append(b).append(", val=").append(c0394b == null ? "EMPTY (FREE)" : c0394b.name());
        return c0394b == null ? C0394b.FREE : c0394b;
    }

    public final void m2726a(C0394b c0394b) {
        String b = m2724b();
        this.f1559b.put(b, c0394b);
        C0300n.m2099a(this.f1560c, this.f1559b);
        new StringBuilder("conn/ipcache/update key=").append(b).append(", val=").append(c0394b);
    }

    private String m2724b() {
        return C0294h.m1973f(this.f1560c) + ";" + C0294h.m1979i(this.f1560c) + ";" + C0294h.m1976g() + ";" + this.f1558a.m401p() + ";" + C0300n.m2143i(this.f1560c);
    }
}
