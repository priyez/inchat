package com.facebook.lite.p062j;

import com.facebook.lite.p058f.C0333a;
import com.facebook.lite.p058f.C0336d;
import com.facebook.lite.p058f.C0338f;

/* renamed from: com.facebook.lite.j.f */
public final class C0359f implements C0358i {
    final /* synthetic */ C0366n f1413a;

    public C0359f(C0366n c0366n) {
        this.f1413a = c0366n;
    }

    public final String m2517a(StringBuilder stringBuilder) {
        if (C0336d.f1316a) {
            stringBuilder.append("DataUsage: ");
            C0333a c0333a = (C0333a) this.f1413a.f1424a.m2636K().m2333a().get(C0338f.TOTAL);
            if (c0333a == null) {
                return stringBuilder.toString();
            }
            stringBuilder.append(c0333a.toString());
        } else {
            stringBuilder.append("DataUsage: DISABLED");
        }
        return stringBuilder.toString();
    }
}
