package com.facebook.p038e.p039a;

/* renamed from: com.facebook.e.a.b */
public final class C0209b implements C0207d {
    public final StringBuilder f794a;

    public C0209b() {
        this.f794a = new StringBuilder("{");
    }

    public final void m1513a(C0210c c0210c, C0207d c0207d) {
        if (C0211e.m1516a((Object) c0207d)) {
            if (this.f794a.length() != 1) {
                this.f794a.append(",");
            }
            this.f794a.append(c0210c).append(":").append(c0207d.toString());
            return;
        }
        throw new IllegalStateException("illegal input type " + c0207d);
    }

    public final boolean m1514a() {
        return this.f794a.length() == 1;
    }

    public final String toString() {
        return this.f794a.toString() + "}";
    }
}
