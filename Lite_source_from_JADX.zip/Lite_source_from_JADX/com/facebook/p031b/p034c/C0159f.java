package com.facebook.p031b.p034c;

import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Map;
import java.util.Map.Entry;

/* renamed from: com.facebook.b.c.f */
final class C0159f implements C0156c {
    final /* synthetic */ Map f631a;

    C0159f(Map map) {
        this.f631a = map;
    }

    public final void m1344a(OutputStream outputStream) {
        Writer bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream));
        C0171r c0171r = new C0171r(bufferedWriter);
        Object obj = 1;
        for (Entry entry : this.f631a.entrySet()) {
            Object key = entry.getKey();
            if (obj == null) {
                bufferedWriter.append('&');
            }
            Object value = entry.getValue();
            if (value == null) {
                value = "";
            }
            c0171r.write(key.toString());
            bufferedWriter.write(61);
            c0171r.write(value.toString());
            obj = null;
        }
        bufferedWriter.flush();
    }
}
