package com.facebook.p038e.p044c;

import com.facebook.p038e.C0251k;
import java.util.Arrays;
import java.util.Random;

/* renamed from: com.facebook.e.c.c */
public final class C0228c {
    private static final Random f858a;
    private long f859b;
    private long f860c;
    private int[] f861d;
    private int f862e;
    private final String f863f;
    private int f864g;

    static {
        f858a = new Random();
    }

    public C0228c() {
        this.f863f = C0228c.m1564a();
        this.f864g = -1;
        this.f862e = 0;
        this.f861d = null;
    }

    public final C0251k m1570a(long j, int i) {
        switch (C0226a.f852a[i - 1]) {
            case 1:
                long j2 = j / 1000;
                if (j2 > this.f860c) {
                    return m1566b(j2);
                }
                return null;
            case 2:
            case 3:
            case 4:
                if (this.f861d != null) {
                    return m1567b(j / 1000, i);
                }
                return null;
            default:
                return null;
        }
    }

    private static String m1564a() {
        return Integer.toString(Math.abs(f858a.nextInt()), 36);
    }

    private void m1565a(long j) {
        this.f860c = j;
        this.f859b = j;
        this.f861d = new int[2];
        this.f861d[0] = 1;
        for (int i = 1; i < 2; i++) {
            this.f861d[1] = 0;
        }
        this.f864g++;
        this.f862e++;
    }

    private void m1568b() {
        this.f861d = null;
        this.f860c = 0;
    }

    private C0251k m1567b(long j, int i) {
        C0251k c = m1569c(j, i);
        m1568b();
        return c;
    }

    private C0251k m1569c(long j, int i) {
        if (this.f861d == null) {
            return null;
        }
        int min;
        if (j > this.f860c) {
            min = (int) Math.min(64, (j - this.f859b) + 1);
        } else {
            min = (int) ((this.f860c - this.f859b) + 1);
        }
        C0251k c0251k = new C0251k("time_spent_bit_array");
        c0251k.m1680b("tos_id", this.f863f);
        c0251k.m1679b("start_time", this.f859b);
        c0251k.m1680b("tos_array", Arrays.toString(this.f861d));
        c0251k.m1679b("tos_len", (long) min);
        c0251k.m1679b("tos_seq", (long) this.f864g);
        c0251k.m1679b("tos_cum", (long) this.f862e);
        if (i == C0227b.f854b) {
            c0251k.m1680b("trigger", "clock_change");
        }
        return c0251k;
    }

    private C0251k m1566b(long j) {
        long j2 = j - this.f859b;
        C0251k c0251k = null;
        if (j2 < 0 || j2 >= 64) {
            c0251k = m1567b(j, C0227b.f856d);
        }
        if (this.f861d == null) {
            m1565a(j);
        } else {
            int[] iArr = this.f861d;
            int i = ((int) j2) >> 5;
            iArr[i] = (1 << (((int) j2) & 31)) | iArr[i];
            this.f860c = j;
            this.f862e++;
        }
        return c0251k;
    }
}
