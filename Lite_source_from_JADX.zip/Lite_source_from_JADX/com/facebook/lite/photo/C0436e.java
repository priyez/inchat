package com.facebook.lite.photo;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

/* renamed from: com.facebook.lite.photo.e */
final class C0436e implements OnTouchListener {
    final /* synthetic */ GalleryItem f1760a;
    final /* synthetic */ int f1761b;
    final /* synthetic */ C0437f f1762c;

    C0436e(C0437f c0437f, GalleryItem galleryItem, int i) {
        this.f1762c = c0437f;
        this.f1760a = galleryItem;
        this.f1761b = i;
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        boolean z = true;
        if (!this.f1762c.f1763a.f1732g) {
            switch (motionEvent.getAction()) {
                case 0:
                    this.f1762c.f1763a.f1734i.postDelayed(this.f1762c.f1763a.f1744s, 500);
                    break;
                case 1:
                    if (!this.f1762c.f1763a.f1737l.m3196a()) {
                        z = this.f1762c.f1763a.m2968a(this.f1761b, this.f1760a, view);
                        break;
                    }
                    this.f1762c.f1763a.f1740o = this.f1760a;
                    z = this.f1762c.f1763a.m2967a(this.f1761b, this.f1760a);
                    break;
                case 3:
                case 4:
                    break;
                default:
                    break;
            }
            this.f1762c.f1763a.f1734i.removeCallbacks(this.f1762c.f1763a.f1744s);
            this.f1762c.f1763a.f1737l.m3198c();
        }
        return z;
    }
}
