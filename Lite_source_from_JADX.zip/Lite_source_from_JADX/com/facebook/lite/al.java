package com.facebook.lite;

final class al implements Runnable {
    final /* synthetic */ MainActivity f1157a;

    al(MainActivity mainActivity) {
        this.f1157a = mainActivity;
    }

    public final void run() {
        this.f1157a.f993y.m3134a();
        this.f1157a.f993y.setVisibility(8);
    }
}
