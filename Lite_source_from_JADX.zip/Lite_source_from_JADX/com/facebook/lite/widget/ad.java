package com.facebook.lite.widget;

public final class ad implements Comparable {
    private short f2025a;
    private short f2026b;
    private long f2027c;

    public final /* synthetic */ int compareTo(Object obj) {
        return m3261a((ad) obj);
    }

    public ad(short s, short s2, long j) {
        this.f2026b = s;
        this.f2025a = s2;
        this.f2027c = j;
    }

    private int m3261a(ad adVar) {
        return this.f2026b - adVar.m3264b();
    }

    public final short m3262a() {
        return this.f2025a;
    }

    public final short m3264b() {
        return this.f2026b;
    }

    public final long m3266c() {
        return this.f2027c;
    }

    public final void m3263a(short s) {
        this.f2025a = s;
    }

    public final void m3265b(short s) {
        this.f2026b = s;
    }
}
