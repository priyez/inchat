package com.facebook.p031b.p034c;

import java.net.HttpURLConnection;
import java.net.URL;

/* renamed from: com.facebook.b.c.b */
public interface C0155b {
    HttpURLConnection m1340a(URL url);
}
